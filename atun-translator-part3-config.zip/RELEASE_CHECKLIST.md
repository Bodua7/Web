# Checklist trước khi phát hành bản release

Làm theo thứ tự, đừng bỏ bước nào:

1. **Bump version** (nếu có thay đổi đáng để người dùng thấy số version mới): sửa
   `"version": "..."` trong `package.json`. Không bump thì bản release mới vẫn build được bình
   thường, chỉ là `versionName` hiển thị (trong Cài đặt > Ứng dụng trên điện thoại) sẽ giống bản
   trước — `versionCode` nội bộ (dùng để Android/Google Play biết bản nào mới hơn) vẫn luôn tự
   tăng theo số lần chạy CI dù bạn không bump, xem `scripts/patch-version.py`.
2. **Kiểm tra tất cả secret cần thiết đã set đủ** (Settings → Secrets and variables → Actions):
   `ANDROID_KEYSTORE_BASE64`, `RELEASE_KEYSTORE_PASSWORD`, `RELEASE_KEY_ALIAS`,
   `RELEASE_KEY_PASSWORD` — thiếu 1 trong 4 thì job `build-release` tự dừng ngay, không build lỡ
   dở bằng debug keystore.
3. **Đảm bảo đang ở đúng nhánh** `main` hoặc `release/*` — job `build-release` tự chặn nhánh
   khác (xem bước "Kiểm tra nhánh được phép build release" trong `android-build.yml`).
4. **Push code lên nhánh đó trước**, đợi job `validation` + `build-debug` (chạy tự động trên
   push) chạy xanh hết đã — không nên bấm `build_release` khi còn chưa chắc code build được bản
   debug bình thường.
5. **Chạy workflow_dispatch, tick `build_release`** (tab Actions → chọn workflow "Android
   build" → "Run workflow" → tick ô `build_release`).
6. Nếu đã tạo Environment `release` với Required reviewers (xem README, mục "Bật phê duyệt thủ
   công cho release") — vào đúng chỗ GitHub thông báo để bấm **Approve**, job mới chạy tiếp.
7. **Đợi job xong**, kiểm tra:
   - Bước "Xác thực chữ ký APK release (apksigner)" — phải in ra `Verified` (không có dòng nào
     báo lỗi/`DOES NOT VERIFY`).
   - Bước "In permissions thật trong APK" — liệt kê đúng những quyền bạn mong đợi app xin (đối
     chiếu bằng mắt, không có gì lạ ngoài dự tính).
8. **Tải APK** ở 1 trong 2 chỗ (cùng 1 file, chọn cái nào tiện hơn):
   - Tab Actions → lần chạy vừa xong → mục Artifacts.
   - Tab **Releases** của repo (tự tạo, đính kèm sẵn APK + ghi chú các PR đã merge kể từ bản
     trước — xem bước "Tạo GitHub Release" trong workflow).
9. **Cài thử APK đó trên máy thật** trước khi coi là "xong" — CI xanh chỉ có nghĩa là build/ký
   thành công, không đảm bảo app chạy đúng ý trên máy thật (không có bước test UI tự động nào
   trong pipeline hiện tại — xem README, mục "Việc còn phải tự làm").
