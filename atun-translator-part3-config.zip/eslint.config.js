// eslint.config.js
//
// Cấu hình tối thiểu (ESLint 9, "flat config") cho bước "Lint JS (ESLint, chỉ báo cáo)" trong
// .github/workflows/android-build.yml - bước đó gọi đúng lệnh:
//   npx --yes eslint@9 www/app.js www/app.module.js --no-config-lookup --config eslint.config.js
//
// Fix (audit Lint/CI): file này TRƯỚC ĐÂY không tồn tại trong repo (không nằm trong bất kỳ
// atun-translator-part*.zip nào) dù android-build.yml đã tham chiếu tới nó từ trước - mọi lần
// chạy CI đều fail ngay ở bước LOAD config ("could not find config file eslint.config.js"), chỉ
// không chặn build vì continue-on-error: true. Hậu quả thật: eslint-report.txt sinh ra mỗi lần
// chỉ chứa đúng 1 lỗi "thiếu config", KHÔNG phải kết quả lint thật của www/app.js/app.module.js -
// tức ESLint chưa từng thực sự chạy qua 1 dòng code nào của dự án.
//
// Không dùng package "globals" từ npm (vd `import globals from "globals"`) vì bước CI KHÔNG
// chạy "npm install" trước khi lint (xem comment ngay phía trên bước "Lint JS" trong
// android-build.yml - cố tình bỏ qua npm install vì không bước nào khác trong job "validation"
// cần node_modules) - "npx --yes eslint@9 ..." chỉ tự tải chính gói eslint, KHÔNG tự tải thêm
// dependency mà config này lỡ import, import 1 gói ngoài sẽ chỉ đổi lỗi "thiếu config" cũ thành
// lỗi "thiếu package globals" mới, không giải quyết được gì. Tự khai tay danh sách global cần
// thiết - đã grep trực tiếp toàn bộ www/app.js + www/app.module.js để xác nhận ĐÚNG tập global
// THẬT SỰ được 2 file dùng tới (window/document/fetch/localStorage/Capacitor/supabase/...),
// không đoán chừng hay copy nguyên set "browser" đầy đủ của thư viện globals.
//
// www/app.js: nạp qua <script src="app.js"> (script "thường", KHÔNG có type="module") - scope
// top-level là global thật của trang, xem chú thích đầu file đó.
// www/app.module.js: nạp qua <script type="module" src="app.module.js"> - ES module thật
// (sourceType khác app.js, top-level KHÔNG rơi vào global scope).
// 2 file KHÔNG chung scope (xác nhận lại trong app.js: "app.module.js và file này KHÔNG chung
// scope, mọi cầu nối 2 chiều vẫn đi qua window.__xxx") - vì vậy dùng chung 1 danh sách global
// trình duyệt cho cả 2 block bên dưới là đủ, không cần khai chéo biến/hàm nội bộ của file kia.

const sharedBrowserGlobals = {
  window: "readonly",
  document: "readonly",
  console: "readonly",
  fetch: "readonly",
  localStorage: "readonly",
  setTimeout: "readonly",
  clearTimeout: "readonly",
  Promise: "readonly",
  Blob: "readonly",
  FormData: "readonly",
  URL: "readonly",
  Audio: "readonly",
  AbortController: "readonly",
  alert: "readonly",
  atob: "readonly",
  // Web Screen Orientation API - dùng trong ScreenOrientationPlugin fallback (xem app.js, khối
  // "BUG đã sửa: trước đây chỉ gọi screen.orientation.lock(...)").
  screen: "readonly",
  // Toàn cục do 2 thư viện nạp qua <script> "thường" (KHÔNG qua import) tự gắn vào window - xem
  // index.html: Capacitor core runtime (window.Capacitor) và Supabase JS SDK bản UMD
  // (window.supabase, nạp từ cdn.jsdelivr.net TRƯỚC app.js - xem chú thích trong index.html).
  Capacitor: "readonly",
  supabase: "readonly",
  // YouTube IFrame Player API (window.YT) - tải qua <script src="https://www.youtube.com/
  // iframe_api"> trong index.html, dùng trong app.js (new YT.Player(...)) để chỉnh âm lượng
  // video gốc - xem README mục "Âm lượng video gốc".
  YT: "readonly",
  // Web Speech API - dùng làm fallback TTS khi chạy NGOÀI app native (không có plugin
  // TtsBoost) - xem README mục "Tăng âm lượng dịch vượt 100%".
  SpeechSynthesisUtterance: "readonly",
};

// Chỉ bật rule "an toàn" - bắt lỗi THẬT (biến/hàm không tồn tại do gõ nhầm tên, khai báo trùng
// tên) thay vì đè thêm hàng loạt rule phong cách (style) có thể tạo ra hàng trăm cảnh báo vô
// nghĩa ngay lần chạy đầu trên 1 file 90KB+ chưa từng qua linter nào - đúng tinh thần
// "continue-on-error: true, báo cáo trước, chưa chặn build" đã ghi trong android-build.yml.
// Muốn siết thêm rule sau này thì thêm dần vào đây, đối chiếu report thực tế trước khi bật
// continue-on-error: false.
const baseRules = {
  "no-undef": "error",
  "no-unused-vars": "warn",
  "no-redeclare": "error",
};

module.exports = [
  {
    files: ["www/app.js"],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: "script",
      globals: sharedBrowserGlobals,
    },
    rules: baseRules,
  },
  {
    files: ["www/app.module.js"],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: "module",
      globals: sharedBrowserGlobals,
    },
    rules: baseRules,
  },
];
