#!/usr/bin/env python3
"""scripts/patch-robolectric.py

Thêm Robolectric (giả lập khung Android trên JVM, để unit test JVM thuần gọi được các class
đụng android.app.Service/SharedPreferences... mà KHÔNG cần emulator/thiết bị thật) vào
android/app/build.gradle - LUÔN chạy (không gated bởi secret nào, khác patch-firebase.py), vì
đây là dependency test-only, không ảnh hưởng gì tới APK thật (chỉ nằm trong testImplementation).
"""
import re
import sys

ROBOLECTRIC_VERSION = "4.13"
ANDROIDX_TEST_CORE_VERSION = "1.6.1"

APP_GRADLE = "android/app/build.gradle"


def fail(msg: str) -> None:
    print(f"::error::{msg}", file=sys.stderr)
    sys.exit(1)


def main() -> None:
    with open(APP_GRADLE, encoding="utf-8") as f:
        content = f.read()

    changed = False

    if "org.robolectric:robolectric" not in content:
        deps = (
            "dependencies {"
            f"\n    testImplementation \"org.robolectric:robolectric:{ROBOLECTRIC_VERSION}\""
            f"\n    testImplementation \"androidx.test:core:{ANDROIDX_TEST_CORE_VERSION}\""
        )
        new_content, n = re.subn(r"dependencies\s*\{", deps, content, count=1)
        if n == 0:
            fail(f"Không tìm thấy 'dependencies {{' trong {APP_GRADLE}.")
        content = new_content
        changed = True
        print(f"OK: đã thêm testImplementation robolectric/androidx.test:core vào {APP_GRADLE}")
    else:
        print(f"SKIP: {APP_GRADLE} đã có Robolectric từ trước")

    # Robolectric CẦN includeAndroidResources = true (đọc AndroidManifest.xml lúc test) - thiếu
    # dòng này Robolectric fail ngay ở bước khởi tạo test runner, không liên quan gì tới nội dung
    # test case.
    if "includeAndroidResources" not in content:
        if "android {" not in content:
            fail(f"Không tìm thấy 'android {{' trong {APP_GRADLE}.")
        test_options_block = (
            "android {"
            "\n    testOptions {"
            "\n        unitTests {"
            "\n            includeAndroidResources = true"
            "\n        }"
            "\n    }"
        )
        content = content.replace("android {", test_options_block, 1)
        changed = True
        print(f"OK: đã thêm testOptions.unitTests.includeAndroidResources vào {APP_GRADLE}")
    else:
        print(f"SKIP: {APP_GRADLE} đã có testOptions.unitTests từ trước")

    if changed:
        with open(APP_GRADLE, "w", encoding="utf-8") as f:
            f.write(content)

    print("=== Xong patch Robolectric ===")


if __name__ == "__main__":
    main()
