import re

# Patch android/app/build.gradle: thêm signingConfigs.release (đọc từ biến môi trường do CI
# set từ GitHub Secrets, xem .github/workflows/*.yml) + bật minifyEnabled/shrinkResources cho
# buildType release. Không đụng gì đến buildType debug (assembleDebug vẫn build như cũ, không
# ký, không minify - dùng để test nhanh).

app_path = "android/app/build.gradle"
with open(app_path, "r", encoding="utf-8") as f:
    content = f.read()

changed = False

# 1) signingConfigs.release - đọc keystore path/password/alias từ env, do bước
# "Decode keystore" trong workflow ghi file + export biến trước khi gọi gradlew assembleRelease.
# Fix (audit bảo mật - theo yêu cầu chọn "fail cứng"): trước đây nếu thiếu env thì tự fallback
# sang tái dùng debug keystore (storeFile signingConfigs.debug.storeFile...) để build vẫn "chạy
# được" - đúng như cách CI cũ từng làm, nhưng tạo ra bản .apk gắn mác "release" (đã minify) mà
# lại ký bằng debug key, dễ bị tải nhầm/gửi nhầm cho người khác dùng lâu dài dù không giữ được
# đường cập nhật ổn định. Giờ KHÔNG còn fallback: thiếu bất kỳ biến nào, storeFile trỏ tới
# đường dẫn không tồn tại -> Gradle tự fail rõ ràng ngay lúc ký, dừng hẳn assembleRelease, không
# âm thầm tạo ra APK "release" ký tạm nữa. (Lớp fail-closed CHÍNH nằm ở bước "Decode release
# keystore" trong .yml - check sớm hơn, thông báo rõ hơn; lớp này chỉ là phòng hờ nếu ai chạy
# thẳng script này ngoài luồng CI mà không qua bước check đó.)
signing_block = '''
    signingConfigs {
        release {
            def ksPath = System.getenv("RELEASE_KEYSTORE_PATH")
            storeFile ksPath != null ? file(ksPath) : file("release-keystore-not-configured.jks")
            storePassword System.getenv("RELEASE_KEYSTORE_PASSWORD")
            keyAlias System.getenv("RELEASE_KEY_ALIAS")
            keyPassword System.getenv("RELEASE_KEY_PASSWORD")
        }
    }
'''
if "signingConfigs" not in content:
    android_block_start = content.index("android {") + len("android {")
    content = content[:android_block_start] + signing_block + content[android_block_start:]
    changed = True
    print("OK: da them signingConfigs.release vao android/app/build.gradle")
else:
    print("SKIP: signingConfigs da co san")

# 2) buildTypes.release - bật minify + shrinkResources + gắn signingConfig.
# Template Capacitor mặc định sinh: "release {\n            minifyEnabled false\n            proguardFiles ..."
release_pattern = re.compile(r"(release\s*\{\s*\n\s*)minifyEnabled\s+false")
if release_pattern.search(content) and "shrinkResources" not in content:
    content = release_pattern.sub(
        r"\1minifyEnabled true\n            shrinkResources true\n            signingConfig signingConfigs.release",
        content,
        count=1,
    )
    changed = True
    print("OK: da bat minifyEnabled/shrinkResources + gan signingConfig cho buildType release")
elif "shrinkResources" in content:
    print("SKIP: buildType release da duoc patch tu truoc")
else:
    raise SystemExit(
        "FAIL: khong tim thay pattern 'release { minifyEnabled false' trong "
        "android/app/build.gradle - template Capacitor co the da doi, can cap nhat script nay."
    )

if changed:
    with open(app_path, "w", encoding="utf-8") as f:
        f.write(content)

# 3) Proguard rules cho Capacitor (bridge dùng reflection để gọi các @PluginMethod) - thiếu các
# rule này thì code hoạt động OK ở debug (không minify) nhưng crash hoặc im lặng không phản hồi
# ở bản release đã minify (ClassNotFoundException / NoSuchMethodException do R8 đổi tên hoặc
# loại bỏ nhầm class được gọi qua reflection).
PROGUARD_MARKER = "# ===== Atun Translator: Capacitor keep rules ====="
proguard_rules = f"""
{PROGUARD_MARKER}
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# Capacitor bridge gọi @PluginMethod qua reflection theo tên class/method - phải giữ
# nguyên, không được đổi tên (rename) hay loại bỏ (shrink) dù không thấy call site tĩnh nào.
-keep class com.getcapacitor.** {{ *; }}
-keep @com.getcapacitor.annotation.CapacitorPlugin class * {{ *; }}
-keepclassmembers class * {{
    @com.getcapacitor.annotation.PluginMethod public *;
}}
-keepclassmembers class * {{
    @android.webkit.JavascriptInterface <methods>;
}}

# Toàn bộ code của app (native/*.kt) - nhỏ, không cần shrink nội bộ, và có chỗ đăng ký qua
# reflection (registerPlugin) nên giữ an toàn nguyên khối.
-keep class com.atun.translator.** {{ *; }}
"""

pg_path = "android/app/proguard-rules.pro"
try:
    with open(pg_path, "r", encoding="utf-8") as f:
        pg_content = f.read()
except FileNotFoundError:
    pg_content = ""

if PROGUARD_MARKER not in pg_content:
    with open(pg_path, "a", encoding="utf-8") as f:
        f.write(proguard_rules)
    print("OK: da them Capacitor keep rules vao android/app/proguard-rules.pro")
else:
    print("SKIP: proguard-rules.pro da co keep rules tu truoc")

print("=== Xong patch release build ===")
