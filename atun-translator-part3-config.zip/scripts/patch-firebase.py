#!/usr/bin/env python3
"""scripts/patch-firebase.py

Bật Firebase Crashlytics + Performance Monitoring + Analytics — CHỈ được gọi khi workflow đã
xác nhận có secret GOOGLE_SERVICES_JSON_BASE64 và đã decode ra android/app/google-services.json
(xem bước "Decode Firebase google-services.json" trong android-build.yml) — khác với
patch-release-build.py (luôn fail cứng nếu thiếu secret), script NÀY hoàn toàn TUỲ CHỌN: workflow
chỉ gọi nó khi secret đã có, không có thì bước gọi bị bỏ qua từ trước, script này không tự chạy
để "fail cứng" làm gì (Firebase là tính năng bổ sung, không phải yêu cầu bắt buộc để build APK).

Patch 2 file:
  android/build.gradle       - thêm classpath 3 Gradle plugin (google-services, crashlytics,
                                perf) vào buildscript { dependencies { ... } }
  android/app/build.gradle   - apply 3 plugin đó + thêm dependency firebase-bom/crashlytics-ktx/
                                perf-ktx/analytics-ktx vào dependencies { ... }
"""
import re
import sys

GOOGLE_SERVICES_VERSION = "4.4.2"
CRASHLYTICS_GRADLE_VERSION = "3.0.2"
PERF_PLUGIN_VERSION = "1.4.2"
FIREBASE_BOM_VERSION = "33.5.1"

ROOT_GRADLE = "android/build.gradle"
APP_GRADLE = "android/app/build.gradle"


def fail(msg: str) -> None:
    print(f"::error::{msg}", file=sys.stderr)
    sys.exit(1)


def patch_root() -> None:
    with open(ROOT_GRADLE, encoding="utf-8") as f:
        content = f.read()

    if "com.google.gms:google-services" in content:
        print(f"SKIP: {ROOT_GRADLE} đã có classpath Firebase từ trước")
        return

    match = re.search(r"buildscript\s*\{.*?dependencies\s*\{", content, re.DOTALL)
    if not match:
        fail(f"Không tìm thấy buildscript{{ dependencies{{ }} trong {ROOT_GRADLE}.")

    classpaths = (
        f"\n        classpath 'com.google.gms:google-services:{GOOGLE_SERVICES_VERSION}'"
        f"\n        classpath 'com.google.firebase:firebase-crashlytics-gradle:{CRASHLYTICS_GRADLE_VERSION}'"
        f"\n        classpath 'com.google.firebase:perf-plugin:{PERF_PLUGIN_VERSION}'"
    )
    insert_pos = match.end()
    content = content[:insert_pos] + classpaths + content[insert_pos:]
    with open(ROOT_GRADLE, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"OK: đã thêm classpath Firebase (google-services/crashlytics/perf) vào {ROOT_GRADLE}")


def patch_app() -> None:
    with open(APP_GRADLE, encoding="utf-8") as f:
        content = f.read()

    changed = False

    if "com.google.gms.google-services" not in content:
        if "apply plugin: 'com.android.application'" not in content:
            fail(f"Không tìm thấy \"apply plugin: 'com.android.application'\" trong {APP_GRADLE}.")
        content = content.replace(
            "apply plugin: 'com.android.application'",
            "apply plugin: 'com.android.application'"
            "\napply plugin: 'com.google.gms.google-services'"
            "\napply plugin: 'com.google.firebase.crashlytics'"
            "\napply plugin: 'com.google.firebase.firebase-perf'",
            1,
        )
        changed = True
        print(f"OK: đã apply 3 plugin Firebase vào {APP_GRADLE}")

    if "firebase-bom" not in content:
        firebase_deps = (
            "dependencies {"
            f"\n    implementation platform('com.google.firebase:firebase-bom:{FIREBASE_BOM_VERSION}')"
            "\n    implementation 'com.google.firebase:firebase-crashlytics-ktx'"
            "\n    implementation 'com.google.firebase:firebase-perf-ktx'"
            "\n    implementation 'com.google.firebase:firebase-analytics-ktx'"
        )
        new_content, n = re.subn(r"dependencies\s*\{", firebase_deps, content, count=1)
        if n == 0:
            fail(f"Không tìm thấy 'dependencies {{' trong {APP_GRADLE}.")
        content = new_content
        changed = True
        print(f"OK: đã thêm dependency firebase-bom/crashlytics-ktx/perf-ktx/analytics-ktx vào {APP_GRADLE}")

    if changed:
        with open(APP_GRADLE, "w", encoding="utf-8") as f:
            f.write(content)
    else:
        print(f"SKIP: {APP_GRADLE} đã có sẵn Firebase từ trước")


def main() -> None:
    import os

    if not os.path.isfile("android/app/google-services.json"):
        fail(
            "Không thấy android/app/google-services.json — script này chỉ nên được gọi SAU bước "
            "decode secret GOOGLE_SERVICES_JSON_BASE64 thành công. Kiểm tra lại điều kiện "
            "'if:' của bước gọi script này trong android-build.yml."
        )
    patch_root()
    patch_app()
    print("=== Xong patch Firebase Crashlytics/Performance/Analytics ===")


if __name__ == "__main__":
    main()
