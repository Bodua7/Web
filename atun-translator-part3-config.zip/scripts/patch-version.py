#!/usr/bin/env python3
"""scripts/patch-version.py

Ghi versionCode/versionName THẬT vào android/app/build.gradle, thay cho giá trị mặc định cố
định Capacitor sinh ra ("versionCode 1" / "versionName '1.0'", không bao giờ đổi giữa các lần
build nếu không patch).

Đọc 2 biến môi trường (workflow android-build.yml set trước khi gọi script này):
  APP_VERSION_NAME  - chuỗi hiển thị cho người dùng, vd "1.0.0" (từ package.json)
  APP_VERSION_CODE  - số nguyên tăng dần, vd số run của GitHub Actions (luôn > lần build trước)

Không tìm thấy dòng versionCode/versionName trong defaultConfig -> FAIL rõ ràng (exit 1) thay vì
im lặng bỏ qua, vì im lặng bỏ qua nghĩa là APK build ra vẫn mang version cũ mà không ai biết -
cùng triết lý với các script patch-*.py khác trong thư mục này (patch-kotlin.py,
patch-manifest.py, patch-release-build.py): thà build đỏ (rõ ràng) còn hơn build xanh nhưng sai.
"""
import os
import re
import sys

BUILD_GRADLE = "android/app/build.gradle"


def fail(msg: str) -> None:
    print(f"::error::{msg}", file=sys.stderr)
    sys.exit(1)


def main() -> None:
    version_name = os.environ.get("APP_VERSION_NAME", "").strip()
    version_code = os.environ.get("APP_VERSION_CODE", "").strip()

    if not version_name:
        fail("Thiếu biến môi trường APP_VERSION_NAME (hoặc rỗng).")
    if not version_code or not version_code.isdigit():
        fail(f"APP_VERSION_CODE phải là số nguyên, đang nhận: '{version_code}'.")

    if not os.path.isfile(BUILD_GRADLE):
        fail(f"Không thấy {BUILD_GRADLE} - chạy `npx cap add android` trước bước này chưa?")

    with open(BUILD_GRADLE, encoding="utf-8") as f:
        content = f.read()

    new_content, n_code = re.subn(
        r"versionCode\s+\d+", f"versionCode {version_code}", content, count=1
    )
    if n_code == 0:
        fail(
            f"Không tìm thấy dòng 'versionCode <số>' trong {BUILD_GRADLE} - Capacitor có thể đã "
            "đổi cấu trúc template mặc định, cần cập nhật lại regex trong script này."
        )

    new_content, n_name = re.subn(
        r'versionName\s+"[^"]*"', f'versionName "{version_name}"', new_content, count=1
    )
    if n_name == 0:
        fail(
            f"Không tìm thấy dòng 'versionName \"...\"' trong {BUILD_GRADLE} - Capacitor có thể "
            "đã đổi cấu trúc template mặc định, cần cập nhật lại regex trong script này."
        )

    with open(BUILD_GRADLE, "w", encoding="utf-8") as f:
        f.write(new_content)

    print(f"Đã patch {BUILD_GRADLE}: versionCode={version_code}, versionName=\"{version_name}\"")


if __name__ == "__main__":
    main()
