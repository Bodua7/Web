package com.atun.sieutoc

import android.app.Activity
import android.content.Context
import android.net.Uri
import android.view.View
import android.view.WindowManager
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.ContentBlocking
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.GeckoView
import org.mozilla.geckoview.WebExtension

// ============================================================================================
// BƯỚC 1-2 CỦA LỘ TRÌNH MIGRATE SANG GECKOVIEW
// ============================================================================================
// File này CHƯA thay thế BrowserActivity/WebView hiện tại - chạy hoàn toàn song song, không
// đụng vào code cũ. Mục đích: build thử để (a) xác nhận dependency GeckoView tải và link được,
// (b) đo APK tăng bao nhiêu MB, (c) có sẵn khung GeckoSession đúng kiến trúc "1 session/tab"
// giống hệt "1 WebView/tab" hiện tại, để bước sau ghép dần vào BrowserActivity.
//
// BƯỚC 3/7: incognito qua usePrivateMode(true) - xem createSession() + closeSession() bên dưới.
// Khác hẳn cơ chế cũ của IncognitoActivity (tách android:process riêng + tự tay
// removeAllCookies()/deleteAllData() lúc đóng): với GeckoSession private mode, dữ liệu (cookie/
// localStorage/cache) của phiên KHÔNG BAO GIỜ được ghi xuống đĩa ngay từ đầu (khác WebView incognito
// hiện tại - vốn vẫn ghi bình thường rồi mới xoá tay lúc đóng), toàn bộ chỉ tồn tại trong RAM và tự
// mất khi không còn session riêng tư nào tham chiếu tới nữa. Nhờ vậy KHÔNG cần tách process/Activity
// riêng (android:process=":incognito") lẫn không cần tự gọi CookieManager/WebStorage để dọn dẹp -
// gọi closeSession() là đủ để giải phóng ngay, không cần đợi tiến trình bị hệ thống dọn.
//
// LƯU Ý QUAN TRỌNG: điều này CHƯA thay được IncognitoActivity thật - đây vẫn là code chạy song song,
// chưa nối vào BrowserActivity. Việc thật sự bỏ IncognitoActivity/android:process=":incognito" và
// chuyển hẳn sang GeckoSession phải đợi xong bước 5-6 (fullscreen, JS bridge) để không bị mất
// tính năng khi chuyển - xem README "Đang làm" để biết đang ở bước nào.
//
// BƯỚC 4/7: chặn quảng cáo/tracker theo blocklist.txt qua NavigationDelegate.onLoadRequest -
// xem khối comment ngay phía trên isBlockedUrl() ở cuối file để biết chi tiết khác biệt so với
// shouldInterceptRequest cũ.
//
// BƯỚC 5/7: fullscreen video thật (ẩn thanh tab/địa chỉ + thanh điều hướng hệ thống) - xem
// enterImmersiveMode()/exitImmersiveMode()/applyFullScreenChrome() bên dưới.
//
// BƯỚC 6/7 (bước khó nhất): JS bridge thay addJavascriptInterface, viết bằng WebExtension thật
// (app/src/main/assets/mediabridge/) - xem khối comment ngay trước installMediaBridge() bên dưới
// để biết vì sao GeckoView không có API tương đương trực tiếp và cách hoạt động của cơ chế mới.
//
// CHƯA làm (để bước sau, xem README "Nâng cấp gợi ý sau này"):
//   - Chưa nối vào danh sách tab/thanh tab của BrowserActivity
//   - Chặn subresource (ảnh/script tracker nhúng sâu trong trang, khác với chặn navigation ở
//     bước 4) CÓ THỂ làm bằng cách thêm quyền "webRequest"/"webRequestBlocking" + listener
//     browser.webRequest.onBeforeRequest vào CHÍNH webextension vừa tạo ở bước 6 - để dành làm
//     sau vì đây là 1 hạng mục độc lập, không bắt buộc để hoàn thành lộ trình 7 bước
//   - Chưa xử lý dịch trang / xoá dữ liệu duyệt web tab thường
// ============================================================================================

object GeckoEngine {

    @Volatile
    private var runtime: GeckoRuntime? = null

    // GeckoRuntime là singleton BẮT BUỘC - toàn app chỉ được tạo 1 lần (khác WebView, vốn
    // không cần runtime riêng). Gọi getRuntime() lười ở lần cần đầu tiên là đủ, không cần khởi
    // tạo trong Application.onCreate().
    fun getRuntime(context: Context): GeckoRuntime {
        val existing = runtime
        if (existing != null) return existing
        synchronized(this) {
            val existing2 = runtime
            if (existing2 != null) return existing2
            val settings = GeckoRuntimeSettings.Builder()
                // Tương đương "Chặn quảng cáo/tracker" hiện có (pref_block_tracker) - nhưng
                // đây là chặn theo PHÂN LOẠI (tracker/ad/social/cryptomining/fingerprinting) do
                // Mozilla tự phân loại & cập nhật, KHÔNG đọc file blocklist.txt của mình.
                // Muốn giữ đúng danh sách domain tự chọn trong blocklist.txt thì vẫn phải tự
                // chặn thêm ở NavigationDelegate.onLoadRequest (xem TODO bên dưới) - ETP không
                // thay thế hoàn toàn, chỉ bổ sung.
                .contentBlocking(
                    ContentBlocking.Settings.Builder()
                        // API GeckoView bản 154.x: method là .antiTracking(...) (không phải
                        // .categories(...)), và class hằng số là ContentBlocking.AntiTracking
                        // (không phải ContentBlocking.AntiTrackingCategory - class đó không tồn
                        // tại trong bản này).
                        .antiTracking(
                            ContentBlocking.AntiTracking.STRICT or
                                ContentBlocking.AntiTracking.CRYPTOMINING or
                                ContentBlocking.AntiTracking.FINGERPRINTING
                        )
                        .cookieBehavior(ContentBlocking.CookieBehavior.ACCEPT_NON_TRACKERS)
                        .build()
                )
                .build()
            val created = GeckoRuntime.create(context.applicationContext, settings)
            runtime = created
            return created
        }
    }

    // Tương đương createWebView() trong BrowserActivity, nhưng tách GeckoView (phần hiển thị,
    // ứng với "view") ra khỏi GeckoSession (phần state/điều hướng, ứng với "webView" logic) -
    // đây là khác biệt kiến trúc quan trọng nhất so với WebView (gộp làm 1). GeckoSession sống
    // độc lập, GeckoView chỉ là "khung hiển thị" có thể gắn/gỡ session bất kỳ lúc nào - hữu ích
    // sau này nếu muốn tái dùng 1 GeckoView cho tab đang active thay vì 1 view/tab.
    fun createSession(context: Context, isPrivate: Boolean): GeckoSession {
        val settings = GeckoSessionSettings.Builder()
            // Thay thế hẳn cơ chế tách android:process=":incognito" hiện tại của IncognitoActivity -
            // không cần tách process/Activity riêng nữa, 1 session bật cờ này là đủ, dữ liệu
            // (cookie/storage) của nó KHÔNG rơi vào cookie jar dùng chung.
            .usePrivateMode(isPrivate)
            .build()
        val session = GeckoSession(settings)
        session.open(getRuntime(context))
        return session
    }

    fun attach(geckoView: GeckoView, session: GeckoSession) {
        geckoView.setSession(session)
    }

    // BƯỚC 3: gọi khi đóng 1 tab (đặc biệt là tab ẩn danh) - tương đương phần
    // "onDestroy() { removeAllCookies(); deleteAllData() }" của IncognitoActivity hiện tại, nhưng
    // đơn giản hơn nhiều: không cần tự xoá cookie/storage tay, vì phiên private-mode vốn chưa từng
    // ghi gì xuống đĩa. close() chỉ đóng kết nối GeckoSession<->GeckoView và giải phóng dữ liệu
    // trong RAM của session đó ngay lập tức, không cần đợi cả process bị hệ thống dọn như bản
    // android:process=":incognito" hiện tại.
    fun closeSession(session: GeckoSession) {
        if (session.isOpen) {
            session.close()
        }
    }

    // ========================================================================================
    // BƯỚC 4/7: chặn quảng cáo/tracker theo blocklist.txt (thay shouldInterceptRequest)
    // ========================================================================================
    // ETP (categories(...) ở getRuntime() phía trên) đã bật từ bước 1-2, nhưng đó là chặn theo
    // PHÂN LOẠI do Mozilla tự phân loại/cập nhật - không đọc blocklist.txt của mình. Muốn giữ
    // đúng danh sách domain tự chọn (vd domain đặc thù VN chưa nằm trong phân loại của Mozilla)
    // thì vẫn cần tự chặn thêm, và GeckoView chỉ cho chặn ở cấp NAVIGATION qua
    // NavigationDelegate.onLoadRequest (trả AllowOrDeny.DENY) - không có kiểu "trả response rỗng
    // cho riêng 1 request con" như WebResourceResponse của shouldInterceptRequest. Nghĩa là:
    //   - Chặn được: click link / redirect / iframe top-level tới domain trong blocklist.txt
    //   - CHƯA chặn được: ảnh/script/tracker nhúng làm subresource sâu trong 1 trang đã cho phép
    //     load (vd "facebook.com/tr" nhúng trong 1 trang báo) - muốn chặn kiểu này cần thêm
    //     quyền "webRequest"/"webRequestBlocking" vào WebExtension đã dựng ở bước 6
    //     (app/src/main/assets/mediabridge/), để dành làm sau vì là hạng mục độc lập.
    @Volatile
    private var blockedHosts: Set<String>? = null

    private fun loadBlockedHosts(context: Context): Set<String> {
        val existing = blockedHosts
        if (existing != null) return existing
        synchronized(this) {
            val existing2 = blockedHosts
            if (existing2 != null) return existing2
            val hosts = mutableSetOf<String>()
            try {
                context.assets.open("blocklist.txt").bufferedReader().useLines { lines ->
                    lines.forEach { line ->
                        val host = line.trim()
                        if (host.isNotEmpty() && !host.startsWith("#")) {
                            hosts.add(host.lowercase())
                        }
                    }
                }
            } catch (e: Exception) {
                // Không có blocklist thì vẫn chạy bình thường - giống hệt loadBlocklist() ở
                // BrowserActivity.kt
            }
            blockedHosts = hosts
            return hosts
        }
    }

    // Đọc CHUNG khoá SharedPreferences ("sieutoc_prefs" / "pref_block_tracker") với
    // BrowserActivity.isTrackerBlockEnabled() - bật/tắt ở Menu > Cài đặt áp dụng đồng thời cho
    // cả WebView lẫn GeckoSession, không cần cài đặt riêng cho từng engine.
    private fun isTrackerBlockEnabled(context: Context): Boolean =
        context.getSharedPreferences("sieutoc_prefs", Context.MODE_PRIVATE)
            .getBoolean("pref_block_tracker", true)

    // Logic khớp domain giống hệt isBlocked() ở BrowserActivity.kt (subdomain match + entry có
    // path riêng như "facebook.com/tr") - cố tình giữ y hệt để 2 engine chặn cùng 1 tập domain,
    // không lệch hành vi khi người dùng chuyển qua lại.
    fun isBlockedUrl(context: Context, url: String): Boolean {
        if (!isTrackerBlockEnabled(context)) return false
        val uri = try {
            Uri.parse(url)
        } catch (e: Exception) {
            return false
        }
        val host = uri.host?.lowercase() ?: return false
        return loadBlockedHosts(context).any { blocked ->
            val slash = blocked.indexOf('/')
            if (slash < 0) {
                host == blocked || host.endsWith(".$blocked")
            } else {
                val blockedHost = blocked.substring(0, slash)
                val blockedPath = blocked.substring(slash)
                (host == blockedHost || host.endsWith(".$blockedHost")) &&
                    (uri.path ?: "").startsWith(blockedPath)
            }
        }
    }

    // Gọi sớm (vd ngay khi tạo session đầu tiên) để nạp blocklist.txt trước - không bắt buộc,
    // loadBlockedHosts() đã tự lười nạp khi cần, gọi hàm này chỉ để tránh lần đọc file đầu tiên
    // rơi đúng lúc đang xử lý điều hướng trang.
    fun preloadBlocklist(context: Context) {
        loadBlockedHosts(context)
    }

    // ========================================================================================
    // BƯỚC 5/7: fullscreen video thật (ẩn thanh tab/địa chỉ + thanh điều hướng hệ thống)
    // ========================================================================================
    // Khác WebChromeClient.onShowCustomView (đưa 1 View riêng để BrowserActivity tự add vào
    // fullscreenContainer): GeckoView KHÔNG có "customView" nào để swap - chính geckoView đang
    // hiển thị tự vẽ luôn nội dung fullscreen (xem comment trong ContentDelegate.onFullScreen ở
    // GeckoTab bên dưới). Vì vậy việc còn lại chỉ là đúng phần "UI chrome" mà BrowserActivity
    // hiện đang làm thủ công trong onShowCustomView/onHideCustomView + enterImmersiveMode()/
    // exitImmersiveMode() - tách ra đây thành hàm dùng chung, để lúc ghép Gecko vào
    // BrowserActivity (bước sau) chỉ cần gọi applyFullScreenChrome() từ callback onFullScreen,
    // khỏi viết trùng logic ẩn/hiện + immersive mode lần thứ 2 cho nhánh Gecko.
    //
    // GeckoEngine không giữ tham chiếu view riêng của BrowserActivity (rootUiLayout) nên
    // applyFullScreenChrome() nhận vào activity + rootUiLayout làm tham số, thay vì tự tìm - giữ
    // GeckoEngine không phụ thuộc ngược vào BrowserActivity, đúng tinh thần "song song, chưa nối"
    // của cả file này.
    @Suppress("DEPRECATION")
    fun enterImmersiveMode(activity: Activity) {
        // Y hệt enterImmersiveMode() hiện có trong BrowserActivity.kt - cố tình giữ đúng flag để
        // 2 nhánh WebView/Gecko có hành vi ẩn status bar/nav bar giống hệt nhau.
        activity.window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
        // Chống tắt màn hình khi đang phát video fullscreen - y hệt dòng
        // window.addFlags(FLAG_KEEP_SCREEN_ON) trong onShowCustomView() hiện tại.
        activity.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    @Suppress("DEPRECATION")
    fun exitImmersiveMode(activity: Activity) {
        activity.window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // Hàm gộp tiện dùng - gọi thẳng 1 lần từ callback onFullScreen(fullScreen, _) lúc ghép vào
    // BrowserActivity, thay vì tự gọi enter/exitImmersiveMode() + toggle visibility rootUiLayout
    // riêng lẻ ở 2 chỗ khác nhau như onShowCustomView/onHideCustomView hiện đang làm cho WebView.
    fun applyFullScreenChrome(activity: Activity, rootUiLayout: View, fullScreen: Boolean) {
        if (fullScreen) {
            rootUiLayout.visibility = View.GONE
            enterImmersiveMode(activity)
        } else {
            rootUiLayout.visibility = View.VISIBLE
            exitImmersiveMode(activity)
        }
    }

    // ========================================================================================
    // BƯỚC 6/7: JS bridge thay addJavascriptInterface (viết bằng WebExtension)
    // ========================================================================================
    // `addJavascriptInterface` gắn thẳng 1 object Kotlin vào `window` của trang - JS gọi
    // `AndroidMediaBridge.onPlay()` là gọi trực tiếp hàm Kotlin, không qua lớp trung gian nào.
    // GeckoView (giống Firefox thật) KHÔNG cho phép kiểu truy cập trực tiếp này vì lý do an
    // toàn/kiến trúc tiến trình (content script chạy cô lập, không được đụng thẳng vào code
    // native của app) - thay vào đó phải đóng gói thành 1 WebExtension thật:
    //   - `app/src/main/assets/mediabridge/manifest.json` + `content.js`: bản Gecko của
    //     `mediaHookScript` hiện có, gắn listener play/pause/ended/error lên mọi thẻ
    //     video/audio - GIỮ NGUYÊN logic, chỉ đổi cách gửi tin: JS gọi
    //     `browser.runtime.sendNativeMessage("sieutoc", {...})` (API chuẩn của WebExtension)
    //     thay vì gọi thẳng `AndroidMediaBridge.onPlay()`.
    //   - Phía Kotlin: `installMediaBridge()` nạp extension đó 1 LẦN cho toàn app (dùng chung
    //     `GeckoRuntime`, giống hệt 1 addon cài vào Firefox), rồi `attachMediaBridge()` gắn 1
    //     `MessageDelegate` RIÊNG cho từng `GeckoSession` (mỗi tab) để biết chính xác message
    //     "play"/"pause"/"error" đến từ tab nào - vai trò tương đương tham số `ownerWebView`
    //     trong `MediaPlaybackBridge(webView)` cũ.
    // Đây là lý do bước này đứng cuối cùng (khó nhất): phải dựng hẳn 1 "extension" hoàn chỉnh
    // (manifest + content script + quyền `nativeMessaging`/`nativeMessagingFromContent`/
    // `geckoViewAddons`) thay vì chỉ gọi 1 API Kotlin đơn giản như các bước trước.
    //
    // LƯU Ý VỀ PHIÊN BẢN: tên hàm chính xác (`webExtensionController`, `ensureBuiltIn`,
    // `WebExtension.SessionController.setMessageDelegate`) đúng với dòng GeckoView hiện hành
    // tại thời điểm viết, nhưng đây là API còn tương đối mới và có thể đổi tên nhẹ giữa các
    // bản build-id khác nhau của Mozilla. Nếu build lỗi "unresolved reference" ở đúng những
    // dòng này, tra javadoc GeckoView đúng version đang khai trong `gradle.properties` (tìm
    // class `WebExtensionController` và `WebExtension.SessionController`) để đối chiếu tên gọi
    // - phần còn lại của lộ trình (bước 1-5) không bị ảnh hưởng vì dùng API đã ổn định lâu.
    private const val MEDIA_BRIDGE_NATIVE_APP = "sieutoc"
    private const val MEDIA_BRIDGE_EXTENSION_ID = "mediabridge@sieutoc.local"
    private const val MEDIA_BRIDGE_ASSET_PATH = "resource://android/assets/mediabridge/"

    @Volatile
    private var mediaBridgeExtension: WebExtension? = null

    // Nạp extension 1 lần cho toàn app - gọi sớm (vd lúc tạo GeckoSession đầu tiên), tương tự
    // getRuntime() ở trên cũng chỉ tạo 1 lần. Gọi lại nhiều lần sau khi đã nạp xong sẽ trả ngay
    // qua onReady() mà không cài lại.
    fun installMediaBridge(
        context: Context,
        onReady: (WebExtension) -> Unit,
        onError: (Throwable) -> Unit
    ) {
        val existing = mediaBridgeExtension
        if (existing != null) {
            onReady(existing)
            return
        }
        getRuntime(context).webExtensionController
            .ensureBuiltIn(MEDIA_BRIDGE_ASSET_PATH, MEDIA_BRIDGE_EXTENSION_ID)
            .accept(
                { extension ->
                    if (extension != null) {
                        mediaBridgeExtension = extension
                        onReady(extension)
                    }
                },
                { error -> onError(error ?: RuntimeException("Không rõ nguyên nhân (ensureBuiltIn trả về lỗi null)")) }
            )
    }

    // Gắn message delegate RIÊNG cho 1 session/tab - đây là chỗ nhận message JSON mà
    // content.js gửi lên qua browser.runtime.sendNativeMessage(). Gọi từ
    // GeckoTab.attachMediaBridge() sau khi installMediaBridge() đã có extension.
    fun attachMediaBridgeDelegate(
        session: GeckoSession,
        extension: WebExtension,
        onPlay: () -> Unit,
        onPause: () -> Unit,
        onMediaError: (String) -> Unit
    ) {
        session.webExtensionController.setMessageDelegate(
            extension,
            object : WebExtension.MessageDelegate {
                override fun onMessage(
                    nativeApp: String,
                    message: Any,
                    sender: WebExtension.MessageSender
                ): GeckoResult<Any>? {
                    // message là org.json.JSONObject do content.js gửi {type: "play"/"pause"/"error", ...}
                    // - xem content.js để biết cấu trúc chính xác từng loại message.
                    val json = message as? org.json.JSONObject ?: return null
                    when (json.optString("type")) {
                        "play" -> onPlay()
                        "pause" -> onPause()
                        "error" -> onMediaError(json.optString("detail"))
                    }
                    return null
                }
            },
            MEDIA_BRIDGE_NATIVE_APP
        )
    }
}

// Model 1 tab kiểu Gecko - cố tình đặt tên/field song song với "Tab" (WebView) trong
// BrowserActivity.kt để bước ghép sau này chỉ cần đổi kiểu, không cần đổi logic quản lý danh
// sách tab/thanh tab.
class GeckoTab(
    private val context: Context,
    val geckoView: GeckoView,
    val session: GeckoSession,
    var title: String = "Tab mới",
    var url: String = "",
    var isPopup: Boolean = false,
    var hasPlayingMedia: Boolean = false,
    // Tương đương jsDialogCount trong Tab (WebView) cũ - đếm số hộp thoại alert/confirm/
    // beforeunload đã hiện, để chặn êm hộp thoại "bẫy" người dùng thứ 4 trở đi khi đang bật
    // "Chặn quảng cáo / theo dõi".
    var jsDialogCount: Int = 0,
    // GeckoSession không có canGoBack()/canGoForward() ĐỒNG BỘ như WebView - phải tự lưu lại
    // trạng thái mới nhất do NavigationDelegate.onCanGoBack/onCanGoForward báo về (bất đồng bộ),
    // rồi đọc 2 field này thay vì gọi thẳng lên session. Xem attachBasicDelegates() bên dưới.
    var canGoBack: Boolean = false,
    var canGoForward: Boolean = false
) {
    // Đúng bằng "popupFirstLoadChecked" trong Tab (WebView) cũ - đã kiểm tra xong lần điều
    // hướng đầu tiên của tab popup này hay chưa (dùng trong onLoadRequest bên dưới).
    private var popupFirstLoadChecked = false

    // Gắn các delegate cơ bản. onTitle/onLocation dùng để cập nhật thanh địa chỉ + tên tab,
    // tương đương onReceivedTitle/onPageFinished bên WebView.
    fun attachBasicDelegates(
        onTitleChanged: (String) -> Unit,
        onLocationChanged: (String) -> Unit,
        onLoadingStateChanged: (Boolean) -> Unit,
        onCanGoBackChanged: (Boolean) -> Unit,
        onCanGoForwardChanged: (Boolean) -> Unit,
        onFullScreen: (Boolean, View?) -> Unit,
        // Gọi khi NỘI DUNG ĐẦU TIÊN của 1 tab popup bị chặn bởi blocklist.txt - tương đương
        // đúng khối "if (tab.isPopup && !tab.popupFirstLoadChecked...) closeTab(...)" trong
        // shouldInterceptRequest cũ. Không gọi cho tab thường (isPopup = false).
        onPopupBlockedOnFirstLoad: () -> Unit,
        // Tương đương onCreateWindow trả về true + tạo Tab mới cũ - trả về 1 GeckoSession MỚI
        // (đã tạo qua GeckoEngine.createSession(), CHƯA gắn delegate/UI) nếu muốn cho phép mở
        // popup, hoặc null để chặn hẳn (JS window.open() sẽ trả về null, giống return false cũ).
        // Nơi gọi (BrowserActivity) chịu trách nhiệm: tạo GeckoTab bọc session mới này, gắn
        // delegate, thêm vào danh sách tab/thanh tab - y hệt registerNewTab() cũ.
        onNewPopupSession: (uri: String) -> GeckoSession?
    ) {
        session.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onTitleChange(session: GeckoSession, title: String?) {
                this@GeckoTab.title = title ?: this@GeckoTab.title
                onTitleChanged(this@GeckoTab.title)
            }

            override fun onFullScreen(session: GeckoSession, fullScreen: Boolean) {
                // Khác WebChromeClient.onShowCustomView: GeckoView KHÔNG đưa 1 View riêng cho
                // fullscreen - chính geckoView hiện tại tự vẽ nội dung fullscreen. Việc của
                // mình chỉ là ẩn/hiện thanh tab + thanh địa chỉ + thanh điều hướng hệ thống,
                // y hệt phần UI-chrome đã làm trong onShowCustomView/onHideCustomView hiện tại -
                // không cần fullscreenContainer + customView + customViewCallback nữa.
                //
                // Lúc ghép vào BrowserActivity (bước sau), truyền lambda gọi thẳng
                // GeckoEngine.applyFullScreenChrome(activity, rootUiLayout, fullScreen) ở đây -
                // hàm đó đã gộp sẵn cả enter/exitImmersiveMode() lẫn ẩn/hiện rootUiLayout, khỏi
                // viết lại logic 2 lần cho nhánh Gecko.
                onFullScreen(fullScreen, null)
            }

            // FIXME (rủi ro cao nhất trong lần nối này): tên hàm chính xác cho sự kiện JS gọi
            // window.close() trên chính tab đó (tương đương onCloseWindow cũ) CHƯA được đối
            // chiếu trực tiếp với javadoc đúng version GeckoView đang dùng - các bản GeckoView
            // đã từng đổi tên hàm này qua vài lần. Nếu build báo lỗi "onCloseRequest" không tồn
            // tại/không override được gì, tra class GeckoSession.ContentDelegate đúng version
            // trong gradle.properties (tìm từ khoá "close"/"DOMWindowClose") để sửa đúng tên.
            override fun onCloseRequest(session: GeckoSession) {
                onPopupBlockedOnFirstLoad() // tạm dùng chung callback đóng tab - xem TODO ở trên
            }
        }

        session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onLocationChange(
                session: GeckoSession,
                url: String?,
                perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>,
                hasUserGesture: Boolean
            ) {
                this@GeckoTab.url = url ?: this@GeckoTab.url
                onLocationChanged(this@GeckoTab.url)
            }

            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                this@GeckoTab.canGoBack = canGoBack
                onCanGoBackChanged(canGoBack)
            }

            override fun onCanGoForward(session: GeckoSession, canGoForward: Boolean) {
                this@GeckoTab.canGoForward = canGoForward
                onCanGoForwardChanged(canGoForward)
            }

            // Tương đương onCreateWindow (mở tab mới) - Gecko gọi hàm này khi content muốn mở 1
            // "cửa sổ" mới (window.open()/target=_blank), TRẢ VỀ session mới nếu muốn cho phép.
            // Khác cơ chế WebViewTransport cũ (nhận 1 WebView rỗng rồi mới biết URL đích sau):
            // ở đây Gecko cho biết TRƯỚC uri đích ngay trong tham số, nên áp blocklist.txt được
            // NGAY TẠI ĐÂY (không cần đợi onLoadRequest của session mới) - nếu domain bị chặn,
            // trả về null luôn, không tạo session/tab rác.
            //
            // LƯU Ý: hàm này KHÔNG có tham số "isUserGesture" như onCreateWindow cũ - phần giới
            // hạn "mỗi lần chạm chỉ 1 popup" (chặn popup ăn theo bắn liên tiếp) phải chuyển hết
            // sang phía BrowserActivity tự đo thời gian giữa các lần gọi onNewPopupSession, xem
            // comment ở BrowserActivity.kt.
            override fun onNewSession(session: GeckoSession, uri: String): GeckoResult<GeckoSession> {
                if (GeckoEngine.isBlockedUrl(context, uri)) {
                    return GeckoResult.fromValue(null)
                }
                return GeckoResult.fromValue(onNewPopupSession(uri))
            }

            // BƯỚC 4/7: áp blocklist.txt (xem GeckoEngine.isBlockedUrl() để biết chi tiết khác
            // biệt so với shouldInterceptRequest cũ - chặn ở cấp navigation, chưa chặn được
            // subresource nhúng sâu trong trang; chặn subresource để dành làm sau bằng quyền
            // webRequest thêm vào WebExtension ở bước 6, xem ghi chú đầu file).
            override fun onLoadRequest(
                session: GeckoSession,
                request: GeckoSession.NavigationDelegate.LoadRequest
            ): GeckoResult<AllowOrDeny> {
                val blocked = GeckoEngine.isBlockedUrl(context, request.uri)
                // Tương đương khối "tab.isPopup && !tab.popupFirstLoadChecked && isForMainFrame"
                // trong shouldInterceptRequest cũ - chỉ tab popup mới tự đóng khi nội dung ĐẦU
                // TIÊN bị chặn, các lần điều hướng sau đó (người dùng đã ở lại tab, tự bấm link
                // khác) không đóng tab nữa dù có bị chặn.
                if (isPopup && !popupFirstLoadChecked) {
                    popupFirstLoadChecked = true
                    if (blocked) onPopupBlockedOnFirstLoad()
                }
                return GeckoResult.fromValue(if (blocked) AllowOrDeny.DENY else AllowOrDeny.ALLOW)
            }
        }

        session.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(session: GeckoSession, url: String) {
                onLoadingStateChanged(true)
            }

            override fun onPageStop(session: GeckoSession, success: Boolean) {
                onLoadingStateChanged(false)
            }
            // Lưu ý: KHÔNG có onProgressChanged(newProgress: Int) như WebChromeClient - GeckoView
            // chỉ báo bắt đầu/kết thúc, không báo % tiến độ tải trang. progressBar hiện tại
            // (thanh %) sẽ phải đổi thành kiểu indeterminate (quay vòng) hoặc bỏ luôn.
        }
    }

    // Tương đương khối onJsAlert/onJsConfirm/onJsBeforeUnload + allowJsDialog() cũ - gộp cả 3
    // loại hộp thoại JS vào 1 PromptDelegate, dùng chung logic đếm/giới hạn qua allowDialog().
    // allowDialog() do BrowserActivity truyền vào, trả false khi đã quá 3 hộp thoại VÀ đang bật
    // "Chặn quảng cáo/theo dõi" - y hệt điều kiện `tab.jsDialogCount <= 3` cũ, chỉ chuyển chỗ
    // lưu bộ đếm sang field jsDialogCount ở trên.
    //
    // FIXME: ngữ nghĩa confirm()/dismiss() của BeforeUnloadPrompt (trang có nên được rời đi hay
    // không) suy luận từ JsResult.confirm() = "cho rời trang" của WebView cũ, CHƯA kiểm chứng
    // trực tiếp trên máy thật với GeckoView - nếu bấm Back mà bị "kẹt" lại ở trang có
    // onbeforeunload, thử đảo ngược 2 nhánh confirm()/dismiss() bên dưới.
    fun attachPromptAndPermissionDelegates(allowDialog: () -> Boolean) {
        session.promptDelegate = object : GeckoSession.PromptDelegate {
            override fun onAlertPrompt(
                session: GeckoSession,
                prompt: GeckoSession.PromptDelegate.AlertPrompt
            ): GeckoResult<GeckoSession.PromptDelegate.PromptResponse> {
                jsDialogCount++
                return GeckoResult.fromValue(prompt.dismiss())
            }

            override fun onButtonPrompt(
                session: GeckoSession,
                prompt: GeckoSession.PromptDelegate.ButtonPrompt
            ): GeckoResult<GeckoSession.PromptDelegate.PromptResponse> {
                jsDialogCount++
                return if (allowDialog()) {
                    // Không có UI riêng ở bước này (chưa build dialog Android thật cho confirm())
                    // - tạm để Gecko dùng hộp thoại mặc định của chính nó nếu có, hoặc coi như
                    // OK để không kẹt trang. Làm UI riêng đẹp hơn để ở nâng cấp sau.
                    GeckoResult.fromValue(prompt.confirm(GeckoSession.PromptDelegate.ButtonPrompt.Type.POSITIVE))
                } else {
                    GeckoResult.fromValue(prompt.dismiss())
                }
            }

            override fun onBeforeUnloadPrompt(
                session: GeckoSession,
                prompt: GeckoSession.PromptDelegate.BeforeUnloadPrompt
            ): GeckoResult<GeckoSession.PromptDelegate.PromptResponse> {
                jsDialogCount++
                return if (allowDialog()) {
                    GeckoResult.fromValue(prompt.dismiss()) // dismiss = không chặn điều hướng
                } else {
                    // BasePrompt.confirm() (không tham số) là protected, không gọi trực tiếp
                    // được nữa - BeforeUnloadPrompt cần confirm(AllowOrDeny). DENY = chặn điều
                    // hướng (giữ user ở lại trang), khớp ý định cũ của nhánh này.
                    GeckoResult.fromValue(prompt.confirm(AllowOrDeny.DENY)) // FIXME: xem ghi chú confirm/dismiss ở trên
                }
            }
        }

        session.permissionDelegate = object : GeckoSession.PermissionDelegate {
            // FIXME (rủi ro cao thứ 2): tương đương khối onPermissionRequest cấp DRM
            // (RESOURCE_PROTECTED_MEDIA_ID) cũ. Chữ ký chính xác của onContentPermissionRequest
            // đã đổi qua lại giữa các version GeckoView (kiểu (session, uri, type, callback) cũ
            // vs kiểu (session, ContentPermission) mới hơn) - PHẢI đối chiếu javadoc đúng version
            // trong gradle.properties trước khi tin dòng dưới đây chạy đúng. Nếu build lỗi, tìm
            // class GeckoSession.PermissionDelegate.ContentPermission + hằng số
            // "MEDIA_KEY_SYSTEM_ACCESS" để sửa lại đúng chữ ký.
            override fun onContentPermissionRequest(
                session: GeckoSession,
                perm: GeckoSession.PermissionDelegate.ContentPermission
            ): GeckoResult<Int> {
                return if (perm.permission == GeckoSession.PermissionDelegate.PERMISSION_MEDIA_KEY_SYSTEM_ACCESS) {
                    GeckoResult.fromValue(GeckoSession.PermissionDelegate.ContentPermission.VALUE_ALLOW)
                } else {
                    GeckoResult.fromValue(GeckoSession.PermissionDelegate.ContentPermission.VALUE_DENY)
                }
            }
        }
    }

    fun loadUrl(url: String) {
        session.loadUri(url)
    }

    fun goBack() {
        session.goBack()
    }

    fun goForward() {
        session.goForward()
    }

    // BƯỚC 6/7: tương đương dòng
    // webView.addJavascriptInterface(MediaPlaybackBridge(webView), "AndroidMediaBridge") cũ -
    // gọi sau khi GeckoEngine.installMediaBridge() đã có extension (thường ngay sau
    // attachBasicDelegates()). onPlay/onPause/onMediaError nhận cùng dữ liệu (onMediaError nhận
    // chuỗi JSON {code, message, src, tag}) như onWebMediaPlayStateChanged()/onWebMediaError()
    // hiện có trong BrowserActivity, chỉ khác nguồn gửi.
    fun attachMediaBridge(
        extension: WebExtension,
        onPlay: () -> Unit,
        onPause: () -> Unit,
        onMediaError: (String) -> Unit
    ) {
        GeckoEngine.attachMediaBridgeDelegate(session, extension, onPlay, onPause, onMediaError)
    }

    // Đóng tab: giải phóng session ngay (xem GeckoEngine.closeSession() - quan trọng nhất với
    // tab ẩn danh vì đây là lúc dữ liệu RAM của phiên private-mode bị xoá thật sự).
    fun close() {
        GeckoEngine.closeSession(session)
    }
}
