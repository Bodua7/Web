package com.atun.translator

import android.Manifest
import android.app.DownloadManager
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Environment
import android.view.View
import android.view.ViewGroup
import android.webkit.PermissionRequest
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayInputStream

// ===== Tách từ BrowserActivity.kt (phần quản lý tab + WebView) =====
// Toàn bộ hàm dưới đây là extension function của BrowserActivity - vẫn truy cập trực tiếp các
// field "internal" của Activity (tabs, currentTabIndex, nextTabId, tabsContainer, addressBar,
// btnBookmark, securityIconView, progressBar, tabStrip, storage, customFullscreenView,
// customFullscreenCallback...) y hệt như khi còn nằm chung 1 file, KHÔNG đổi hành vi.

internal fun BrowserActivity.rebuildTabChip(tab: BrowserActivity.BrowserTab) {
    tab.chip.text = (tab.title.ifBlank { "Trang mới" }).let {
        if (it.length > 14) it.substring(0, 14) + "…" else it
    }
    val isCurrent = tabs.getOrNull(currentTabIndex)?.id == tab.id
    tab.chip.setBackgroundColor(if (isCurrent) tabChipActiveColor() else Color.TRANSPARENT)
    tab.chip.setTypeface(null, if (isCurrent) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
    tab.chip.setTextColor(chromeTextColor())
    tab.closeBtn.setTextColor(chromeTextColor())
}

// ================= Quản lý tab =================
internal fun BrowserActivity.currentWebView(): WebView? = tabs.getOrNull(currentTabIndex)?.webView

internal fun BrowserActivity.openNewTab(url: String) {
    if (tabs.size >= BrowserActivity.MAX_TABS) {
        Toast.makeText(this, "Đã mở tối đa ${BrowserActivity.MAX_TABS} tab - đóng bớt tab trước khi mở thêm", Toast.LENGTH_SHORT).show()
        return
    }

    val webView = createWebView()
    val chip = TextView(this).apply {
        text = "Trang mới"
        textSize = 13f
        setPadding(dp(12f), dp(8f), dp(12f), dp(8f))
    }
    // Nút "×" riêng để đóng tab - trước đây chỉ đóng được bằng long-press vào chip, không
    // dễ nhận ra; giữ lại long-press như phím tắt phụ, thêm nút này cho rõ ràng, dễ bấm.
    val closeBtn = TextView(this).apply {
        text = "×"
        textSize = 15f
        setPadding(dp(8f), dp(8f), dp(10f), dp(8f))
    }
    val row = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = android.view.Gravity.CENTER_VERTICAL
    }
    row.addView(chip)
    row.addView(closeBtn)

    val tab = BrowserActivity.BrowserTab(id = nextTabId++, webView = webView, chip = chip, closeBtn = closeBtn, row = row)
    chip.setOnClickListener { switchToTab(tab.id) }
    chip.setOnLongClickListener { closeTab(tab.id); true }
    closeBtn.setOnClickListener { closeTab(tab.id) }

    tabs.add(tab)
    // Chèn row TRƯỚC nút "Tab mới" (nút này luôn ở cuối cùng trong tabStrip)
    tabStrip.addView(row, tabStrip.childCount - 1)

    switchToTab(tab.id)
    loadInCurrentTab(normalizeUrl(url))
}

internal fun BrowserActivity.switchToTab(tabId: Long) {
    val index = tabs.indexOfFirst { it.id == tabId }
    if (index == -1) return
    tabsContainer.removeAllViews()
    currentTabIndex = index
    val tab = tabs[index]
    tabsContainer.addView(
        tab.webView,
        FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
    )
    addressBar.setText(tab.webView.url ?: "")
    btnBookmark.text = if (storage.isBookmarked(tab.webView.url ?: "")) "★" else "☆"
    securityIconView.text = when {
        tab.webView.url?.startsWith("https://") == true -> "🔒"
        tab.webView.url?.startsWith("http://") == true -> "⚠️"
        else -> "🌐"
    }
    tabs.forEach { rebuildTabChip(it) }
}

internal fun BrowserActivity.closeTab(tabId: Long) {
    val index = tabs.indexOfFirst { it.id == tabId }
    if (index == -1) return
    if (tabs.size == 1) {
        // Tab cuối cùng: không đóng app đột ngột, đóng luôn màn hình web mini
        finish()
        return
    }
    val tab = tabs.removeAt(index)
    tabStrip.removeView(tab.row)
    tab.webView.destroy()
    val fallbackIndex = (index - 1).coerceAtLeast(0)
    currentTabIndex = -1
    switchToTab(tabs[fallbackIndex].id)
}

// ================= WebView =================
@Suppress("SetJavaScriptEnabled")
internal fun BrowserActivity.createWebView(): WebView {
    val webView = WebView(this)
    webView.settings.apply {
        javaScriptEnabled = true
        domStorageEnabled = true
        loadWithOverviewMode = true
        useWideViewPort = true
        mediaPlaybackRequiresUserGesture = false
        mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        cacheMode = WebSettings.LOAD_DEFAULT
    }
    applyForceDark(webView)

    // Trước đây chưa xử lý gì khi trang có link tải file (mp3/video/pdf...) - bấm vào coi
    // như không có phản hồi. Giờ đẩy qua DownloadManager của hệ thống, tải về thư mục
    // Downloads công khai, có thông báo tiến trình + xong của chính Android lo, không cần
    // tự vẽ progress bar tải file riêng.
    webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
        handleDownload(url, userAgent, contentDisposition, mimeType)
    }

    webView.webViewClient = object : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
            // Luôn mở link ngay trong WebView này (không nhảy ra app trình duyệt ngoài),
            // giữ đúng chủ trương "trang chạy TRONG app này" để audio thuộc phiên âm thanh
            // của chính app -> "Bắt âm thanh hệ thống" của app chính vẫn bắt được.
            return false
        }

        // Chặn quảng cáo: mọi request (ảnh, script, iframe con...) đi qua đây trước khi
        // WebView tải - so host với AdBlockList, khớp thì trả về response RỖNG thay vì cho
        // tải thật (chặn im lặng, trang vẫn chạy tiếp bình thường, chỉ thiếu phần quảng
        // cáo/tracker đó). Tôn trọng tuỳ chọn bật/tắt trong menu - đọc trực tiếp từ storage
        // mỗi lần để luôn phản ánh đúng trạng thái mới nhất, không cache sai.
        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
            if (storage.isAdBlockEnabled() && AdBlockList.isBlocked(request.url.host)) {
                return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
            }
            return super.shouldInterceptRequest(view, request)
        }

        override fun onPageFinished(view: WebView, url: String?) {
            super.onPageFinished(view, url)
            val tab = tabs.find { it.webView == view } ?: return
            tab.title = view.title?.takeIf { it.isNotBlank() } ?: (url ?: tab.title)
            rebuildTabChip(tab)
            if (tabs.getOrNull(currentTabIndex)?.id == tab.id) {
                addressBar.setText(url ?: "")
                btnBookmark.text = if (storage.isBookmarked(url ?: "")) "★" else "☆"
                securityIconView.text = when {
                    url?.startsWith("https://") == true -> "🔒"
                    url?.startsWith("http://") == true -> "⚠️"
                    else -> "🌐"
                }
            }
            if (!url.isNullOrBlank()) {
                storage.addHistory(url, tab.title)
            }
        }
    }

    webView.webChromeClient = object : WebChromeClient() {
        override fun onProgressChanged(view: WebView, newProgress: Int) {
            if (tabs.getOrNull(currentTabIndex)?.webView == view) {
                progressBar.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                progressBar.progress = newProgress
            }
        }

        // Hỗ trợ fullscreen cho video HTML5 (nhiều trang phát video dùng chuẩn này thay vì
        // Fullscreen API của DOM) - phủ view fullscreen lên toàn bộ root, thoát ra khi trang
        // tự gọi onHideCustomView() hoặc người dùng bấm back (xem onBackPressed()).
        //
        // BUG đã sửa: "phóng to video chưa xoay ngang màn hình" - cùng nguyên nhân đã sửa
        // cho player chính ở www/index.html (xem ScreenOrientationPlugin.kt), nhưng
        // BrowserActivity là Activity native RIÊNG (không chạy qua Capacitor WebView của
        // MainActivity) nên bug này độc lập, phải tự sửa riêng ở đây - trước đây
        // onShowCustomView() chỉ thêm view fullscreen vào decorView mà KHÔNG hề khoá xoay
        // màn hình, nên máy vẫn giữ nguyên chiều dọc trong lúc video 16:9 fullscreen theo
        // khung dọc đó -> video chỉ lấp được 1 dải ngang mỏng ở giữa, 2 mảng đen lớn trên/
        // dưới. Vì đây là Activity native thật (không phải WebView JS gọi qua plugin), khoá
        // thẳng requestedOrientation tại chỗ, không cần đi vòng qua ScreenOrientationPlugin.
        // SENSOR_LANDSCAPE (không phải REVERSE/LANDSCAPE cố định 1 chiều) để vẫn xoay được
        // giữa trái/phải theo cảm biến, chỉ chặn lật về dọc.
        override fun onShowCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
            if (customFullscreenView != null) {
                callback.onCustomViewHidden()
                return
            }
            customFullscreenView = view
            customFullscreenCallback = callback
            requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            (window.decorView as FrameLayout).addView(
                view,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT).apply {
                    gravity = android.view.Gravity.CENTER
                }
            )
        }

        override fun onHideCustomView() {
            hideCustomFullscreenView()
        }

        // Trước đây chưa override -> WebView tự động từ chối MỌI yêu cầu camera/mic của
        // trang web (vd trang gọi video, ghi âm online...) mà không có gì báo cho biết vì
        // sao. Giờ: chỉ cấp mic (RESOURCE_AUDIO_CAPTURE) và CHỈ khi app đã có quyền
        // RECORD_AUDIO ở tầng hệ thống (app xin quyền này cho tính năng bắt giọng nói
        // chính). Camera luôn từ chối vì app không khai báo permission CAMERA trong
        // Manifest - cấp bừa sẽ crash chứ không hoạt động được.
        override fun onPermissionRequest(request: PermissionRequest) {
            val hasMic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
            val granted = request.resources.filter {
                it == PermissionRequest.RESOURCE_AUDIO_CAPTURE && hasMic
            }
            if (granted.isNotEmpty()) {
                request.grant(granted.toTypedArray())
            } else {
                request.deny()
            }
        }
    }

    return webView
}

internal fun BrowserActivity.handleDownload(url: String, userAgent: String, contentDisposition: String, mimeType: String?) {
    try {
        val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
        val request = DownloadManager.Request(Uri.parse(url)).apply {
            setMimeType(mimeType)
            addRequestHeader("User-Agent", userAgent)
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
            setAllowedOverMetered(true)
        }
        val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        dm.enqueue(request)
        Toast.makeText(this, "Đang tải: $fileName", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Toast.makeText(this, "Không tải được file: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

internal fun BrowserActivity.hideCustomFullscreenView() {
    val view = customFullscreenView ?: return
    (window.decorView as FrameLayout).removeView(view)
    customFullscreenView = null
    customFullscreenCallback?.onCustomViewHidden()
    customFullscreenCallback = null
    // Mở khoá xoay lại - trả quyền quyết định về cho hệ thống/theme của Activity, không ép
    // thêm chính sách xoay riêng đè lên toàn "Web mini" sau khi thoát fullscreen (giống
    // ScreenOrientationPlugin.unlock() đã làm cho player chính).
    requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
}

internal fun BrowserActivity.loadInCurrentTab(url: String) {
    currentWebView()?.loadUrl(url)
}

internal fun BrowserActivity.normalizeUrl(input: String): String {
    // Bỏ khoảng trắng thường (trim()) + các ký tự VÔ HÌNH hay dính theo khi copy link từ
    // app khác (share sheet của YouTube, bàn phím Samsung...): zero-width space/joiner
    // (U+200B/U+200C/U+200D), BOM (U+FEFF), dấu định hướng trái/phải LRM/RLM (U+200E/U+200F).
    // Các ký tự này KHÔNG phải whitespace theo Char.isWhitespace() nên trim() thường không
    // loại được - trước đây khiến startsWith("https://") trượt oan (dù nhìn bằng mắt vẫn y
    // hệt "https://...") và cả câu rơi xuống nhánh tìm kiếm Google thay vì mở thẳng link.
    val trimmed = input.trim().trim('\u200B', '\u200C', '\u200D', '\uFEFF', '\u200E', '\u200F')
    if (trimmed.isEmpty()) return "https://www.google.com"
    // So khớp scheme không phân biệt hoa/thường - bàn phím có thể tự viết hoa ký tự đầu.
    val lower = trimmed.lowercase()
    val looksLikeUrl = trimmed.contains(".") && !trimmed.any { it.isWhitespace() }
    return when {
        lower.startsWith("http://") || lower.startsWith("https://") -> trimmed
        lower.startsWith("www.") -> "https://$trimmed"
        looksLikeUrl -> "https://$trimmed"
        else -> "https://www.google.com/search?q=" + java.net.URLEncoder.encode(trimmed, "UTF-8")
    }
}
