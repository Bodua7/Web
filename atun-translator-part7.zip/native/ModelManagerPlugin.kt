package com.atun.translator

import android.content.Context
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import kotlin.concurrent.thread

// Quản lý model Vosk KHÔNG bundle sẵn trong APK (mọi ngôn ngữ trừ "en") - tải zip trực tiếp
// từ URL chính chủ alphacephei.com (xem CATALOG), giải nén vào filesDir/models/<lang>/, dùng
// trực tiếp bằng Model(path) (xem VoskEngine.resolveModelSource) thay vì StorageService.unpack
// (chỉ đọc được asset đóng gói sẵn trong APK, không đọc được file tải về runtime).
//
// Lý do không bundle hết mọi ngôn ngữ vào APK: mỗi model Vosk ~30-80MB, bundle 4-5 ngôn ngữ
// sẽ đẩy APK vượt 200MB, rất khó tải/phân phối qua GitHub Releases + cài trực tiếp (không qua
// Play Store). Chỉ bundle "en" (ngôn ngữ dùng nhiều nhất), còn lại tải khi cần.
@CapacitorPlugin(name = "ModelManager")
class ModelManagerPlugin : com.getcapacitor.Plugin() {

    companion object {
        // Dùng thẳng model chính chủ từ alphacephei.com (giống cách "en-large" bên dưới đã
        // làm) thay vì tự nén lại rồi tự host trên GitHub Releases của repo này - tránh phải
        // tự tải về máy, nén .zip, tạo GitHub Release, upload thủ công mỗi khi cần thêm/đổi
        // model. unzip() bên dưới đã tự phát hiện + bóc lớp thư mục cha mà các zip gốc của
        // alphacephei hay bọc ngoài (vd "vosk-model-small-vn-0.4/"), nên dùng thẳng URL gốc
        // không cần xử lý gì thêm.
        // sizeMB lấy đúng theo trang https://alphacephei.com/vosk/models - chỉ để hiển thị
        // ước lượng cho UI trước khi tải, không ảnh hưởng logic.
        val CATALOG: Map<String, ModelInfo> = mapOf(
            "vi" to ModelInfo(
                "Tiếng Việt",
                "https://alphacephei.com/vosk/models/vosk-model-small-vn-0.4.zip",
                32,
                mirrorUrl = "https://huggingface.co/localstack/vosk-models/resolve/main/vosk-model-small-vn-0.4.zip"
            ),
            "ja" to ModelInfo(
                "日本語",
                "https://alphacephei.com/vosk/models/vosk-model-small-ja-0.22.zip",
                48,
                mirrorUrl = "https://huggingface.co/localstack/vosk-models/resolve/main/vosk-model-small-ja-0.22.zip"
            ),
            "ko" to ModelInfo(
                "한국어",
                "https://alphacephei.com/vosk/models/vosk-model-small-ko-0.22.zip",
                82,
                mirrorUrl = "https://huggingface.co/localstack/vosk-models/resolve/main/vosk-model-small-ko-0.22.zip"
            ),
            // Model tiếng Anh LỚN, chính xác cao hơn hẳn bản "en" bundled (~40MB, WER thấp hơn
            // nhiều so với model small). Cùng cơ chế tải trực tiếp từ URL chính chủ Alphacephei
            // như vi/ja/ko ở trên - zip này cũng bọc 1 lớp thư mục cha "vosk-model-en-us-0.22/"
            // mà unzip() tự bóc ra. Cảnh báo: ~1.8GB, chỉ nên tải qua Wi-Fi.
            "en-large" to ModelInfo(
                "English (chính xác cao)",
                "https://alphacephei.com/vosk/models/vosk-model-en-us-0.22.zip",
                1800,
                mirrorUrl = "https://huggingface.co/grimso/vosk-models/resolve/main/vosk-model-en-us-0.22.zip"
            )
        )

        // "en" không nằm trong CATALOG - luôn coi là "bundled" (đã đóng gói sẵn trong APK,
        // xem scripts/copy-model-assets.py + assets-for-android/model-en).
        const val BUNDLED_LANG = "en"

        fun modelsDir(context: Context): File = File(context.filesDir, "models")

        fun modelDir(context: Context, lang: String): File = File(modelsDir(context), lang)

        // Dùng lại ở VoskEngine để biết model đã sẵn sàng chưa trước khi start capture.
        fun isDownloaded(context: Context, lang: String): Boolean {
            val dir = modelDir(context, lang)
            return dir.isDirectory && (dir.listFiles()?.isNotEmpty() == true)
        }

        // 15s cũ QUÁ NGẮN cho mạng di động/WiFi chập chờn - chỉ cần khựng >15s giữa chừng
        // (rất dễ xảy ra với model lớn như en-large ~1.8GB tải nhiều phút) là toàn bộ request
        // bị huỷ. Đây là nguyên nhân chính khiến tải hay báo "Lỗi tải - thử lại" dù mạng vẫn
        // dùng bình thường cho việc khác. Tăng lên rộng rãi hơn nhiều.
        const val CONNECT_TIMEOUT_MS = 20_000
        const val READ_TIMEOUT_MS = 60_000
        // Số lần thử TRÊN MỖI NGUỒN (primary/mirror) - không phải tổng số lần thử. Đổi tên từ
        // MAX_ATTEMPTS (4) vì giờ có thể có 2 nguồn (xem mirrorUrl bên dưới): thực tế đã ghi
        // nhận alphacephei.com tự nó đủ chậm/chập chờn để 4 lần thử LIÊN TIẾP CÙNG 1 HOST vẫn
        // fail hết (báo "Lỗi tải - thử lại" dù đã tăng timeout) - tăng số lần thử trên cùng 1
        // host không giải quyết được vấn đề nếu bản thân host đó đang có sự cố, nên hướng đúng
        // là thử sang host KHÁC hẳn thay vì thử lại mãi cùng 1 chỗ.
        const val MAX_ATTEMPTS_PER_SOURCE = 3
    }

    // mirrorUrl: nguồn dự phòng khác host, dùng khi url gốc (alphacephei.com) tải lỗi hết
    // MAX_ATTEMPTS_PER_SOURCE lần - xem downloadWithRetry(). File zip là bản mirror y hệt
    // (cùng tên file, cùng nội dung) đăng lại trên Hugging Face, không phải bản tự đóng gói.
    data class ModelInfo(val displayName: String, val url: String, val sizeMB: Int, val mirrorUrl: String? = null)

    // Theo dõi các lượt tải đang chạy để hỗ trợ cancelDownload() - key = lang.
    private val activeDownloads = mutableMapOf<String, Thread>()

    @PluginMethod
    fun listModels(call: PluginCall) {
        val arr = JSArray()

        val bundledObj = JSObject()
        bundledObj.put("lang", BUNDLED_LANG)
        bundledObj.put("name", "English")
        bundledObj.put("sizeMB", 40)
        bundledObj.put("status", "bundled")
        arr.put(bundledObj)

        for ((lang, info) in CATALOG) {
            val obj = JSObject()
            obj.put("lang", lang)
            obj.put("name", info.displayName)
            obj.put("sizeMB", info.sizeMB)
            obj.put("status", if (isDownloaded(context, lang)) "downloaded" else "not_downloaded")
            arr.put(obj)
        }

        val ret = JSObject()
        ret.put("models", arr)
        call.resolve(ret)
    }

    @PluginMethod
    fun downloadModel(call: PluginCall) {
        val lang = call.getString("lang")
        if (lang.isNullOrBlank()) {
            call.reject("Thiếu tham số lang.")
            return
        }
        val info = CATALOG[lang]
        if (info == null) {
            call.reject("Không có model cho lang=$lang trong catalog.")
            return
        }
        if (isDownloaded(context, lang)) {
            call.resolve(JSObject().apply { put("alreadyDownloaded", true) })
            return
        }
        if (activeDownloads.containsKey(lang)) {
            call.reject("Đang tải model cho lang=$lang rồi, đợi xong hoặc cancelDownload() trước.")
            return
        }

        // Kiểm tra dung lượng trống TRƯỚC khi tải - thiếu dung lượng là nguyên nhân phổ biến
        // gây "Lỗi tải - thử lại" ở model lớn (en-large ~1.8GB) mà RETRY KHÔNG BAO GIỜ tự sửa
        // được (không phải lỗi mạng thoáng qua), khiến vòng lặp downloadWithRetry() cứ chờ
        // backoff rồi thử lại vô ích cả 3 lần x 2 nguồn trước khi báo lỗi (tốn thời gian, và
        // thông báo lỗi cuối cùng thường chỉ là "No space left on device" khó hiểu với user).
        // Cần ~2x sizeMB (zip tải về TẠM + thư mục model giải nén ra, tồn tại song song đến
        // lúc unzip() xong mới xoá zip) + 100MB đệm an toàn.
        val requiredBytes = (info.sizeMB.toLong() * 2 + 100) * 1024 * 1024
        val freeBytes = context.filesDir.usableSpace
        if (freeBytes < requiredBytes) {
            val requiredGB = String.format("%.1f", requiredBytes / 1024.0 / 1024.0 / 1024.0)
            val freeGB = String.format("%.1f", freeBytes / 1024.0 / 1024.0 / 1024.0)
            call.reject("Không đủ dung lượng trống để tải model này (cần khoảng ${requiredGB}GB, máy còn ${freeGB}GB). Hãy giải phóng bớt bộ nhớ rồi thử lại.")
            return
        }

        val targetDir = modelDir(context, lang)
        val tmpZip = File(context.cacheDir, "model-$lang-download.zip")

        // Nguồn gốc trước, mirror (nếu có) sau - xem downloadWithRetry() để biết lúc nào
        // chuyển sang thử nguồn tiếp theo.
        val sources = listOfNotNull(info.url, info.mirrorUrl)

        val t = thread(name = "ModelDownload-$lang") {
            try {
                downloadWithRetry(sources, tmpZip) { downloadedBytes, totalBytes ->
                    emitProgress(lang, downloadedBytes, totalBytes)
                }
                unzip(tmpZip, targetDir)
                tmpZip.delete()

                if (!isDownloaded(context, lang)) {
                    throw IllegalStateException("Giải nén xong nhưng thư mục model rỗng - zip có thể sai cấu trúc.")
                }

                emitDone(lang, success = true, error = null)
            } catch (e: Exception) {
                // Dọn dẹp thư mục model dở dang (giải nén lỗi giữa chừng) để lần tải sau không
                // bị lẫn dữ liệu hỏng. KHÔNG xoá tmpZip ở đây nữa - downloadWithRetry() đã tự lo
                // giữ/xoá tmpZip tuỳ trường hợp (giữ lại để resume nếu còn khả năng thử lại,
                // xoá nếu đã bỏ cuộc hẳn - xem downloadWithRetry()).
                targetDir.deleteRecursively()
                emitDone(lang, success = false, error = e.message ?: e.toString())
            } finally {
                activeDownloads.remove(lang)
            }
        }
        activeDownloads[lang] = t

        // resolve ngay - tiến trình tải chạy nền, JS theo dõi qua sự kiện modelDownloadProgress
        // và modelDownloadDone (giống pattern audioLevel/partialText của AudioCapturePlugin).
        call.resolve(JSObject().apply { put("started", true) })
    }

    @PluginMethod
    fun cancelDownload(call: PluginCall) {
        val lang = call.getString("lang")
        val t = activeDownloads[lang]
        if (t != null) {
            t.interrupt()
            activeDownloads.remove(lang)
        }
        call.resolve()
    }

    @PluginMethod
    fun deleteModel(call: PluginCall) {
        val lang = call.getString("lang")
        if (lang.isNullOrBlank()) {
            call.reject("Thiếu tham số lang.")
            return
        }
        modelDir(context, lang).deleteRecursively()
        call.resolve()
    }

    // Bọc downloadWithProgress() bằng vòng lặp thử lại tự động - lỗi mạng thoáng qua (timeout,
    // mất kết nối giữa chừng...) không còn bắt người dùng tự bấm "Tải về" lại thủ công từng lần.
    // File tải dở (tmpZip) được GIỮ LẠI giữa các lần thử CÙNG 1 NGUỒN (không xoá) để lần thử
    // tiếp theo RESUME tiếp từ chỗ dở dang qua HTTP Range, không tải lại từ đầu - quan trọng
    // nhất với model lớn như en-large (~1.8GB).
    //
    // Nhận DANH SÁCH nguồn (urls) thay vì 1 URL cố định: đã ghi nhận thực tế alphacephei.com tự
    // nó có lúc đủ chậm/chập chờn để MAX_ATTEMPTS_PER_SOURCE lần thử LIÊN TIẾP CÙNG HOST đó vẫn
    // fail hết dù đã tăng timeout rộng rãi - tăng thêm số lần thử trên cùng 1 host không giải
    // quyết được nếu bản thân host đang có sự cố. Nên hết lượt thử ở 1 nguồn thì CHUYỂN SANG
    // NGUỒN KẾ TIẾP (mirror) trong danh sách thay vì tiếp tục thử nguồn cũ.
    private fun downloadWithRetry(urls: List<String>, dest: File, onProgress: (Long, Long) -> Unit) {
        var lastError: Exception? = null
        for ((sourceIndex, urlStr) in urls.withIndex()) {
            // Đổi sang nguồn khác (host khác) thì xoá phần tải dở của nguồn TRƯỚC đi - không
            // chắc 2 host phục vụ byte-for-byte giống hệt nhau (thứ tự nén, chunk...), resume
            // qua Range dựa trên phần dở của host khác có rủi ro nối rác vào file.
            if (sourceIndex > 0 && dest.exists()) dest.delete()

            for (attempt in 1..MAX_ATTEMPTS_PER_SOURCE) {
                try {
                    downloadWithProgress(urlStr, dest, onProgress)
                    return // thành công
                } catch (e: InterruptedException) {
                    dest.delete() // user chủ động huỷ (cancelDownload) - dọn luôn, không giữ lại để resume
                    throw e
                } catch (e: Exception) {
                    // Hết dung lượng GIỮA CHỪNG (vd máy vừa đầy thêm do app khác) - lỗi này
                    // retry/đổi nguồn không sửa được, dừng ngay thay vì lãng phí hết
                    // MAX_ATTEMPTS_PER_SOURCE x số nguồn rồi mới báo lỗi khó hiểu.
                    val msg = e.message?.lowercase() ?: ""
                    if (e is java.io.IOException && (msg.contains("enospc") || msg.contains("no space left"))) {
                        dest.delete()
                        throw IllegalStateException("Hết dung lượng trống trên máy giữa lúc tải - hãy giải phóng bớt bộ nhớ rồi thử lại.")
                    }
                    lastError = e
                    val isLastAttemptOfSource = attempt == MAX_ATTEMPTS_PER_SOURCE
                    val isLastSource = sourceIndex == urls.lastIndex
                    if (!(isLastAttemptOfSource && isLastSource)) {
                        // Backoff tăng dần: 2s, 5s, 10s - đủ để mạng chập chờn có thời gian ổn
                        // định lại mà không bắt người dùng chờ quá lâu giữa các lần thử.
                        val backoffMs = when (attempt) { 1 -> 2000L; 2 -> 5000L; else -> 10000L }
                        Thread.sleep(backoffMs)
                        // Nếu còn thử tiếp CÙNG nguồn này (chưa isLastAttemptOfSource): KHÔNG
                        // xoá dest - giữ lại phần đã tải để resume. Nếu sắp chuyển nguồn (đã hết
                        // lượt thử của nguồn này nhưng còn nguồn khác): việc xoá dest sẽ được xử
                        // lý ở đầu vòng lặp ngoài (sourceIndex > 0) lúc sang nguồn kế tiếp.
                    }
                }
            }
        }
        dest.delete() // hết lượt thử ở MỌI nguồn, dọn file dở dang thật sự bỏ cuộc
        throw lastError ?: IllegalStateException("Tải thất bại không rõ lý do sau khi thử hết ${urls.size} nguồn.")
    }

    private fun downloadWithProgress(urlStr: String, dest: File, onProgress: (Long, Long) -> Unit) {
        // Resume: nếu đã có file tải dở từ lần thử trước (cùng phiên downloadModel(), xem
        // downloadWithRetry()), tiếp tục từ đúng byte đã có bằng header Range - không tải lại
        // từ đầu. Server tĩnh như alphacephei.com/GitHub Releases đều hỗ trợ Range mặc định.
        val alreadyHave = if (dest.exists()) dest.length() else 0L

        val url = URL(urlStr)
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = CONNECT_TIMEOUT_MS
        conn.readTimeout = READ_TIMEOUT_MS
        conn.instanceFollowRedirects = true // GitHub Releases redirect sang S3 - bắt buộc phải theo
        if (alreadyHave > 0) {
            conn.setRequestProperty("Range", "bytes=$alreadyHave-")
        }
        conn.connect()

        val isResuming = alreadyHave > 0 && conn.responseCode == 206
        if (conn.responseCode !in 200..299) {
            throw IllegalStateException("HTTP ${conn.responseCode} khi tải model từ $urlStr")
        }
        // Server không hỗ trợ Range (trả 200 thay vì 206 dù mình có gửi Range) -> nó sẽ gửi lại
        // TOÀN BỘ file từ đầu, nên phải bỏ phần cũ đi để không bị nối rác vào đầu file.
        if (alreadyHave > 0 && !isResuming) {
            dest.delete()
        }

        // totalBytes phải cộng lại phần đã có sẵn khi đang resume, vì Content-Length lúc này
        // chỉ tính phần CÒN LẠI server trả về (theo đúng ngữ nghĩa response 206 Partial Content).
        val remainingBytes = conn.contentLengthLong
        val totalBytes = if (isResuming && remainingBytes > 0) alreadyHave + remainingBytes else remainingBytes
        var downloadedBytes = if (isResuming) alreadyHave else 0L
        var lastEmitAt = 0L

        conn.inputStream.use { input ->
            FileOutputStream(dest, isResuming).use { output -> // append=true khi đang resume
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    if (Thread.currentThread().isInterrupted) throw InterruptedException("Đã huỷ tải model.")
                    val read = input.read(buffer)
                    if (read == -1) break
                    output.write(buffer, 0, read)
                    downloadedBytes += read

                    val now = System.currentTimeMillis()
                    if (now - lastEmitAt >= 300) { // throttle ~3 lần/giây, tránh spam bridge JS
                        onProgress(downloadedBytes, totalBytes)
                        lastEmitAt = now
                    }
                }
            }
        }
        onProgress(downloadedBytes, totalBytes)
    }

    private fun unzip(zipFile: File, targetDir: File) {
        targetDir.deleteRecursively()
        targetDir.mkdirs()

        // Zip gốc tải thẳng từ alphacephei.com bọc mọi thứ trong 1 thư mục cha (vd
        // "vosk-model-en-us-0.22/"), trong khi zip mình tự đóng gói lại (model-vi/ja/ko) thì
        // phẳng, không bọc. Tự phát hiện + bóc lớp đó ra khi giải nén, để catalog dùng được
        // CẢ 2 kiểu zip mà không cần re-zip thủ công từng model.
        val commonPrefix = detectCommonRootPrefix(zipFile)

        ZipInputStream(zipFile.inputStream()).use { zis ->
            var entry: ZipEntry? = zis.nextEntry
            val buffer = ByteArray(64 * 1024)
            while (entry != null) {
                val relativeName = if (commonPrefix != null && entry.name.startsWith(commonPrefix)) {
                    entry.name.substring(commonPrefix.length)
                } else {
                    entry.name
                }
                if (relativeName.isEmpty()) {
                    zis.closeEntry()
                    entry = zis.nextEntry
                    continue
                }

                // Chặn path traversal (zip slip) - phòng trường hợp zip nguồn bị chỉnh sửa độc hại.
                val outFile = File(targetDir, relativeName)
                if (!outFile.canonicalPath.startsWith(targetDir.canonicalPath + File.separator)) {
                    throw SecurityException("Zip entry bất thường: ${entry.name}")
                }
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { out ->
                        var read = zis.read(buffer)
                        while (read != -1) {
                            out.write(buffer, 0, read)
                            read = zis.read(buffer)
                        }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }

    // Đọc qua danh sách tên entry (không giải nén) để tìm xem toàn bộ zip có nằm chung trong
    // đúng 1 thư mục cha hay không. Đọc file zip 2 lần (lần này + lần unzip thật) chấp nhận
    // được vì đây là file cục bộ đã tải xong, không phải đọc lại qua mạng.
    private fun detectCommonRootPrefix(zipFile: File): String? {
        val topLevelDirs = mutableSetOf<String>()
        var hasRootLevelEntry = false
        ZipInputStream(zipFile.inputStream()).use { zis ->
            var entry: ZipEntry? = zis.nextEntry
            while (entry != null) {
                val name = entry.name.trimStart('/')
                val slashIdx = name.indexOf('/')
                if (slashIdx <= 0) {
                    if (name.isNotEmpty()) hasRootLevelEntry = true
                } else {
                    topLevelDirs.add(name.substring(0, slashIdx))
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        return if (!hasRootLevelEntry && topLevelDirs.size == 1) topLevelDirs.first() + "/" else null
    }

    private fun emitProgress(lang: String, downloadedBytes: Long, totalBytes: Long) {
        val data = JSObject()
        data.put("lang", lang)
        data.put("downloadedBytes", downloadedBytes)
        data.put("totalBytes", totalBytes)
        data.put("percent", if (totalBytes > 0) (downloadedBytes * 100 / totalBytes).toInt() else -1)
        notifyListeners("modelDownloadProgress", data)
    }

    private fun emitDone(lang: String, success: Boolean, error: String?) {
        val data = JSObject()
        data.put("lang", lang)
        data.put("success", success)
        if (error != null) data.put("error", error)
        notifyListeners("modelDownloadDone", data)
    }
}
