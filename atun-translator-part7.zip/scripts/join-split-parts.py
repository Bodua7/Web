import os
import re

# Ghép lại các file bị chia nhỏ (assets-for-android/model-en/.../*.partNNN) thành file gốc -
# do model Vosk bundled có vài file quá lớn (Gr.fst ~23MB, HCLr.fst ~21MB, final.mdl ~15MB,
# final.ie ~8MB) không tải lên được qua giao diện GitHub trên di động, nên trước khi đóng gói
# đã cắt các file này thành nhiều mảnh ~5MB (xem tên "<tên gốc>.partNNN", đánh số 000, 001...).
# Chạy script này SAU KHI đã giải nén (unzip -o) hết toàn bộ các part*.zip vào cùng 1 thư mục -
# nó tự tìm mọi file có đuôi ".partNNN", ghép các mảnh cùng gốc lại theo đúng thứ tự số, ghi ra
# file gốc (bỏ đuôi ".partNNN"), rồi xoá các mảnh đã ghép xong.

ROOT = "."
PART_RE = re.compile(r"^(.*)\.part(\d{3})$")

def find_split_groups(root):
    groups = {}  # base_path -> {index: full_path}
    for dirpath, _dirs, files in os.walk(root):
        for fn in files:
            m = PART_RE.match(fn)
            if not m:
                continue
            base_name, idx = m.group(1), int(m.group(2))
            base_path = os.path.join(dirpath, base_name)
            full_path = os.path.join(dirpath, fn)
            groups.setdefault(base_path, {})[idx] = full_path
    return groups

def main():
    groups = find_split_groups(ROOT)
    if not groups:
        print("Không tìm thấy file .partNNN nào - có thể đã ghép xong từ trước, bỏ qua.")
        return

    for base_path, parts in sorted(groups.items()):
        indices = sorted(parts.keys())
        if indices != list(range(len(indices))):
            print(f"CẢNH BÁO: {base_path} thiếu mảnh (có {indices}) - BỎ QUA, kiểm tra lại đã unzip đủ part*.zip chưa.")
            continue
        os.makedirs(os.path.dirname(base_path), exist_ok=True)
        with open(base_path, "wb") as out:
            for i in indices:
                with open(parts[i], "rb") as chunk:
                    out.write(chunk.read())
        for i in indices:
            os.remove(parts[i])
        size_mb = os.path.getsize(base_path) / 1024 / 1024
        print(f"OK: ghép {len(indices)} mảnh -> {base_path} ({size_mb:.1f}MB)")

    print("\n=== Xong ghép file. ===")

if __name__ == "__main__":
    main()
