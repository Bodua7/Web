"""Validate CATALOG trong native/ModelManagerPlugin.kt.

Chạy: cd tests/model_catalog && pip install pytest && pytest -v
Chạy CẢ kiểm tra URL thật (cần internet, nên chạy trong CI): pytest -v -m network
Chỉ chạy kiểm tra tĩnh, bỏ qua kiểm tra mạng (chạy máy cá nhân không có mạng):
    pytest -v -m "not network"

Mục tiêu: bắt lớp bug "entry catalog có URL placeholder/sai/không tồn tại"
NGAY khi push code (CI), thay vì chỉ tình cờ phát hiện lúc bấm tải model trên
máy thật và thấy lỗi 404. Đây chính là bug F đã từng gặp trước đó.

catalog_parser.py đọc THẲNG file .kt thật (không hand-port) - xem docstring
ở đó để biết lý do.
"""

import sys
import urllib.error
import urllib.request
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent))

from catalog_parser import CatalogEntry, get_bundled_lang, parse_catalog  # noqa: E402


# Các chuỗi placeholder/giả hay gặp khi code chưa hoàn thiện (bug F thuộc dạng này) -
# nếu URL chứa bất kỳ chuỗi nào dưới đây (không phân biệt hoa/thường) thì coi là lỗi.
_PLACEHOLDER_MARKERS = [
    "todo",
    "placeholder",
    "changeme",
    "example.com",
    "your-",
    "xxx",
    "fixme",
    "localhost",
    "127.0.0.1",
]

# Danh sách host được tin cậy để host model Vosk - mở rộng danh sách này nếu sau
# này catalog dùng thêm nguồn khác (vd tự host trên GitHub Releases của repo).
_TRUSTED_HOSTS = [
    "alphacephei.com",
    "github.com",
    "githubusercontent.com",
    "objects.githubusercontent.com",
]


@pytest.fixture(scope="module")
def catalog() -> list[CatalogEntry]:
    return parse_catalog()


# ===== Kiểm tra tĩnh - luôn chạy, không cần mạng ===== #

def test_catalog_is_not_empty(catalog):
    assert len(catalog) > 0


def test_no_duplicate_lang_keys(catalog):
    langs = [e.lang for e in catalog]
    assert len(langs) == len(set(langs)), f"Có lang trùng lặp trong CATALOG: {langs}"


def test_bundled_lang_not_in_catalog(catalog):
    bundled = get_bundled_lang()
    langs = [e.lang for e in catalog]
    assert bundled not in langs, (
        f"BUNDLED_LANG={bundled!r} không nên nằm trong CATALOG (đã bundle sẵn trong APK, "
        "không cần tải)."
    )


@pytest.mark.parametrize("field", ["lang", "name", "url"])
def test_no_blank_fields(catalog, field):
    for e in catalog:
        value = getattr(e, field)
        assert value and value.strip(), f"Entry lang={e.lang!r} có field {field!r} rỗng."


def test_urls_use_https(catalog):
    for e in catalog:
        assert e.url.startswith("https://"), (
            f"Entry lang={e.lang!r} có URL không dùng https://: {e.url}"
        )


def test_urls_end_with_zip(catalog):
    for e in catalog:
        assert e.url.endswith(".zip"), (
            f"Entry lang={e.lang!r} có URL không kết thúc bằng .zip (model Vosk luôn là "
            f"file zip): {e.url}"
        )


def test_urls_have_no_placeholder_markers(catalog):
    for e in catalog:
        lowered = e.url.lower()
        for marker in _PLACEHOLDER_MARKERS:
            assert marker not in lowered, (
                f"Entry lang={e.lang!r} có URL chứa chuỗi placeholder {marker!r} - đây "
                f"chính là lớp bug F đã gặp trước đó: {e.url}"
            )


def test_urls_use_trusted_host(catalog):
    for e in catalog:
        host_ok = any(trusted in e.url for trusted in _TRUSTED_HOSTS)
        assert host_ok, (
            f"Entry lang={e.lang!r} dùng host không nằm trong danh sách tin cậy "
            f"({_TRUSTED_HOSTS}): {e.url}\n"
            "Nếu đây là host mới hợp lệ, thêm vào _TRUSTED_HOSTS trong test này."
        )


def test_size_mb_is_sane(catalog):
    for e in catalog:
        assert 0 < e.size_mb <= 5000, (
            f"Entry lang={e.lang!r} có sizeMB={e.size_mb} bất thường (0 hoặc >5000MB, "
            "có thể gõ nhầm số 0 hoặc thiếu chữ số)."
        )


def test_lang_keys_look_like_lang_codes(catalog):
    for e in catalog:
        # vd "vi", "ja", "ko", "en-large" - 2-3 chữ thường, có thể kèm "-<hậu tố>"
        assert e.lang[:2].isalpha() and e.lang[:2].islower(), (
            f"lang={e.lang!r} không giống mã ngôn ngữ hợp lệ (phải bắt đầu bằng 2 chữ "
            "thường, vd 'vi', 'ja', 'en-large')."
        )


# ===== Kiểm tra mạng thật - chỉ chạy khi có -m network (khuyến khích chạy trong CI) ===== #


@pytest.mark.network
def test_urls_are_actually_reachable(catalog):
    """HEAD request thật tới từng URL - bắt được URL 404/sai domain mà kiểm tra tĩnh
    ở trên không thể phát hiện (vd domain đúng format nhưng model đã bị gỡ/đổi tên).

    Dùng HEAD (không GET) để không phải tải cả model - 1 số model trong catalog
    nặng tới ~1.8GB (en-large), GET thật sẽ rất chậm/tốn băng thông CI.
    """
    failures: list[str] = []
    for e in catalog:
        req = urllib.request.Request(e.url, method="HEAD")
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                status = resp.status
                if not (200 <= status < 400):
                    failures.append(f"{e.lang} ({e.url}): HTTP {status}")
        except urllib.error.HTTPError as err:
            # Server trả lời thật nhưng bằng mã lỗi (vd 404) - đây LÀ bug thật, không skip.
            failures.append(f"{e.lang} ({e.url}): HTTP {err.code}")
        except urllib.error.URLError as err:
            # Không kết nối được (DNS/timeout/không có mạng trong môi trường chạy test) -
            # không đủ căn cứ kết luận URL sai, skip thay vì fail để tránh CI flaky vì lý
            # do ngoài tầm kiểm soát (vd sandbox không có internet).
            pytest.skip(f"Không kết nối được để kiểm tra mạng thật ({err}) - bỏ qua test này.")

    assert not failures, "Các URL sau không truy cập được:\n" + "\n".join(failures)
