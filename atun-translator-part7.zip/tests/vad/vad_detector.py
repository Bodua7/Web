"""Port thuần Python của native/VadDetector.kt.

MỤC ĐÍCH: cho phép test logic VAD (ngưỡng, hysteresis, hangover, tốc độ thích
nghi noise floor...) bằng pytest chạy trên máy tính thường, KHÔNG cần build
APK + cài lên điện thoại thật mỗi lần đổi 1 hằng số. Cùng cách tiếp cận đã
dùng cho VietnameseTelexKeyboard (Telex11): port logic gốc sang Python, giữ
đúng công thức/thứ tự phép tính, rồi viết test cho bản Python đó.

QUAN TRỌNG - giữ đồng bộ 2 chiều:
Đây là bản dịch tay từ Kotlin, KHÔNG phải import trực tiếp. Mỗi khi sửa
native/VadDetector.kt (đổi hằng số, đổi công thức, thêm state...), phải cập
nhật lại file này cho khớp, nếu không test ở đây sẽ pass/fail sai lệch so với
hành vi thật trên app. Coi các hằng số bên dưới là bản sao 1-1 của companion
object trong file .kt gốc.
"""

from __future__ import annotations

import math
from dataclasses import dataclass


# ===== Hằng số - COPY Y HỆT companion object trong native/VadDetector.kt ===== #
NOISE_ADAPT_RATE = 0.05
ENTER_SPEECH_RATIO = 2.5
EXIT_SPEECH_RATIO = 1.6
MIN_NOISE_FLOOR = 30.0
HANGOVER_FRAMES = 4

# Giá trị khởi tạo noiseFloor - khớp `private var noiseFloor = 200.0` trong .kt
INITIAL_NOISE_FLOOR = 200.0


@dataclass
class VadDebugInfo:
    """Thông tin nội bộ tại 1 khung, phục vụ test/assert chi tiết hơn giá trị
    is_voice trả về từ process() - .kt gốc không expose các giá trị này ra
    ngoài, nhưng ở bản Python thì tiện để kiểm tra khi viết test/tune ngưỡng."""

    rms: float
    noise_floor: float
    enter_threshold: float
    exit_threshold: float
    is_voice: bool
    hangover_counter: int


class VadDetector:
    """Dịch 1-1 từ class VadDetector trong native/VadDetector.kt.

    Khác biệt duy nhất so với bản Kotlin: process() nhận thẳng list/array
    số thực đại diện cho mẫu PCM16 (không cần ShortArray + length riêng vì
    Python không cần khai báo kiểu mảng cố định); dùng len(samples) thay
    cho tham số `length`.
    """

    def __init__(self) -> None:
        self.noise_floor = INITIAL_NOISE_FLOOR
        self.is_voice = False
        self.hangover_counter = 0

    def process(self, samples) -> bool:
        length = len(samples)
        if length <= 0:
            return self.is_voice

        sum_squares = 0.0
        for i in range(length):
            v = float(samples[i])
            sum_squares += v * v
        rms = math.sqrt(sum_squares / length)

        enter_threshold = max(
            self.noise_floor * ENTER_SPEECH_RATIO,
            MIN_NOISE_FLOOR * ENTER_SPEECH_RATIO,
        )
        exit_threshold = max(
            self.noise_floor * EXIT_SPEECH_RATIO,
            MIN_NOISE_FLOOR * EXIT_SPEECH_RATIO,
        )

        if not self.is_voice:
            if rms > enter_threshold:
                self.is_voice = True
                self.hangover_counter = HANGOVER_FRAMES
            else:
                self.noise_floor += (rms - self.noise_floor) * NOISE_ADAPT_RATE
        else:
            if rms > exit_threshold:
                self.hangover_counter = HANGOVER_FRAMES
            elif self.hangover_counter > 0:
                self.hangover_counter -= 1
            else:
                self.is_voice = False

        return self.is_voice

    def process_debug(self, samples) -> VadDebugInfo:
        """Như process(), nhưng trả về toàn bộ state nội bộ - tiện cho test
        muốn assert riêng noise_floor/threshold thay vì chỉ true/false."""
        length = len(samples)
        rms = 0.0
        if length > 0:
            sum_squares = sum(float(s) * float(s) for s in samples)
            rms = math.sqrt(sum_squares / length)

        is_voice = self.process(samples)
        enter_threshold = max(
            self.noise_floor * ENTER_SPEECH_RATIO,
            MIN_NOISE_FLOOR * ENTER_SPEECH_RATIO,
        )
        exit_threshold = max(
            self.noise_floor * EXIT_SPEECH_RATIO,
            MIN_NOISE_FLOOR * EXIT_SPEECH_RATIO,
        )
        return VadDebugInfo(
            rms=rms,
            noise_floor=self.noise_floor,
            enter_threshold=enter_threshold,
            exit_threshold=exit_threshold,
            is_voice=is_voice,
            hangover_counter=self.hangover_counter,
        )

    def reset(self) -> None:
        self.noise_floor = INITIAL_NOISE_FLOOR
        self.is_voice = False
        self.hangover_counter = 0
