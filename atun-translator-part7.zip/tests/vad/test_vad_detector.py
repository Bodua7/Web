"""Test cho VadDetector (bản port Python của native/VadDetector.kt).

Chạy: cd tests/vad && pip install pytest && pytest -v

Mục tiêu: bắt được ngay lập tức khi đổi 1 hằng số (ENTER_SPEECH_RATIO,
HANGOVER_FRAMES...) làm hỏng hành vi mong đợi, thay vì chỉ phát hiện sau khi
cài APK lên máy thật rồi nói vào mic thử.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from vad_detector import (  # noqa: E402
    VadDetector,
    ENTER_SPEECH_RATIO,
    EXIT_SPEECH_RATIO,
    MIN_NOISE_FLOOR,
    HANGOVER_FRAMES,
    NOISE_ADAPT_RATE,
    INITIAL_NOISE_FLOOR,
)
from signal_gen import (  # noqa: E402
    sine_frame,
    noise_frame,
    silence_frame,
    ramp_rms,
    FRAME_LEN,
)


# ===== Khởi tạo & reset ===== #

def test_initial_state_is_silence():
    vad = VadDetector()
    assert vad.is_voice is False
    assert vad.noise_floor == INITIAL_NOISE_FLOOR
    assert vad.hangover_counter == 0


def test_reset_restores_initial_state():
    vad = VadDetector()
    # Đẩy vào trạng thái voice trước.
    for _ in range(5):
        vad.process(sine_frame(1000))
    assert vad.is_voice is True

    vad.reset()
    assert vad.is_voice is False
    assert vad.noise_floor == INITIAL_NOISE_FLOOR
    assert vad.hangover_counter == 0


def test_zero_length_frame_returns_current_state_unchanged():
    vad = VadDetector()
    before = vad.is_voice
    result = vad.process([])
    assert result == before
    assert vad.noise_floor == INITIAL_NOISE_FLOOR  # không update gì cả


# ===== Thích nghi noise floor lúc im lặng ===== #

def test_noise_floor_adapts_toward_quiet_signal():
    vad = VadDetector()
    # noiseFloor khởi tạo 200.0, đưa nhiễu nền thật ~40 vào nhiều khung liên
    # tiếp -> noiseFloor phải trôi dần XUỐNG gần 40 (EMA, alpha=0.05).
    for _ in range(200):
        vad.process(noise_frame(40, seed=1))
    assert 30 < vad.noise_floor < 60, (
        f"noise_floor={vad.noise_floor} chưa hội tụ về gần mức nhiễu nền thật (~40)"
    )
    assert vad.is_voice is False


def test_noise_floor_does_not_update_while_in_voice_state():
    vad = VadDetector()
    # Hội tụ noise floor về mức thấp trước.
    for _ in range(100):
        vad.process(noise_frame(40, seed=2))
    floor_before_speech = vad.noise_floor

    # Nói to liên tục nhiều khung - noise_floor phải ĐỨNG YÊN trong lúc này,
    # theo đúng comment gốc: "CHỈ cập nhật lúc im lặng".
    for _ in range(50):
        vad.process(sine_frame(500))
    assert vad.noise_floor == floor_before_speech


def test_min_noise_floor_enforced_even_after_absolute_silence():
    vad = VadDetector()
    # Im lặng số tuyệt đối (RMS=0) rất nhiều khung - noiseFloor sẽ trôi dần
    # về gần 0 (EMA đuổi theo rms=0), nhưng ngưỡng vào tiếng nói vẫn phải bị
    # chặn dưới bởi MIN_NOISE_FLOOR * ENTER_SPEECH_RATIO, không được tụt theo.
    for _ in range(500):
        vad.process(silence_frame())
    assert vad.noise_floor < MIN_NOISE_FLOOR  # noise floor thật sự tụt rất thấp...

    info = vad.process_debug(silence_frame())
    expected_min_enter = MIN_NOISE_FLOOR * ENTER_SPEECH_RATIO
    assert info.enter_threshold == expected_min_enter, (
        "enter_threshold phải bị chặn dưới bởi MIN_NOISE_FLOOR*ENTER_SPEECH_RATIO "
        "kể cả khi noise_floor thực tế đã tụt thấp hơn MIN_NOISE_FLOOR"
    )


# ===== Vào tiếng nói (enter) ===== #

def test_loud_signal_triggers_voice_from_default_state():
    vad = VadDetector()
    # noiseFloor mặc định 200 -> enterThreshold = 200*2.5 = 500. Tín hiệu 2000
    # phải kích hoạt voice ngay khung đầu tiên.
    result = vad.process(sine_frame(2000))
    assert result is True
    assert vad.is_voice is True
    assert vad.hangover_counter == HANGOVER_FRAMES


def test_quiet_signal_at_default_floor_does_not_trigger_voice():
    vad = VadDetector()
    # RMS thấp hơn nhiều so với enterThreshold=500 -> vẫn im lặng, chỉ cập
    # nhật noise floor.
    result = vad.process(sine_frame(60))
    assert result is False
    assert vad.is_voice is False


def test_enter_speech_after_noise_floor_converges_low():
    vad = VadDetector()
    # Hội tụ về nhiễu nền thấp (~35) trước - giống phòng yên tĩnh.
    for _ in range(200):
        vad.process(noise_frame(35, seed=3))
    floor = vad.noise_floor
    enter_threshold = max(floor * ENTER_SPEECH_RATIO, MIN_NOISE_FLOOR * ENTER_SPEECH_RATIO)

    # Giọng nói vừa đủ vượt enterThreshold một chút.
    result = vad.process(sine_frame(enter_threshold * 1.2))
    assert result is True


# ===== Hysteresis: không "rung" quanh biên ===== #

def test_no_flicker_when_hovering_between_exit_and_enter_threshold():
    vad = VadDetector()
    # Đẩy vào voice trước bằng tín hiệu to.
    vad.process(sine_frame(2000))
    assert vad.is_voice is True

    # noiseFloor mặc định 200 -> enter=500, exit=320. Tín hiệu ở mức 400 nằm
    # GIỮA exit và enter: nếu đã đang voice thì phải VẪN giữ voice (refresh
    # hangover) chứ không tắt, vì 400 > exitThreshold=320.
    for _ in range(10):
        result = vad.process(sine_frame(400))
        assert result is True, "Không được flicker về false khi RMS nằm giữa exit và enter"


def test_energy_just_above_min_floor_enter_does_not_trigger_from_high_floor():
    vad = VadDetector()
    # noiseFloor mặc định 200 -> enterThreshold=500 (cao hơn MIN_NOISE_FLOOR*2.5=75).
    # Tín hiệu 100 (> MIN*ENTER=75 nhưng < 500) KHÔNG được kích hoạt voice,
    # vì ngưỡng thực tế dùng max(noiseFloor*ratio, MIN*ratio) = 500 ở đây.
    result = vad.process(sine_frame(100))
    assert result is False


# ===== Hangover: giữ voice thêm vài khung khi tắt dần ===== #

def test_hangover_keeps_voice_for_exact_frame_count_then_drops():
    vad = VadDetector()
    vad.process(sine_frame(2000))  # vào voice, hangover_counter = HANGOVER_FRAMES
    assert vad.is_voice is True

    # Tín hiệu tụt xuống dưới exitThreshold đột ngột (giả lập nói dừng hẳn).
    # Phải còn giữ voice=True đúng HANGOVER_FRAMES khung tiếp theo, khung sau
    # đó mới chuyển về False.
    results = [vad.process(silence_frame()) for _ in range(HANGOVER_FRAMES)]
    assert all(results), (
        f"Phải giữ voice=True suốt {HANGOVER_FRAMES} khung hangover, "
        f"thực tế: {results}"
    )

    final = vad.process(silence_frame())
    assert final is False, "Sau khi hết hangover phải chuyển về voice=False"


def test_hangover_resets_if_voice_resumes_before_it_expires():
    vad = VadDetector()
    vad.process(sine_frame(2000))
    assert vad.is_voice is True

    # Tụt xuống 2 khung (chưa hết hangover=4)...
    vad.process(silence_frame())
    vad.process(silence_frame())
    assert vad.hangover_counter == HANGOVER_FRAMES - 2

    # ...rồi nói to lại - hangover phải được REFRESH về đầy, không tắt giữa chừng.
    vad.process(sine_frame(2000))
    assert vad.hangover_counter == HANGOVER_FRAMES
    assert vad.is_voice is True


def test_gradual_fade_out_still_ends_via_hangover_not_abrupt_cut():
    """Mô phỏng đúng lo ngại nêu trong comment gốc: 'âm cuối từ/câu thường
    nhỏ dần từ từ chứ không tắt đột ngột'. Kiểm tra câu nói fade-out dần vẫn
    không bị cắt cụt ngay khung đầu tiên RMS tụt dưới exitThreshold."""
    vad = VadDetector()
    vad.process(sine_frame(2000))
    assert vad.is_voice is True

    fade_frames = ramp_rms(start_rms=250, end_rms=0, num_frames=8)
    voice_flags = [vad.process(f) for f in fade_frames]

    # Không được tắt ngay ở khung fade đầu tiên - phải còn ít nhất vài khung
    # True nhờ hangover trước khi chuyển hẳn về False.
    assert voice_flags[0] is True
    assert False in voice_flags, "Cuối chuỗi fade-out cuối cùng vẫn phải tắt về false"


# ===== Kịch bản thực tế end-to-end ===== #

def test_realistic_session_silence_then_speech_then_silence():
    """Mô phỏng 1 phiên nghe thật: im lặng nền -> có người nói -> im lặng lại,
    kiểm tra is_voice bám đúng hình dạng mong đợi theo thời gian."""
    vad = VadDetector()

    # 1) 1s im lặng nền (~50 khung @ 20ms) để hội tụ noise floor.
    silence_flags = [vad.process(noise_frame(45, seed=i)) for i in range(50)]
    assert not any(silence_flags), "Không được báo voice=True trong đoạn im lặng nền"

    # 2) Giọng nói to rõ ràng trong 1s.
    speech_flags = [vad.process(sine_frame(1500)) for _ in range(50)]
    assert all(speech_flags), "Phải nhận diện voice=True suốt đoạn nói to"

    # 3) Im lặng trở lại - phải tắt voice trong vòng vài khung (hangover),
    # không được "kẹt" mãi ở True.
    tail_flags = [vad.process(noise_frame(45, seed=100 + i)) for i in range(20)]
    assert tail_flags[-1] is False, "Voice phải tắt hẳn sau khi im lặng đủ lâu"
