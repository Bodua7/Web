"""Sinh khung audio PCM16 giả lập (list[int]) để feed vào VadDetector.process()
trong test, không cần file .wav thật.

VadDetector chỉ quan tâm RMS của khung, không quan tâm hình dạng sóng, nên
dùng sóng sin biên độ cố định là đủ để mô phỏng "im lặng có nhiễu nền biên độ
X" hay "giọng nói biên độ Y" - RMS của sin biên độ A xấp xỉ A/sqrt(2), các
hàm bên dưới tự quy đổi ngược để bạn truyền thẳng "RMS mong muốn" cho dễ
đọc test, thay vì phải tự nhân sqrt(2) mỗi lần viết test case mới.
"""

from __future__ import annotations

import math
import random


FRAME_LEN = 320  # ~20ms @ 16kHz, giống cỡ khung AudioRecord.read() điển hình


def sine_frame(target_rms: float, frame_len: int = FRAME_LEN, freq_hz: float = 300.0,
               sample_rate: int = 16000, phase: float = 0.0):
    """1 khung sóng sin cho RMS xấp xỉ target_rms. Dùng để mô phỏng tín hiệu
    ổn định (giọng nói đều, hoặc nhiễu nền động cơ/quạt có tần số khá cố định)."""
    amplitude = target_rms * math.sqrt(2)
    return [
        amplitude * math.sin(2 * math.pi * freq_hz * i / sample_rate + phase)
        for i in range(frame_len)
    ]


def noise_frame(target_rms: float, frame_len: int = FRAME_LEN, seed: int | None = None):
    """1 khung nhiễu trắng ngẫu nhiên cho RMS xấp xỉ target_rms. Dùng để mô
    phỏng nhiễu nền thật (không đều đặn như sin) - vd. tiếng quạt/đường phố."""
    rng = random.Random(seed)
    # Uniform(-a, a) có RMS = a/sqrt(3) -> quy đổi ngược để đạt target_rms.
    a = target_rms * math.sqrt(3)
    return [rng.uniform(-a, a) for _ in range(frame_len)]


def silence_frame(frame_len: int = FRAME_LEN):
    """Im lặng tuyệt đối (RMS = 0) - trường hợp biên MIN_NOISE_FLOOR phải xử lý."""
    return [0.0] * frame_len


def ramp_rms(start_rms: float, end_rms: float, num_frames: int, frame_len: int = FRAME_LEN,
              kind: str = "sine"):
    """Sinh 1 chuỗi num_frames khung, RMS tăng/giảm tuyến tính từ start_rms
    đến end_rms - mô phỏng câu nói tắt dần cuối câu (kiểm tra hangover) hoặc
    tiếng ồn nền tăng dần."""
    gen = sine_frame if kind == "sine" else noise_frame
    frames = []
    for i in range(num_frames):
        t = i / max(1, num_frames - 1)
        rms = start_rms + (end_rms - start_rms) * t
        frames.append(gen(rms, frame_len))
    return frames
