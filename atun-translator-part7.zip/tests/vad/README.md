# Test harness cho VadDetector (Hạng mục E)

Port thuần Python của `native/VadDetector.kt`, để test ngưỡng/hysteresis/
hangover/tốc độ thích nghi noise floor **không cần build APK + cài máy thật**.

## Chạy test

```bash
cd tests/vad
pip install pytest
pytest -v
```

## Cấu trúc

- `vad_detector.py` — bản dịch tay 1-1 từ `VadDetector.kt` (cùng hằng số,
  cùng công thức, cùng thứ tự phép tính). Có thêm `process_debug()` để lấy
  noise_floor/threshold nội bộ phục vụ assert chi tiết (bản Kotlin gốc không
  cần expose ra ngoài vì chỉ Vosk pipeline dùng `process()` trả `Boolean`).
- `signal_gen.py` — sinh khung audio giả lập (sin ổn định, nhiễu trắng ngẫu
  nhiên, im lặng tuyệt đối, fade tuyến tính) theo RMS mong muốn, để feed vào
  `VadDetector.process()` mà không cần file `.wav` thật.
- `test_vad_detector.py` — 15 test case bao phủ: khởi tạo/reset, thích nghi
  noise floor lúc im lặng (và KHÔNG thích nghi lúc đang voice), chặn dưới
  `MIN_NOISE_FLOOR`, vào tiếng nói (enter), hysteresis (không rung ở vùng
  giữa exit/enter), hangover (giữ đúng số khung, refresh nếu nói lại giữa
  chừng, không cắt cụt khi fade-out dần), và 1 kịch bản end-to-end im lặng →
  nói → im lặng.

## ⚠️ Bắt buộc giữ đồng bộ

File `vad_detector.py` là bản dịch **tay**, không phải import trực tiếp từ
Kotlin. Mỗi khi sửa `native/VadDetector.kt` (đổi hằng số như
`ENTER_SPEECH_RATIO`, `HANGOVER_FRAMES`, đổi công thức RMS, thêm state mới...)
thì phải sửa lại `vad_detector.py` cho khớp, rồi chạy lại `pytest` để biết
thay đổi đó ảnh hưởng gì đến hành vi (vd. đổi `HANGOVER_FRAMES` từ 4 xuống 2
sẽ khiến `test_hangover_keeps_voice_for_exact_frame_count_then_drops` fail
ngay, cho biết cần cập nhật lại kỳ vọng test hoặc lùi lại thay đổi).

## Dùng để tune ngưỡng mới

Muốn thử 1 bộ hằng số khác (vd. hạ `ENTER_SPEECH_RATIO` vì VAD đang bỏ sót
giọng nói nhỏ), sửa trực tiếp các hằng số đầu `vad_detector.py`, chạy
`pytest -v` để xem test nào fail — đó chính là hành vi sẽ thay đổi trên máy
thật, xem trước được mà không cần cài APK. Khi đã chốt được bộ hằng số ưng ý,
áp lại đúng giá trị đó vào `native/VadDetector.kt`.
