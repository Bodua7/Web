package com.atun.translator

// Danh sách domain quảng cáo/tracker để chặn trong "web mini" (BrowserActivity) - KHÔNG phải
// danh sách đầy đủ kiểu EasyList/AdAway (hàng chục nghìn dòng, nặng và khó bảo trì trong code
// Kotlin thuần) mà chỉ ~45 domain quảng cáo/tracker phổ biến nhất, đủ chặn phần lớn
// banner/pop-up/tracker trên các trang thường gặp. Chỉ chọn domain CHUYÊN DỤNG cho quảng cáo/
// tracking (không phải domain đa năng như facebook.com/amazon.com - chặn cả domain đó sẽ chặn
// luôn nội dung chính hợp lệ của trang, phản tác dụng).
object AdBlockList {
    private val BLOCKED_DOMAINS = setOf(
        // Google Ads / DoubleClick / phân tích
        "doubleclick.net",
        "googlesyndication.com",
        "googleadservices.com",
        "google-analytics.com",
        "googletagmanager.com",
        "googletagservices.com",
        "adservice.google.com",
        // Ad network / tracker phổ biến khác
        "adnxs.com",
        "taboola.com",
        "outbrain.com",
        "criteo.com",
        "criteo.net",
        "media.net",
        "adroll.com",
        "advertising.com",
        "adsrvr.org",
        "rubiconproject.com",
        "pubmatic.com",
        "openx.net",
        "casalemedia.com",
        "smartadserver.com",
        "moatads.com",
        "scorecardresearch.com",
        "quantserve.com",
        "adform.net",
        "bidswitch.net",
        "yieldmo.com",
        "sharethrough.com",
        "revcontent.com",
        "mgid.com",
        "propellerads.com",
        "popads.net",
        "exoclick.com",
        "adcolony.com",
        "applovin.com",
        "vungle.com",
        "chartboost.com",
        "inmobi.com",
        "adcash.com",
        "bidvertiser.com",
        "zedo.com",
        "3lift.com",
        "amazon-adsystem.com",
        "contextweb.com",
        "indexexchange.com",
        "spotxchange.com",
        "teads.tv"
    )

    // So khớp CHÍNH XÁC hoặc subdomain (vd "pagead2.googlesyndication.com" khớp nhờ endsWith
    // ".googlesyndication.com") - không dùng "contains" để tránh khớp nhầm domain lạ chỉ tình
    // cờ chứa chuỗi con giống tên 1 domain quảng cáo.
    fun isBlocked(host: String?): Boolean {
        if (host.isNullOrBlank()) return false
        val h = host.lowercase()
        return BLOCKED_DOMAINS.any { h == it || h.endsWith(".$it") }
    }
}
