package com.atun.translator

import android.content.Context
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import kotlin.concurrent.thread

// Quản lý TOÀN BỘ model Vosk - tải zip trực tiếp từ URL chính chủ alphacephei.com (xem
// CATALOG), giải nén vào filesDir/models/<lang>/, dùng trực tiếp bằng Model(path) (xem
// VoskEngine.resolveModelSource).
//
// Trước đây "en" (small) được bundle sẵn trong APK (assets-for-android/model-en) để có model
// dùng ngay không cần tải - nhưng model Vosk kể cả bản "small" cũng ~40MB, các file nhị phân
// bên trong (Gr.fst/HCLr.fst/final.mdl/final.ie) quá lớn để commit/tải lên qua giao diện
// GitHub trên di động (phải cắt mảnh .partNNN rất bất tiện mỗi lần cập nhật, xem lịch sử
// scripts/join-split-parts.py). Giờ "en" cũng tải on-demand giống mọi ngôn ngữ khác - đổi lại
// APK nhẹ hơn nhiều và repo không còn file lớn nào phải cắt mảnh, nhưng người dùng phải tải
// model tiếng Anh lần đầu trước khi dùng (thay vì có sẵn ngay sau khi cài).
@CapacitorPlugin(name = "ModelManager")
class ModelManagerPlugin : com.getcapacitor.Plugin() {

    companion object {
        // Dùng thẳng model chính chủ từ alphacephei.com (giống cách "en-large" bên dưới đã
        // làm) thay vì tự nén lại rồi tự host trên GitHub Releases của repo này - tránh phải
        // tự tải về máy, nén .zip, tạo GitHub Release, upload thủ công mỗi khi cần thêm/đổi
        // model. unzip() bên dưới đã tự phát hiện + bóc lớp thư mục cha mà các zip gốc của
        // alphacephei hay bọc ngoài (vd "vosk-model-small-vn-0.4/"), nên dùng thẳng URL gốc
        // không cần xử lý gì thêm.
        // sizeMB lấy đúng theo trang https://alphacephei.com/vosk/models - chỉ để hiển thị
        // ước lượng cho UI trước khi tải, không ảnh hưởng logic.
        val CATALOG: Map<String, ModelInfo> = mapOf(
            // "en" (small): trước đây bundle sẵn trong APK, giờ tải on-demand như mọi ngôn ngữ
            // khác (xem ghi chú ở đầu file) - đặt lên đầu CATALOG vì là ngôn ngữ dùng nhiều nhất.
            "en" to ModelInfo(
                "English",
                "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip",
                40,
                mirrorUrl = "https://huggingface.co/localstack/vosk-models/resolve/main/vosk-model-small-en-us-0.15.zip"
            ),
            "vi" to ModelInfo(
                "Tiếng Việt",
                "https://alphacephei.com/vosk/models/vosk-model-small-vn-0.4.zip",
                32,
                mirrorUrl = "https://huggingface.co/localstack/vosk-models/resolve/main/vosk-model-small-vn-0.4.zip"
            ),
            "ja" to ModelInfo(
                "日本語",
                "https://alphacephei.com/vosk/models/vosk-model-small-ja-0.22.zip",
                48,
                mirrorUrl = "https://huggingface.co/localstack/vosk-models/resolve/main/vosk-model-small-ja-0.22.zip"
            ),
            "ko" to ModelInfo(
                "한국어",
                "https://alphacephei.com/vosk/models/vosk-model-small-ko-0.22.zip",
                82,
                mirrorUrl = "https://huggingface.co/localstack/vosk-models/resolve/main/vosk-model-small-ko-0.22.zip"
            ),
            // Model tiếng Anh MỨC TRUNG - cùng acoustic model với "en-large" (chính xác gần
            // tương đương) nhưng dùng "lgraph" (dynamic/pruned language graph, tự mở rộng lúc
            // decode) thay vì graph tĩnh khổng lồ được nén sẵn toàn bộ -> chỉ ~128MB, nhẹ hơn
            // en-large ~14 lần, đỡ áp lực RAM hẳn khi load (không đảm bảo tuyệt đối không bao
            // giờ bị kill trên máy RAM rất thấp, nhưng khả năng cao hơn nhiều so với 1.8GB).
            // Đánh đổi: decode graph động chậm hơn graph tĩnh 1 chút (thường không đáng kể trên
            // di động hiện đại), không có mirror riêng (chưa xác minh mirror HuggingFace nào).
            "en-lgraph" to ModelInfo(
                "English (khá chính xác, nhẹ hơn)",
                "https://alphacephei.com/vosk/models/vosk-model-en-us-0.22-lgraph.zip",
                128
            ),
            // Model tiếng Anh LỚN, chính xác cao hơn hẳn bản "en" bundled (~40MB, WER thấp hơn
            // nhiều so với model small). Cùng cơ chế tải trực tiếp từ URL chính chủ Alphacephei
            // như vi/ja/ko ở trên - zip này cũng bọc 1 lớp thư mục cha "vosk-model-en-us-0.22/"
            // mà unzip() tự bóc ra. Cảnh báo: ~1.8GB, chỉ nên tải qua Wi-Fi.
            "en-large" to ModelInfo(
                "English (chính xác cao)",
                "https://alphacephei.com/vosk/models/vosk-model-en-us-0.22.zip",
                1800,
                mirrorUrl = "https://huggingface.co/grimso/vosk-models/resolve/main/vosk-model-en-us-0.22.zip"
            ),
            // ===== Mở rộng "đầy đủ" theo đúng danh sách chính thức tại alphacephei.com/vosk/models
            // (đọc trực tiếp từ trang đó, không đoán mò tên file) - mỗi ngôn ngữ dùng bản "small"
            // nếu có (ưu tiên cho di động, ~30-100MB), chỉ dùng bản lớn khi ngôn ngữ đó KHÔNG có
            // bản small nào (vd Ả Rập, Hy Lạp, Filipino, Thuỵ Điển) - các trường hợp này sizeMB
            // > 250 nên UI (www/index.html) tự hiện cảnh báo khuyên tải qua Wi-Fi giống en-large,
            // không cần đánh dấu cờ riêng trong data class. KHÔNG có mirrorUrl (chỉ nguồn chính
            // chủ) - không tự đoán/tạo mirror HuggingFace cho từng ngôn ngữ vì không xác minh được
            // các repo đó có thật hay còn tồn tại, khác 4 model phía trên đã được xác minh sẵn.
            "en-in" to ModelInfo("English (Ấn Độ)", "https://alphacephei.com/vosk/models/vosk-model-small-en-in-0.4.zip", 36),
            "zh" to ModelInfo("中文 (Trung Quốc)", "https://alphacephei.com/vosk/models/vosk-model-small-cn-0.22.zip", 42),
            "ru" to ModelInfo("Русский (Nga)", "https://alphacephei.com/vosk/models/vosk-model-small-ru-0.22.zip", 45),
            "fr" to ModelInfo("Français (Pháp)", "https://alphacephei.com/vosk/models/vosk-model-small-fr-0.22.zip", 41),
            "de" to ModelInfo("Deutsch (Đức)", "https://alphacephei.com/vosk/models/vosk-model-small-de-0.15.zip", 45),
            "es" to ModelInfo("Español (Tây Ban Nha)", "https://alphacephei.com/vosk/models/vosk-model-small-es-0.42.zip", 39),
            "pt" to ModelInfo("Português (Bồ Đào Nha)", "https://alphacephei.com/vosk/models/vosk-model-small-pt-0.3.zip", 31),
            "tr" to ModelInfo("Türkçe (Thổ Nhĩ Kỳ)", "https://alphacephei.com/vosk/models/vosk-model-small-tr-0.3.zip", 35),
            "it" to ModelInfo("Italiano (Ý)", "https://alphacephei.com/vosk/models/vosk-model-small-it-0.22.zip", 48),
            "nl" to ModelInfo("Nederlands (Hà Lan)", "https://alphacephei.com/vosk/models/vosk-model-small-nl-0.22.zip", 39),
            "ca" to ModelInfo("Català (Catalan)", "https://alphacephei.com/vosk/models/vosk-model-small-ca-0.4.zip", 42),
            // Ả Rập không có bản "small" chính thức - chỉ có bản mgb2 318MB.
            "ar" to ModelInfo("العربية (Ả Rập)", "https://alphacephei.com/vosk/models/vosk-model-ar-mgb2-0.4.zip", 318),
            "fa" to ModelInfo("فارسی (Ba Tư/Iran)", "https://alphacephei.com/vosk/models/vosk-model-small-fa-0.42.zip", 53),
            "uk" to ModelInfo("Українська (Ukraine)", "https://alphacephei.com/vosk/models/vosk-model-small-uk-v3-nano.zip", 73),
            "kz" to ModelInfo("Қазақша (Kazakhstan)", "https://alphacephei.com/vosk/models/vosk-model-small-kz-0.42.zip", 58),
            // Thuỵ Điển không có bản "small" nhỏ - bản Rhasspy repackaged 289MB là nhẹ nhất có sẵn.
            "sv" to ModelInfo("Svenska (Thuỵ Điển)", "https://alphacephei.com/vosk/models/vosk-model-small-sv-rhasspy-0.15.zip", 289),
            "eo" to ModelInfo("Esperanto", "https://alphacephei.com/vosk/models/vosk-model-small-eo-0.42.zip", 42),
            "hi" to ModelInfo("हिन्दी (Ấn Độ - Hindi)", "https://alphacephei.com/vosk/models/vosk-model-small-hi-0.22.zip", 42),
            "cs" to ModelInfo("Čeština (Séc)", "https://alphacephei.com/vosk/models/vosk-model-small-cs-0.4-rhasspy.zip", 44),
            "pl" to ModelInfo("Polski (Ba Lan)", "https://alphacephei.com/vosk/models/vosk-model-small-pl-0.22.zip", 50),
            "uz" to ModelInfo("O'zbekcha (Uzbekistan)", "https://alphacephei.com/vosk/models/vosk-model-small-uz-0.22.zip", 49),
            "gu" to ModelInfo("ગુજરાતી (Gujarat)", "https://alphacephei.com/vosk/models/vosk-model-small-gu-0.42.zip", 100),
            "tg" to ModelInfo("Тоҷикӣ (Tajikistan)", "https://alphacephei.com/vosk/models/vosk-model-small-tg-0.22.zip", 50),
            "te" to ModelInfo("తెలుగు (Telugu)", "https://alphacephei.com/vosk/models/vosk-model-small-te-0.42.zip", 58),
            "ky" to ModelInfo("Кыргызча (Kyrgyzstan)", "https://alphacephei.com/vosk/models/vosk-model-small-ky-0.42.zip", 49),
            "ka" to ModelInfo("ქართული (Georgia)", "https://alphacephei.com/vosk/models/vosk-model-small-ka-0.42.zip", 45),
            // 3 ngôn ngữ dưới đây CHỈ có bản lớn (>250MB), không có bản small chính thức.
            "tl" to ModelInfo("Filipino (Tagalog)", "https://alphacephei.com/vosk/models/vosk-model-tl-ph-generic-0.6.zip", 320),
            "br" to ModelInfo("Brezhoneg (Breton)", "https://alphacephei.com/vosk/models/vosk-model-br-0.8.zip", 70),
            "el" to ModelInfo("Ελληνικά (Hy Lạp)", "https://alphacephei.com/vosk/models/vosk-model-el-gr-0.7.zip", 1100)
        )

        // Trước đây có BUNDLED_LANG = "en" (coi tiếng Anh luôn "sẵn sàng" vì bundle sẵn trong
        // APK). Giờ "en" nằm trong CATALOG như mọi ngôn ngữ khác - không còn khái niệm
        // "bundled" nữa, isDownloaded(context, "en") trả lời đúng luôn mà không cần đặc cách.

        // Ngôn ngữ bị loại khỏi chế độ "Tự động nhận diện nhiều ngôn ngữ" (xem
        // MultiLangVoskEngine + readyLangsForAuto bên dưới) - model quá lớn để tải nhiều bản
        // CÙNG LÚC vào RAM song song (mỗi ngôn ngữ bật auto là +1 Recognizer sống suốt phiên
        // nghe). Ranh giới 250MB là ước lượng thực dụng, không phải con số chính thức từ Vosk.
        val EXCLUDED_FROM_AUTO: Set<String> = CATALOG.filterValues { it.sizeMB > 250 }.keys

        // Trần số ngôn ngữ chạy song song ở chế độ auto - nhiều hơn nữa dễ làm máy tầm trung/yếu
        // ì ạch hoặc hết RAM (mỗi Recognizer Vosk small tốn thêm ~150-300MB RAM khi chạy).
        const val MAX_AUTO_LANGS = 4

        // Danh sách ngôn ngữ dùng cho chế độ "auto": mọi ngôn ngữ NGƯỜI DÙNG ĐÃ TẢI VỀ (không tự
        // tải hộ gì cả - auto chỉ dùng lại model đã có, không phát sinh tải mạng ngoài ý muốn),
        // loại các model quá lớn (xem EXCLUDED_FROM_AUTO), giới hạn tối đa MAX_AUTO_LANGS.
        // Không sắp xếp ưu tiên gì đặc biệt ngoài "đã tải trước thì vào danh sách trước" (thứ
        // tự Map.entries, "en" đứng đầu CATALOG nên thường vào danh sách trước nếu đã tải).
        fun readyLangsForAuto(context: Context): List<String> {
            val result = mutableListOf<String>()
            for ((lang, _) in CATALOG) {
                if (result.size >= MAX_AUTO_LANGS) break
                if (lang in EXCLUDED_FROM_AUTO) continue
                if (isDownloaded(context, lang)) result.add(lang)
            }
            return result
        }

        fun modelsDir(context: Context): File = File(context.filesDir, "models")

        fun modelDir(context: Context, lang: String): File = File(modelsDir(context), lang)

        // Dùng lại ở VoskEngine để biết model đã sẵn sàng chưa trước khi start capture.
        fun isDownloaded(context: Context, lang: String): Boolean {
            val dir = modelDir(context, lang)
            return dir.isDirectory && (dir.listFiles()?.isNotEmpty() == true)
        }

        // 15s cũ QUÁ NGẮN cho mạng di động/WiFi chập chờn - chỉ cần khựng >15s giữa chừng
        // (rất dễ xảy ra với model lớn như en-large ~1.8GB tải nhiều phút) là toàn bộ request
        // bị huỷ. Đây là nguyên nhân chính khiến tải hay báo "Lỗi tải - thử lại" dù mạng vẫn
        // dùng bình thường cho việc khác. Tăng lên rộng rãi hơn nhiều.
        const val CONNECT_TIMEOUT_MS = 20_000
        const val READ_TIMEOUT_MS = 60_000
        // Số lần thử TRÊN MỖI NGUỒN (primary/mirror) - không phải tổng số lần thử. Đổi tên từ
        // MAX_ATTEMPTS (4) vì giờ có thể có 2 nguồn (xem mirrorUrl bên dưới): thực tế đã ghi
        // nhận alphacephei.com tự nó đủ chậm/chập chờn để 4 lần thử LIÊN TIẾP CÙNG 1 HOST vẫn
        // fail hết (báo "Lỗi tải - thử lại" dù đã tăng timeout) - tăng số lần thử trên cùng 1
        // host không giải quyết được vấn đề nếu bản thân host đó đang có sự cố, nên hướng đúng
        // là thử sang host KHÁC hẳn thay vì thử lại mãi cùng 1 chỗ.
        const val MAX_ATTEMPTS_PER_SOURCE = 3
    }

    // mirrorUrl: nguồn dự phòng khác host, dùng khi url gốc (alphacephei.com) tải lỗi hết
    // MAX_ATTEMPTS_PER_SOURCE lần - xem downloadWithRetry(). File zip là bản mirror y hệt
    // (cùng tên file, cùng nội dung) đăng lại trên Hugging Face, không phải bản tự đóng gói.
    data class ModelInfo(val displayName: String, val url: String, val sizeMB: Int, val mirrorUrl: String? = null)

    // Theo dõi các lượt tải đang chạy để hỗ trợ cancelDownload() - key = lang.
    private val activeDownloads = mutableMapOf<String, Thread>()

    @PluginMethod
    fun listModels(call: PluginCall) {
        val arr = JSArray()

        for ((lang, info) in CATALOG) {
            val obj = JSObject()
            obj.put("lang", lang)
            obj.put("name", info.displayName)
            obj.put("sizeMB", info.sizeMB)
            obj.put("status", if (isDownloaded(context, lang)) "downloaded" else "not_downloaded")
            arr.put(obj)
        }

        val ret = JSObject()
        ret.put("models", arr)
        call.resolve(ret)
    }

    @PluginMethod
    fun downloadModel(call: PluginCall) {
        val lang = call.getString("lang")
        if (lang.isNullOrBlank()) {
            call.reject("Thiếu tham số lang.")
            return
        }
        val info = CATALOG[lang]
        if (info == null) {
            call.reject("Không có model cho lang=$lang trong catalog.")
            return
        }
        if (isDownloaded(context, lang)) {
            call.resolve(JSObject().apply { put("alreadyDownloaded", true) })
            return
        }
        if (activeDownloads.containsKey(lang)) {
            call.reject("Đang tải model cho lang=$lang rồi, đợi xong hoặc cancelDownload() trước.")
            return
        }

        // Kiểm tra dung lượng trống TRƯỚC khi tải - thiếu dung lượng là nguyên nhân phổ biến
        // gây "Lỗi tải - thử lại" ở model lớn (en-large ~1.8GB) mà RETRY KHÔNG BAO GIỜ tự sửa
        // được (không phải lỗi mạng thoáng qua), khiến vòng lặp downloadWithRetry() cứ chờ
        // backoff rồi thử lại vô ích cả 3 lần x 2 nguồn trước khi báo lỗi (tốn thời gian, và
        // thông báo lỗi cuối cùng thường chỉ là "No space left on device" khó hiểu với user).
        // Cần ~2x sizeMB (zip tải về TẠM + thư mục model giải nén ra, tồn tại song song đến
        // lúc unzip() xong mới xoá zip) + 100MB đệm an toàn.
        val requiredBytes = (info.sizeMB.toLong() * 2 + 100) * 1024 * 1024
        val freeBytes = context.filesDir.usableSpace
        if (freeBytes < requiredBytes) {
            val requiredGB = String.format("%.1f", requiredBytes / 1024.0 / 1024.0 / 1024.0)
            val freeGB = String.format("%.1f", freeBytes / 1024.0 / 1024.0 / 1024.0)
            call.reject("Không đủ dung lượng trống để tải model này (cần khoảng ${requiredGB}GB, máy còn ${freeGB}GB). Hãy giải phóng bớt bộ nhớ rồi thử lại.")
            return
        }

        val targetDir = modelDir(context, lang)
        val tmpZip = File(context.cacheDir, "model-$lang-download.zip")

        // Nguồn gốc trước, mirror (nếu có) sau - xem downloadWithRetry() để biết lúc nào
        // chuyển sang thử nguồn tiếp theo.
        val sources = listOfNotNull(info.url, info.mirrorUrl)

        val t = thread(name = "ModelDownload-$lang") {
            try {
                downloadWithRetry(sources, tmpZip) { downloadedBytes, totalBytes ->
                    emitProgress(lang, downloadedBytes, totalBytes)
                }
                unzip(tmpZip, targetDir)
                tmpZip.delete()

                if (!isDownloaded(context, lang)) {
                    throw IllegalStateException("Giải nén xong nhưng thư mục model rỗng - zip có thể sai cấu trúc.")
                }

                emitDone(lang, success = true, error = null)
            } catch (e: Exception) {
                // Dọn dẹp thư mục model dở dang (giải nén lỗi giữa chừng) để lần tải sau không
                // bị lẫn dữ liệu hỏng. KHÔNG xoá tmpZip ở đây nữa - downloadWithRetry() đã tự lo
                // giữ/xoá tmpZip tuỳ trường hợp (giữ lại để resume nếu còn khả năng thử lại,
                // xoá nếu đã bỏ cuộc hẳn - xem downloadWithRetry()).
                targetDir.deleteRecursively()
                // InterruptedException không có message hữu ích (từ cancelDownload() gọi
                // Thread.interrupt()) - thay bằng câu tiếng Việt rõ ràng thay vì để UI hiện
                // "LỖI tải model: java.lang.InterruptedException" khó hiểu.
                val errorMsg = if (e is InterruptedException) "Đã huỷ tải theo yêu cầu." else (e.message ?: e.toString())
                emitDone(lang, success = false, error = errorMsg, cancelled = e is InterruptedException)
            } finally {
                activeDownloads.remove(lang)
            }
        }
        activeDownloads[lang] = t

        // resolve ngay - tiến trình tải chạy nền, JS theo dõi qua sự kiện modelDownloadProgress
        // và modelDownloadDone (giống pattern audioLevel/partialText của AudioCapturePlugin).
        call.resolve(JSObject().apply { put("started", true) })
    }

    @PluginMethod
    fun cancelDownload(call: PluginCall) {
        val lang = call.getString("lang")
        val t = activeDownloads[lang]
        if (t != null) {
            t.interrupt()
            activeDownloads.remove(lang)
        }
        call.resolve()
    }

    @PluginMethod
    fun deleteModel(call: PluginCall) {
        val lang = call.getString("lang")
        if (lang.isNullOrBlank()) {
            call.reject("Thiếu tham số lang.")
            return
        }
        modelDir(context, lang).deleteRecursively()
        call.resolve()
    }

    // Bọc downloadWithProgress() bằng vòng lặp thử lại tự động - lỗi mạng thoáng qua (timeout,
    // mất kết nối giữa chừng...) không còn bắt người dùng tự bấm "Tải về" lại thủ công từng lần.
    // File tải dở (tmpZip) được GIỮ LẠI giữa các lần thử CÙNG 1 NGUỒN (không xoá) để lần thử
    // tiếp theo RESUME tiếp từ chỗ dở dang qua HTTP Range, không tải lại từ đầu - quan trọng
    // nhất với model lớn như en-large (~1.8GB).
    //
    // Nhận DANH SÁCH nguồn (urls) thay vì 1 URL cố định: đã ghi nhận thực tế alphacephei.com tự
    // nó có lúc đủ chậm/chập chờn để MAX_ATTEMPTS_PER_SOURCE lần thử LIÊN TIẾP CÙNG HOST đó vẫn
    // fail hết dù đã tăng timeout rộng rãi - tăng thêm số lần thử trên cùng 1 host không giải
    // quyết được nếu bản thân host đang có sự cố. Nên hết lượt thử ở 1 nguồn thì CHUYỂN SANG
    // NGUỒN KẾ TIẾP (mirror) trong danh sách thay vì tiếp tục thử nguồn cũ.
    private fun downloadWithRetry(urls: List<String>, dest: File, onProgress: (Long, Long) -> Unit) {
        var lastError: Exception? = null
        for ((sourceIndex, urlStr) in urls.withIndex()) {
            // Đổi sang nguồn khác (host khác) thì xoá phần tải dở của nguồn TRƯỚC đi - không
            // chắc 2 host phục vụ byte-for-byte giống hệt nhau (thứ tự nén, chunk...), resume
            // qua Range dựa trên phần dở của host khác có rủi ro nối rác vào file.
            if (sourceIndex > 0 && dest.exists()) dest.delete()

            for (attempt in 1..MAX_ATTEMPTS_PER_SOURCE) {
                try {
                    downloadWithProgress(urlStr, dest, onProgress)
                    return // thành công
                } catch (e: InterruptedException) {
                    dest.delete() // user chủ động huỷ (cancelDownload) - dọn luôn, không giữ lại để resume
                    throw e
                } catch (e: Exception) {
                    // Hết dung lượng GIỮA CHỪNG (vd máy vừa đầy thêm do app khác) - lỗi này
                    // retry/đổi nguồn không sửa được, dừng ngay thay vì lãng phí hết
                    // MAX_ATTEMPTS_PER_SOURCE x số nguồn rồi mới báo lỗi khó hiểu.
                    val msg = e.message?.lowercase() ?: ""
                    if (e is java.io.IOException && (msg.contains("enospc") || msg.contains("no space left"))) {
                        dest.delete()
                        throw IllegalStateException("Hết dung lượng trống trên máy giữa lúc tải - hãy giải phóng bớt bộ nhớ rồi thử lại.")
                    }
                    lastError = e
                    val isLastAttemptOfSource = attempt == MAX_ATTEMPTS_PER_SOURCE
                    val isLastSource = sourceIndex == urls.lastIndex
                    if (!(isLastAttemptOfSource && isLastSource)) {
                        // Backoff tăng dần: 2s, 5s, 10s - đủ để mạng chập chờn có thời gian ổn
                        // định lại mà không bắt người dùng chờ quá lâu giữa các lần thử.
                        val backoffMs = when (attempt) { 1 -> 2000L; 2 -> 5000L; else -> 10000L }
                        Thread.sleep(backoffMs)
                        // Nếu còn thử tiếp CÙNG nguồn này (chưa isLastAttemptOfSource): KHÔNG
                        // xoá dest - giữ lại phần đã tải để resume. Nếu sắp chuyển nguồn (đã hết
                        // lượt thử của nguồn này nhưng còn nguồn khác): việc xoá dest sẽ được xử
                        // lý ở đầu vòng lặp ngoài (sourceIndex > 0) lúc sang nguồn kế tiếp.
                    }
                }
            }
        }
        dest.delete() // hết lượt thử ở MỌI nguồn, dọn file dở dang thật sự bỏ cuộc
        throw lastError ?: IllegalStateException("Tải thất bại không rõ lý do sau khi thử hết ${urls.size} nguồn.")
    }

    private fun downloadWithProgress(urlStr: String, dest: File, onProgress: (Long, Long) -> Unit) {
        // Resume: nếu đã có file tải dở từ lần thử trước (cùng phiên downloadModel(), xem
        // downloadWithRetry()), tiếp tục từ đúng byte đã có bằng header Range - không tải lại
        // từ đầu. Server tĩnh như alphacephei.com/GitHub Releases đều hỗ trợ Range mặc định.
        val alreadyHave = if (dest.exists()) dest.length() else 0L

        val url = URL(urlStr)
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = CONNECT_TIMEOUT_MS
        conn.readTimeout = READ_TIMEOUT_MS
        conn.instanceFollowRedirects = true // GitHub Releases redirect sang S3 - bắt buộc phải theo
        if (alreadyHave > 0) {
            conn.setRequestProperty("Range", "bytes=$alreadyHave-")
        }
        conn.connect()

        val isResuming = alreadyHave > 0 && conn.responseCode == 206
        if (conn.responseCode !in 200..299) {
            throw IllegalStateException("HTTP ${conn.responseCode} khi tải model từ $urlStr")
        }
        // Server không hỗ trợ Range (trả 200 thay vì 206 dù mình có gửi Range) -> nó sẽ gửi lại
        // TOÀN BỘ file từ đầu, nên phải bỏ phần cũ đi để không bị nối rác vào đầu file.
        if (alreadyHave > 0 && !isResuming) {
            dest.delete()
        }

        // totalBytes phải cộng lại phần đã có sẵn khi đang resume, vì Content-Length lúc này
        // chỉ tính phần CÒN LẠI server trả về (theo đúng ngữ nghĩa response 206 Partial Content).
        val remainingBytes = conn.contentLengthLong
        val totalBytes = if (isResuming && remainingBytes > 0) alreadyHave + remainingBytes else remainingBytes
        var downloadedBytes = if (isResuming) alreadyHave else 0L
        var lastEmitAt = 0L

        conn.inputStream.use { input ->
            FileOutputStream(dest, isResuming).use { output -> // append=true khi đang resume
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    if (Thread.currentThread().isInterrupted) throw InterruptedException("Đã huỷ tải model.")
                    val read = input.read(buffer)
                    if (read == -1) break
                    output.write(buffer, 0, read)
                    downloadedBytes += read

                    val now = System.currentTimeMillis()
                    if (now - lastEmitAt >= 300) { // throttle ~3 lần/giây, tránh spam bridge JS
                        onProgress(downloadedBytes, totalBytes)
                        lastEmitAt = now
                    }
                }
            }
        }
        onProgress(downloadedBytes, totalBytes)
    }

    private fun unzip(zipFile: File, targetDir: File) {
        targetDir.deleteRecursively()
        targetDir.mkdirs()

        // Zip gốc tải thẳng từ alphacephei.com bọc mọi thứ trong 1 thư mục cha (vd
        // "vosk-model-en-us-0.22/"), trong khi zip mình tự đóng gói lại (model-vi/ja/ko) thì
        // phẳng, không bọc. Tự phát hiện + bóc lớp đó ra khi giải nén, để catalog dùng được
        // CẢ 2 kiểu zip mà không cần re-zip thủ công từng model.
        val commonPrefix = detectCommonRootPrefix(zipFile)

        ZipInputStream(zipFile.inputStream()).use { zis ->
            var entry: ZipEntry? = zis.nextEntry
            val buffer = ByteArray(64 * 1024)
            while (entry != null) {
                val relativeName = if (commonPrefix != null && entry.name.startsWith(commonPrefix)) {
                    entry.name.substring(commonPrefix.length)
                } else {
                    entry.name
                }
                if (relativeName.isEmpty()) {
                    zis.closeEntry()
                    entry = zis.nextEntry
                    continue
                }

                // Chặn path traversal (zip slip) - phòng trường hợp zip nguồn bị chỉnh sửa độc hại.
                val outFile = File(targetDir, relativeName)
                if (!outFile.canonicalPath.startsWith(targetDir.canonicalPath + File.separator)) {
                    throw SecurityException("Zip entry bất thường: ${entry.name}")
                }
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { out ->
                        var read = zis.read(buffer)
                        while (read != -1) {
                            out.write(buffer, 0, read)
                            read = zis.read(buffer)
                        }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }

    // Đọc qua danh sách tên entry (không giải nén) để tìm xem toàn bộ zip có nằm chung trong
    // đúng 1 thư mục cha hay không. Đọc file zip 2 lần (lần này + lần unzip thật) chấp nhận
    // được vì đây là file cục bộ đã tải xong, không phải đọc lại qua mạng.
    private fun detectCommonRootPrefix(zipFile: File): String? {
        val topLevelDirs = mutableSetOf<String>()
        var hasRootLevelEntry = false
        ZipInputStream(zipFile.inputStream()).use { zis ->
            var entry: ZipEntry? = zis.nextEntry
            while (entry != null) {
                val name = entry.name.trimStart('/')
                val slashIdx = name.indexOf('/')
                if (slashIdx <= 0) {
                    if (name.isNotEmpty()) hasRootLevelEntry = true
                } else {
                    topLevelDirs.add(name.substring(0, slashIdx))
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        return if (!hasRootLevelEntry && topLevelDirs.size == 1) topLevelDirs.first() + "/" else null
    }

    private fun emitProgress(lang: String, downloadedBytes: Long, totalBytes: Long) {
        val data = JSObject()
        data.put("lang", lang)
        data.put("downloadedBytes", downloadedBytes)
        data.put("totalBytes", totalBytes)
        data.put("percent", if (totalBytes > 0) (downloadedBytes * 100 / totalBytes).toInt() else -1)
        notifyListeners("modelDownloadProgress", data)
    }

    private fun emitDone(lang: String, success: Boolean, error: String?, cancelled: Boolean = false) {
        val data = JSObject()
        data.put("lang", lang)
        data.put("success", success)
        if (error != null) data.put("error", error)
        // cancelled: JS dùng để KHÔNG hiện dòng "LỖI tải model..." đỏ trong log (huỷ theo yêu
        // cầu người dùng không phải lỗi thật) - xem plugin_downloadModel() ở www/index.html.
        data.put("cancelled", cancelled)
        notifyListeners("modelDownloadDone", data)
    }
}
