package com.atun.translator

import android.content.Context

// ===== Chế độ "Tự động nhận diện" khi người nói xen kẽ nhiều ngôn ngữ trong cùng 1 phiên =====
// Vosk KHÔNG có model nhận diện ngôn ngữ (LID) riêng biệt. Cách khả thi với những gì Vosk cung
// cấp: chạy SONG SONG 1 Recognizer riêng cho MỖI ngôn ngữ đã tải (xem
// ModelManagerPlugin.readyLangsForAuto), cùng nhận Y HỆT 1 luồng PCM, rồi ở mỗi lần "chốt câu"
// (final), so sánh độ tin cậy (confidence trung bình theo từ) mà TỪNG recognizer tự chấm cho kết
// quả của nó và chọn recognizer có confidence cao nhất - vì recognizer đúng ngôn ngữ thường cho
// confidence cao hẳn so với recognizer sai ngôn ngữ (model sai ngôn ngữ decode ra những từ nghe
// gần giống về âm nhưng không khớp ngữ cảnh, Vosk tự chấm confidence thấp cho các từ kiểu này).
//
// Đánh đổi: tốn CPU/RAM gấp N lần (N = số ngôn ngữ bật cùng lúc, xem MAX_AUTO_LANGS) vì phải
// chạy N Recognizer thật sự song song trên CÙNG 1 khung audio. Vì vậy danh sách langs truyền vào
// đây LUÔN được lọc trước ở ModelManagerPlugin.readyLangsForAuto (loại model quá lớn, giới hạn
// số lượng) - class này không tự kiểm tra lại các ràng buộc đó.
//
// Quan trọng: feed()/forcePauseFinal() gọi engine.feed()/engine.forcePauseFinal() của TỪNG
// VoskEngine con TUẦN TỰ trên CÙNG 1 thread gọi vào (không spawn thread riêng cho mỗi ngôn ngữ) -
// nhờ vậy callback onEvent của mỗi engine con chạy ĐỒNG BỘ ngay trong lệnh gọi, cho phép gom hết
// kết quả Final của mọi ngôn ngữ trong đúng 1 lượt feed() rồi so sánh, KHÔNG cần khoá/hàng đợi gì
// thêm. Đánh đổi: tổng thời gian xử lý 1 khung audio = tổng thời gian của N recognizer cộng lại
// (không chạy thật sự song song trên nhiều lõi CPU) - chấp nhận được vì mỗi model "small" xử lý
// 1 khung rất nhanh (vài ms), N<=MAX_AUTO_LANGS nhỏ.
class MultiLangVoskEngine(
    context: Context,
    sampleRate: Float,
    langs: List<String>,
    private val onEvent: (VoskEngine.Event) -> Unit
) : SttEngine {

    private class Sub(val lang: String, val engine: VoskEngine) {
        @Volatile var ready = false
        // "Đã xong lượt load" - ready THÀNH CÔNG hoặc đã LỖI hẳn (model hỏng/tải dở dang).
        // Khác `ready`: `settled` chỉ báo "không còn chờ nữa", không đảm bảo dùng được.
        @Volatile var settled = false
        var lastPartial: String = ""
        // (text, confidence) của lượt feed()/forcePauseFinal() ĐANG XỬ LÝ - reset về null đầu
        // mỗi lượt gọi, chỉ tồn tại trong đúng 1 lượt để resolveFinalsIfAny() gom lại so sánh.
        var pendingFinal: Pair<String, Double>? = null
    }

    private val subs: List<Sub> = langs.mapNotNull { lang ->
        val source = VoskEngine.resolveModelSource(context, lang) ?: return@mapNotNull null
        lateinit var sub: Sub
        val engine = VoskEngine(context, sampleRate, source) { event -> handleSubEvent(sub, event) }
        sub = Sub(lang, engine)
        sub
    }

    @Volatile private var readyCount = 0
    // Số sub đã "settled" (ready hoặc lỗi hẳn) - xem maybeNotifyReady().
    @Volatile private var settledCount = 0
    @Volatile private var allReadyNotified = false
    // Ngôn ngữ "đang thắng" của câu final GẦN NHẤT - ưu tiên hiển thị partial của nó tiếp theo,
    // đỡ nhấp nháy đổi ngôn ngữ hiển thị liên tục giữa chừng 1 câu do các recognizer dao động
    // confidence khi câu chưa nói xong.
    @Volatile private var leadingLang: String? = null

    override fun init() {
        subs.forEach { it.engine.init() }
    }

    private fun handleSubEvent(sub: Sub, event: VoskEngine.Event) {
        when (event) {
            is VoskEngine.Event.ModelReady -> {
                if (!sub.settled) {
                    sub.ready = true
                    sub.settled = true
                    readyCount++
                    settledCount++
                    maybeNotifyReady()
                }
            }
            is VoskEngine.Event.Partial -> sub.lastPartial = event.text
            is VoskEngine.Event.Final -> sub.pendingFinal = event.text to event.confidence
            // Vẫn gom vào để so sánh confidence tổng hợp - việc lọc "câu rác" ở mức tổng hợp làm
            // trong resolveFinalsIfAny(), không lọc riêng theo từng recognizer con ở đây (1
            // recognizer bị coi "low confidence" không có nghĩa recognizer khác cũng vậy).
            is VoskEngine.Event.LowConfidence -> sub.pendingFinal = event.text to event.confidence
            is VoskEngine.Event.Error -> {
                // BUG đã sửa: trước đây Error không được tính là "đã xử lý xong lượt load" -
                // nếu model của 1 ngôn ngữ hỏng/tải dở dang (constructor Model() throw ở thread
                // riêng trong VoskEngine.initFromPath()), sub đó `ready` mãi mãi là false,
                // readyCount không bao giờ chạm subs.size -> ModelReady tổng không bao giờ được
                // báo ra ngoài -> UI kẹt "Model: đang tải..." vĩnh viễn dù các ngôn ngữ còn lại
                // vẫn load xong bình thường. Giờ Error cũng tính vào settledCount (đã "xong lượt
                // load", dù không thành công) để không chặn các sub khác mãi mãi.
                if (!sub.settled) {
                    sub.settled = true
                    settledCount++
                    maybeNotifyReady()
                }
                onEvent(VoskEngine.Event.Error("[${sub.lang}] ${event.message}"))
            }
            is VoskEngine.Event.DetectedFinal -> Unit // không xảy ra: sub-engine là VoskEngine thường, không tự bắn cái này
            is VoskEngine.Event.LoadingProgress -> Unit // không xảy ra: sub-engine con không tự bắn cái này, chỉ MultiLangVoskEngine bắn ra ngoài (xem maybeNotifyReady)
        }
    }

    // Chỉ báo "sẵn sàng" ra ngoài (bật nút nghe) khi TẤT CẢ sub đã "settled" (ready hoặc lỗi hẳn)
    // - vẫn giữ đúng ý định gốc "đợi đủ mọi ngôn ngữ trước khi bắt đầu nghe" (bắt đầu sớm hơn sẽ
    // bỏ lỡ audio ở các recognizer còn đang load), nhưng KHÔNG còn treo vĩnh viễn nếu 1 (hoặc
    // nhiều, nhưng không phải tất cả) sub lỗi hẳn - chỉ cần settledCount == subs.size là đủ,
    // không bắt buộc readyCount == subs.size như trước.
    private fun maybeNotifyReady() {
        if (allReadyNotified) return
        // Báo tiến độ ra ngoài MỖI LẦN có thêm 1 sub settled (kể cả khi chưa đủ cả subs.size) -
        // để UI vẽ progress bar thật (vd "2/4 model đã sẵn sàng") thay vì text tĩnh "đang tải..."
        // suốt cả quá trình load nhiều model song song ở chế độ "Tự động nhận diện".
        onEvent(VoskEngine.Event.LoadingProgress(settledCount, subs.size))
        if (settledCount < subs.size) return // vẫn còn sub đang load dở, đợi tiếp

        allReadyNotified = true
        if (readyCount == 0) {
            // Trường hợp cực hiếm: TẤT CẢ ngôn ngữ đều lỗi - không còn recognizer nào dùng
            // được, báo lỗi rõ ràng thay vì im lặng treo mãi ở "đang tải...".
            onEvent(VoskEngine.Event.Error(
                "Không có model nào trong chế độ tự động nhận diện load được - kiểm tra lại " +
                    "các model đã tải ở mục \"Quản lý mô hình ngôn ngữ\"."
            ))
        } else {
            onEvent(VoskEngine.Event.ModelReady)
        }
    }

    override fun feed(pcm: ShortArray, length: Int) {
        for (sub in subs) sub.pendingFinal = null
        for (sub in subs) {
            // BUG đã sửa: trước đây bỏ qua feed() HOÀN TOÀN cho sub chưa `ready` (đang load
            // model) - audio đọc được trong lúc đó bị mất hẳn cho sub này, y hệt bug "mất câu
            // đầu" ở VoskEngine 1 ngôn ngữ. Giờ luôn gọi feed() cho mọi sub CHƯA lỗi hẳn (kể cả
            // đang load dở) - VoskEngine.feed() tự đệm (buffer) audio nội bộ trong lúc chưa
            // ready và tự phát lại đúng thứ tự ngay khi model của nó load xong (xem
            // VoskEngine.kt), nên không cần né gọi ở đây nữa. Chỉ thật sự bỏ qua sub đã
            // `settled` nhưng KHÔNG `ready` (tức lỗi hẳn, model hỏng) - feed cho sub này vĩnh
            // viễn không có tác dụng, chỉ tốn CPU/RAM đệm audio vô ích.
            if (sub.settled && !sub.ready) continue
            sub.engine.feed(pcm, length)
        }
        resolveFinalsIfAny()
        emitBestPartial()
    }

    override fun forcePauseFinal() {
        for (sub in subs) sub.pendingFinal = null
        for (sub in subs) {
            if (!sub.ready) continue
            sub.engine.forcePauseFinal()
        }
        resolveFinalsIfAny()
    }

    // Trong 1 lượt feed()/forcePauseFinal(), CHỈ giữ lại candidate của recognizer nào vừa chốt
    // câu (pendingFinal != null, text không rỗng) và có confidence CAO NHẤT - các recognizer
    // khác dù có lỡ cũng chốt câu ở cùng thời điểm đều bị coi là "đoán sai ngôn ngữ" và bỏ qua.
    private fun resolveFinalsIfAny() {
        val candidates = subs.filter { it.pendingFinal != null && it.pendingFinal!!.first.isNotBlank() }
        if (candidates.isEmpty()) return
        val winner = candidates.maxByOrNull { it.pendingFinal!!.second } ?: return
        val (text, confidence) = winner.pendingFinal!!
        leadingLang = winner.lang
        if (confidence in 0.0..VoskEngine.CONFIDENCE_DROP_THRESHOLD) {
            onEvent(VoskEngine.Event.LowConfidence(text, confidence))
        } else {
            onEvent(VoskEngine.Event.DetectedFinal(winner.lang, text, confidence))
        }
    }

    // Ưu tiên partial của ngôn ngữ đang "thắng" gần nhất nếu nó còn partial không rỗng; nếu rỗng
    // (vd người nói vừa đổi sang ngôn ngữ khác) thì chọn partial DÀI NHẤT trong số các recognizer
    // còn lại - recognizer đoán đúng ngôn ngữ thường tích luỹ partial dài hơn, còn recognizer sai
    // ngôn ngữ hay bị "đứt" giữa chừng vì không khớp từ vựng.
    private fun emitBestPartial() {
        val leading = leadingLang?.let { l -> subs.find { it.lang == l } }
        val candidate = if (leading != null && leading.lastPartial.isNotBlank()) leading
            else subs.filter { it.lastPartial.isNotBlank() }.maxByOrNull { it.lastPartial.length }
        if (candidate != null && candidate.lastPartial.isNotBlank()) {
            onEvent(VoskEngine.Event.Partial(candidate.lastPartial))
        }
    }

    override fun release() {
        subs.forEach { it.engine.release() }
    }
}
