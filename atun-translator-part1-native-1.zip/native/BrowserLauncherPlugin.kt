package com.atun.translator

import android.content.Intent
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin

// Cầu nối JS (www/index.html) -> mở BrowserActivity ("web mini") bằng Intent thường - 1
// Activity RIÊNG trong CÙNG app (không phải app/package riêng, không dùng WebView của
// Capacitor Bridge chính). AudioCaptureService (bắt âm thanh hệ thống, chạy nền độc lập với
// Activity nào đang hiển thị) không bị ảnh hưởng gì khi người dùng chuyển qua màn hình này.
@CapacitorPlugin(name = "BrowserLauncher")
class BrowserLauncherPlugin : Plugin() {
    @PluginMethod
    fun open(call: PluginCall) {
        val url = call.getString("url")
        val intent = Intent(context, BrowserActivity::class.java)
        if (!url.isNullOrBlank()) intent.putExtra("url", url)
        activity.startActivity(intent)
        call.resolve()
    }
}
