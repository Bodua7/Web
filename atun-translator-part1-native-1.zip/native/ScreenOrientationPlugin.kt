package com.atun.translator

import android.content.pm.ActivityInfo
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin

// Khoá/mở xoay màn hình bằng API native Android (Activity.requestedOrientation) - dùng cho
// video fullscreen trong index.html (#videoStage). KHÔNG dùng Web Screen Orientation Lock API
// (screen.orientation.lock() phía JS) vì API đó không hoạt động trong Android WebView (nơi
// Capacitor chạy JS, khác hẳn Chrome/trình duyệt thật hỗ trợ đầy đủ) - gọi luôn ném lỗi ngay
// lập tức, JS phía index.html trước đây bọc catch() nên nuốt lỗi âm thầm, kết quả là video
// fullscreen không bao giờ tự xoay ngang được (đây chính là bug "video không xoay ngang/lấp
// đầy màn hình lúc fullscreen"). Plugin này khoá xoay THẬT ở tầng Activity, luôn hoạt động
// không phụ thuộc WebView có implement Web API hay không.
@CapacitorPlugin(name = "ScreenOrientation")
class ScreenOrientationPlugin : Plugin() {

    @PluginMethod
    fun lock(call: PluginCall) {
        val orientation = call.getString("orientation", "landscape")
        // SENSOR_LANDSCAPE/SENSOR_PORTRAIT (không phải REVERSE/LANDSCAPE cố định 1 chiều) để
        // vẫn xoay được giữa 2 chiều ngang (trái/phải) hoặc 2 chiều dọc tuỳ cảm biến, chỉ
        // chặn không cho lật sang trục vuông góc còn lại - đúng ý "khoá ngang"/"khoá dọc" mà
        // không ép cứng 1 hướng camera/notch cụ thể.
        val requested = when (orientation) {
            "portrait" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            else -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
        activity?.runOnUiThread {
            activity.requestedOrientation = requested
        }
        call.resolve()
    }

    @PluginMethod
    fun unlock(call: PluginCall) {
        // UNSPECIFIED (không phải FULL_SENSOR) - trả quyền quyết định lại cho hệ thống/theme
        // của Activity (thường theo cảm biến tự do như mặc định trước khi lock() được gọi),
        // tránh ép thêm 1 chính sách xoay riêng của plugin đè lên toàn app sau khi thoát video.
        activity?.runOnUiThread {
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        call.resolve()
    }
}
