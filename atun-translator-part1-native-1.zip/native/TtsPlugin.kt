package com.atun.translator

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.audiofx.LoudnessEnhancer
import android.os.Build
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

// Đọc to bản dịch tiếng Việt qua TextToSpeech có sẵn trong Android (KHÔNG cần thêm thư viện/
// npm package nào, không cần mạng nếu máy đã có giọng đọc offline) - hữu ích khi đang xem
// video mà không tiện nhìn màn hình liên tục để đọc phụ đề overlay.
//
// Mỗi lần đọc, xin AudioFocus kiểu "duck" (AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK) - hầu hết app
// media Android (YouTube, VLC...) tôn trọng yêu cầu này và tự hạ nhỏ tiếng gốc lại thay vì đè
// chan chát lên giọng đọc, rồi trả về mức cũ khi đọc xong (abandonAudioFocus).
@CapacitorPlugin(name = "TtsPlugin")
class TtsPlugin : Plugin() {

    private var tts: TextToSpeech? = null
    private var ready = false
    // BUG đã sửa: trước đây load() gọi thẳng `tts?.language = Locale("vi","VN")` và BỎ QUA kết
    // quả trả về - nếu máy chưa cài giọng đọc tiếng Việt (rất phổ biến, nhất là sau khi vừa tải
    // model STT tiếng Anh lớn - người dùng thường mới cài app/máy chưa có sẵn data giọng đọc),
    // setLanguage() trả LANG_MISSING_DATA/LANG_NOT_SUPPORTED nhưng code cũ vẫn coi `ready=true`
    // và speak() vẫn cho gọi bình thường -> Android TTS engine ÂM THẦM không phát ra tiếng gì
    // (hoặc phát bằng giọng mặc định của máy, không phải tiếng Việt), JS không nhận được lỗi gì
    // để báo cho người dùng. Giờ lưu kết quả thật vào cờ này, speak() kiểm tra trước khi gọi.
    private var vietnameseAvailable = false
    private val pendingUtterances = AtomicInteger(0)
    private var audioManager: AudioManager? = null
    private var focusRequest: AudioFocusRequest? = null

    // Âm lượng giọng đọc dịch, 0.0-1.0, truyền qua Bundle KEY_PARAM_VOLUME mỗi lần speak() -
    // TextToSpeech không có "setVolume" riêng như setSpeechRate(), phải truyền theo utterance.
    private var speechVolume = 1.0f

    // ===== Khắc phục "âm lượng dịch nhỏ quá" =====
    // TextToSpeech phát qua AudioAttributes USAGE_ASSISTANCE_ACCESSIBILITY -> Android route
    // audio này qua STREAM_ACCESSIBILITY (API 30+), MỘT STREAM HOÀN TOÀN TÁCH BIỆT với
    // STREAM_MUSIC. speechVolume=1.0f ở trên chỉ là volume TƯƠNG ĐỐI trong phạm vi mức hiện
    // tại của STREAM_ACCESSIBILITY - nếu mức đó tự nó đang bị hệ thống để rất thấp (nhiều máy
    // Android mặc định để stream Trợ năng thấp hơn hẳn Media, vì bình thường ít app dùng tới),
    // 1.0f vẫn ra tiếng nhỏ dù đã "max" theo nghĩa tương đối. Khắc phục bằng cách CHỦ ĐỘNG nâng
    // thẳng mức tuyệt đối của STREAM_ACCESSIBILITY lên mỗi lần setVolume() được gọi (tương tự
    // cách duckMusicVolumeIfNeeded() chủ động chỉnh STREAM_MUSIC ở dưới) - không chỉ đợi user
    // tự mò vào Cài đặt hệ thống > Âm lượng trợ năng để chỉnh, việc mà hầu như không ai biết.
    // API 30 trở xuống không có STREAM_ACCESSIBILITY -> bỏ qua, chỉ còn dựa vào speechVolume
    // tương đối như cũ (chấp nhận được vì các máy cũ hơn thường route qua STREAM_MUSIC).
    private val accessibilityStreamId = 10 // AudioManager.STREAM_ACCESSIBILITY, hardcode vì
        // hằng số này chỉ có trong SDK 30+, project có thể compile với SDK thấp hơn.

    // ===== Tự động hạ âm lượng gốc khi đang đọc dịch (Nâng cấp: "Tự chỉnh âm lượng dịch và
    // âm lượng gốc") =====
    // AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK (requestAudioFocus() bên dưới) chỉ là ĐỀ NGHỊ - app
    // đang phát nhạc/video (YouTube, VLC...) TỰ QUYẾT định có hạ tiếng và hạ bao nhiêu, nhiều
    // app hạ rất ít hoặc bỏ qua hoàn toàn. Để chắc chắn có hiệu quả, chủ động hạ THẲNG volume
    // hệ thống của STREAM_MUSIC (stream mà hầu hết app media dùng, bao gồm YouTube) xuống còn
    // duckLevelPercent% mức hiện tại lúc bắt đầu đọc, rồi khôi phục lại khi đọc xong toàn bộ
    // hàng đợi (pendingUtterances về 0) - CHỦ ĐỘNG hơn hẳn so với chỉ dựa vào AudioFocus, đổi
    // lại là chỉnh âm lượng CẢ HỆ THỐNG (ảnh hưởng mọi app đang phát, không riêng gì app nguồn)
    // vì Android không cho 1 app chỉnh volume RIÊNG của app khác.
    private var autoDuckEnabled = true
    private var duckLevelPercent = 30 // hạ còn 30% mức hiện tại theo mặc định
    private var savedMusicVolume: Int? = null // null = hiện không có phiên đọc nào đang hạ tiếng

    // ===== "Khuếch đại thêm" âm lượng dịch VƯỢT quá mức tối đa hệ thống - yêu cầu người dùng:
    // "chỉnh âm lượng dịch to hơn âm lượng gốc". speechVolume + raiseAccessibilityStreamVolume()
    // ở trên chỉ đưa được TỐI ĐA tới 100% mức STREAM_ACCESSIBILITY của máy - nếu original vẫn
    // còn nghe rõ hơn dù đã set volume dịch=100%/duck gốc thấp, không còn cách nào tăng thêm qua
    // đường volume thường. LoudnessEnhancer (audio effect có sẵn từ API 19) khuếch đại THẬT sự
    // biên độ tín hiệu TTS trước khi ra loa, vượt được trần 100% đó - cần audioSessionId RIÊNG
    // (tự sinh, không dùng session mặc định) gắn vào effect NÀY và truyền cho TextToSpeech qua
    // Bundle KEY_PARAM_SESSION_ID mỗi lần speak() để 2 bên cùng chung 1 session.
    private var audioSessionId: Int = AudioManager.ERROR
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var boostMillibel: Int = 0 // 0 = tắt khuếch đại thêm, 1000 = +10dB, coerce 0..3000

    private val speechAttributes: AudioAttributes by lazy {
        AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
    }

    override fun load() {
        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        // Sinh session riêng cho TTS TRƯỚC khi engine sẵn sàng - truyền session này vào mỗi lần
        // speak() (xem Bundle ở speak()) để LoudnessEnhancer gắn đúng luồng audio của giọng đọc,
        // không đụng tới session của bất kỳ audio nào khác trong app.
        audioSessionId = audioManager?.generateAudioSessionId() ?: AudioManager.ERROR
        setupLoudnessEnhancer()
        tts = TextToSpeech(context) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                // Đọc kết quả THẬT thay vì gọi setter rồi bỏ qua (xem giải thích ở khai báo
                // vietnameseAvailable phía trên) - LANG_AVAILABLE/LANG_COUNTRY_AVAILABLE/
                // LANG_COUNTRY_VAR_AVAILABLE đều coi là dùng được, còn lại (MISSING_DATA/
                // NOT_SUPPORTED) coi như chưa có giọng tiếng Việt.
                val langResult = tts?.setLanguage(Locale("vi", "VN")) ?: TextToSpeech.LANG_NOT_SUPPORTED
                vietnameseAvailable = langResult == TextToSpeech.LANG_AVAILABLE ||
                    langResult == TextToSpeech.LANG_COUNTRY_AVAILABLE ||
                    langResult == TextToSpeech.LANG_COUNTRY_VAR_AVAILABLE
                tts?.setAudioAttributes(speechAttributes)
                raiseAccessibilityStreamVolume(speechVolume)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        if (pendingUtterances.decrementAndGet() <= 0) {
                            abandonAudioFocus()
                            restoreMusicVolumeIfNeeded()
                        }
                    }
                    @Deprecated("Deprecated in Java, vẫn phải override vì API cũ chưa gỡ")
                    override fun onError(utteranceId: String?) {
                        if (pendingUtterances.decrementAndGet() <= 0) {
                            abandonAudioFocus()
                            restoreMusicVolumeIfNeeded()
                        }
                    }
                })
            }
            val data = JSObject()
            data.put("ready", ready)
            notifyListeners("ttsStatus", data)
        }
    }

    @PluginMethod
    fun speak(call: PluginCall) {
        val text = call.getString("text")
        if (text.isNullOrBlank()) {
            call.resolve()
            return
        }
        val engine = tts
        if (engine == null || !ready) {
            call.reject("TTS engine chưa sẵn sàng (máy có thể chưa cài giọng đọc tiếng Việt)")
            return
        }
        // Chặn NGAY ở đây thay vì để engine.speak() âm thầm không ra tiếng - xem giải thích ở
        // khai báo vietnameseAvailable. JS (index.html) đã có sẵn nút "Cài giọng đọc tiếng
        // Việt" qua promptInstallVoiceData(), nhưng trước đây không có tín hiệu lỗi nào ở speak()
        // để biết KHI NÀO cần hiện nút đó (chỉ có checkVietnameseVoice() gọi rời, dễ bị bỏ qua).
        if (!vietnameseAvailable) {
            call.reject("Máy chưa cài giọng đọc tiếng Việt - vào Cài đặt hệ thống hoặc bấm \"Cài giọng đọc tiếng Việt\" để tải.")
            return
        }

        // flushMode=true: xoá hàng đợi cũ, đọc câu MỚI NHẤT ngay - dùng khi bản dịch ra nhanh
        // hơn tốc độ đọc để tránh đọc dồn trễ xa audio thật. false (mặc định): QUEUE_ADD, đọc
        // đủ hết không bỏ câu nào, nhưng dễ bị trễ dần nếu người nói nhanh/liên tục.
        val flushMode = call.getBoolean("flushMode") ?: false
        val queueMode = if (flushMode) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        if (flushMode) pendingUtterances.set(0)

        requestAudioFocus()
        duckMusicVolumeIfNeeded()
        val params = android.os.Bundle().apply {
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, speechVolume)
            if (audioSessionId != AudioManager.ERROR) {
                putInt(TextToSpeech.Engine.KEY_PARAM_SESSION_ID, audioSessionId)
            }
        }
        val utteranceId = "atun-tts-" + System.currentTimeMillis()
        pendingUtterances.incrementAndGet()
        engine.speak(text, queueMode, params, utteranceId)
        call.resolve()
    }

    @PluginMethod
    fun stop(call: PluginCall) {
        tts?.stop()
        pendingUtterances.set(0)
        abandonAudioFocus()
        restoreMusicVolumeIfNeeded()
        call.resolve()
    }

    @PluginMethod
    fun setRate(call: PluginCall) {
        val rate = (call.getFloat("rate") ?: 1.0f).coerceIn(0.5f, 2.5f)
        tts?.setSpeechRate(rate)
        call.resolve()
    }

    @PluginMethod
    fun setVolume(call: PluginCall) {
        speechVolume = (call.getFloat("volume") ?: 1.0f).coerceIn(0.0f, 1.0f)
        raiseAccessibilityStreamVolume(speechVolume)
        call.resolve()
    }

    // Khởi tạo (hoặc tái tạo nếu session đổi) LoudnessEnhancer gắn vào audioSessionId riêng của
    // TTS. Gọi lại an toàn nhiều lần - tự release cái cũ trước khi tạo cái mới. Một số máy/ROM
    // (đặc biệt bản Android rẻ tiền/tuỳ biến sâu) không hỗ trợ effect này trên luồng phát audio
    // trợ năng -> bắt Exception, coi như không khuếch đại thêm được, các mức âm lượng khác
    // (ttsVolume/duckPercent) vẫn hoạt động bình thường không bị ảnh hưởng.
    private fun setupLoudnessEnhancer() {
        if (audioSessionId == AudioManager.ERROR) return
        try {
            loudnessEnhancer?.release()
            loudnessEnhancer = LoudnessEnhancer(audioSessionId).apply {
                setTargetGain(boostMillibel)
                enabled = boostMillibel > 0
            }
        } catch (e: Exception) {
            loudnessEnhancer = null
        }
    }

    // Nâng thẳng mức TUYỆT ĐỐI của STREAM_ACCESSIBILITY theo đúng tỉ lệ speechVolume (0-1) so
    // với mức MAX của stream đó - xem giải thích ở khai báo accessibilityStreamId phía trên.
    // Chỉ NÂNG lên (không hạ xuống dưới mức user đang để) nếu mức hiện tại đã cao hơn mục tiêu,
    // để không tự ý làm nhỏ đi thứ user đã chủ động chỉnh to hơn qua Cài đặt hệ thống.
    private fun raiseAccessibilityStreamVolume(targetFraction: Float) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return // STREAM_ACCESSIBILITY cần API 30+
        val am = audioManager ?: return
        try {
            val max = am.getStreamMaxVolume(accessibilityStreamId)
            if (max <= 0) return
            val current = am.getStreamVolume(accessibilityStreamId)
            val target = (max * targetFraction).toInt().coerceIn(0, max)
            if (target > current) {
                am.setStreamVolume(accessibilityStreamId, target, 0)
            }
        } catch (e: SecurityException) {
            // 1 số ROM chặn app tự chỉnh volume trong vài tình huống (vd Do Not Disturb) -
            // bỏ qua, coi như không nâng được, không phải lỗi nghiêm trọng.
        } catch (e: IllegalArgumentException) {
            // Vài thiết bị/ROM tuỳ biến không thật sự hỗ trợ STREAM_ACCESSIBILITY dù báo API 30+
            // - bỏ qua tương tự.
        }
    }

    // Khuếch đại thêm âm lượng dịch VƯỢT mức tối đa hệ thống, qua LoudnessEnhancer - xem giải
    // thích ở khai báo boostMillibel/audioSessionId phía trên. boostDb: 0-30 (dB), truyền từ UI
    // (thanh trượt riêng, tách biệt với "Âm lượng bản dịch" 0-100% vốn chỉ chỉnh trong phạm vi
    // mức hệ thống cho phép).
    @PluginMethod
    fun setBoost(call: PluginCall) {
        val boostDb = (call.getInt("boostDb") ?: 0).coerceIn(0, 30)
        boostMillibel = boostDb * 100
        if (loudnessEnhancer == null) setupLoudnessEnhancer()
        try {
            loudnessEnhancer?.setTargetGain(boostMillibel)
            loudnessEnhancer?.enabled = boostMillibel > 0
        } catch (e: Exception) {
            // Máy/ROM không hỗ trợ - bỏ qua, không phải lỗi nghiêm trọng (xem setupLoudnessEnhancer()).
        }
        call.resolve()
    }

    // enabled: bật/tắt tự động hạ âm lượng gốc. duckPercent: hạ còn bao nhiêu % mức hiện tại
    // (0 = im lặng hẳn lúc đọc, 100 = không hạ gì - tương đương tắt tính năng nhưng vẫn giữ
    // cờ enabled=true, không có ý nghĩa thực tế khác biệt so với enabled=false).
    @PluginMethod
    fun setAutoDuck(call: PluginCall) {
        autoDuckEnabled = call.getBoolean("enabled") ?: true
        duckLevelPercent = (call.getInt("duckPercent") ?: 30).coerceIn(0, 100)
        // Nếu tắt tính năng NGAY TRONG LÚC đang hạ tiếng dở (savedMusicVolume != null) - khôi
        // phục lại ngay, đừng để tiếng gốc bị kẹt ở mức thấp cho tới utterance kế tiếp.
        if (!autoDuckEnabled) restoreMusicVolumeIfNeeded()
        call.resolve()
    }

    private fun duckMusicVolumeIfNeeded() {
        if (!autoDuckEnabled) return
        if (savedMusicVolume != null) return // đã có phiên hạ tiếng đang chạy - không lưu đè
        val am = audioManager ?: return
        val current = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        savedMusicVolume = current
        val target = (current * duckLevelPercent / 100f).toInt().coerceIn(0, current)
        if (target != current) {
            try {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
            } catch (e: SecurityException) {
                // 1 số thiết bị/ROM chặn app thay đổi volume trong 1 số tình huống (vd Do Not
                // Disturb) - bỏ qua, coi như không hạ được, không phải lỗi nghiêm trọng.
            }
        }
    }

    private fun restoreMusicVolumeIfNeeded() {
        val saved = savedMusicVolume ?: return
        savedMusicVolume = null
        val am = audioManager ?: return
        try {
            am.setStreamVolume(AudioManager.STREAM_MUSIC, saved, 0)
        } catch (e: SecurityException) {
            // Xem giải thích ở duckMusicVolumeIfNeeded().
        }
    }

    // Giọng đọc tiếng Việt không có sẵn trên mọi máy (đặc biệt máy cũ/ROM tuỳ biến) - cho JS
    // biết trước để hiện nút "Cài giọng đọc tiếng Việt" thay vì im lặng không đọc được gì mà
    // không rõ lý do.
    @PluginMethod
    fun checkVietnameseVoice(call: PluginCall) {
        val engine = tts
        val result = if (engine == null) TextToSpeech.LANG_NOT_SUPPORTED
            else engine.isLanguageAvailable(Locale("vi", "VN"))
        val ret = JSObject()
        ret.put("available", result >= TextToSpeech.LANG_AVAILABLE)
        call.resolve(ret)
    }

    // Mở màn hình hệ thống để tải giọng đọc tiếng Việt (thường qua Google Text-to-Speech) -
    // không có API tự tải ngầm, bắt buộc phải qua màn hình hệ thống để user tự xác nhận tải.
    @PluginMethod
    fun promptInstallVoiceData(call: PluginCall) {
        try {
            val intent = Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(intent)
            call.resolve()
        } catch (e: Exception) {
            call.reject("Không mở được màn hình cài giọng đọc: ${e.message}")
        }
    }

    private fun requestAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val req = focusRequest ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(speechAttributes)
                .build().also { focusRequest = it }
            am.requestAudioFocus(req)
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
        }
    }

    private fun abandonAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            focusRequest?.let { am.abandonAudioFocusRequest(it) }
        } else {
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(null)
        }
    }

    override fun handleOnDestroy() {
        tts?.stop()
        tts?.shutdown()
        loudnessEnhancer?.release()
        loudnessEnhancer = null
        restoreMusicVolumeIfNeeded()
        super.handleOnDestroy()
    }
}
