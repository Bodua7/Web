package com.atun.translator

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView

// Overlay hiện phụ đề đè lên màn hình. Phase 3: cho kéo-thả đổi vị trí (nhớ lại vị trí lần
// sau qua SharedPreferences), tự mờ dần dòng cũ sau vài giây thay vì đứng yên chờ dòng mới,
// và cỡ chữ tùy chỉnh (small/medium/large).
class OverlayView(private val context: Context) {
    companion object {
        private const val PREFS_NAME = "overlay_position"
        private const val KEY_X = "x"
        private const val KEY_Y = "y"

        // Sau chừng này (ms) không có dòng mới thì bắt đầu mờ dần dòng đang hiện, để không
        // che khuất màn hình vô thời hạn trong lúc chờ câu tiếp theo.
        private const val FADE_DELAY_MS = 4000L
        private const val FADE_DURATION_MS = 600L
        private const val FADE_TARGET_ALPHA = 0.15f

        fun fontSizeSpFor(size: String?): Float = when (size) {
            "small" -> 13f
            "large" -> 20f
            else -> 16f // "medium" hoặc giá trị lạ -> mặc định
        }
    }

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val fadeHandler = Handler(Looper.getMainLooper())
    private val fadeRunnable = Runnable {
        textView.animate().alpha(FADE_TARGET_ALPHA).setDuration(FADE_DURATION_MS).start()
    }

    private fun dp(value: Float): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, value, context.resources.displayMetrics
    ).toInt()

    private val textView = TextView(context).apply {
        setTextColor(Color.WHITE)
        textSize = fontSizeSpFor("medium")
        setPadding(dp(16f), dp(8f), dp(16f), dp(8f))
        gravity = Gravity.CENTER
        maxWidth = (context.resources.displayMetrics.widthPixels * 0.85f).toInt()
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#CC1A1A1A"))
            cornerRadius = dp(14f).toFloat()
        }
        text = "Testing overlay..."
    }

    // Gravity BOTTOM|CENTER_HORIZONTAL cố định làm điểm neo (anchor); x/y là offset từ điểm neo
    // đó, được kéo-thả chỉnh tiếp qua onTouch bên dưới. Khôi phục offset đã lưu lần trước
    // (mặc định 0,90dp = vị trí gốc trước Phase 3 nếu chưa từng kéo-thả).
    private val params = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        android.graphics.PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        x = prefs.getInt(KEY_X, 0)
        y = prefs.getInt(KEY_Y, dp(90f))
    }

    private var dragStartParamsX = 0
    private var dragStartParamsY = 0
    private var dragStartTouchX = 0f
    private var dragStartTouchY = 0f
    private var isDragging = false

    init {
        textView.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    isDragging = false
                    dragStartParamsX = params.x
                    dragStartParamsY = params.y
                    dragStartTouchX = event.rawX
                    dragStartTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - dragStartTouchX).toInt()
                    val dy = (event.rawY - dragStartTouchY).toInt()
                    if (!isDragging && (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8)) {
                        isDragging = true
                    }
                    if (isDragging) {
                        // gravity CENTER_HORIZONTAL: x dương = dịch phải.
                        // gravity BOTTOM: y là khoảng cách tính từ mép dưới màn hình lên trên,
                        // nên kéo lên (dy âm vì toạ độ màn hình tăng dần xuống dưới) phải TĂNG y.
                        params.x = dragStartParamsX + dx
                        params.y = dragStartParamsY - dy
                        windowManager.updateViewLayout(view, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (isDragging) {
                        prefs.edit().putInt(KEY_X, params.x).putInt(KEY_Y, params.y).apply()
                    }
                    isDragging = false
                    true
                }
                else -> false
            }
        }
    }

    fun attach() = windowManager.addView(textView, params)

    fun setText(text: String) {
        fadeHandler.removeCallbacks(fadeRunnable)
        textView.animate().cancel()
        textView.alpha = 1f
        textView.text = text
        if (text.isNotBlank()) {
            fadeHandler.postDelayed(fadeRunnable, FADE_DELAY_MS)
        }
    }

    fun setFontSize(size: String) {
        textView.textSize = fontSizeSpFor(size)
    }

    fun detach() {
        fadeHandler.removeCallbacks(fadeRunnable)
        textView.animate().cancel()
        windowManager.removeView(textView)
    }
}
