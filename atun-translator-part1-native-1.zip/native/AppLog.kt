package com.atun.translator

import android.content.Context
import java.io.File

// Kho log lỗi/crash cục bộ, dùng chung giữa:
//  - MainActivity.installCrashLogger() (bắt uncaught exception -> ghi CRASH)
//  - ExportPlugin (nhận log lỗi JS gửi lên qua appendErrorLog, và đọc/xoá log qua
//    getErrorLog/clearErrorLog để hiện nút "Chia sẻ log lỗi" trên UI)
//
// Ghi vào bộ nhớ riêng của app (filesDir) thay vì Download công khai:
//  - Không cần MediaStore/permission, ghi append được ngay (MediaStore.insert() mỗi lần
//    gọi tạo 1 ROW MỚI trên Android 10+ -> sinh ra "..._log(1).txt", "..._log(2).txt"...
//    thay vì nối vào 1 file, gây rối khi cần xem log gần nhất).
//  - Sống sót qua nhiều lần mở/tắt app (khác với logLines trong JS chỉ tồn tại trong
//    session hiện tại), và có thể chia sẻ ra ngoài bất kỳ lúc nào qua Share Sheet
//    (ExportPlugin.shareFile) mà không cần user tự mò vào My Files > Download.
object AppLog {
    private const val FILE_NAME = "atun_error_log.txt"

    // Giới hạn kích thước để log không phình vô hạn qua nhiều ngày dùng app - khi vượt
    // ngưỡng, cắt bớt phần đầu (cũ nhất), giữ lại phần cuối (mới nhất) vì lỗi gần nhất mới
    // là thứ cần xem khi báo lỗi.
    private const val MAX_BYTES = 200 * 1024 // 200 KB

    @Synchronized
    fun append(context: Context, line: String) {
        try {
            val file = File(context.filesDir, FILE_NAME)
            val time = java.text.SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()
            ).format(java.util.Date())
            file.appendText("[$time] $line\n", Charsets.UTF_8)
            trimIfNeeded(file)
        } catch (e: Exception) {
            // Không được để việc ghi log gây crash thêm lần nữa.
        }
    }

    @Synchronized
    fun read(context: Context): String {
        val file = File(context.filesDir, FILE_NAME)
        return if (file.exists()) file.readText(Charsets.UTF_8) else ""
    }

    @Synchronized
    fun clear(context: Context) {
        val file = File(context.filesDir, FILE_NAME)
        if (file.exists()) file.delete()
    }

    private fun trimIfNeeded(file: File) {
        if (file.length() <= MAX_BYTES) return
        val content = file.readText(Charsets.UTF_8)
        // Giữ lại nửa sau (mới hơn) khi file vượt ngưỡng.
        val trimmed = content.substring(content.length / 2)
        // Cắt tới đầu dòng gần nhất để không vỡ dòng giữa chừng.
        val newlineIdx = trimmed.indexOf('\n')
        val clean = if (newlineIdx >= 0) trimmed.substring(newlineIdx + 1) else trimmed
        file.writeText("[...log cũ đã bị cắt bớt...]\n$clean", Charsets.UTF_8)
    }
}
