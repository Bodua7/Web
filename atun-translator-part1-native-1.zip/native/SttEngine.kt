package com.atun.translator

// Interface chung cho "1 engine STT đang chạy" - VoskEngine (1 ngôn ngữ cố định) và
// MultiLangVoskEngine (nhiều ngôn ngữ chạy song song, chế độ "tự động nhận diện") đều implement
// interface này, để AudioCaptureService dùng chung 1 biến/1 luồng gọi mà không cần if/else phân
// biệt 2 loại ở read loop (xem AudioCaptureService.startVoskAndReadLoop).
interface SttEngine {
    fun init()
    fun feed(pcm: ShortArray, length: Int)
    fun forcePauseFinal()
    fun release()
}
