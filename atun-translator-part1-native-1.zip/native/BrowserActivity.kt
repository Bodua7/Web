package com.atun.translator

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.PermissionRequest
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayInputStream

// ===== "Web mini": trình duyệt web thu nhỏ =====
// Tách BIỆT HOÀN TOÀN khỏi www/index.html (app dịch chính, chạy trong Capacitor Bridge
// WebView) - đây là 1 Activity Android THUẦN (không phải BridgeActivity), tự dựng UI hoàn
// toàn bằng code (không cần thêm file layout .xml nào), mở từ nút trong app chính qua
// BrowserLauncherPlugin (Intent thường, VẪN CÙNG app/process).
//
// Mục đích: cho người dùng vào bất kỳ trang web nào để phát audio/video, phục vụ tính năng
// "Bắt âm thanh hệ thống" dịch trực tiếp của app chính. AudioCaptureService (MediaProjection)
// chạy nền hoàn toàn độc lập với Activity nào đang hiển thị trên màn hình, nên KHÔNG cần nối
// code trực tiếp giữa 2 màn hình - chỉ cần audio phát ra từ thiết bị (kể cả từ Activity này)
// là app chính bắt được, y hệt như bắt audio từ bất kỳ app nào khác.
class BrowserActivity : Activity() {

    private data class BrowserTab(
        val id: Long,
        val webView: WebView,
        val chip: TextView,
        val row: LinearLayout,
        var title: String = "Trang mới"
    )

    companion object {
        // Giới hạn số tab đang mở cùng lúc - mỗi tab giữ 1 WebView sống hoàn toàn (không tab
        // nào bị suspend khi không dùng), mở vô hạn tab sẽ tốn RAM dần. 8 là đủ dùng cho nhu
        // cầu thực tế (mở vài trang để bắt audio hệ thống), không cần nhiều hơn.
        private const val MAX_TABS = 8
    }

    private val tabs = mutableListOf<BrowserTab>()
    private var currentTabIndex = -1
    private var nextTabId = 1L

    private lateinit var storage: BrowserStorage
    private lateinit var addressBar: EditText
    private lateinit var addressBarClearBtn: Button
    private lateinit var securityIconView: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var tabStrip: LinearLayout
    private lateinit var webViewContainer: FrameLayout
    private lateinit var btnBookmark: Button

    private var customFullscreenView: View? = null
    private var customFullscreenCallback: WebChromeClient.CustomViewCallback? = null

    private fun dp(v: Float): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        storage = BrowserStorage(applicationContext)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        root.addView(buildTopBar())
        root.addView(buildTabStrip())

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        root.addView(progressBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3f)))

        webViewContainer = FrameLayout(this)
        root.addView(
            webViewContainer,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )

        setContentView(root)

        // Nếu được mở kèm 1 URL cụ thể (BrowserLauncherPlugin.open({url: ...})) thì ưu tiên mở
        // đúng URL đó (phiên làm việc mới, không phục hồi tab cũ). Ngược lại (trường hợp thường
        // gặp nhất - bấm "🌐 Mở web mini" không kèm url nào) thì khôi phục lại các tab đã lưu từ
        // lần dùng trước, để không mất trắng nếu Android đã kill Activity ở nền giữa lúc dùng.
        val explicitUrl = intent.getStringExtra("url")?.takeIf { it.isNotBlank() }
        if (explicitUrl != null) {
            openNewTab(explicitUrl)
        } else {
            val (savedUrls, savedActiveIndex) = storage.getOpenTabs()
            if (savedUrls.isNotEmpty()) {
                savedUrls.forEach { openNewTab(it) }
                val restoreIndex = savedActiveIndex.coerceIn(0, tabs.size - 1)
                switchToTab(tabs[restoreIndex].id)
            } else {
                openNewTab("https://www.google.com")
            }
        }
    }

    // Lưu URL hiện tại của từng tab mỗi khi Activity ra nền (chuyển app khác, tắt màn hình...) -
    // đây là thời điểm hệ thống ĐẢM BẢO gọi trước khi có thể kill Activity, đúng lúc cần lưu.
    override fun onPause() {
        super.onPause()
        val urls = tabs.map { it.webView.url ?: "https://www.google.com" }
        storage.saveOpenTabs(urls, currentTabIndex.coerceAtLeast(0))
    }

    // ================= Top bar (địa chỉ + điều hướng) =================
    private fun buildTopBar(): LinearLayout {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4f), dp(6f), dp(4f), dp(6f))
            setBackgroundColor(Color.parseColor("#F5F5F5"))
        }

        val btnBack = flatButton("←") { currentWebView()?.let { if (it.canGoBack()) it.goBack() } }
        val btnForward = flatButton("→") { currentWebView()?.let { if (it.canGoForward()) it.goForward() } }
        val btnReload = flatButton("⟳") { currentWebView()?.reload() }

        // Icon khoá báo trang an toàn (https) hay không (http) - cập nhật trong onPageFinished
        // của WebViewClient bên dưới mỗi khi trang load xong. "🌐" là trạng thái mặc định
        // trước khi có trang nào load (about:blank, chưa nhập gì...).
        securityIconView = TextView(this).apply {
            text = "🌐"
            textSize = 14f
            setPadding(dp(6f), 0, dp(2f), 0)
        }

        addressBar = EditText(this).apply {
            hint = "Nhập địa chỉ web hoặc từ khoá..."
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_GO) {
                    loadInCurrentTab(normalizeUrl(text.toString()))
                    true
                } else false
            }
            addTextChangedListener(object : android.text.TextWatcher {
                override fun afterTextChanged(s: android.text.Editable?) {
                    addressBarClearBtn.visibility = if (s.isNullOrEmpty()) View.GONE else View.VISIBLE
                }
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            })
        }
        val addrParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(4f)
            marginEnd = dp(4f)
        }

        // Nút "×" xoá nhanh chữ đang gõ trong ô địa chỉ - trước đây phải tự bôi đen/xoá tay
        // từng ký tự. Ẩn mặc định, chỉ hiện khi ô địa chỉ đang có chữ (xem TextWatcher ở trên).
        addressBarClearBtn = flatButton("×") { addressBar.setText("") }
        addressBarClearBtn.visibility = View.GONE

        btnBookmark = flatButton("☆") { toggleBookmarkCurrentTab() }
        val btnMenu = flatButton("⋮") {}
        btnMenu.setOnClickListener { showMenu(btnMenu) }

        bar.addView(btnBack)
        bar.addView(btnForward)
        bar.addView(btnReload)
        bar.addView(securityIconView)
        bar.addView(addressBar, addrParams)
        bar.addView(addressBarClearBtn)
        bar.addView(btnBookmark)
        bar.addView(btnMenu)
        return bar
    }

    private fun flatButton(label: String, onClick: () -> Unit): Button {
        // Dùng Button chữ/ký hiệu thay vì icon vector -> khỏi cần thêm resource drawable nào.
        return Button(this).apply {
            text = label
            textSize = 16f
            isAllCaps = false
            setPadding(dp(10f), 0, dp(10f), 0)
            minWidth = dp(40f)
            minimumWidth = dp(40f)
            background = null
            setOnClickListener { onClick() }
        }
    }

    // ================= Tab strip (nhiều tab, cuộn ngang) =================
    private fun buildTabStrip(): HorizontalScrollView {
        tabStrip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(Color.parseColor("#EEEEEE"))
            addView(tabStrip)
        }
        val plusBtn = flatButton("＋ Tab mới") { openNewTab("https://www.google.com") }
        tabStrip.addView(plusBtn)
        return scroll
    }

    private fun rebuildTabChip(tab: BrowserTab) {
        tab.chip.text = (tab.title.ifBlank { "Trang mới" }).let {
            if (it.length > 14) it.substring(0, 14) + "…" else it
        }
        val isCurrent = tabs.getOrNull(currentTabIndex)?.id == tab.id
        tab.chip.setBackgroundColor(if (isCurrent) Color.parseColor("#FFFFFF") else Color.TRANSPARENT)
        tab.chip.setTypeface(null, if (isCurrent) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
    }

    // ================= Quản lý tab =================
    private fun currentWebView(): WebView? = tabs.getOrNull(currentTabIndex)?.webView

    private fun openNewTab(url: String) {
        if (tabs.size >= MAX_TABS) {
            Toast.makeText(this, "Đã mở tối đa $MAX_TABS tab - đóng bớt tab trước khi mở thêm", Toast.LENGTH_SHORT).show()
            return
        }

        val webView = createWebView()
        val chip = TextView(this).apply {
            text = "Trang mới"
            textSize = 13f
            setPadding(dp(12f), dp(8f), dp(12f), dp(8f))
        }
        // Nút "×" riêng để đóng tab - trước đây chỉ đóng được bằng long-press vào chip, không
        // dễ nhận ra; giữ lại long-press như phím tắt phụ, thêm nút này cho rõ ràng, dễ bấm.
        val closeBtn = TextView(this).apply {
            text = "×"
            textSize = 15f
            setPadding(dp(8f), dp(8f), dp(10f), dp(8f))
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(chip)
        row.addView(closeBtn)

        val tab = BrowserTab(id = nextTabId++, webView = webView, chip = chip, row = row)
        chip.setOnClickListener { switchToTab(tab.id) }
        chip.setOnLongClickListener { closeTab(tab.id); true }
        closeBtn.setOnClickListener { closeTab(tab.id) }

        tabs.add(tab)
        // Chèn row TRƯỚC nút "Tab mới" (nút này luôn ở cuối cùng trong tabStrip)
        tabStrip.addView(row, tabStrip.childCount - 1)

        switchToTab(tab.id)
        loadInCurrentTab(normalizeUrl(url))
    }

    private fun switchToTab(tabId: Long) {
        val index = tabs.indexOfFirst { it.id == tabId }
        if (index == -1) return
        webViewContainer.removeAllViews()
        currentTabIndex = index
        val tab = tabs[index]
        webViewContainer.addView(
            tab.webView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        addressBar.setText(tab.webView.url ?: "")
        btnBookmark.text = if (storage.isBookmarked(tab.webView.url ?: "")) "★" else "☆"
        securityIconView.text = when {
            tab.webView.url?.startsWith("https://") == true -> "🔒"
            tab.webView.url?.startsWith("http://") == true -> "⚠️"
            else -> "🌐"
        }
        tabs.forEach { rebuildTabChip(it) }
    }

    private fun closeTab(tabId: Long) {
        val index = tabs.indexOfFirst { it.id == tabId }
        if (index == -1) return
        if (tabs.size == 1) {
            // Tab cuối cùng: không đóng app đột ngột, đóng luôn màn hình web mini
            finish()
            return
        }
        val tab = tabs.removeAt(index)
        tabStrip.removeView(tab.row)
        tab.webView.destroy()
        val fallbackIndex = (index - 1).coerceAtLeast(0)
        currentTabIndex = -1
        switchToTab(tabs[fallbackIndex].id)
    }

    // ================= WebView =================
    @Suppress("SetJavaScriptEnabled")
    private fun createWebView(): WebView {
        val webView = WebView(this)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        // Trước đây chưa xử lý gì khi trang có link tải file (mp3/video/pdf...) - bấm vào coi
        // như không có phản hồi. Giờ đẩy qua DownloadManager của hệ thống, tải về thư mục
        // Downloads công khai, có thông báo tiến trình + xong của chính Android lo, không cần
        // tự vẽ progress bar tải file riêng.
        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            handleDownload(url, userAgent, contentDisposition, mimeType)
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                // Luôn mở link ngay trong WebView này (không nhảy ra app trình duyệt ngoài),
                // giữ đúng chủ trương "trang chạy TRONG app này" để audio thuộc phiên âm thanh
                // của chính app -> "Bắt âm thanh hệ thống" của app chính vẫn bắt được.
                return false
            }

            // Chặn quảng cáo: mọi request (ảnh, script, iframe con...) đi qua đây trước khi
            // WebView tải - so host với AdBlockList, khớp thì trả về response RỖNG thay vì cho
            // tải thật (chặn im lặng, trang vẫn chạy tiếp bình thường, chỉ thiếu phần quảng
            // cáo/tracker đó). Tôn trọng tuỳ chọn bật/tắt trong menu - đọc trực tiếp từ storage
            // mỗi lần để luôn phản ánh đúng trạng thái mới nhất, không cache sai.
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                if (storage.isAdBlockEnabled() && AdBlockList.isBlocked(request.url.host)) {
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                val tab = tabs.find { it.webView == view } ?: return
                tab.title = view.title?.takeIf { it.isNotBlank() } ?: (url ?: tab.title)
                rebuildTabChip(tab)
                if (tabs.getOrNull(currentTabIndex)?.id == tab.id) {
                    addressBar.setText(url ?: "")
                    btnBookmark.text = if (storage.isBookmarked(url ?: "")) "★" else "☆"
                    securityIconView.text = when {
                        url?.startsWith("https://") == true -> "🔒"
                        url?.startsWith("http://") == true -> "⚠️"
                        else -> "🌐"
                    }
                }
                if (!url.isNullOrBlank()) {
                    storage.addHistory(url, tab.title)
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                if (tabs.getOrNull(currentTabIndex)?.webView == view) {
                    progressBar.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                    progressBar.progress = newProgress
                }
            }

            // Hỗ trợ fullscreen cho video HTML5 (nhiều trang phát video dùng chuẩn này thay vì
            // Fullscreen API của DOM) - phủ view fullscreen lên toàn bộ root, thoát ra khi trang
            // tự gọi onHideCustomView() hoặc người dùng bấm back (xem onBackPressed()).
            override fun onShowCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
                if (customFullscreenView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                customFullscreenView = view
                customFullscreenCallback = callback
                (window.decorView as FrameLayout).addView(
                    view,
                    FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT).apply {
                        gravity = Gravity.CENTER
                    }
                )
            }

            override fun onHideCustomView() {
                hideCustomFullscreenView()
            }

            // Trước đây chưa override -> WebView tự động từ chối MỌI yêu cầu camera/mic của
            // trang web (vd trang gọi video, ghi âm online...) mà không có gì báo cho biết vì
            // sao. Giờ: chỉ cấp mic (RESOURCE_AUDIO_CAPTURE) và CHỈ khi app đã có quyền
            // RECORD_AUDIO ở tầng hệ thống (app xin quyền này cho tính năng bắt giọng nói
            // chính). Camera luôn từ chối vì app không khai báo permission CAMERA trong
            // Manifest - cấp bừa sẽ crash chứ không hoạt động được.
            override fun onPermissionRequest(request: PermissionRequest) {
                val hasMic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) ==
                    PackageManager.PERMISSION_GRANTED
                val granted = request.resources.filter {
                    it == PermissionRequest.RESOURCE_AUDIO_CAPTURE && hasMic
                }
                if (granted.isNotEmpty()) {
                    request.grant(granted.toTypedArray())
                } else {
                    request.deny()
                }
            }
        }

        return webView
    }

    private fun handleDownload(url: String, userAgent: String, contentDisposition: String, mimeType: String?) {
        try {
            val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
            val request = DownloadManager.Request(Uri.parse(url)).apply {
                setMimeType(mimeType)
                addRequestHeader("User-Agent", userAgent)
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                setAllowedOverMetered(true)
            }
            val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
            dm.enqueue(request)
            Toast.makeText(this, "Đang tải: $fileName", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Không tải được file: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun hideCustomFullscreenView() {
        val view = customFullscreenView ?: return
        (window.decorView as FrameLayout).removeView(view)
        customFullscreenView = null
        customFullscreenCallback?.onCustomViewHidden()
        customFullscreenCallback = null
    }

    private fun loadInCurrentTab(url: String) {
        currentWebView()?.loadUrl(url)
    }

    private fun normalizeUrl(input: String): String {
        // Bỏ khoảng trắng thường (trim()) + các ký tự VÔ HÌNH hay dính theo khi copy link từ
        // app khác (share sheet của YouTube, bàn phím Samsung...): zero-width space/joiner
        // (U+200B/U+200C/U+200D), BOM (U+FEFF), dấu định hướng trái/phải LRM/RLM (U+200E/U+200F).
        // Các ký tự này KHÔNG phải whitespace theo Char.isWhitespace() nên trim() thường không
        // loại được - trước đây khiến startsWith("https://") trượt oan (dù nhìn bằng mắt vẫn y
        // hệt "https://...") và cả câu rơi xuống nhánh tìm kiếm Google thay vì mở thẳng link.
        val trimmed = input.trim().trim('\u200B', '\u200C', '\u200D', '\uFEFF', '\u200E', '\u200F')
        if (trimmed.isEmpty()) return "https://www.google.com"
        // So khớp scheme không phân biệt hoa/thường - bàn phím có thể tự viết hoa ký tự đầu.
        val lower = trimmed.lowercase()
        val looksLikeUrl = trimmed.contains(".") && !trimmed.any { it.isWhitespace() }
        return when {
            lower.startsWith("http://") || lower.startsWith("https://") -> trimmed
            lower.startsWith("www.") -> "https://$trimmed"
            looksLikeUrl -> "https://$trimmed"
            else -> "https://www.google.com/search?q=" + java.net.URLEncoder.encode(trimmed, "UTF-8")
        }
    }

    // ================= Bookmark / History / Menu =================
    private fun toggleBookmarkCurrentTab() {
        val tab = tabs.getOrNull(currentTabIndex) ?: return
        val url = tab.webView.url ?: return
        if (storage.isBookmarked(url)) {
            storage.removeBookmark(url)
            btnBookmark.text = "☆"
            Toast.makeText(this, "Đã bỏ đánh dấu", Toast.LENGTH_SHORT).show()
        } else {
            storage.addBookmark(url, tab.title)
            btnBookmark.text = "★"
            Toast.makeText(this, "Đã đánh dấu trang", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add("Bookmark")
        popup.menu.add("Lịch sử")
        popup.menu.add("Xoá lịch sử")
        val adBlockLabel = if (storage.isAdBlockEnabled()) "Tắt chặn quảng cáo" else "Bật chặn quảng cáo"
        popup.menu.add(adBlockLabel)
        popup.menu.add("Đóng tab này")
        popup.menu.add("Quay lại app dịch")
        popup.setOnMenuItemClickListener { item ->
            when (item.title) {
                "Bookmark" -> showBookmarksDialog()
                "Lịch sử" -> showHistoryDialog()
                "Xoá lịch sử" -> confirmClearHistory()
                adBlockLabel -> {
                    storage.setAdBlockEnabled(!storage.isAdBlockEnabled())
                    val nowOn = storage.isAdBlockEnabled()
                    Toast.makeText(this, if (nowOn) "Đã bật chặn quảng cáo" else "Đã tắt chặn quảng cáo", Toast.LENGTH_SHORT).show()
                    currentWebView()?.reload()
                }
                "Đóng tab này" -> tabs.getOrNull(currentTabIndex)?.let { closeTab(it.id) }
                "Quay lại app dịch" -> finish()
            }
            true
        }
        popup.show()
    }

    private fun showBookmarksDialog() {
        val entries = storage.getBookmarks()
        if (entries.isEmpty()) {
            Toast.makeText(this, "Chưa có bookmark nào", Toast.LENGTH_SHORT).show()
            return
        }
        showEntryListDialog("Bookmark", entries) { entry ->
            AlertDialog.Builder(this)
                .setTitle(entry.title)
                .setItems(arrayOf("Mở", "Xoá bookmark")) { d, which ->
                    if (which == 0) {
                        loadInCurrentTab(entry.url)
                    } else {
                        storage.removeBookmark(entry.url)
                        btnBookmark.text = if (storage.isBookmarked(currentWebView()?.url ?: "")) "★" else "☆"
                    }
                    d.dismiss()
                }
                .show()
        }
    }

    private fun confirmClearHistory() {
        AlertDialog.Builder(this)
            .setTitle("Xoá lịch sử")
            .setMessage("Xoá toàn bộ lịch sử duyệt web mini? Không ảnh hưởng bookmark.")
            .setPositiveButton("Xoá") { d, _ ->
                storage.clearHistory()
                Toast.makeText(this, "Đã xoá lịch sử", Toast.LENGTH_SHORT).show()
                d.dismiss()
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }

    private fun showHistoryDialog() {
        val entries = storage.getHistory()
        if (entries.isEmpty()) {
            Toast.makeText(this, "Chưa có lịch sử duyệt web", Toast.LENGTH_SHORT).show()
            return
        }
        showEntryListDialog("Lịch sử", entries) { entry ->
            loadInCurrentTab(entry.url)
        }
    }

    private fun showEntryListDialog(
        title: String,
        entries: List<BrowserStorage.Entry>,
        onPick: (BrowserStorage.Entry) -> Unit
    ) {
        val labels = entries.map { "${it.title}\n${it.url}" }.toTypedArray()
        val listView = ListView(this).apply {
            adapter = ArrayAdapter(this@BrowserActivity, android.R.layout.simple_list_item_1, labels)
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(title)
            .setView(listView)
            .setNegativeButton("Đóng", null)
            .create()
        listView.setOnItemClickListener { _, _, position, _ ->
            onPick(entries[position])
            dialog.dismiss()
        }
        dialog.show()
    }

    // ================= Back button =================
    override fun onBackPressed() {
        if (customFullscreenView != null) {
            hideCustomFullscreenView()
            return
        }
        val webView = currentWebView()
        if (webView != null && webView.canGoBack()) {
            webView.goBack()
            return
        }
        if (tabs.size > 1) {
            tabs.getOrNull(currentTabIndex)?.let { closeTab(it.id) }
            return
        }
        super.onBackPressed()
    }

    override fun onDestroy() {
        tabs.forEach { it.webView.destroy() }
        super.onDestroy()
    }
}
