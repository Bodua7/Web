package com.atun.translator

import android.provider.Settings
import com.getcapacitor.*
import com.getcapacitor.annotation.CapacitorPlugin

@CapacitorPlugin(name = "OverlayPlugin")
class OverlayWindowPlugin : Plugin() {
    private var overlayView: OverlayView? = null

    @PluginMethod
    fun checkPermission(call: PluginCall) {
        val granted = Settings.canDrawOverlays(context)
        val ret = JSObject()
        ret.put("granted", granted)
        call.resolve(ret)
    }

    @PluginMethod
    fun requestPermission(call: PluginCall) {
        val intent = android.content.Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            android.net.Uri.parse("package:${context.packageName}")
        )
        activity.startActivity(intent)
        call.resolve()
    }

    @PluginMethod
    fun show(call: PluginCall) {
        if (overlayView == null) {
            overlayView = OverlayView(context)
            overlayView?.attach()
        }
        call.resolve()
    }

    @PluginMethod
    fun updateText(call: PluginCall) {
        val text = call.getString("text") ?: ""
        overlayView?.setText(text)
        call.resolve()
    }

    // Phase 3: cỡ chữ tùy chỉnh (size = "small" | "medium" | "large"), gọi từ Settings JS.
    // Nếu overlay chưa attach (chưa show() lần nào) thì bỏ qua êm - lần show() kế tiếp sẽ
    // tạo TextView mới với cỡ chữ mặc định; JS nên gọi lại updateFontSize ngay sau show().
    @PluginMethod
    fun updateFontSize(call: PluginCall) {
        val size = call.getString("size") ?: "medium"
        overlayView?.setFontSize(size)
        call.resolve()
    }

    @PluginMethod
    fun hide(call: PluginCall) {
        removeOverlay()
        call.resolve()
    }

    private fun removeOverlay() {
        overlayView?.detach()
        overlayView = null
    }

    // Tự dọn overlay khi Activity bị huỷ (tắt app / swipe khỏi recent apps),
    // tránh trường hợp view overlay treo lại vĩnh viễn trên màn hình vì
    // WindowManager không tự gỡ view khi chỉ Activity mất đi (process vẫn sống).
    override fun handleOnDestroy() {
        removeOverlay()
        super.handleOnDestroy()
    }
}
