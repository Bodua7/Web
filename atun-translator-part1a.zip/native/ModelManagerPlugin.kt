package com.atun.translator

import android.content.Context
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import kotlin.concurrent.thread

// Quản lý model Vosk KHÔNG bundle sẵn trong APK (mọi ngôn ngữ trừ "en") - tải zip từ URL cấu
// hình sẵn (GitHub Release), giải nén vào filesDir/models/<lang>/, dùng trực tiếp bằng
// Model(path) (xem VoskEngine.resolveModelSource) thay vì StorageService.unpack (chỉ đọc
// được asset đóng gói sẵn trong APK, không đọc được file tải về runtime).
//
// Lý do không bundle hết mọi ngôn ngữ vào APK: mỗi model Vosk ~35-50MB, bundle 4-5 ngôn ngữ
// sẽ đẩy APK vượt 200MB, rất khó tải/phân phối qua GitHub Releases + cài trực tiếp (không qua
// Play Store). Chỉ bundle "en" (ngôn ngữ dùng nhiều nhất), còn lại tải khi cần.
@CapacitorPlugin(name = "ModelManager")
class ModelManagerPlugin : com.getcapacitor.Plugin() {

    companion object {
        // ===== TODO(ATun): điền URL thật sau khi đã nén model thành .zip và upload lên
        // GitHub Releases (Settings -> Releases -> tạo release mới -> đính kèm file .zip).
        // Mỗi zip giải nén ra phải có cấu trúc model Vosk chuẩn (thư mục am/, conf/, graph/...)
        // nằm NGAY TRONG zip (không bọc thêm 1 lớp thư mục cha), để catalog map thẳng
        // filesDir/models/<lang>/ -> model root.
        // sizeMB chỉ để hiển thị ước lượng cho UI trước khi tải - không ảnh hưởng logic.
        val CATALOG: Map<String, ModelInfo> = mapOf(
            "vi" to ModelInfo("Tiếng Việt", "https://github.com/USER/REPO/releases/download/models/model-vi.zip", 45),
            "ja" to ModelInfo("日本語", "https://github.com/USER/REPO/releases/download/models/model-ja.zip", 48),
            "ko" to ModelInfo("한국어", "https://github.com/USER/REPO/releases/download/models/model-ko.zip", 40),
            // Model tiếng Anh LỚN, chính xác cao hơn hẳn bản "en" bundled (~40MB, WER thấp hơn
            // nhiều so với model small). Tải trực tiếp từ URL chính chủ Alphacephei - zip này có
            // 1 lớp thư mục cha "vosk-model-en-us-0.22/" bọc ngoài (khác zip model-vi/ja/ko đã tự
            // đóng gói phẳng ở trên) - hàm unzip() bên dưới tự phát hiện và bóc lớp đó ra, không
            // cần re-zip thủ công. Cảnh báo: ~1.8GB, chỉ nên tải qua Wi-Fi.
            "en-large" to ModelInfo(
                "English (chính xác cao)",
                "https://alphacephei.com/vosk/models/vosk-model-en-us-0.22.zip",
                1800
            )
        )

        // "en" không nằm trong CATALOG - luôn coi là "bundled" (đã đóng gói sẵn trong APK,
        // xem scripts/copy-model-assets.py + assets-for-android/model-en).
        const val BUNDLED_LANG = "en"

        fun modelsDir(context: Context): File = File(context.filesDir, "models")

        fun modelDir(context: Context, lang: String): File = File(modelsDir(context), lang)

        // Dùng lại ở VoskEngine để biết model đã sẵn sàng chưa trước khi start capture.
        fun isDownloaded(context: Context, lang: String): Boolean {
            val dir = modelDir(context, lang)
            return dir.isDirectory && (dir.listFiles()?.isNotEmpty() == true)
        }
    }

    data class ModelInfo(val displayName: String, val url: String, val sizeMB: Int)

    // Theo dõi các lượt tải đang chạy để hỗ trợ cancelDownload() - key = lang.
    private val activeDownloads = mutableMapOf<String, Thread>()

    @PluginMethod
    fun listModels(call: PluginCall) {
        val arr = JSArray()

        val bundledObj = JSObject()
        bundledObj.put("lang", BUNDLED_LANG)
        bundledObj.put("name", "English")
        bundledObj.put("sizeMB", 40)
        bundledObj.put("status", "bundled")
        arr.put(bundledObj)

        for ((lang, info) in CATALOG) {
            val obj = JSObject()
            obj.put("lang", lang)
            obj.put("name", info.displayName)
            obj.put("sizeMB", info.sizeMB)
            obj.put("status", if (isDownloaded(context, lang)) "downloaded" else "not_downloaded")
            arr.put(obj)
        }

        val ret = JSObject()
        ret.put("models", arr)
        call.resolve(ret)
    }

    @PluginMethod
    fun downloadModel(call: PluginCall) {
        val lang = call.getString("lang")
        if (lang.isNullOrBlank()) {
            call.reject("Thiếu tham số lang.")
            return
        }
        val info = CATALOG[lang]
        if (info == null) {
            call.reject("Không có model cho lang=$lang trong catalog.")
            return
        }
        if (isDownloaded(context, lang)) {
            call.resolve(JSObject().apply { put("alreadyDownloaded", true) })
            return
        }
        if (activeDownloads.containsKey(lang)) {
            call.reject("Đang tải model cho lang=$lang rồi, đợi xong hoặc cancelDownload() trước.")
            return
        }

        val targetDir = modelDir(context, lang)
        val tmpZip = File(context.cacheDir, "model-$lang-download.zip")

        val t = thread(name = "ModelDownload-$lang") {
            try {
                downloadWithProgress(info.url, tmpZip) { downloadedBytes, totalBytes ->
                    emitProgress(lang, downloadedBytes, totalBytes)
                }
                unzip(tmpZip, targetDir)
                tmpZip.delete()

                if (!isDownloaded(context, lang)) {
                    throw IllegalStateException("Giải nén xong nhưng thư mục model rỗng - zip có thể sai cấu trúc.")
                }

                emitDone(lang, success = true, error = null)
            } catch (e: Exception) {
                // Dọn dẹp file/thư mục dở dang để lần tải sau không bị lẫn dữ liệu hỏng.
                tmpZip.delete()
                targetDir.deleteRecursively()
                emitDone(lang, success = false, error = e.message ?: e.toString())
            } finally {
                activeDownloads.remove(lang)
            }
        }
        activeDownloads[lang] = t

        // resolve ngay - tiến trình tải chạy nền, JS theo dõi qua sự kiện modelDownloadProgress
        // và modelDownloadDone (giống pattern audioLevel/partialText của AudioCapturePlugin).
        call.resolve(JSObject().apply { put("started", true) })
    }

    @PluginMethod
    fun cancelDownload(call: PluginCall) {
        val lang = call.getString("lang")
        val t = activeDownloads[lang]
        if (t != null) {
            t.interrupt()
            activeDownloads.remove(lang)
        }
        call.resolve()
    }

    @PluginMethod
    fun deleteModel(call: PluginCall) {
        val lang = call.getString("lang")
        if (lang.isNullOrBlank()) {
            call.reject("Thiếu tham số lang.")
            return
        }
        modelDir(context, lang).deleteRecursively()
        call.resolve()
    }

    private fun downloadWithProgress(urlStr: String, dest: File, onProgress: (Long, Long) -> Unit) {
        val url = URL(urlStr)
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 15000
        conn.instanceFollowRedirects = true // GitHub Releases redirect sang S3 - bắt buộc phải theo
        conn.connect()

        if (conn.responseCode !in 200..299) {
            throw IllegalStateException("HTTP ${conn.responseCode} khi tải model từ $urlStr")
        }

        val totalBytes = conn.contentLengthLong // -1 nếu server không trả Content-Length
        var downloadedBytes = 0L
        var lastEmitAt = 0L

        conn.inputStream.use { input ->
            FileOutputStream(dest).use { output ->
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    if (Thread.currentThread().isInterrupted) throw InterruptedException("Đã huỷ tải model.")
                    val read = input.read(buffer)
                    if (read == -1) break
                    output.write(buffer, 0, read)
                    downloadedBytes += read

                    val now = System.currentTimeMillis()
                    if (now - lastEmitAt >= 300) { // throttle ~3 lần/giây, tránh spam bridge JS
                        onProgress(downloadedBytes, totalBytes)
                        lastEmitAt = now
                    }
                }
            }
        }
        onProgress(downloadedBytes, totalBytes)
    }

    private fun unzip(zipFile: File, targetDir: File) {
        targetDir.deleteRecursively()
        targetDir.mkdirs()

        // Zip gốc tải thẳng từ alphacephei.com bọc mọi thứ trong 1 thư mục cha (vd
        // "vosk-model-en-us-0.22/"), trong khi zip mình tự đóng gói lại (model-vi/ja/ko) thì
        // phẳng, không bọc. Tự phát hiện + bóc lớp đó ra khi giải nén, để catalog dùng được
        // CẢ 2 kiểu zip mà không cần re-zip thủ công từng model.
        val commonPrefix = detectCommonRootPrefix(zipFile)

        ZipInputStream(zipFile.inputStream()).use { zis ->
            var entry: ZipEntry? = zis.nextEntry
            val buffer = ByteArray(64 * 1024)
            while (entry != null) {
                val relativeName = if (commonPrefix != null && entry.name.startsWith(commonPrefix)) {
                    entry.name.substring(commonPrefix.length)
                } else {
                    entry.name
                }
                if (relativeName.isEmpty()) {
                    zis.closeEntry()
                    entry = zis.nextEntry
                    continue
                }

                // Chặn path traversal (zip slip) - phòng trường hợp zip nguồn bị chỉnh sửa độc hại.
                val outFile = File(targetDir, relativeName)
                if (!outFile.canonicalPath.startsWith(targetDir.canonicalPath + File.separator)) {
                    throw SecurityException("Zip entry bất thường: ${entry.name}")
                }
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { out ->
                        var read = zis.read(buffer)
                        while (read != -1) {
                            out.write(buffer, 0, read)
                            read = zis.read(buffer)
                        }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }

    // Đọc qua danh sách tên entry (không giải nén) để tìm xem toàn bộ zip có nằm chung trong
    // đúng 1 thư mục cha hay không. Đọc file zip 2 lần (lần này + lần unzip thật) chấp nhận
    // được vì đây là file cục bộ đã tải xong, không phải đọc lại qua mạng.
    private fun detectCommonRootPrefix(zipFile: File): String? {
        val topLevelDirs = mutableSetOf<String>()
        var hasRootLevelEntry = false
        ZipInputStream(zipFile.inputStream()).use { zis ->
            var entry: ZipEntry? = zis.nextEntry
            while (entry != null) {
                val name = entry.name.trimStart('/')
                val slashIdx = name.indexOf('/')
                if (slashIdx <= 0) {
                    if (name.isNotEmpty()) hasRootLevelEntry = true
                } else {
                    topLevelDirs.add(name.substring(0, slashIdx))
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        return if (!hasRootLevelEntry && topLevelDirs.size == 1) topLevelDirs.first() + "/" else null
    }

    private fun emitProgress(lang: String, downloadedBytes: Long, totalBytes: Long) {
        val data = JSObject()
        data.put("lang", lang)
        data.put("downloadedBytes", downloadedBytes)
        data.put("totalBytes", totalBytes)
        data.put("percent", if (totalBytes > 0) (downloadedBytes * 100 / totalBytes).toInt() else -1)
        notifyListeners("modelDownloadProgress", data)
    }

    private fun emitDone(lang: String, success: Boolean, error: String?) {
        val data = JSObject()
        data.put("lang", lang)
        data.put("success", success)
        if (error != null) data.put("error", error)
        notifyListeners("modelDownloadDone", data)
    }
}
