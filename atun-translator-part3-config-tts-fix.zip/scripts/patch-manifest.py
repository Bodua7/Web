path = "android/app/src/main/AndroidManifest.xml"
with open(path, "r", encoding="utf-8") as f:
    content = f.read()

permissions = [
    # SYSTEM_ALERT_WINDOW: đã gỡ (dọn code chết) - từng cần cho OverlayWindowPlugin/OverlayView
    # (chữ nổi đè app khác), nhưng tính năng đó đã bị thay hoàn toàn bằng phụ đề trong app
    # (#inVideoCaption ở www/index.html) từ lâu, 2 file plugin đó đã xoá khỏi native/. Xin thừa
    # quyền nhạy cảm này không có lợi gì, chỉ khiến Play Store review khó hơn không cần thiết.
    '<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />',
    '<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION" />',
    '<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE" />',
    '<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
    '<uses-permission android:name="android.permission.RECORD_AUDIO" />',
    '<uses-permission android:name="android.permission.WAKE_LOCK" />',
    # INTERNET: KHÔNG khai báo lại ở đây - template mặc định của `npx cap add android` đã tự
    # thêm sẵn permission này rồi, khai báo trùng chỉ gây warning "duplicated with element
    # declared at AndroidManifest.xml:10" khi build (không phải lỗi, nhưng dọn cho log sạch).
    # Nâng cấp "ổn định chạy nền dài": cho phép xin miễn trừ tối ưu pin, tránh OEM
    # (Xiaomi/Oppo/Samsung...) tự kill AudioCaptureService giữa phiên nghe dài.
    '<uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />',
]

# Insert permissions right after <manifest ...> opening tag
if 'FOREGROUND_SERVICE_MEDIA_PROJECTION' not in content:
    manifest_tag_end = content.index(">", content.index("<manifest")) + 1
    perm_block = "\n    " + "\n    ".join(permissions)
    content = content[:manifest_tag_end] + perm_block + content[manifest_tag_end:]

# Fix "TTS/Boost không hoạt động": từ Android 11 (targetSdk 30+; Capacitor 6 target 34) app PHẢI khai
# báo <queries> cho intent TTS_SERVICE thì `TextToSpeech(context, ...)` mới thấy/bind được engine TTS
# của máy - thiếu thì onInit() trả ERROR, getVoices() rỗng, speak() không ra tiếng (không có lỗi nào
# hiện ra). Không liên quan tới code khuếch đại - hỏng ngay từ bước khởi tạo engine.
if 'android.intent.action.TTS_SERVICE' not in content:
    tts_intent = '<intent><action android:name="android.intent.action.TTS_SERVICE" /></intent>'
    if '<queries>' in content:
        idx = content.index('<queries>') + len('<queries>')
        content = content[:idx] + "\n        " + tts_intent + content[idx:]
    else:
        app_idx = content.index("<application")
        content = content[:app_idx] + "<queries>\n        " + tts_intent + "\n    </queries>\n\n    " + content[app_idx:]

# largeHeap="true": phòng hờ chung cho WebView + chuỗi dịch API đang chạy sẵn trên máy RAM thấp -
# largeHeap chỉ nới trần heap của Dalvik/ART (phần app tự cấp phát bằng Kotlin/Java), không đảm
# bảo hết bị kill hẳn trên máy RAM quá thấp, nhưng giảm khả năng bị kill.
if 'android:largeHeap' not in content:
    app_tag_start = content.index("<application")
    app_tag_end = content.index(">", app_tag_start)
    content = content[:app_tag_end] + '\n        android:largeHeap="true"' + content[app_tag_end:]

# Insert service declaration inside <application>...</application>, before closing tag.
# Chỉ còn AudioCaptureService - ForegroundService.kt đã bị xoá (dead code, không nơi
# nào start nó; AudioCaptureService đã tự làm foreground notification riêng, đúng
# foregroundServiceType=mediaProjection|microphone theo yêu cầu Android 14+).
service_block = '''
    <service
        android:name=".AudioCaptureService"
        android:foregroundServiceType="mediaProjection|microphone"
        android:exported="false" />
'''
if 'AudioCaptureService' not in content:
    app_close_idx = content.rindex("</application>")
    content = content[:app_close_idx] + service_block + content[app_close_idx:]

with open(path, "w", encoding="utf-8") as f:
    f.write(content)

print("Manifest patched OK")
