package com.atun.translator

import android.media.AudioRecord
import kotlin.concurrent.thread

// ===== Tách từ AudioCaptureService.kt (phần vòng lặp đọc audio + STT) =====
// Toàn bộ hàm dưới đây là extension function của AudioCaptureService - vẫn truy cập trực tiếp
// field/hàm "internal" của service (isCapturing, audioRecord, sttEngine, acquireWakeLock/
// releaseWakeLock) y hệt như khi còn nằm chung 1 file, KHÔNG đổi hành vi.

// Dùng chung cho cả VoskEngine (1 ngôn ngữ) lẫn MultiLangVoskEngine (auto) - xem
// VoskEngine.Event.DetectedFinal (chỉ MultiLangVoskEngine mới bắn event này).
private fun AudioCaptureService.dispatchSttEvent(event: VoskEngine.Event) {
    when (event) {
        is VoskEngine.Event.Partial -> AudioCapturePlugin.instance?.emitPartial(event.text)
        is VoskEngine.Event.Final -> AudioCapturePlugin.instance?.emitFinal(event.text, event.confidence, null)
        is VoskEngine.Event.DetectedFinal ->
            AudioCapturePlugin.instance?.emitFinal(event.text, event.confidence, event.lang)
        is VoskEngine.Event.LowConfidence -> AudioCapturePlugin.instance?.emitLowConfidence(event.text, event.confidence)
        is VoskEngine.Event.ModelReady -> AudioCapturePlugin.instance?.emitModelLoading(true)
        is VoskEngine.Event.Error -> AudioCapturePlugin.instance?.emitError(event.message)
        is VoskEngine.Event.LoadingProgress ->
            AudioCapturePlugin.instance?.emitModelLoadingProgress(event.loaded, event.total)
    }
}

internal fun AudioCaptureService.startVoskAndReadLoop(record: AudioRecord, sourceLang: String, minBufferSize: Int, smartPause: Boolean) {
    val engine: SttEngine

    if (sourceLang == "auto") {
        // Chế độ tự động nhận diện: chỉ dùng lại model ĐÃ TẢI SẴN (không tự tải hộ gì cả -
        // xem ModelCatalog.readyLangsForAuto), cần ít nhất 2 ngôn ngữ mới có ý nghĩa
        // "nhận diện giữa nhiều ngôn ngữ".
        val autoLangs = ModelCatalog.readyLangsForAuto(applicationContext)
        if (autoLangs.size < 2) {
            AudioCapturePlugin.instance?.emitError(
                "Chế độ tự động nhận diện cần tải ít nhất 2 ngôn ngữ " +
                    "ở mục \"Quản lý mô hình ngôn ngữ\" trước khi dùng."
            )
            AudioCaptureService.clearSavedState(applicationContext)
            try { record.stop() } catch (e: Exception) { /* chưa start thì bỏ qua */ }
            record.release()
            audioRecord = null
            releaseWakeLock()
            stopSelf()
            return
        }
        engine = MultiLangVoskEngine(applicationContext, AudioCaptureService.SAMPLE_RATE.toFloat(), autoLangs) { event ->
            dispatchSttEvent(event)
        }
    } else {
        // Chặn sớm nếu model của sourceLang chưa tải về qua ModelManagerPlugin - tránh việc
        // AudioRecord đã start (tốn pin/CPU) nhưng Vosk không bao giờ nhận diện được gì vì
        // model null.
        val modelSource = VoskEngine.resolveModelSource(applicationContext, sourceLang)
        if (modelSource == null) {
            AudioCapturePlugin.instance?.emitError(
                "Chưa tải model cho ngôn ngữ '$sourceLang'. Vào phần Quản lý mô hình để tải về trước."
            )
            AudioCaptureService.clearSavedState(applicationContext) // tránh service tự resume lại với model vẫn thiếu
            try { record.stop() } catch (e: Exception) { /* chưa start thì bỏ qua */ }
            record.release()
            audioRecord = null
            releaseWakeLock()
            stopSelf()
            return
        }
        engine = VoskEngine(applicationContext, AudioCaptureService.SAMPLE_RATE.toFloat(), modelSource) { event ->
            dispatchSttEvent(event)
        }
    }

    sttEngine = engine
    engine.init()

    isCapturing = true
    record.startRecording()
    captureThread = thread(name = "AudioCaptureReadLoop") {
        val buffer = ShortArray(minBufferSize / 2)
        // VAD thích nghi thay ngưỡng peak cố định (xem VadDetector.kt) - quyết định
        // isSilentRead cho cả thống kê audioLevel VÀ smartPause bên dưới.
        val vad = VadDetector()

        var lastLevelEmitAt = System.currentTimeMillis()
        var peakSinceLastEmit = 0
        var readCallsSinceLastEmit = 0
        var silentReadsSinceLastEmit = 0
        var badReadsSinceLastEmit = 0 // read() <= 0

        // ===== Chế độ ngắt câu thông minh: theo dõi mốc thời gian có giọng nói gần nhất
        // theo TỪNG lần read() (độ phân giải ~vài chục ms), KHÔNG dùng số liệu gộp mỗi giây
        // ở trên (quá thô để bắt pause ~700ms chính xác). pauseHandled chặn gọi
        // forcePauseFinal() lặp lại nhiều lần cho cùng 1 khoảng im lặng.
        var lastVoiceAt = System.currentTimeMillis()
        var pauseHandled = false

        while (isCapturing) {
            val read = record.read(buffer, 0, buffer.size)
            val now = System.currentTimeMillis()

            if (read > 0) {
                sttEngine?.feed(buffer, read)

                var peak = 0
                for (i in 0 until read) {
                    val v = kotlin.math.abs(buffer[i].toInt())
                    if (v > peak) peak = v
                }
                if (peak > peakSinceLastEmit) peakSinceLastEmit = peak
                readCallsSinceLastEmit++

                // isSilentRead giờ do VAD quyết định (năng lượng + ngưỡng thích nghi theo
                // nhiễu nền), không còn so peak với hằng số cố định - xem VadDetector.kt.
                val isVoiceFrame = vad.process(buffer, read)
                val isSilentRead = !isVoiceFrame
                if (isSilentRead) silentReadsSinceLastEmit++

                if (smartPause) {
                    if (isSilentRead) {
                        if (!pauseHandled && (now - lastVoiceAt) >= AudioCaptureService.SMART_PAUSE_MS) {
                            sttEngine?.forcePauseFinal()
                            pauseHandled = true
                        }
                    } else {
                        lastVoiceAt = now
                        pauseHandled = false
                    }
                }
            } else {
                badReadsSinceLastEmit++
            }

            if (now - lastLevelEmitAt >= 1000) {
                AudioCapturePlugin.instance?.emitAudioLevel(
                    peakSinceLastEmit, readCallsSinceLastEmit, silentReadsSinceLastEmit, badReadsSinceLastEmit
                )
                lastLevelEmitAt = now
                peakSinceLastEmit = 0
                readCallsSinceLastEmit = 0
                silentReadsSinceLastEmit = 0
                badReadsSinceLastEmit = 0
            }
        }
    }
}

// ===== Cloud STT (Whisper qua groq-relay?op=transcribe) - đường thay thế HOÀN TOÀN cho
// startVoskAndReadLoop() ở trên, không dùng chung code với Vosk (tách riêng cho rõ ràng,
// tránh rủi ro đụng chạm logic Vosk đang chạy ổn định). Không cần SttEngine/model Vosk nào
// cả - chỉ dùng VadDetector (thuần thuật toán, không phải model) để biết lúc nào người nói
// tạm dừng, cắt PCM đã đệm thành 1 đoạn WAV, base64 rồi bắn sang JS qua emitCloudSttSegment().
// JS tự lo phần upload mạng - xem www/index.html (transcribeCloudSegment).
internal fun AudioCaptureService.startCloudSttReadLoop(record: AudioRecord, sourceLang: String, minBufferSize: Int) {
    isCapturing = true
    record.startRecording()
    // Không có model local nào để tải - coi như "sẵn sàng" ngay lập tức để JS ẩn luôn
    // trạng thái "đang tải model" (xem onModelStatus trong www/index.html).
    AudioCapturePlugin.instance?.emitModelLoading(true)

    captureThread = thread(name = "AudioCaptureCloudSttLoop") {
        val buffer = ShortArray(minBufferSize / 2)
        val vad = VadDetector()
        val pcmBuffer = java.io.ByteArrayOutputStream()

        var lastLevelEmitAt = System.currentTimeMillis()
        var peakSinceLastEmit = 0
        var readCallsSinceLastEmit = 0
        var silentReadsSinceLastEmit = 0
        var badReadsSinceLastEmit = 0

        var segmentStartAt = System.currentTimeMillis()
        var lastVoiceAt = System.currentTimeMillis()
        var hasVoiceInSegment = false

        fun flushSegment() {
            // Bỏ qua đoạn toàn im lặng (VAD chưa từng báo có giọng nói) hoặc quá ngắn (nhiều
            // khả năng chỉ là tiếng click/nhiễu ngắn) - tránh tốn request Whisper vô ích.
            if (hasVoiceInSegment && pcmBuffer.size() >= AudioCaptureService.CLOUD_SEGMENT_MIN_BYTES) {
                val wav = buildWavFile(pcmBuffer.toByteArray(), AudioCaptureService.SAMPLE_RATE)
                val base64 = android.util.Base64.encodeToString(wav, android.util.Base64.NO_WRAP)
                AudioCapturePlugin.instance?.emitCloudSttSegment(base64, sourceLang)
            }
            pcmBuffer.reset()
            hasVoiceInSegment = false
            segmentStartAt = System.currentTimeMillis()
        }

        while (isCapturing) {
            val read = record.read(buffer, 0, buffer.size)
            val now = System.currentTimeMillis()

            if (read > 0) {
                pcmBuffer.write(shortsToBytesLE(buffer, read))

                var peak = 0
                for (i in 0 until read) {
                    val v = kotlin.math.abs(buffer[i].toInt())
                    if (v > peak) peak = v
                }
                if (peak > peakSinceLastEmit) peakSinceLastEmit = peak
                readCallsSinceLastEmit++

                val isVoiceFrame = vad.process(buffer, read)
                if (isVoiceFrame) {
                    lastVoiceAt = now
                    hasVoiceInSegment = true
                } else {
                    silentReadsSinceLastEmit++
                }

                // Cắt đoạn khi: (1) đã có giọng nói trong đoạn này VÀ vừa im lặng đủ lâu
                // (coi như hết câu), HOẶC (2) đoạn đã kéo dài quá lâu dù chưa thấy pause
                // (người nói liên tục không ngừng) - tránh đệm audio vô hạn trong RAM.
                if (hasVoiceInSegment && (now - lastVoiceAt) >= AudioCaptureService.CLOUD_SEGMENT_PAUSE_MS) {
                    flushSegment()
                } else if ((now - segmentStartAt) >= AudioCaptureService.CLOUD_SEGMENT_MAX_MS) {
                    flushSegment()
                }
            } else {
                badReadsSinceLastEmit++
            }

            if (now - lastLevelEmitAt >= 1000) {
                AudioCapturePlugin.instance?.emitAudioLevel(
                    peakSinceLastEmit, readCallsSinceLastEmit, silentReadsSinceLastEmit, badReadsSinceLastEmit
                )
                lastLevelEmitAt = now
                peakSinceLastEmit = 0
                readCallsSinceLastEmit = 0
                silentReadsSinceLastEmit = 0
                badReadsSinceLastEmit = 0
            }
        }
        // Đẩy nốt đoạn còn dang dở khi dừng nghe giữa câu (vd user bấm "Dừng nghe") - không
        // thì mất trắng câu cuối cùng đang nói dở.
        flushSegment()
    }
}

// PCM16 mono, little-endian - đúng thứ tự byte chuẩn của WAV/hầu hết API STT (kể cả Whisper).
private fun shortsToBytesLE(samples: ShortArray, len: Int): ByteArray {
    val bb = java.nio.ByteBuffer.allocate(len * 2).order(java.nio.ByteOrder.LITTLE_ENDIAN)
    for (i in 0 until len) bb.putShort(samples[i])
    return bb.array()
}

// Đóng gói PCM16 mono thô thành file WAV hoàn chỉnh (header 44 byte chuẩn) - Whisper API
// (qua groq-relay) nhận file audio thật (có header), không nhận PCM thô.
private fun buildWavFile(pcm: ByteArray, sampleRate: Int): ByteArray {
    val header = java.nio.ByteBuffer.allocate(44).order(java.nio.ByteOrder.LITTLE_ENDIAN)
    val byteRate = sampleRate * 2 // 16-bit mono: 2 byte/mẫu
    header.put("RIFF".toByteArray(Charsets.US_ASCII))
    header.putInt(36 + pcm.size)
    header.put("WAVE".toByteArray(Charsets.US_ASCII))
    header.put("fmt ".toByteArray(Charsets.US_ASCII))
    header.putInt(16) // Subchunk1Size cho PCM
    header.putShort(1) // AudioFormat = 1 (PCM)
    header.putShort(1) // NumChannels = 1 (mono)
    header.putInt(sampleRate)
    header.putInt(byteRate)
    header.putShort(2) // BlockAlign = NumChannels * BitsPerSample/8
    header.putShort(16) // BitsPerSample
    header.put("data".toByteArray(Charsets.US_ASCII))
    header.putInt(pcm.size)
    return header.array() + pcm
}
