package com.atun.translator

import android.media.AudioRecord
import kotlin.concurrent.thread

// ===== Tách từ AudioCaptureService.kt (phần vòng lặp đọc audio + STT) =====
// Hàm dưới đây là extension function của AudioCaptureService - vẫn truy cập trực tiếp field/hàm
// "internal" của service (isCapturing, audioRecord, currentMode, acquireWakeLock/
// releaseWakeLock) y hệt như khi còn nằm chung 1 file, KHÔNG đổi hành vi.
//
// Cloud STT (Whisper qua groq-relay?op=transcribe) là đường DUY NHẤT còn lại (đã bỏ nhánh Vosk
// offline). Không cần model/engine STT nào tải sẵn - chỉ dùng VadDetector (thuần thuật toán,
// không phải model) để biết lúc nào người nói tạm dừng, cắt PCM đã đệm thành 1 đoạn WAV, base64
// rồi bắn sang JS qua emitCloudSttSegment(). JS tự lo phần upload mạng - xem www/index.html
// (transcribeCloudSegment).
// channel: nhãn gắn vào audioLevel/cloudSttSegment để JS phân biệt luồng khi ở MODE_MIXED (2
// luồng chạy song song, currentMode="mixed" dùng chung cho cả 2 nên KHÔNG đủ để phân biệt như
// trước đây - phải truyền rõ CHANNEL_MIC/CHANNEL_SYSTEM). Ở MODE_MIC/MODE_SYSTEM đơn, mặc định
// bằng currentMode y hệt hành vi cũ (không đổi).
// assignThread: nơi lưu Thread vừa tạo - mặc định captureThread (dùng cho MODE_MIC/SYSTEM đơn
// VÀ luồng system của MIXED), truyền captureThreadMic cho luồng mic của MIXED. Không thể gán
// thẳng "captureThread = thread(...) {...}" như cũ vì giờ có 2 field khả dĩ.
internal fun AudioCaptureService.startCloudSttReadLoop(
    record: AudioRecord,
    sourceLang: String,
    minBufferSize: Int,
    channel: String = currentMode,
    assignThread: (Thread) -> Unit = { captureThread = it },
) {
    isCapturing = true
    record.startRecording()
    // Không có model local nào để tải - coi như "sẵn sàng" ngay lập tức để JS ẩn luôn
    // trạng thái "đang tải model" (xem onModelStatus trong www/index.html). Ở MIXED, cả 2 luồng
    // gọi hàm này (idempotent với JS - chỉ set lại đúng giá trị true), không cần gộp.
    AudioCapturePlugin.instance?.emitModelLoading(true)

    val newThread = thread(name = "AudioCaptureCloudSttLoop-$channel") {
        val buffer = ShortArray(minBufferSize / 2)
        val vad = VadDetector()
        val pcmBuffer = java.io.ByteArrayOutputStream()
        // Fix (audit đợt 2): logic quyết định "khi nào cắt đoạn" tách ra SttSegmentCutter (pure
        // class, xem file đó + native-test/SttSegmentCutterTest.kt) - hành vi giữ NGUYÊN, chỉ
        // đổi chỗ ở để có thể JUnit test riêng logic timing/voice mà không cần AudioRecord thật.
        val cutter = SttSegmentCutter(
            pauseMs = AudioCaptureService.CLOUD_SEGMENT_PAUSE_MS,
            maxSegmentMs = AudioCaptureService.CLOUD_SEGMENT_MAX_MS,
        )
        cutter.reset(System.currentTimeMillis())

        var lastLevelEmitAt = System.currentTimeMillis()
        var peakSinceLastEmit = 0
        var readCallsSinceLastEmit = 0
        var silentReadsSinceLastEmit = 0
        var badReadsSinceLastEmit = 0

        fun flushSegment() {
            // Bỏ qua đoạn toàn im lặng (VAD chưa từng báo có giọng nói) hoặc quá ngắn (nhiều
            // khả năng chỉ là tiếng click/nhiễu ngắn) - tránh tốn request Whisper vô ích.
            if (cutter.hasVoice() && pcmBuffer.size() >= AudioCaptureService.CLOUD_SEGMENT_MIN_BYTES) {
                val wav = buildWavFile(pcmBuffer.toByteArray(), AudioCaptureService.SAMPLE_RATE)
                val base64 = android.util.Base64.encodeToString(wav, android.util.Base64.NO_WRAP)
                AudioCapturePlugin.instance?.emitCloudSttSegment(base64, sourceLang, channel)
            }
            pcmBuffer.reset()
            cutter.reset(System.currentTimeMillis())
        }

        // ===== Fix "app crash khi mic ngoài bị ngắt route lúc app xuống nền" / "mic trong báo
        // 0 volume lặng lẽ khi xuống nền": record.read() được bọc try/catch quanh TOÀN BỘ thân
        // vòng lặp (không chỉ riêng read()) - khi hệ thống thu hồi route audio giữa chừng (rất
        // hay xảy ra với mic ngoài USB/Bluetooth lúc app mất focus, đôi khi cả mic trong tuỳ
        // hãng máy hạn chế mic nền), nhiều driver ném Exception thật ngay tại read(). Bắt lại ở
        // đây để dừng an toàn thay vì crash, báo rõ lý do lên JS (code MIC_READ_LOST) thay vì
        // lặng lẽ tụt về 0 volume không rõ nguyên nhân.
        try {
            while (isCapturing) {
                val read = record.read(buffer, 0, buffer.size)
                val now = System.currentTimeMillis()

                if (read > 0) {
                    pcmBuffer.write(shortsToBytesLE(buffer, read))

                    var peak = 0
                    for (i in 0 until read) {
                        val v = kotlin.math.abs(buffer[i].toInt())
                        if (v > peak) peak = v
                    }
                    if (peak > peakSinceLastEmit) peakSinceLastEmit = peak
                    readCallsSinceLastEmit++

                    val isVoiceFrame = vad.process(buffer, read, now)
                    if (!isVoiceFrame) silentReadsSinceLastEmit++
                    cutter.onFrame(now, isVoiceFrame)

                    if (cutter.shouldFlush(now)) {
                        flushSegment()
                    }
                } else {
                    badReadsSinceLastEmit++
                }

                if (now - lastLevelEmitAt >= 1000) {
                    AudioCapturePlugin.instance?.emitAudioLevel(
                        peakSinceLastEmit, readCallsSinceLastEmit, silentReadsSinceLastEmit, badReadsSinceLastEmit,
                        channel = channel
                    )
                    lastLevelEmitAt = now
                    peakSinceLastEmit = 0
                    readCallsSinceLastEmit = 0
                    silentReadsSinceLastEmit = 0
                    badReadsSinceLastEmit = 0
                }
            }
            // Đẩy nốt đoạn còn dang dở khi dừng nghe giữa câu (vd user bấm "Dừng nghe") - không
            // thì mất trắng câu cuối cùng đang nói dở.
            flushSegment()
        } catch (e: Exception) {
            AppLog.append(
                this,
                "AudioCaptureReadLoop (Cloud STT) lỗi khi đọc AudioRecord - dừng an toàn thay " +
                    "vì crash. Nguyên nhân thường gặp: mic ngoài (USB/Bluetooth) bị rút/ngắt kết " +
                    "nối, hoặc hệ thống thu hồi quyền truy cập mic khi app xuống nền (tuỳ hãng " +
                    "máy): ${e.message}"
            )
            AudioCapturePlugin.instance?.emitError(
                "Mất kết nối với micro giữa chừng (có thể do rút mic ngoài, hoặc hệ thống " +
                    "tạm ngắt quyền micro khi app chạy nền) - đã dừng nghe. Vào Cài đặt > " +
                    "\"Miễn trừ tối ưu pin\" nếu hay gặp lại, rồi bấm \"Bắt đầu nghe\" lại.",
                code = "MIC_READ_LOST"
            )
            AudioCaptureService.clearSavedState(applicationContext)
            stopCapture()
            stopSelf()
        }
    }
    assignThread(newThread)
}

