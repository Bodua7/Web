package com.atun.translator

import android.content.Context
import java.io.File

// Tách ra từ ModelManagerPlugin.kt (companion object cũ) - phần catalog + hằng số + hàm tĩnh
// KHÔNG cần là 1 Capacitor Plugin thật (không có @PluginMethod nào ở đây), nên tách hẳn khỏi
// class Plugin để file đó gọn lại, chỉ còn đúng phần xử lý @PluginMethod (dispatch từ JS).
// Nơi khác trong code gọi các hàm/hằng số này qua "ModelCatalog.xxx" (trước đây là
// "ModelManagerPlugin.xxx") - xem AudioCaptureService.kt, LidEngine.kt, VoskEngine.kt.
object ModelCatalog {

    // mirrorUrl: nguồn dự phòng khác host, dùng khi url gốc (alphacephei.com) tải lỗi hết
    // MAX_ATTEMPTS_PER_SOURCE lần - xem downloadWithRetry() trong ModelDownloader.kt. File zip
    // là bản mirror y hệt (cùng tên file, cùng nội dung) đăng lại trên Hugging Face, không phải
    // bản tự đóng gói.
    data class ModelInfo(val displayName: String, val url: String, val sizeMB: Int, val mirrorUrl: String? = null)

    // Dùng thẳng model chính chủ từ alphacephei.com (giống cách "en" - lgraph 128MB - bên
    // dưới đã làm) thay vì tự nén lại rồi tự host trên GitHub Releases của repo này - tránh phải
    // tự tải về máy, nén .zip, tạo GitHub Release, upload thủ công mỗi khi cần thêm/đổi
    // model. unzip() (ModelDownloader.kt) tự phát hiện + bóc lớp thư mục cha mà các zip gốc của
    // alphacephei hay bọc ngoài (vd "vosk-model-small-vn-0.4/"), nên dùng thẳng URL gốc
    // không cần xử lý gì thêm.
    // sizeMB lấy đúng theo trang https://alphacephei.com/vosk/models - chỉ để hiển thị
    // ước lượng cho UI trước khi tải, không ảnh hưởng logic.
    val CATALOG: Map<String, ModelInfo> = mapOf(
        // "en": trước đây trỏ tới bản "small" (~40MB, WER cao hơn hẳn) - giờ đổi hẳn sang
        // dùng chung model với "en-lgraph" cũ (~128MB, cùng acoustic model gần tương đương
        // "en-large" nhưng dùng lgraph - graph động/pruned thay vì graph tĩnh khổng lồ) làm
        // model tiếng Anh MẶC ĐỊNH DUY NHẤT. Không còn 3 biến thể "en"/"en-lgraph"/"en-large"
        // riêng lẻ nữa (dễ gây nhầm lẫn chọn nhầm bản kém hơn) - "en-lgraph" bị xoá vì đã gộp
        // thẳng vào đây, "en-large" (~1.8GB, chính xác cao hơn 1 chút nhưng quá nặng để tải
        // on-demand qua mạng di động/CI) bị xoá hẳn khỏi catalog, không giữ lại làm lựa chọn
        // "chính xác cao" riêng nữa. Chưa xác minh mirror HuggingFace nào cho đúng file
        // lgraph này (khác bản "small" cũ đã có mirror) nên chưa có mirrorUrl.
        "en" to ModelInfo(
            "English",
            "https://alphacephei.com/vosk/models/vosk-model-en-us-0.22-lgraph.zip",
            128
        ),
        "vi" to ModelInfo(
            "Tiếng Việt",
            "https://alphacephei.com/vosk/models/vosk-model-small-vn-0.4.zip",
            32,
            mirrorUrl = "https://huggingface.co/localstack/vosk-models/resolve/main/vosk-model-small-vn-0.4.zip"
        ),
        "ja" to ModelInfo(
            "日本語",
            "https://alphacephei.com/vosk/models/vosk-model-small-ja-0.22.zip",
            48,
            mirrorUrl = "https://huggingface.co/localstack/vosk-models/resolve/main/vosk-model-small-ja-0.22.zip"
        ),
        "ko" to ModelInfo(
            "한국어",
            "https://alphacephei.com/vosk/models/vosk-model-small-ko-0.22.zip",
            82,
            mirrorUrl = "https://huggingface.co/localstack/vosk-models/resolve/main/vosk-model-small-ko-0.22.zip"
        ),
        // ===== Mở rộng "đầy đủ" theo đúng danh sách chính thức tại alphacephei.com/vosk/models
        // (đọc trực tiếp từ trang đó, không đoán mò tên file) - mỗi ngôn ngữ dùng bản "small"
        // nếu có (ưu tiên cho di động, ~30-100MB). Đã BỎ HẲN 4 ngôn ngữ không có bản "small"
        // cùng giọng/phương ngữ chuẩn dưới 200MB (Ả Rập mgb2 318MB, Thuỵ Điển Rhasspy 289MB,
        // Filipino 320MB, Hy Lạp 1.1GB) - đây từng là bản NHẸ NHẤT hiện có cho các ngôn ngữ
        // này (Vosk chưa publish bản "small" nào), theo yêu cầu chỉ giữ model <200MB. (Ả Rập
        // CÓ 1 bản nhỏ hơn 158MB nhưng là tiếng Ả Rập TUNISIA - phương ngữ khác hẳn Ả Rập
        // chuẩn/MSA, không dùng thay thế vì sẽ nhận sai với người nói giọng chuẩn). KHÔNG có
        // mirrorUrl (chỉ nguồn chính chủ) - không tự đoán/tạo mirror HuggingFace cho từng
        // ngôn ngữ vì không xác minh được các repo đó có thật hay còn tồn tại, khác 4 model
        // phía trên đã được xác minh sẵn.
        "en-in" to ModelInfo("English (Ấn Độ)", "https://alphacephei.com/vosk/models/vosk-model-small-en-in-0.4.zip", 36),
        "zh" to ModelInfo("中文 (Trung Quốc)", "https://alphacephei.com/vosk/models/vosk-model-small-cn-0.22.zip", 42),
        "ru" to ModelInfo("Русский (Nga)", "https://alphacephei.com/vosk/models/vosk-model-small-ru-0.22.zip", 45),
        "fr" to ModelInfo("Français (Pháp)", "https://alphacephei.com/vosk/models/vosk-model-small-fr-0.22.zip", 41),
        "de" to ModelInfo("Deutsch (Đức)", "https://alphacephei.com/vosk/models/vosk-model-small-de-0.15.zip", 45),
        "es" to ModelInfo("Español (Tây Ban Nha)", "https://alphacephei.com/vosk/models/vosk-model-small-es-0.42.zip", 39),
        "pt" to ModelInfo("Português (Bồ Đào Nha)", "https://alphacephei.com/vosk/models/vosk-model-small-pt-0.3.zip", 31),
        "tr" to ModelInfo("Türkçe (Thổ Nhĩ Kỳ)", "https://alphacephei.com/vosk/models/vosk-model-small-tr-0.3.zip", 35),
        "it" to ModelInfo("Italiano (Ý)", "https://alphacephei.com/vosk/models/vosk-model-small-it-0.22.zip", 48),
        "nl" to ModelInfo("Nederlands (Hà Lan)", "https://alphacephei.com/vosk/models/vosk-model-small-nl-0.22.zip", 39),
        "ca" to ModelInfo("Català (Catalan)", "https://alphacephei.com/vosk/models/vosk-model-small-ca-0.4.zip", 42),
        "fa" to ModelInfo("فارسی (Ba Tư/Iran)", "https://alphacephei.com/vosk/models/vosk-model-small-fa-0.42.zip", 53),
        "uk" to ModelInfo("Українська (Ukraine)", "https://alphacephei.com/vosk/models/vosk-model-small-uk-v3-nano.zip", 73),
        "kz" to ModelInfo("Қазақша (Kazakhstan)", "https://alphacephei.com/vosk/models/vosk-model-small-kz-0.42.zip", 58),
        "eo" to ModelInfo("Esperanto", "https://alphacephei.com/vosk/models/vosk-model-small-eo-0.42.zip", 42),
        "hi" to ModelInfo("हिन्दी (Ấn Độ - Hindi)", "https://alphacephei.com/vosk/models/vosk-model-small-hi-0.22.zip", 42),
        "cs" to ModelInfo("Čeština (Séc)", "https://alphacephei.com/vosk/models/vosk-model-small-cs-0.4-rhasspy.zip", 44),
        "pl" to ModelInfo("Polski (Ba Lan)", "https://alphacephei.com/vosk/models/vosk-model-small-pl-0.22.zip", 50),
        "uz" to ModelInfo("O'zbekcha (Uzbekistan)", "https://alphacephei.com/vosk/models/vosk-model-small-uz-0.22.zip", 49),
        "gu" to ModelInfo("ગુજરાતી (Gujarat)", "https://alphacephei.com/vosk/models/vosk-model-small-gu-0.42.zip", 100),
        "tg" to ModelInfo("Тоҷикӣ (Tajikistan)", "https://alphacephei.com/vosk/models/vosk-model-small-tg-0.22.zip", 50),
        "te" to ModelInfo("తెలుగు (Telugu)", "https://alphacephei.com/vosk/models/vosk-model-small-te-0.42.zip", 58),
        "ky" to ModelInfo("Кыргызча (Kyrgyzstan)", "https://alphacephei.com/vosk/models/vosk-model-small-ky-0.42.zip", 49),
        "ka" to ModelInfo("ქართული (Georgia)", "https://alphacephei.com/vosk/models/vosk-model-small-ka-0.42.zip", 45),
        "br" to ModelInfo("Brezhoneg (Breton)", "https://alphacephei.com/vosk/models/vosk-model-br-0.8.zip", 70)
    )

    // Trước đây có BUNDLED_LANG = "en" (coi tiếng Anh luôn "sẵn sàng" vì bundle sẵn trong
    // APK). Giờ "en" nằm trong CATALOG như mọi ngôn ngữ khác - không còn khái niệm
    // "bundled" nữa, isDownloaded(context, "en") trả lời đúng luôn mà không cần đặc cách.

    // Ngôn ngữ bị loại khỏi chế độ "Tự động nhận diện nhiều ngôn ngữ" (xem
    // MultiLangVoskEngine + readyLangsForAuto bên dưới) - model quá lớn để tải nhiều bản
    // CÙNG LÚC vào RAM song song (mỗi ngôn ngữ bật auto là +1 Recognizer sống suốt phiên
    // nghe). Ranh giới 250MB là ước lượng thực dụng, không phải con số chính thức từ Vosk.
    // Sau khi bỏ 4 ngôn ngữ chỉ có bản >200MB (ar/sv/tl/el - xem CATALOG), hiện KHÔNG còn
    // entry nào trong CATALOG vượt ngưỡng này (model lớn nhất là "en" ~128MB) - set này rỗng
    // trên thực tế, nhưng vẫn giữ logic filter để tự động loại nếu sau này thêm ngôn ngữ mới
    // có model lớn, không cần sửa lại chỗ này.
    val EXCLUDED_FROM_AUTO: Set<String> = CATALOG.filterValues { it.sizeMB > 250 }.keys

    // Trần số ngôn ngữ chạy song song ở chế độ auto - nhiều hơn nữa dễ làm máy tầm trung/yếu
    // ì ạch hoặc hết RAM (mỗi Recognizer Vosk small tốn thêm ~150-300MB RAM khi chạy).
    const val MAX_AUTO_LANGS = 4

    // Danh sách ngôn ngữ dùng cho chế độ "auto": mọi ngôn ngữ NGƯỜI DÙNG ĐÃ TẢI VỀ (không tự
    // tải hộ gì cả - auto chỉ dùng lại model đã có, không phát sinh tải mạng ngoài ý muốn),
    // loại các model quá lớn (xem EXCLUDED_FROM_AUTO), giới hạn tối đa MAX_AUTO_LANGS.
    // Không sắp xếp ưu tiên gì đặc biệt ngoài "đã tải trước thì vào danh sách trước" (thứ
    // tự Map.entries, "en" đứng đầu CATALOG nên thường vào danh sách trước nếu đã tải).
    fun readyLangsForAuto(context: Context): List<String> {
        val result = mutableListOf<String>()
        for ((lang, _) in CATALOG) {
            if (result.size >= MAX_AUTO_LANGS) break
            if (lang in EXCLUDED_FROM_AUTO) continue
            if (isDownloaded(context, lang)) result.add(lang)
        }
        return result
    }

    fun modelsDir(context: Context): File = File(context.filesDir, "models")

    fun modelDir(context: Context, lang: String): File = File(modelsDir(context), lang)

    // Dùng lại ở VoskEngine để biết model đã sẵn sàng chưa trước khi start capture.
    fun isDownloaded(context: Context, lang: String): Boolean {
        val dir = modelDir(context, lang)
        return dir.isDirectory && (dir.listFiles()?.isNotEmpty() == true)
    }

    // 15s cũ QUÁ NGẮN cho mạng di động/WiFi chập chờn - chỉ cần khựng >15s giữa chừng
    // (rất dễ xảy ra với mạng di động/WiFi chập chờn khi tải nhiều phút, dù model lớn nhất
    // trong catalog hiện tại chỉ ~128MB) là toàn bộ request
    // bị huỷ. Đây là nguyên nhân chính khiến tải hay báo "Lỗi tải - thử lại" dù mạng vẫn
    // dùng bình thường cho việc khác. Tăng lên rộng rãi hơn nhiều.
    const val CONNECT_TIMEOUT_MS = 20_000
    const val READ_TIMEOUT_MS = 60_000
    // Số lần thử TRÊN MỖI NGUỒN (primary/mirror) - không phải tổng số lần thử. Đổi tên từ
    // MAX_ATTEMPTS (4) vì giờ có thể có 2 nguồn (xem mirrorUrl bên dưới): thực tế đã ghi
    // nhận alphacephei.com tự nó đủ chậm/chập chờn để 4 lần thử LIÊN TIẾP CÙNG 1 HOST vẫn
    // fail hết (báo "Lỗi tải - thử lại" dù đã tăng timeout) - tăng số lần thử trên cùng 1
    // host không giải quyết được vấn đề nếu bản thân host đó đang có sự cố, nên hướng đúng
    // là thử sang host KHÁC hẳn thay vì thử lại mãi cùng 1 chỗ.
    const val MAX_ATTEMPTS_PER_SOURCE = 3

    // ===== Nguồn tải model LID (xem LidEngine.kt) - KHÔNG nằm trong CATALOG vì đây không
    // phải "ngôn ngữ" chọn được, chỉ là model phụ trợ dùng nội bộ. Bản re-upload công khai
    // trên Hugging Face (model gốc snakers4/silero-vad đã deprecated, không còn link tải
    // trực tiếp từ models.silero.ai).
    const val LID_ONNX_URL = "https://huggingface.co/deepghs/silero-lang95-onnx/resolve/main/lang_classifier_95.onnx?download=true"
    const val LID_LANG_DICT_URL = "https://huggingface.co/deepghs/silero-lang95-onnx/resolve/main/lang_dict_95.json?download=true"
    const val LID_LANG_GROUP_DICT_URL = "https://huggingface.co/deepghs/silero-lang95-onnx/resolve/main/lang_group_dict_95.json?download=true"
    const val LID_MODEL_SIZE_MB = 17
}
