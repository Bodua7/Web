package com.atun.translator

import android.content.Intent
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin

// Cầu nối JS (www/index.html) -> mở BrowserActivity ("web mini") bằng Intent thường - 1
// Activity RIÊNG trong CÙNG app (không phải app/package riêng, không dùng WebView của
// Capacitor Bridge chính). AudioCaptureService (bắt âm thanh hệ thống, chạy nền độc lập với
// Activity nào đang hiển thị) không bị ảnh hưởng gì khi người dùng chuyển qua màn hình này.
@CapacitorPlugin(name = "BrowserLauncher")
class BrowserLauncherPlugin : Plugin() {
    @PluginMethod
    fun open(call: PluginCall) {
        val url = call.getString("url")
        val intent = Intent(context, BrowserActivity::class.java)
        if (!url.isNullOrBlank()) intent.putExtra("url", url)
        activity.startActivity(intent)
        call.resolve()
    }

    // Gọi từ applyCaptionSettings() trong www/index.html mỗi khi có câu dịch mới HOẶC người
    // dùng chỉnh thanh trượt Rộng/Cao/cỡ chữ/độ trong suốt - đẩy cả câu dịch lẫn "khung dịch"
    // qua CaptionRelay để BrowserActivity ("Web mini"), nếu đang mở, hiện đúng câu đó TRONG
    // đúng khung (tỉ lệ rộng/cao, cỡ chữ, độ trong suốt) đang cấu hình ở màn hình chính. Không
    // cần biết BrowserActivity có đang mở hay không - CaptionRelay chỉ đơn giản là bỏ qua nếu
    // chưa có listener nào đăng ký (chưa mở Web mini lần nào, hoặc nó đang ở nền). Mọi tham số
    // ngoài "text" đều có giá trị mặc định hợp lý (giữ nguyên hành vi cũ) nếu JS gọi thiếu.
    @PluginMethod
    fun updateCaption(call: PluginCall) {
        val frame = CaptionRelay.CaptionFrame(
            text = call.getString("text") ?: "",
            opacity = (call.getDouble("opacity") ?: 0.75).toFloat(),
            fontSize = call.getString("fontSize") ?: "medium",
            widthPercent = call.getInt("widthPercent") ?: 96,
            heightPercent = call.getInt("heightPercent") ?: 30,
        )
        CaptionRelay.update(frame)
        call.resolve()
    }
}
