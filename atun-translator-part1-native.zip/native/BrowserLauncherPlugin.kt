package com.atun.translator

import android.content.Intent
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin

// Cầu nối JS (www/index.html) -> mở BrowserActivity ("web mini") bằng Intent thường - 1
// Activity RIÊNG trong CÙNG app (không phải app/package riêng, không dùng WebView của
// Capacitor Bridge chính). AudioCaptureService (bắt âm thanh hệ thống, chạy nền độc lập với
// Activity nào đang hiển thị) không bị ảnh hưởng gì khi người dùng chuyển qua màn hình này.
@CapacitorPlugin(name = "BrowserLauncher")
class BrowserLauncherPlugin : Plugin() {
    @PluginMethod
    fun open(call: PluginCall) {
        val url = call.getString("url")
        val intent = Intent(context, BrowserActivity::class.java)
        if (!url.isNullOrBlank()) intent.putExtra("url", url)
        activity.startActivity(intent)
        call.resolve()
    }

    // Gọi từ flushFinalBatch() trong www/index.html mỗi khi có câu dịch mới hiện lên
    // #inVideoCaptionText (hoặc text="" khi dừng video/xoá phụ đề) - đẩy qua CaptionRelay để
    // BrowserActivity ("Web mini"), nếu đang mở, hiện đúng câu đó trong overlay riêng của nó.
    // Không cần biết BrowserActivity có đang mở hay không - CaptionRelay chỉ đơn giản là bỏ
    // qua nếu chưa có listener nào đăng ký (chưa mở Web mini lần nào, hoặc nó đang ở nền).
    @PluginMethod
    fun updateCaption(call: PluginCall) {
        val text = call.getString("text") ?: ""
        CaptionRelay.update(text)
        call.resolve()
    }
}
