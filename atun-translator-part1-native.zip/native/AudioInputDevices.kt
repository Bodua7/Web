package com.atun.translator

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager

// ===== Tách từ AudioCaptureService.kt (phần liệt kê/mô tả thiết bị micro ngoài) =====
// Trước đây nằm trong companion object của AudioCaptureService, gọi qua
// "AudioCaptureService.listExternalInputDevices(...)" v.v. Các hàm này KHÔNG đụng gì tới
// field/instance của service (chỉ nhận Context/AudioDeviceInfo làm tham số) nên tách thành
// object độc lập - dùng chung cho CẢ AudioCaptureService (CaptureSourceManager.kt, lúc thật sự
// chọn thiết bị để ghi) LẪN AudioCapturePlugin.listInputDevices() (lúc JS muốn xem trước máy có
// phát hiện được gì không, KHÔNG cần bắt đầu nghe). Đã cập nhật lại 2 nơi gọi (AudioCapturePlugin.kt,
// CaptureSourceManager.kt) từ "AudioCaptureService.xxx" sang "AudioInputDevices.xxx". KHÔNG đổi
// hành vi.
object AudioInputDevices {

    // Chỉ liệt kê input device - KHÔNG gồm micro liền trong máy (TYPE_BUILTIN_MIC) vì đó là
    // fallback mặc định, không cần user chọn thấy trong danh sách "micro ngoài".
    fun listExternalInputDevices(ctx: Context): List<AudioDeviceInfo> {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val all = am.getDevices(AudioManager.GET_DEVICES_INPUTS)
        return all.filter { it.type != AudioDeviceInfo.TYPE_BUILTIN_MIC && it.type != AudioDeviceInfo.TYPE_BUILTIN_EARPIECE }
    }

    // Thứ tự ưu tiên khi có NHIỀU thiết bị ngoài cùng lúc: USB (chất lượng/độ ổn định thường
    // tốt nhất, không cần đàm phán kết nối) > tai nghe có dây (jack 3.5mm/USB-C analog, luôn
    // sẵn sàng ngay) > Bluetooth SCO (chỉ xuất hiện trong danh sách này khi hệ thống ĐÃ bật
    // kênh thoại SCO - app KHÔNG tự gọi AudioManager.startBluetoothSco() ở đây, nên tai nghe
    // Bluetooth thường chỉ được chọn nếu app/hệ thống khác đã bật sẵn kênh gọi thoại; xem ghi
    // chú ở describeInputDevice bên dưới).
    private fun devicePriority(type: Int): Int = when (type) {
        AudioDeviceInfo.TYPE_USB_HEADSET -> 0
        AudioDeviceInfo.TYPE_USB_DEVICE -> 1
        AudioDeviceInfo.TYPE_WIRED_HEADSET -> 2
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> 2
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> 3
        else -> 9
    }

    fun findBestExternalInputDevice(ctx: Context): AudioDeviceInfo? =
        listExternalInputDevices(ctx).minByOrNull { devicePriority(it.type) }

    // Nhãn tiếng Việt cho UI/log - dùng productName thật của thiết bị khi máy trả về được
    // (không phải lúc nào cũng có, tuỳ driver/thiết bị).
    fun describeInputDevice(d: AudioDeviceInfo): String {
        val kind = when (d.type) {
            AudioDeviceInfo.TYPE_USB_HEADSET -> "Tai nghe USB"
            AudioDeviceInfo.TYPE_USB_DEVICE -> "Micro USB"
            AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Tai nghe có dây (jack)"
            AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "Tai nghe có dây (jack)"
            // SCO = kênh thoại Bluetooth (băng thông thấp hơn A2DP nhưng có đường micro về -
            // A2DP chỉ phát, không có micro). Xem ghi chú devicePriority() ở trên.
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Tai nghe Bluetooth"
            else -> "Micro ngoài"
        }
        val name = d.productName?.toString()
        return if (!name.isNullOrBlank() && name != "?") "$kind ($name)" else kind
    }
}
