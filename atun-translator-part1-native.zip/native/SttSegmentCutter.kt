// Fix (audit Detekt - InvalidPackageDeclaration false-positive): file này nằm phẳng trong
// native/ ở gốc repo, không theo cấu trúc thư mục com/atun/translator/ - CÓ CHỦ ĐÍCH, vì bước
// build-debug (android-build.yml) tự copy file này vào đúng
// android/app/src/main/java/com/atun/translator/ trước khi biên dịch thật (xem step "Copy
// native Kotlin sources"). Detekt ở job validation chạy TRƯỚC bước copy đó (trên native/ phẳng)
// nên luôn báo package không khớp đường dẫn vật lý lúc đó - không phải lỗi thật, khai báo
// package vẫn đúng với vị trí SAU KHI copy (nơi thật sự biên dịch).
@file:Suppress("InvalidPackageDeclaration")

package com.atun.translator

// ===== Tách từ SttReadLoop.kt (đợt audit thêm test JUnit) =====
// SttSegmentCutter: logic THUẦN (không đụng AudioRecord/Thread/Service) quyết định KHI NÀO nên
// cắt đoạn audio đang đệm thành 1 segment để gửi lên Cloud STT. Trước đây state này (hasVoiceInSegment/
// segmentStartAt/lastVoiceAt) nằm thẳng trong các biến local của vòng lặp `captureThread` trong
// SttReadLoop.kt - không tự unit-test bằng JUnit thuần được vì gắn liền với AudioRecord.read()
// thật. Tách state + quyết định ra riêng object này giữ NGUYÊN hành vi gốc (2 điều kiện cắt đoạn
// y hệt: đã có giọng nói + vừa im lặng đủ lâu, HOẶC đoạn đã kéo dài quá lâu dù chưa pause) - xem
// native-test/SttSegmentCutterTest.kt.
//
// KHÔNG tự đếm số byte PCM đã đệm (pcmBuffer.size() vẫn đọc trực tiếp từ ByteArrayOutputStream
// thật trong SttReadLoop.kt) - cutter này chỉ lo phần thời điểm/có-giọng-nói-hay-không, tránh
// trùng lặp state với buffer thật (1 nguồn sự thật duy nhất cho số byte).
class SttSegmentCutter(
    private val pauseMs: Long,
    private val maxSegmentMs: Long,
) {
    companion object {
        // ===== Phương án "nhận giọng ca sĩ khi hát" =====
        // Số lần bị cắt LIÊN TIẾP vì CHẠM TRẦN THỜI LƯỢNG (không phải vì phát hiện khoảng lặng)
        // trước khi coi audio hiện tại là "nghe giống nhạc/bài hát liên tục, không giống lời nói
        // bình thường". Lời nói con người - kể cả nói liên tục/thuyết trình - hầu như luôn có
        // chỗ ngắt hơi vài trăm ms giữa các câu; nhạc/bài hát thì ngược lại, gần như không có
        // khoảng lặng thật trong suốt bài (nhạc nền + giọng hát chồng lên nhau gần như liên tục).
        // 3 lần x maxSegmentMs (12s ở cấu hình hiện tại của AudioCaptureService) = 36s "giọng
        // nói" không hề có 1 khoảng lặng tự nhiên nào - bất thường với lời nói, bình thường với
        // 1 đoạn điệp khúc/verse. Số phỏng đoán ban đầu dựa trên đọc code, CHƯA tinh chỉnh bằng
        // audio thật (nhạc/thuyết trình liên tục thật) - xem SttSegmentCutterTest.kt.
        const val CONTINUOUS_MUSIC_HINT_THRESHOLD = 3
    }

    private var hasVoiceInSegment = false
    private var segmentStartAt = 0L
    private var lastVoiceAt = 0L

    // Đếm số lần LIÊN TIẾP shouldFlush() trả về true vì lý do "chạm trần thời lượng". SỐNG XUYÊN
    // SUỐT NHIỀU ĐOẠN - reset() (dọn state của 1 đoạn) KHÔNG đụng tới biến này, vì đây là bộ đếm
    // theo dõi cả 1 CHUỖI đoạn liên tiếp. Chỉ về lại 0 khi có 1 lần cắt do PAUSE thật xảy ra
    // (dấu hiệu đây là lời nói bình thường, có ngắt quãng tự nhiên) - xem shouldFlush().
    private var consecutiveMaxDurationFlushes = 0
    // true nếu lần shouldFlush() gần nhất trả về true là do chạm trần thời lượng (không phải do
    // khoảng lặng) - dùng để tính justCrossedContinuousMusicHint() ngay sau đó.
    private var lastFlushWasMaxDuration = false

    // Gọi khi bắt đầu 1 đoạn mới (lúc bắt đầu capture, HOẶC ngay sau khi vừa cắt xong 1 đoạn).
    fun reset(now: Long) {
        hasVoiceInSegment = false
        segmentStartAt = now
        lastVoiceAt = now
        // KHÔNG reset consecutiveMaxDurationFlushes/lastFlushWasMaxDuration ở đây - xem comment
        // ở khai báo 2 biến đó.
    }

    // Gọi 1 lần mỗi khung audio đã đọc được (length > 0) - cập nhật state, KHÔNG tự cắt/tự trả
    // gì cả, chỉ ghi nhận. Gọi shouldFlush() riêng sau đó để hỏi có nên cắt hay chưa.
    fun onFrame(now: Long, isVoiceFrame: Boolean) {
        if (isVoiceFrame) {
            lastVoiceAt = now
            hasVoiceInSegment = true
        }
    }

    // true nếu đã tới lúc cắt đoạn hiện tại - vì (1) đã có giọng nói trong đoạn này VÀ vừa im
    // lặng đủ lâu (coi như hết câu), HOẶC (2) đoạn đã kéo dài quá lâu dù chưa thấy pause (người
    // nói liên tục không ngừng) - tránh đệm audio vô hạn trong RAM. Không tự nói đoạn đó có ĐÁNG
    // gửi lên Whisper hay không (xem hasVoice() - caller tự phối hợp với kích thước buffer thật).
    // Có tác dụng phụ cập nhật consecutiveMaxDurationFlushes/lastFlushWasMaxDuration - gọi
    // justCrossedContinuousMusicHint()/isLikelyContinuousMusic() NGAY SAU lần gọi này (trước khi
    // gọi reset() cho đoạn kế tiếp) nếu cần đọc kết quả đúng lúc.
    fun shouldFlush(now: Long): Boolean {
        if (hasVoiceInSegment && (now - lastVoiceAt) >= pauseMs) {
            consecutiveMaxDurationFlushes = 0
            lastFlushWasMaxDuration = false
            return true
        }
        if ((now - segmentStartAt) >= maxSegmentMs) {
            consecutiveMaxDurationFlushes++
            lastFlushWasMaxDuration = true
            return true
        }
        return false
    }

    // true nếu đoạn đang đệm đã từng có ít nhất 1 khung được VAD báo là giọng nói - đoạn toàn
    // im lặng (VAD chưa từng báo true) không đáng gửi lên Whisper dù đã tới lúc "cắt".
    fun hasVoice(): Boolean = hasVoiceInSegment

    // true nếu ĐÃ đạt hoặc vượt ngưỡng "nghe giống nhạc liên tục" - trạng thái LIÊN TỤC (không
    // phải 1 lần duy nhất), tự động về false ngay khi có 1 lần cắt do PAUSE thật xảy ra (xem
    // shouldFlush()). Caller (SttReadLoop.kt) gắn giá trị này vào MỖI đoạn gửi lên JS qua
    // emitCloudSttSegment(likelyMusic=...), để JS tự quyết định có gọi Whisper hay không cho
    // TỪNG đoạn - nhờ vậy JS tự "resume" đúng lúc mà KHÔNG cần thêm sự kiện "hết nhạc rồi" riêng
    // từ native: đoạn kế tiếp sau khi nhạc thật sự dừng sẽ tự nhiên có likelyMusic=false.
    fun isLikelyContinuousMusic(): Boolean = consecutiveMaxDurationFlushes >= CONTINUOUS_MUSIC_HINT_THRESHOLD

    // true CHỈ ĐÚNG 1 LẦN, tại đúng thời điểm bộ đếm vừa CHẠM ngưỡng (so sánh ==, không phải >=)
    // - dùng để bắn sự kiện cảnh báo (emitPossibleMusicDetected) đúng 1 lần mỗi "đợt nhạc", không
    // lặp lại mỗi 12s sau đó dù isLikelyContinuousMusic() vẫn tiếp tục là true. Nếu sau đó có 1
    // đợt nhạc KHÁC (sau khi đã có pause thật xen giữa, đưa bộ đếm về 0 rồi leo lên lại), hàm này
    // sẽ true lại đúng 1 lần cho đợt mới đó.
    fun justCrossedContinuousMusicHint(): Boolean =
        lastFlushWasMaxDuration && consecutiveMaxDurationFlushes == CONTINUOUS_MUSIC_HINT_THRESHOLD
}
