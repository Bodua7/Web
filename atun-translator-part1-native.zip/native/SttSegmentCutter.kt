package com.atun.translator

// ===== Tách từ SttReadLoop.kt (đợt audit thêm test JUnit) =====
// SttSegmentCutter: logic THUẦN (không đụng AudioRecord/Thread/Service) quyết định KHI NÀO nên
// cắt đoạn audio đang đệm thành 1 segment để gửi lên Cloud STT. Trước đây state này (hasVoiceInSegment/
// segmentStartAt/lastVoiceAt) nằm thẳng trong các biến local của vòng lặp `captureThread` trong
// SttReadLoop.kt - không tự unit-test bằng JUnit thuần được vì gắn liền với AudioRecord.read()
// thật. Tách state + quyết định ra riêng object này giữ NGUYÊN hành vi gốc (2 điều kiện cắt đoạn
// y hệt: đã có giọng nói + vừa im lặng đủ lâu, HOẶC đoạn đã kéo dài quá lâu dù chưa pause) - xem
// native-test/SttSegmentCutterTest.kt.
//
// KHÔNG tự đếm số byte PCM đã đệm (pcmBuffer.size() vẫn đọc trực tiếp từ ByteArrayOutputStream
// thật trong SttReadLoop.kt) - cutter này chỉ lo phần thời điểm/có-giọng-nói-hay-không, tránh
// trùng lặp state với buffer thật (1 nguồn sự thật duy nhất cho số byte).
class SttSegmentCutter(
    private val pauseMs: Long,
    private val maxSegmentMs: Long,
) {
    private var hasVoiceInSegment = false
    private var segmentStartAt = 0L
    private var lastVoiceAt = 0L

    // Gọi khi bắt đầu 1 đoạn mới (lúc bắt đầu capture, HOẶC ngay sau khi vừa cắt xong 1 đoạn).
    fun reset(now: Long) {
        hasVoiceInSegment = false
        segmentStartAt = now
        lastVoiceAt = now
    }

    // Gọi 1 lần mỗi khung audio đã đọc được (length > 0) - cập nhật state, KHÔNG tự cắt/tự trả
    // gì cả, chỉ ghi nhận. Gọi shouldFlush() riêng sau đó để hỏi có nên cắt hay chưa.
    fun onFrame(now: Long, isVoiceFrame: Boolean) {
        if (isVoiceFrame) {
            lastVoiceAt = now
            hasVoiceInSegment = true
        }
    }

    // true nếu đã tới lúc cắt đoạn hiện tại - vì (1) đã có giọng nói trong đoạn này VÀ vừa im
    // lặng đủ lâu (coi như hết câu), HOẶC (2) đoạn đã kéo dài quá lâu dù chưa thấy pause (người
    // nói liên tục không ngừng) - tránh đệm audio vô hạn trong RAM. Không tự nói đoạn đó có ĐÁNG
    // gửi lên Whisper hay không (xem hasVoice() - caller tự phối hợp với kích thước buffer thật).
    fun shouldFlush(now: Long): Boolean {
        if (hasVoiceInSegment && (now - lastVoiceAt) >= pauseMs) return true
        if ((now - segmentStartAt) >= maxSegmentMs) return true
        return false
    }

    // true nếu đoạn đang đệm đã từng có ít nhất 1 khung được VAD báo là giọng nói - đoạn toàn
    // im lặng (VAD chưa từng báo true) không đáng gửi lên Whisper dù đã tới lúc "cắt".
    fun hasVoice(): Boolean = hasVoiceInSegment
}
