package com.atun.translator

import android.app.*
import android.content.Intent
import android.content.SharedPreferences
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlin.concurrent.thread

// Bắt audio để dịch, theo 1 trong 2 nguồn:
// - MODE_SYSTEM: audio đang phát bởi app khác trên máy (YouTube, VLC...) qua
//   AudioPlaybackCaptureConfiguration (Android 10+). Cần quyền MediaProjection (xin lại mỗi lần,
//   token dùng 1 lần - KHÔNG tự phục hồi được nếu service bị OS kill).
// - MODE_MIC: ghi âm qua micro máy (nghe audio phát ra loa ngoài). Chỉ cần quyền RECORD_AUDIO
//   (permission thường, xin 1 lần là xong) -> có thể tự khởi động lại sau khi bị OS kill.
class AudioCaptureService : Service() {

    companion object {
        const val ACTION_START = "com.atun.translator.action.START_CAPTURE"
        const val ACTION_STOP = "com.atun.translator.action.STOP_CAPTURE"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"
        const val EXTRA_SOURCE_LANG = "sourceLang"
        const val EXTRA_CAPTURE_MODE = "captureMode"
        const val EXTRA_SMART_PAUSE = "smartPause"
        // true = bỏ qua Vosk hoàn toàn, dùng Whisper Cloud (Groq) - xem startCloudSttReadLoop().
        const val EXTRA_CLOUD_STT = "cloudStt"
        // Chỉ có tác dụng ở MODE_MIC: true = cố định route AudioRecord sang thiết bị micro NGOÀI
        // đang cắm/kết nối (tai nghe dây, micro/tai nghe USB, tai nghe Bluetooth đang bật SCO)
        // thay vì micro liền trong máy - xem selectMicInputDevice()/findExternalInputDevice().
        const val EXTRA_PREFER_EXTERNAL_MIC = "preferExternalMic"

        const val MODE_SYSTEM = "system"
        const val MODE_MIC = "mic"

        // Vosk hoạt động tốt nhất ở 16kHz mono PCM16 - hầu hết model Vosk train ở sample rate này.
        const val SAMPLE_RATE = 16000
        private const val CHANNEL_ID = "audio_capture_channel"
        private const val NOTIFICATION_ID = 42

        // Ngưỡng peak cố định trước đây (SILENCE_PEAK_THRESHOLD=50) đã bị thay bằng VAD thích
        // nghi theo nhiễu nền - xem VadDetector.kt.

        // Ngưỡng im lặng liên tục (giây) trước khi cảnh báo UI - đếm ở JS qua sự kiện audioLevel,
        // hằng số này chỉ dùng phía native để quyết định khi nào cần bắn thêm sự kiện rõ ràng.
        const val SILENCE_WARNING_SECONDS = 8

        // ===== Chế độ ngắt câu thông minh khi người nói tạm nghỉ =====
        // Sau khi phát hiện im lặng liên tục >= khoảng thời gian này (kể từ mẫu có giọng nói
        // gần nhất), coi như người nói đã dứt câu -> ép Vosk chốt final ngay (xem
        // VoskEngine.forcePauseFinal()) thay vì đợi endpointer nội bộ (có thể trễ/không chốt).
        // Giảm dần theo yêu cầu người dùng: 700ms -> 500ms -> 300ms -> 200ms -> 100ms -> 50ms ->
        // 30ms - phụ đề chốt câu nhanh/nhạy hơn, đổi lại dễ cắt câu hơn nếu người nói ngừng lấy
        // hơi hơi lâu giữa câu (ở ngưỡng 30ms, gần như MỌI khoảng nghỉ tự nhiên khi nói, kể cả
        // giữa 2 âm tiết cùng 1 từ, cũng đủ để bị coi là hết câu - dễ vỡ câu vụn hơn hẳn so với
        // 50ms/100ms). Có thể chỉnh lại nếu thấy ngắt quá sớm/quá trễ.
        private const val SMART_PAUSE_MS = 30L

        // ===== Cloud STT (Whisper qua groq-relay?op=transcribe) - cắt audio thành từng đoạn để
        // upload thay vì 1 file dài (giảm độ trễ + tránh timeout/kích thước quá lớn). Ngưỡng
        // pause CỐ ĐỊNH riêng cho cloud (KHÔNG dùng chung SMART_PAUSE_MS vốn quá ngắn - 30ms là
        // để phụ đề hiển thị tức thời từ Vosk, dùng cho cloud sẽ tạo hàng trăm request rất nhỏ,
        // tốn quota/tiền vô ích). Có thêm mốc cắt cứng nếu người nói liên tục không ngừng quá
        // lâu (tránh đệm audio quá dài trong RAM + Whisper cũng kém chính xác hơn với đoạn dài).
        private const val CLOUD_SEGMENT_PAUSE_MS = 600L
        private const val CLOUD_SEGMENT_MAX_MS = 12000L
        // ~0.25s audio 16kHz*16bit mono = 8000 bytes/s -> 2000 bytes cho 0.25s là số lý thuyết,
        // nhưng lấy dư ra (6000 bytes ~ 0.19s) làm ngưỡng "gần như chắc chắn có nội dung" - đoạn
        // ngắn hơn thường chỉ là VAD vừa bắt được vài chục ms giọng nói rồi tắt ngay (nhiễu/tiếng
        // click), gửi lên Whisper chỉ tốn request vô ích.
        private const val CLOUD_SEGMENT_MIN_BYTES = 6000

        private const val PREFS_NAME = "audio_capture_state"
        private const val KEY_WAS_CAPTURING = "wasCapturing"
        private const val KEY_MODE = "mode"
        private const val KEY_LANG = "lang"
        private const val KEY_SMART_PAUSE = "smartPause"
        private const val KEY_CLOUD_STT = "cloudStt"
        private const val KEY_PREFER_EXTERNAL_MIC = "preferExternalMic"

        private fun prefs(ctx: android.content.Context): SharedPreferences =
            ctx.getSharedPreferences(PREFS_NAME, MODE_PRIVATE)

        // ===== Nhận diện micro NGOÀI đang kết nối, dùng chung cho cả AudioCaptureService (lúc
        // thật sự chọn thiết bị để ghi) LẪN AudioCapturePlugin.listInputDevices() (lúc JS muốn
        // xem trước máy có phát hiện được gì không, KHÔNG cần bắt đầu nghe). Chỉ liệt kê input
        // device - KHÔNG gồm micro liền trong máy (TYPE_BUILTIN_MIC) vì đó là fallback mặc định,
        // không cần user chọn thấy trong danh sách "micro ngoài". =====
        fun listExternalInputDevices(ctx: android.content.Context): List<AudioDeviceInfo> {
            val am = ctx.getSystemService(android.content.Context.AUDIO_SERVICE) as AudioManager
            val all = am.getDevices(AudioManager.GET_DEVICES_INPUTS)
            return all.filter { it.type != AudioDeviceInfo.TYPE_BUILTIN_MIC && it.type != AudioDeviceInfo.TYPE_BUILTIN_EARPIECE }
        }

        // Thứ tự ưu tiên khi có NHIỀU thiết bị ngoài cùng lúc: USB (chất lượng/độ ổn định
        // thường tốt nhất, không cần đàm phán kết nối) > tai nghe có dây (jack 3.5mm/USB-C
        // analog, luôn sẵn sàng ngay) > Bluetooth SCO (chỉ xuất hiện trong danh sách này khi hệ
        // thống ĐÃ bật kênh thoại SCO - app KHÔNG tự gọi AudioManager.startBluetoothSco() ở đây,
        // nên tai nghe Bluetooth thường chỉ được chọn nếu app/hệ thống khác đã bật sẵn kênh gọi
        // thoại; xem ghi chú ở describeInputDevice bên dưới).
        private fun devicePriority(type: Int): Int = when (type) {
            AudioDeviceInfo.TYPE_USB_HEADSET -> 0
            AudioDeviceInfo.TYPE_USB_DEVICE -> 1
            AudioDeviceInfo.TYPE_WIRED_HEADSET -> 2
            AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> 2
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> 3
            else -> 9
        }

        fun findBestExternalInputDevice(ctx: android.content.Context): AudioDeviceInfo? =
            listExternalInputDevices(ctx).minByOrNull { devicePriority(it.type) }

        // Nhãn tiếng Việt cho UI/log - dùng productName thật của thiết bị khi máy trả về được
        // (không phải lúc nào cũng có, tuỳ driver/thiết bị).
        fun describeInputDevice(d: AudioDeviceInfo): String {
            val kind = when (d.type) {
                AudioDeviceInfo.TYPE_USB_HEADSET -> "Tai nghe USB"
                AudioDeviceInfo.TYPE_USB_DEVICE -> "Micro USB"
                AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Tai nghe có dây (jack)"
                AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "Tai nghe có dây (jack)"
                // SCO = kênh thoại Bluetooth (băng thông thấp hơn A2DP nhưng có đường micro về -
                // A2DP chỉ phát, không có micro). Xem ghi chú devicePriority() ở trên.
                AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Tai nghe Bluetooth"
                else -> "Micro ngoài"
            }
            val name = d.productName?.toString()
            return if (!name.isNullOrBlank() && name != "?") "$kind ($name)" else kind
        }

        // Gọi từ JS/Activity khi mở lại app, để biết phiên SYSTEM có bị mất giữa chừng không
        // (không tự phục hồi được, phải hiện lại nút "Bắt đầu nghe" cho user bấm lại).
        fun consumeLostSystemSession(ctx: android.content.Context): Boolean {
            val p = prefs(ctx)
            val lost = p.getBoolean(KEY_WAS_CAPTURING, false) && p.getString(KEY_MODE, "") == MODE_SYSTEM
            return lost
        }

        fun clearSavedState(ctx: android.content.Context) {
            prefs(ctx).edit().clear().apply()
        }
    }

    private var mediaProjection: MediaProjection? = null
    private var audioRecord: AudioRecord? = null
    private var captureThread: Thread? = null
    @Volatile private var isCapturing = false
    private var currentMode: String = MODE_SYSTEM

    // PARTIAL_WAKE_LOCK: chỉ giữ CPU chạy (không giữ màn hình sáng), để vòng lặp đọc
    // AudioRecord + Vosk không bị Doze/App Standby làm chậm/treo khi user tắt màn hình
    // giữa lúc đang nghe. Không giữ SCREEN wakelock vì không cần màn hình sáng liên tục.
    private var wakeLock: PowerManager.WakeLock? = null

    // SttEngine: VoskEngine (1 ngôn ngữ) ở chế độ thường, hoặc MultiLangVoskEngine (nhiều ngôn
    // ngữ chạy song song) khi sourceLang == "auto" - xem startVoskAndReadLoop().
    private var sttEngine: SttEngine? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when {
            intent?.action == ACTION_STOP -> {
                clearSavedState(applicationContext)
                stopCapture()
                stopSelf()
            }
            // intent == null xảy ra khi hệ thống tự khởi động lại service sau khi bị OS kill
            // (do trả về START_STICKY). Lúc này không còn resultCode/resultData gốc, nên chỉ
            // phục hồi được nếu phiên trước là MODE_MIC (không cần MediaProjection token).
            intent == null -> {
                val p = prefs(applicationContext)
                val wasCapturing = p.getBoolean(KEY_WAS_CAPTURING, false)
                val savedMode = p.getString(KEY_MODE, MODE_SYSTEM) ?: MODE_SYSTEM
                val savedLang = p.getString(KEY_LANG, "en") ?: "en"
                val savedSmartPause = p.getBoolean(KEY_SMART_PAUSE, true)
                val savedCloudStt = p.getBoolean(KEY_CLOUD_STT, false)
                val savedPreferExternalMic = p.getBoolean(KEY_PREFER_EXTERNAL_MIC, false)
                if (wasCapturing && savedMode == MODE_MIC) {
                    startForegroundNotification(MODE_MIC)
                    startMicCapture(savedLang, savedSmartPause, savedCloudStt, savedPreferExternalMic)
                    AudioCapturePlugin.instance?.emitCaptureResumed(MODE_MIC)
                } else {
                    // Phiên SYSTEM không tự phục hồi được - dừng hẳn, để lại cờ cho JS biết
                    // (consumeLostSystemSession) khi user mở lại app.
                    stopSelf()
                }
            }
            else -> {
                val mode = intent.getStringExtra(EXTRA_CAPTURE_MODE) ?: MODE_SYSTEM
                currentMode = mode
                startForegroundNotification(mode)
                val sourceLang = intent.getStringExtra(EXTRA_SOURCE_LANG) ?: "en"
                val smartPause = intent.getBooleanExtra(EXTRA_SMART_PAUSE, true)
                val cloudStt = intent.getBooleanExtra(EXTRA_CLOUD_STT, false)
                val preferExternalMic = intent.getBooleanExtra(EXTRA_PREFER_EXTERNAL_MIC, false)
                if (mode == MODE_MIC) {
                    startMicCapture(sourceLang, smartPause, cloudStt, preferExternalMic)
                } else {
                    val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                    val resultData = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
                    if (resultCode == Activity.RESULT_OK && resultData != null) {
                        startSystemCapture(resultCode, resultData, sourceLang, smartPause, cloudStt)
                    } else {
                        AudioCapturePlugin.instance?.emitError("Thiếu dữ liệu quyền MediaProjection.")
                        stopSelf()
                    }
                }
            }
        }
        // START_STICKY: xin hệ thống khởi động lại service (với intent = null) nếu bị kill
        // giữa chừng do bộ nhớ thấp/OEM diệt app. Xem nhánh intent == null ở trên để biết
        // giới hạn phục hồi (chỉ MODE_MIC phục hồi được tự động).
        return START_STICKY
    }

    // Bắt buộc có notification foreground TRƯỚC khi tạo MediaProjection/AudioRecord,
    // nếu không Android 14+ sẽ ném SecurityException (foregroundServiceType=mediaProjection).
    private fun startForegroundNotification(mode: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Bắt âm thanh để dịch", NotificationManager.IMPORTANCE_LOW)
        )

        val stopIntent = Intent(this, AudioCaptureService::class.java).apply { action = ACTION_STOP }
        val stopPendingIntentFlags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_IMMUTABLE else 0)
        val stopPendingIntent = PendingIntent.getService(this, 0, stopIntent, stopPendingIntentFlags)

        val contentText = if (mode == MODE_MIC)
            "Đang nghe qua micro để dịch trực tiếp"
        else
            "Đang bắt âm thanh phát ra từ máy để dịch trực tiếp"

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Đang nghe và dịch phụ đề")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Dừng", stopPendingIntent)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val type = if (mode == MODE_MIC)
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            else
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            startForeground(NOTIFICATION_ID, notification, type)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun saveState(
        mode: String, lang: String, capturing: Boolean, smartPause: Boolean, cloudStt: Boolean,
        preferExternalMic: Boolean = false
    ) {
        prefs(applicationContext).edit()
            .putBoolean(KEY_WAS_CAPTURING, capturing)
            .putString(KEY_MODE, mode)
            .putString(KEY_LANG, lang)
            .putBoolean(KEY_SMART_PAUSE, smartPause)
            .putBoolean(KEY_CLOUD_STT, cloudStt)
            .putBoolean(KEY_PREFER_EXTERNAL_MIC, preferExternalMic)
            .apply()
    }

    private fun startSystemCapture(resultCode: Int, resultData: Intent, sourceLang: String, smartPause: Boolean, cloudStt: Boolean) {
        acquireWakeLock()

        val projectionManager =
            getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = projectionManager.getMediaProjection(resultCode, resultData)
        mediaProjection = projection

        // Android 14+ yêu cầu đăng ký callback TRƯỚC khi gọi bất kỳ hàm capture nào.
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                // Hệ thống/user tự dừng chia sẻ màn hình (vd. qua nút Stop của Android trên
                // status bar) - đây là dừng có chủ đích, không phải bị OS kill, nên xoá luôn
                // cờ đã lưu để lần start service kế tiếp (nếu có) không cố phục hồi nhầm.
                clearSavedState(applicationContext)
                stopCapture()
            }
        }, null)

        val config = android.media.AudioPlaybackCaptureConfiguration.Builder(projection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()

        val audioFormat = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SAMPLE_RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()

        val minBufferSize = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBufferSize <= 0) {
            AudioCapturePlugin.instance?.emitError("Thiết bị không hỗ trợ cấu hình audio 16kHz mono.")
            releaseWakeLock()
            stopSelf()
            return
        }

        val record = try {
            AudioRecord.Builder()
                .setAudioFormat(audioFormat)
                .setBufferSizeInBytes(minBufferSize * 4)
                .setAudioPlaybackCaptureConfig(config)
                .build()
        } catch (e: UnsupportedOperationException) {
            // Xảy ra khi thiết bị/app nguồn chặn capture (allowAudioPlaybackCapture=false)
            // hoặc không có app nào đang phát audio khớp usage MEDIA lúc build().
            AudioCapturePlugin.instance?.emitError(
                "Không bắt được audio hệ thống - có thể app đang phát (vd. YouTube) đã chặn playback capture: " + e.message,
                code = "SYSTEM_CAPTURE_BLOCKED"
            )
            releaseWakeLock()
            stopSelf()
            return
        }

        if (record.state != AudioRecord.STATE_INITIALIZED) {
            AudioCapturePlugin.instance?.emitError(
                "AudioRecord khởi tạo thất bại (state != INITIALIZED).",
                code = "SYSTEM_CAPTURE_BLOCKED"
            )
            releaseWakeLock()
            stopSelf()
            return
        }

        audioRecord = record
        saveState(MODE_SYSTEM, sourceLang, capturing = true, smartPause = smartPause, cloudStt = cloudStt)
        if (cloudStt) {
            startCloudSttReadLoop(record, sourceLang, minBufferSize)
        } else {
            startVoskAndReadLoop(record, sourceLang, minBufferSize, smartPause)
        }
    }

    // MODE_MIC: dùng chính micro của máy, không cần MediaProjection -> không cần dialog hệ thống,
    // chỉ cần quyền RECORD_AUDIO đã cấp trước (xin ở phía JS/Plugin). Nhờ vậy service có thể tự
    // khởi động lại và tiếp tục nghe sau khi bị OS kill (xem onStartCommand, nhánh intent == null).
    private fun startMicCapture(sourceLang: String, smartPause: Boolean, cloudStt: Boolean, preferExternalMic: Boolean = false) {
        acquireWakeLock()

        val minBufferSize = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBufferSize <= 0) {
            AudioCapturePlugin.instance?.emitError("Thiết bị không hỗ trợ cấu hình audio 16kHz mono.")
            releaseWakeLock()
            stopSelf()
            return
        }

        val record = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                minBufferSize * 4
            )
        } catch (e: SecurityException) {
            AudioCapturePlugin.instance?.emitError("Thiếu quyền RECORD_AUDIO để nghe qua micro: " + e.message)
            releaseWakeLock()
            stopSelf()
            return
        }

        if (record.state != AudioRecord.STATE_INITIALIZED) {
            AudioCapturePlugin.instance?.emitError("AudioRecord (micro) khởi tạo thất bại (state != INITIALIZED).")
            releaseWakeLock()
            stopSelf()
            return
        }

        audioRecord = record

        // Ghi lại vào error log (Cài đặt > Chia sẻ log lỗi) kích thước buffer THẬT mà driver
        // âm thanh của máy này trả về - minBufferSize KHÔNG phải hằng số, mỗi dòng máy/HAL trả
        // về khác nhau, nên không thể biết trước "1 frame = bao nhiêu ms" cho một model máy cụ
        // thể (vd Samsung A16) mà không chạy thử. Frame ở đây = minBufferSize/2 mẫu (buffer đọc
        // mỗi lần record.read() trong vòng lặp bên dưới), hangover 4 frame là khoảng VAD vẫn
        // coi "đang nói" sau khi năng lượng đã tụt - cộng với SMART_PAUSE_MS mới ra tổng độ trễ
        // thật trước khi 1 câu bị chốt.
        val frameSamples = minBufferSize / 2
        val frameMs = frameSamples * 1000.0 / SAMPLE_RATE
        val hangoverMs = frameMs * 4
        AppLog.append(
            this,
            "MicCapture: minBufferSize=$minBufferSize bytes, 1 frame=$frameSamples mẫu " +
                "(~${"%.1f".format(frameMs)}ms/frame @ ${SAMPLE_RATE}Hz), hangover 4 frame≈" +
                "${"%.0f".format(hangoverMs)}ms, SMART_PAUSE_MS=${SMART_PAUSE_MS}ms, " +
                "tổng độ trễ chốt câu ước tính≈${"%.0f".format(hangoverMs + SMART_PAUSE_MS)}ms"
        )

        selectMicInputDevice(record, preferExternalMic)
        saveState(
            MODE_MIC, sourceLang, capturing = true, smartPause = smartPause, cloudStt = cloudStt,
            preferExternalMic = preferExternalMic
        )
        if (cloudStt) {
            startCloudSttReadLoop(record, sourceLang, minBufferSize)
        } else {
            startVoskAndReadLoop(record, sourceLang, minBufferSize, smartPause)
        }
    }

    // Route AudioRecord sang micro NGOÀI nếu preferExternalMic=true VÀ máy đang có ít nhất 1
    // thiết bị input ngoài kết nối - setPreferredDevice() (API 23+) chỉ đổi ĐƯỜNG THU (routing),
    // không đổi AudioSource (vẫn giữ VOICE_RECOGNITION để hưởng AEC/NS nếu thiết bị hỗ trợ).
    // Không tìm thấy thiết bị ngoài, hoặc preferExternalMic=false -> giữ nguyên hành vi cũ
    // (Android tự chọn route mặc định, thường là micro trong máy). Luôn bắn 1 sự kiện
    // "micDeviceInfo" cho JS biết THẬT SỰ đang dùng thiết bị nào - kể cả khi fallback về máy
    // trong, để UI hiện đúng trạng thái thay vì chỉ dựa vào checkbox user đã tick.
    private fun selectMicInputDevice(record: AudioRecord, preferExternalMic: Boolean) {
        if (!preferExternalMic) {
            AudioCapturePlugin.instance?.emitMicDeviceInfo(false, "Micro trong máy")
            return
        }
        val device = findBestExternalInputDevice(applicationContext)
        if (device == null) {
            AudioCapturePlugin.instance?.emitMicDeviceInfo(
                false, "Không phát hiện micro ngoài đang kết nối - dùng micro trong máy"
            )
            return
        }
        val ok = record.setPreferredDevice(device)
        if (ok) {
            AudioCapturePlugin.instance?.emitMicDeviceInfo(true, describeInputDevice(device))
        } else {
            // setPreferredDevice() hiếm khi trả false (thường do device đã bị rút ra đúng lúc
            // gọi), nhưng vẫn xử lý để không báo sai cho user là đang dùng máy ngoài.
            AudioCapturePlugin.instance?.emitMicDeviceInfo(
                false, "Không đặt được route sang micro ngoài - dùng micro trong máy"
            )
        }
    }

    // Dùng chung cho cả VoskEngine (1 ngôn ngữ) lẫn MultiLangVoskEngine (auto) - xem
    // VoskEngine.Event.DetectedFinal (chỉ MultiLangVoskEngine mới bắn event này).
    private fun dispatchSttEvent(event: VoskEngine.Event) {
        when (event) {
            is VoskEngine.Event.Partial -> AudioCapturePlugin.instance?.emitPartial(event.text)
            is VoskEngine.Event.Final -> AudioCapturePlugin.instance?.emitFinal(event.text, event.confidence, null)
            is VoskEngine.Event.DetectedFinal ->
                AudioCapturePlugin.instance?.emitFinal(event.text, event.confidence, event.lang)
            is VoskEngine.Event.LowConfidence -> AudioCapturePlugin.instance?.emitLowConfidence(event.text, event.confidence)
            is VoskEngine.Event.ModelReady -> AudioCapturePlugin.instance?.emitModelLoading(true)
            is VoskEngine.Event.Error -> AudioCapturePlugin.instance?.emitError(event.message)
            is VoskEngine.Event.LoadingProgress ->
                AudioCapturePlugin.instance?.emitModelLoadingProgress(event.loaded, event.total)
        }
    }

    private fun startVoskAndReadLoop(record: AudioRecord, sourceLang: String, minBufferSize: Int, smartPause: Boolean) {
        val engine: SttEngine

        if (sourceLang == "auto") {
            // Chế độ tự động nhận diện: chỉ dùng lại model ĐÃ TẢI SẴN (không tự tải hộ gì cả -
            // xem ModelManagerPlugin.readyLangsForAuto), cần ít nhất 2 ngôn ngữ mới có ý nghĩa
            // "nhận diện giữa nhiều ngôn ngữ".
            val autoLangs = ModelManagerPlugin.readyLangsForAuto(applicationContext)
            if (autoLangs.size < 2) {
                AudioCapturePlugin.instance?.emitError(
                    "Chế độ tự động nhận diện cần tải ít nhất 2 ngôn ngữ " +
                        "ở mục \"Quản lý mô hình ngôn ngữ\" trước khi dùng."
                )
                clearSavedState(applicationContext)
                try { record.stop() } catch (e: Exception) { /* chưa start thì bỏ qua */ }
                record.release()
                audioRecord = null
                releaseWakeLock()
                stopSelf()
                return
            }
            engine = MultiLangVoskEngine(applicationContext, SAMPLE_RATE.toFloat(), autoLangs) { event ->
                dispatchSttEvent(event)
            }
        } else {
            // Chặn sớm nếu model của sourceLang chưa tải về qua ModelManagerPlugin - tránh việc
            // AudioRecord đã start (tốn pin/CPU) nhưng Vosk không bao giờ nhận diện được gì vì
            // model null.
            val modelSource = VoskEngine.resolveModelSource(applicationContext, sourceLang)
            if (modelSource == null) {
                AudioCapturePlugin.instance?.emitError(
                    "Chưa tải model cho ngôn ngữ '$sourceLang'. Vào phần Quản lý mô hình để tải về trước."
                )
                clearSavedState(applicationContext) // tránh service tự resume lại với model vẫn thiếu
                try { record.stop() } catch (e: Exception) { /* chưa start thì bỏ qua */ }
                record.release()
                audioRecord = null
                releaseWakeLock()
                stopSelf()
                return
            }
            engine = VoskEngine(applicationContext, SAMPLE_RATE.toFloat(), modelSource) { event ->
                dispatchSttEvent(event)
            }
        }

        sttEngine = engine
        engine.init()

        isCapturing = true
        record.startRecording()
        captureThread = thread(name = "AudioCaptureReadLoop") {
            val buffer = ShortArray(minBufferSize / 2)
            // VAD thích nghi thay ngưỡng peak cố định (xem VadDetector.kt) - quyết định
            // isSilentRead cho cả thống kê audioLevel VÀ smartPause bên dưới.
            val vad = VadDetector()

            var lastLevelEmitAt = System.currentTimeMillis()
            var peakSinceLastEmit = 0
            var readCallsSinceLastEmit = 0
            var silentReadsSinceLastEmit = 0
            var badReadsSinceLastEmit = 0 // read() <= 0

            // ===== Chế độ ngắt câu thông minh: theo dõi mốc thời gian có giọng nói gần nhất
            // theo TỪNG lần read() (độ phân giải ~vài chục ms), KHÔNG dùng số liệu gộp mỗi giây
            // ở trên (quá thô để bắt pause ~700ms chính xác). pauseHandled chặn gọi
            // forcePauseFinal() lặp lại nhiều lần cho cùng 1 khoảng im lặng.
            var lastVoiceAt = System.currentTimeMillis()
            var pauseHandled = false

            while (isCapturing) {
                val read = record.read(buffer, 0, buffer.size)
                val now = System.currentTimeMillis()

                if (read > 0) {
                    sttEngine?.feed(buffer, read)

                    var peak = 0
                    for (i in 0 until read) {
                        val v = kotlin.math.abs(buffer[i].toInt())
                        if (v > peak) peak = v
                    }
                    if (peak > peakSinceLastEmit) peakSinceLastEmit = peak
                    readCallsSinceLastEmit++

                    // isSilentRead giờ do VAD quyết định (năng lượng + ngưỡng thích nghi theo
                    // nhiễu nền), không còn so peak với hằng số cố định - xem VadDetector.kt.
                    val isVoiceFrame = vad.process(buffer, read)
                    val isSilentRead = !isVoiceFrame
                    if (isSilentRead) silentReadsSinceLastEmit++

                    if (smartPause) {
                        if (isSilentRead) {
                            if (!pauseHandled && (now - lastVoiceAt) >= SMART_PAUSE_MS) {
                                sttEngine?.forcePauseFinal()
                                pauseHandled = true
                            }
                        } else {
                            lastVoiceAt = now
                            pauseHandled = false
                        }
                    }
                } else {
                    badReadsSinceLastEmit++
                }

                if (now - lastLevelEmitAt >= 1000) {
                    AudioCapturePlugin.instance?.emitAudioLevel(
                        peakSinceLastEmit, readCallsSinceLastEmit, silentReadsSinceLastEmit, badReadsSinceLastEmit
                    )
                    lastLevelEmitAt = now
                    peakSinceLastEmit = 0
                    readCallsSinceLastEmit = 0
                    silentReadsSinceLastEmit = 0
                    badReadsSinceLastEmit = 0
                }
            }
        }
    }

    // ===== Cloud STT (Whisper qua groq-relay?op=transcribe) - đường thay thế HOÀN TOÀN cho
    // startVoskAndReadLoop() ở trên, không dùng chung code với Vosk (tách riêng cho rõ ràng,
    // tránh rủi ro đụng chạm logic Vosk đang chạy ổn định). Không cần SttEngine/model Vosk nào
    // cả - chỉ dùng VadDetector (thuần thuật toán, không phải model) để biết lúc nào người nói
    // tạm dừng, cắt PCM đã đệm thành 1 đoạn WAV, base64 rồi bắn sang JS qua emitCloudSttSegment().
    // JS tự lo phần upload mạng - xem www/index.html (transcribeCloudSegment).
    private fun startCloudSttReadLoop(record: AudioRecord, sourceLang: String, minBufferSize: Int) {
        isCapturing = true
        record.startRecording()
        // Không có model local nào để tải - coi như "sẵn sàng" ngay lập tức để JS ẩn luôn
        // trạng thái "đang tải model" (xem onModelStatus trong www/index.html).
        AudioCapturePlugin.instance?.emitModelLoading(true)

        captureThread = thread(name = "AudioCaptureCloudSttLoop") {
            val buffer = ShortArray(minBufferSize / 2)
            val vad = VadDetector()
            val pcmBuffer = java.io.ByteArrayOutputStream()

            var lastLevelEmitAt = System.currentTimeMillis()
            var peakSinceLastEmit = 0
            var readCallsSinceLastEmit = 0
            var silentReadsSinceLastEmit = 0
            var badReadsSinceLastEmit = 0

            var segmentStartAt = System.currentTimeMillis()
            var lastVoiceAt = System.currentTimeMillis()
            var hasVoiceInSegment = false

            fun flushSegment() {
                // Bỏ qua đoạn toàn im lặng (VAD chưa từng báo có giọng nói) hoặc quá ngắn (nhiều
                // khả năng chỉ là tiếng click/nhiễu ngắn) - tránh tốn request Whisper vô ích.
                if (hasVoiceInSegment && pcmBuffer.size() >= CLOUD_SEGMENT_MIN_BYTES) {
                    val wav = buildWavFile(pcmBuffer.toByteArray(), SAMPLE_RATE)
                    val base64 = android.util.Base64.encodeToString(wav, android.util.Base64.NO_WRAP)
                    AudioCapturePlugin.instance?.emitCloudSttSegment(base64, sourceLang)
                }
                pcmBuffer.reset()
                hasVoiceInSegment = false
                segmentStartAt = System.currentTimeMillis()
            }

            while (isCapturing) {
                val read = record.read(buffer, 0, buffer.size)
                val now = System.currentTimeMillis()

                if (read > 0) {
                    pcmBuffer.write(shortsToBytesLE(buffer, read))

                    var peak = 0
                    for (i in 0 until read) {
                        val v = kotlin.math.abs(buffer[i].toInt())
                        if (v > peak) peak = v
                    }
                    if (peak > peakSinceLastEmit) peakSinceLastEmit = peak
                    readCallsSinceLastEmit++

                    val isVoiceFrame = vad.process(buffer, read)
                    if (isVoiceFrame) {
                        lastVoiceAt = now
                        hasVoiceInSegment = true
                    } else {
                        silentReadsSinceLastEmit++
                    }

                    // Cắt đoạn khi: (1) đã có giọng nói trong đoạn này VÀ vừa im lặng đủ lâu
                    // (coi như hết câu), HOẶC (2) đoạn đã kéo dài quá lâu dù chưa thấy pause
                    // (người nói liên tục không ngừng) - tránh đệm audio vô hạn trong RAM.
                    if (hasVoiceInSegment && (now - lastVoiceAt) >= CLOUD_SEGMENT_PAUSE_MS) {
                        flushSegment()
                    } else if ((now - segmentStartAt) >= CLOUD_SEGMENT_MAX_MS) {
                        flushSegment()
                    }
                } else {
                    badReadsSinceLastEmit++
                }

                if (now - lastLevelEmitAt >= 1000) {
                    AudioCapturePlugin.instance?.emitAudioLevel(
                        peakSinceLastEmit, readCallsSinceLastEmit, silentReadsSinceLastEmit, badReadsSinceLastEmit
                    )
                    lastLevelEmitAt = now
                    peakSinceLastEmit = 0
                    readCallsSinceLastEmit = 0
                    silentReadsSinceLastEmit = 0
                    badReadsSinceLastEmit = 0
                }
            }
            // Đẩy nốt đoạn còn dang dở khi dừng nghe giữa câu (vd user bấm "Dừng nghe") - không
            // thì mất trắng câu cuối cùng đang nói dở.
            flushSegment()
        }
    }

    // PCM16 mono, little-endian - đúng thứ tự byte chuẩn của WAV/hầu hết API STT (kể cả Whisper).
    private fun shortsToBytesLE(samples: ShortArray, len: Int): ByteArray {
        val bb = java.nio.ByteBuffer.allocate(len * 2).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until len) bb.putShort(samples[i])
        return bb.array()
    }

    // Đóng gói PCM16 mono thô thành file WAV hoàn chỉnh (header 44 byte chuẩn) - Whisper API
    // (qua groq-relay) nhận file audio thật (có header), không nhận PCM thô.
    private fun buildWavFile(pcm: ByteArray, sampleRate: Int): ByteArray {
        val header = java.nio.ByteBuffer.allocate(44).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        val byteRate = sampleRate * 2 // 16-bit mono: 2 byte/mẫu
        header.put("RIFF".toByteArray(Charsets.US_ASCII))
        header.putInt(36 + pcm.size)
        header.put("WAVE".toByteArray(Charsets.US_ASCII))
        header.put("fmt ".toByteArray(Charsets.US_ASCII))
        header.putInt(16) // Subchunk1Size cho PCM
        header.putShort(1) // AudioFormat = 1 (PCM)
        header.putShort(1) // NumChannels = 1 (mono)
        header.putInt(sampleRate)
        header.putInt(byteRate)
        header.putShort(2) // BlockAlign = NumChannels * BitsPerSample/8
        header.putShort(16) // BitsPerSample
        header.put("data".toByteArray(Charsets.US_ASCII))
        header.putInt(pcm.size)
        return header.array() + pcm
    }

    // Giữ vô thời hạn (không set timeout) vì phiên dịch live có thể kéo dài vài giờ - nếu
    // set timeout ngắn (vd 30') sẽ tự hết hạn giữa chừng, gây lại đúng vấn đề WakeLock
    // muốn tránh. An toàn vì: mọi nhánh lỗi trong start*Capture(), stopCapture() (được gọi
    // từ ACTION_STOP, MediaProjection.Callback.onStop, VÀ onDestroy) đều gọi releaseWakeLock();
    // nếu process bị OS kill hoàn toàn thì WakeLock cũng tự mất theo, không leak vĩnh viễn.
    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "AtunTranslator:AudioCaptureWakeLock"
        ).apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.let {
            if (it.isHeld) it.release()
        }
        wakeLock = null
    }

    private fun stopCapture() {
        isCapturing = false
        captureThread?.join(500)
        captureThread = null

        audioRecord?.let {
            try { it.stop() } catch (e: Exception) { /* đã stop rồi thì bỏ qua */ }
            it.release()
        }
        audioRecord = null

        sttEngine?.release()
        sttEngine = null

        mediaProjection?.stop()
        mediaProjection = null

        releaseWakeLock()
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }
}
