// Fix (audit Detekt - InvalidPackageDeclaration false-positive): file này nằm phẳng trong
// native/ ở gốc repo, không theo cấu trúc thư mục com/atun/translator/ - CÓ CHỦ ĐÍCH, vì bước
// build-debug (android-build.yml) tự copy file này vào đúng
// android/app/src/main/java/com/atun/translator/ trước khi biên dịch thật (xem step "Copy
// native Kotlin sources"). Detekt ở job validation chạy TRƯỚC bước copy đó (trên native/ phẳng)
// nên luôn báo package không khớp đường dẫn vật lý lúc đó - không phải lỗi thật, khai báo
// package vẫn đúng với vị trí SAU KHI copy (nơi thật sự biên dịch).
@file:Suppress("InvalidPackageDeclaration")

package com.atun.translator

import android.app.*
import android.content.Intent
import android.content.SharedPreferences
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.os.IBinder
import android.os.PowerManager
import android.util.Log

// Bắt audio để dịch, theo 1 trong 2 nguồn:
// - MODE_SYSTEM: audio đang phát bởi app khác trên máy (YouTube, VLC...) qua
//   AudioPlaybackCaptureConfiguration (Android 10+). Cần quyền MediaProjection (xin lại mỗi lần,
//   token dùng 1 lần - KHÔNG tự phục hồi được nếu service bị OS kill).
// - MODE_MIC: ghi âm qua micro máy (nghe audio phát ra loa ngoài). Chỉ cần quyền RECORD_AUDIO
//   (permission thường, xin 1 lần là xong) -> có thể tự khởi động lại sau khi bị OS kill.
//
// - MODE_MIXED: HỒI SINH "dịch hội thoại 2 chiều" (2026-09-10, trước đó đã bỏ khi chuyển sang
//   Cloud STT vì bản Vosk cũ không chuyển đổi được thẳng) - bắt ĐỒNG THỜI mic (mình nói, dịch
//   sang ngôn ngữ đối phương) + system audio (đối phương nói qua loa ngoài/cuộc gọi, dịch sang
//   tiếng Việt). Cần CẢ 2 quyền (RECORD_AUDIO + MediaProjection) cùng lúc. 2 luồng độc lập, mỗi
//   luồng 1 AudioRecord/1 Thread/1 pipeline Cloud STT riêng - xem audioRecordMic/captureThreadMic
//   bên dưới (audioRecord/captureThread dùng chung cho luồng system, giống các mode đơn khác).
//
// STT: CHỈ còn 1 đường - Cloud STT (Whisper qua groq-relay, xem SttReadLoop.startCloudSttReadLoop)
// - đã bỏ hẳn nhánh Vosk offline.
//
// ===== Ghi chú tách module =====
// - CaptureSourceManager.kt : dựng nguồn thu (MediaProjection hệ thống / micro), chọn thiết bị mic
// - SttReadLoop.kt          : vòng lặp đọc AudioRecord + đẩy đoạn audio sang Cloud STT (Whisper)
// - AudioInputDevices.kt    : liệt kê/mô tả thiết bị micro ngoài (object thuần, không đụng field
//                             service - KHÔNG phải extension function như 2 file còn lại)
// - CaptureNotification.kt  : dựng notification foreground (startForegroundNotification)
// Các hàm ở CaptureSourceManager.kt/SttReadLoop.kt/CaptureNotification.kt là extension function
// của chính class này (khai báo "internal fun AudioCaptureService.xxx(...)") - vẫn truy cập trực
// tiếp field của service như trước, KHÔNG đổi hành vi, chỉ tách vị trí code sang file riêng cho
// dễ đọc/maintain. Field/hằng số nào được các file đó dùng đã đổi từ "private" sang "internal".
class AudioCaptureService : Service() {

    companion object {
        private const val TAG = "AudioCaptureService"
        const val ACTION_START = "com.atun.translator.action.START_CAPTURE"
        const val ACTION_STOP = "com.atun.translator.action.STOP_CAPTURE"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"
        const val EXTRA_SOURCE_LANG = "sourceLang"
        const val EXTRA_CAPTURE_MODE = "captureMode"
        // Chỉ có tác dụng ở MODE_MIC: true = cố định route AudioRecord sang thiết bị micro NGOÀI
        // đang cắm/kết nối (tai nghe dây, micro/tai nghe USB, tai nghe Bluetooth đang bật SCO)
        // thay vì micro liền trong máy - xem CaptureSourceManager.kt (selectMicInputDevice/
        // findExternalInputDevice).
        const val EXTRA_PREFER_EXTERNAL_MIC = "preferExternalMic"

        const val MODE_SYSTEM = "system"
        const val MODE_MIC = "mic"
        // "Dịch hội thoại 2 chiều" - bắt đồng thời MODE_MIC + MODE_SYSTEM, xem ghi chú đầu file.
        const val MODE_MIXED = "mixed"

        // channel dùng để gắn nhãn sự kiện (audioLevel/cloudSttSegment) khi ở MODE_MIXED, phân
        // biệt luồng nào đang nói - xem SttReadLoop.kt/AudioCapturePlugin.kt.
        const val CHANNEL_MIC = "mic"
        const val CHANNEL_SYSTEM = "system"

        // 16kHz mono PCM16 - định dạng chuẩn cho STT (kể cả Whisper qua groq-relay).
        const val SAMPLE_RATE = 16000
        // internal (thay vì private): CaptureNotification.kt (startForegroundNotification) đọc.
        internal const val CHANNEL_ID = "audio_capture_channel"
        internal const val NOTIFICATION_ID = 42

        // Ngưỡng peak cố định trước đây (SILENCE_PEAK_THRESHOLD=50) đã bị thay bằng VAD thích
        // nghi theo nhiễu nền - xem VadDetector.kt.

        // Ngưỡng im lặng liên tục (giây) trước khi cảnh báo UI - đếm ở JS qua sự kiện audioLevel,
        // hằng số này chỉ dùng phía native để quyết định khi nào cần bắn thêm sự kiện rõ ràng.
        const val SILENCE_WARNING_SECONDS = 8

        // ===== Cloud STT (Whisper qua groq-relay?op=transcribe) - cắt audio thành từng đoạn để
        // upload thay vì 1 file dài (giảm độ trễ + tránh timeout/kích thước quá lớn). Có thêm mốc
        // cắt cứng nếu người nói liên tục không ngừng quá lâu (tránh đệm audio quá dài trong RAM +
        // Whisper cũng kém chính xác hơn với đoạn dài).
        // internal: dùng trong SttReadLoop.kt (startCloudSttReadLoop).
        internal const val CLOUD_SEGMENT_PAUSE_MS = 600L
        internal const val CLOUD_SEGMENT_MAX_MS = 12000L
        // ~0.25s audio 16kHz*16bit mono = 8000 bytes/s -> 2000 bytes cho 0.25s là số lý thuyết,
        // nhưng lấy dư ra (6000 bytes ~ 0.19s) làm ngưỡng "gần như chắc chắn có nội dung" - đoạn
        // ngắn hơn thường chỉ là VAD vừa bắt được vài chục ms giọng nói rồi tắt ngay (nhiễu/tiếng
        // click), gửi lên Whisper chỉ tốn request vô ích.
        internal const val CLOUD_SEGMENT_MIN_BYTES = 6000

        private const val PREFS_NAME = "audio_capture_state"
        private const val KEY_WAS_CAPTURING = "wasCapturing"
        private const val KEY_MODE = "mode"
        private const val KEY_LANG = "lang"
        private const val KEY_PREFER_EXTERNAL_MIC = "preferExternalMic"

        private fun prefs(ctx: android.content.Context): SharedPreferences =
            ctx.getSharedPreferences(PREFS_NAME, MODE_PRIVATE)

        // Nhận diện/mô tả micro ngoài: xem AudioInputDevices.kt (listExternalInputDevices,
        // findBestExternalInputDevice, describeInputDevice) - đã tách ra khỏi companion object
        // này vì là hàm thuần, không đụng field/instance của service.

        // Gọi từ JS/Activity khi mở lại app, để biết phiên SYSTEM có bị mất giữa chừng không
        // (không tự phục hồi được, phải hiện lại nút "Bắt đầu nghe" cho user bấm lại).
        fun consumeLostSystemSession(ctx: android.content.Context): Boolean {
            val p = prefs(ctx)
            val savedMode = p.getString(KEY_MODE, "")
            // MODE_MIXED cũng cần MediaProjection token (luồng system trong cặp) nên KHÔNG tự
            // phục hồi được, giống hệt MODE_SYSTEM đơn - áp dụng cùng cảnh báo "mất phiên".
            val lost = p.getBoolean(KEY_WAS_CAPTURING, false) &&
                (savedMode == MODE_SYSTEM || savedMode == MODE_MIXED)
            return lost
        }

        fun clearSavedState(ctx: android.content.Context) {
            prefs(ctx).edit().clear().apply()
        }
    }

    // internal (thay vì private): CaptureSourceManager.kt gán/đọc lúc dựng nguồn thu,
    // SttReadLoop.kt đọc/gán trong vòng lặp đọc audio, stopCapture() ở dưới đây giải phóng.
    internal var mediaProjection: MediaProjection? = null
    // Ở MODE_MIXED: audioRecord/captureThread = luồng SYSTEM (đối phương), audioRecordMic/
    // captureThreadMic = luồng MIC (mình nói) - 2 field riêng vì 2 AudioRecord/Thread chạy song
    // song. Ở MODE_MIC/MODE_SYSTEM đơn (như trước đây): chỉ dùng audioRecord/captureThread,
    // audioRecordMic/captureThreadMic luôn null.
    internal var audioRecord: AudioRecord? = null
    internal var captureThread: Thread? = null
    internal var audioRecordMic: AudioRecord? = null
    internal var captureThreadMic: Thread? = null
    // isCapturing dùng CHUNG cho cả 2 luồng ở MODE_MIXED - dừng nghe luôn dừng cả 2 cùng lúc,
    // không có nhu cầu dừng riêng lẻ 1 luồng.
    @Volatile internal var isCapturing = false
    internal var currentMode: String = MODE_SYSTEM

    // PARTIAL_WAKE_LOCK: chỉ giữ CPU chạy (không giữ màn hình sáng), để vòng lặp đọc
    // AudioRecord + cắt đoạn Cloud STT không bị Doze/App Standby làm chậm/treo khi user tắt màn
    // hình giữa lúc đang nghe. Không giữ SCREEN wakelock vì không cần màn hình sáng liên tục.
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when {
            intent?.action == ACTION_STOP -> {
                clearSavedState(applicationContext)
                stopCapture()
                stopSelf()
            }
            // intent == null xảy ra khi hệ thống tự khởi động lại service sau khi bị OS kill
            // (do trả về START_STICKY). Lúc này không còn resultCode/resultData gốc, nên chỉ
            // phục hồi được nếu phiên trước là MODE_MIC (không cần MediaProjection token).
            intent == null -> {
                val p = prefs(applicationContext)
                val wasCapturing = p.getBoolean(KEY_WAS_CAPTURING, false)
                val savedMode = p.getString(KEY_MODE, MODE_SYSTEM) ?: MODE_SYSTEM
                val savedLang = p.getString(KEY_LANG, "en") ?: "en"
                val savedPreferExternalMic = p.getBoolean(KEY_PREFER_EXTERNAL_MIC, false)
                if (wasCapturing && savedMode == MODE_MIC) {
                    // Fix (audit đợt 4 - "currentMode không được khôi phục sau khi bị OS kill"):
                    // TRƯỚC ĐÂY thiếu dòng này - service là instance MỚI (bị kill rồi Android tự
                    // tạo lại), currentMode quay về giá trị mặc định khai báo ("system") thay vì
                    // "mic" dù phiên đang phục hồi rõ ràng là MIC. Hậu quả: startCloudSttReadLoop()
                    // (tham số channel mặc định = currentMode) gắn nhãn channel="system" cho toàn
                    // bộ sự kiện audioLevel/cloudSttSegment của 1 phiên MIC thật - kéo theo bug ở
                    // phía JS (xem fix "isMic" trong app.module.js: onCloudSttSegment dựa vào
                    // channel để chọn hướng dịch). Phải set TRƯỚC startForegroundNotification/
                    // startMicCapture, giống hệt cách nhánh "else" (khởi động bình thường) đã làm
                    // ("currentMode = mode" trước khi gọi các hàm start*Capture()).
                    currentMode = MODE_MIC
                    startForegroundNotification(MODE_MIC)
                    startMicCapture(savedLang, savedPreferExternalMic)
                    AudioCapturePlugin.instance?.emitCaptureResumed(MODE_MIC)
                } else {
                    // Phiên SYSTEM không tự phục hồi được - dừng hẳn, để lại cờ cho JS biết
                    // (consumeLostSystemSession) khi user mở lại app.
                    stopSelf()
                }
            }
            else -> {
                val mode = intent.getStringExtra(EXTRA_CAPTURE_MODE) ?: MODE_SYSTEM
                currentMode = mode
                startForegroundNotification(mode)
                val sourceLang = intent.getStringExtra(EXTRA_SOURCE_LANG) ?: "en"
                val preferExternalMic = intent.getBooleanExtra(EXTRA_PREFER_EXTERNAL_MIC, false)
                if (mode == MODE_MIC) {
                    startMicCapture(sourceLang, preferExternalMic)
                } else {
                    // MODE_SYSTEM và MODE_MIXED đều cần token MediaProjection (luồng system).
                    val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                    val resultData = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
                    if (resultCode == Activity.RESULT_OK && resultData != null) {
                        if (mode == MODE_MIXED) {
                            startMixedCapture(resultCode, resultData, sourceLang, preferExternalMic)
                        } else {
                            startSystemCapture(resultCode, resultData, sourceLang)
                        }
                    } else {
                        AudioCapturePlugin.instance?.emitError("Thiếu dữ liệu quyền MediaProjection.", code = "CAPTURE_START_FAILED")
                        stopSelf()
                    }
                }
            }
        }
        // START_STICKY: xin hệ thống khởi động lại service (với intent = null) nếu bị kill
        // giữa chừng do bộ nhớ thấp/OEM diệt app. Xem nhánh intent == null ở trên để biết
        // giới hạn phục hồi (chỉ MODE_MIC phục hồi được tự động).
        return START_STICKY
    }

    // Bắt buộc có notification foreground TRƯỚC khi tạo MediaProjection/AudioRecord, nếu không
    // Android 14+ sẽ ném SecurityException (foregroundServiceType=mediaProjection). Hàm dựng
    // notification: xem CaptureNotification.kt (startForegroundNotification).

    // internal: gọi từ CaptureSourceManager.kt (startSystemCapture/startMicCapture) sau khi
    // đã dựng nguồn thu thành công.
    internal fun saveState(
        mode: String, lang: String, capturing: Boolean, preferExternalMic: Boolean = false
    ) {
        prefs(applicationContext).edit()
            .putBoolean(KEY_WAS_CAPTURING, capturing)
            .putString(KEY_MODE, mode)
            .putString(KEY_LANG, lang)
            .putBoolean(KEY_PREFER_EXTERNAL_MIC, preferExternalMic)
            .apply()
    }

    // Giữ vô thời hạn (không set timeout) vì phiên dịch live có thể kéo dài vài giờ - nếu
    // set timeout ngắn (vd 30') sẽ tự hết hạn giữa chừng, gây lại đúng vấn đề WakeLock
    // muốn tránh. An toàn vì: mọi nhánh lỗi trong start*Capture() (CaptureSourceManager.kt),
    // stopCapture() (được gọi từ ACTION_STOP, MediaProjection.Callback.onStop, VÀ onDestroy)
    // đều gọi releaseWakeLock(); nếu process bị OS kill hoàn toàn thì WakeLock cũng tự mất
    // theo, không leak vĩnh viễn.
    // internal: gọi từ CaptureSourceManager.kt và SttReadLoop.kt (nhánh lỗi sớm thoát).
    internal fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "AtunTranslator:AudioCaptureWakeLock"
        ).apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    internal fun releaseWakeLock() {
        wakeLock?.let {
            if (it.isHeld) it.release()
        }
        wakeLock = null
    }

    // internal: MediaProjection.Callback.onStop() trong CaptureSourceManager.kt (startSystemCapture)
    // cũng cần gọi hàm này khi hệ thống tự dừng chia sẻ màn hình. CŨNG được gọi từ chính bên
    // TRONG captureThread khi vòng đọc AudioRecord tự bắt lỗi (xem catch trong SttReadLoop.kt) -
    // vì vậy PHẢI tự kiểm tra không tự join() chính mình (Thread.join() gọi bởi chính thread đó
    // không deadlock hẳn - vẫn trả về sau khi hết timeout - nhưng vô nghĩa và tốn 500ms chờ
    // suông mỗi lần, nên bỏ qua hẳn bước join trong trường hợp này).
    internal fun stopCapture() {
        isCapturing = false
        if (Thread.currentThread() !== captureThread) {
            captureThread?.join(500)
        }
        captureThread = null
        // Luồng mic của MODE_MIXED (null ở mọi mode khác) - cùng logic tự-join an toàn như
        // captureThread ở trên (xem ghi chú gốc tại onDestroy/MediaProjection.Callback.onStop
        // về lý do không tự join chính thread đang gọi hàm này).
        if (Thread.currentThread() !== captureThreadMic) {
            captureThreadMic?.join(500)
        }
        captureThreadMic = null

        audioRecord?.let {
            // Fix (audit Detekt - SwallowedException): trước đây bắt Exception rồi bỏ qua HOÀN
            // TOÀN, kể cả loại lỗi không liên quan tới "đã stop rồi" (vd. lỗi driver audio thật).
            // Vẫn nuốt lỗi (không throw lại - đây là code dọn dẹp lúc dừng capture, không nên làm
            // crash luôn tiến trình dừng vì 1 lỗi ở bước stop()), nhưng giờ ghi lại Logcat để còn
            // dấu vết khi debug thay vì mất trắng thông tin.
            try { it.stop() } catch (e: Exception) { Log.w(TAG, "audioRecord.stop() lỗi (có thể đã stop rồi, bỏ qua)", e) }
            it.release()
        }
        audioRecord = null

        audioRecordMic?.let {
            try { it.stop() } catch (e: Exception) { Log.w(TAG, "audioRecordMic.stop() lỗi (có thể đã stop rồi, bỏ qua)", e) }
            it.release()
        }
        audioRecordMic = null

        mediaProjection?.stop()
        mediaProjection = null

        releaseWakeLock()
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }
}
