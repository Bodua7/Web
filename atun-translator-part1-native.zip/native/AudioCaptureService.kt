package com.atun.translator

import android.app.*
import android.content.Intent
import android.content.SharedPreferences
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.os.IBinder
import android.os.PowerManager

// Bắt audio để dịch, theo 1 trong 2 nguồn:
// - MODE_SYSTEM: audio đang phát bởi app khác trên máy (YouTube, VLC...) qua
//   AudioPlaybackCaptureConfiguration (Android 10+). Cần quyền MediaProjection (xin lại mỗi lần,
//   token dùng 1 lần - KHÔNG tự phục hồi được nếu service bị OS kill).
// - MODE_MIC: ghi âm qua micro máy (nghe audio phát ra loa ngoài). Chỉ cần quyền RECORD_AUDIO
//   (permission thường, xin 1 lần là xong) -> có thể tự khởi động lại sau khi bị OS kill.
//
// ===== Ghi chú tách module (file gốc 760 dòng đã được chia nhỏ thành 4 file) =====
// - CaptureSourceManager.kt : dựng nguồn thu (MediaProjection hệ thống / micro), chọn thiết bị mic
// - SttReadLoop.kt          : vòng lặp đọc AudioRecord + đẩy vào Vosk hoặc Cloud STT (Whisper)
// - AudioInputDevices.kt    : liệt kê/mô tả thiết bị micro ngoài (object thuần, không đụng field
//                             service - KHÔNG phải extension function như 3 file còn lại)
// - CaptureNotification.kt  : dựng notification foreground (startForegroundNotification)
// Các hàm ở CaptureSourceManager.kt/SttReadLoop.kt/CaptureNotification.kt là extension function
// của chính class này (khai báo "internal fun AudioCaptureService.xxx(...)") - vẫn truy cập trực
// tiếp field của service như trước, KHÔNG đổi hành vi, chỉ tách vị trí code sang file riêng cho
// dễ đọc/maintain. Field/hằng số nào được các file đó dùng đã đổi từ "private" sang "internal".
class AudioCaptureService : Service() {

    companion object {
        const val ACTION_START = "com.atun.translator.action.START_CAPTURE"
        const val ACTION_STOP = "com.atun.translator.action.STOP_CAPTURE"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"
        const val EXTRA_SOURCE_LANG = "sourceLang"
        const val EXTRA_CAPTURE_MODE = "captureMode"
        const val EXTRA_SMART_PAUSE = "smartPause"
        // true = bỏ qua Vosk hoàn toàn, dùng Whisper Cloud (Groq) - xem SttReadLoop.kt.
        const val EXTRA_CLOUD_STT = "cloudStt"
        // Chỉ có tác dụng ở MODE_MIC: true = cố định route AudioRecord sang thiết bị micro NGOÀI
        // đang cắm/kết nối (tai nghe dây, micro/tai nghe USB, tai nghe Bluetooth đang bật SCO)
        // thay vì micro liền trong máy - xem CaptureSourceManager.kt (selectMicInputDevice/
        // findExternalInputDevice).
        const val EXTRA_PREFER_EXTERNAL_MIC = "preferExternalMic"

        const val MODE_SYSTEM = "system"
        const val MODE_MIC = "mic"

        // Vosk hoạt động tốt nhất ở 16kHz mono PCM16 - hầu hết model Vosk train ở sample rate này.
        const val SAMPLE_RATE = 16000
        // internal (thay vì private): CaptureNotification.kt (startForegroundNotification) đọc.
        internal const val CHANNEL_ID = "audio_capture_channel"
        internal const val NOTIFICATION_ID = 42

        // Ngưỡng peak cố định trước đây (SILENCE_PEAK_THRESHOLD=50) đã bị thay bằng VAD thích
        // nghi theo nhiễu nền - xem VadDetector.kt.

        // Ngưỡng im lặng liên tục (giây) trước khi cảnh báo UI - đếm ở JS qua sự kiện audioLevel,
        // hằng số này chỉ dùng phía native để quyết định khi nào cần bắn thêm sự kiện rõ ràng.
        const val SILENCE_WARNING_SECONDS = 8

        // ===== Chế độ ngắt câu thông minh khi người nói tạm nghỉ =====
        // Sau khi phát hiện im lặng liên tục >= khoảng thời gian này (kể từ mẫu có giọng nói
        // gần nhất), coi như người nói đã dứt câu -> ép Vosk chốt final ngay (xem
        // VoskEngine.forcePauseFinal()) thay vì đợi endpointer nội bộ (có thể trễ/không chốt).
        // Giảm dần theo yêu cầu người dùng: 700ms -> 500ms -> 300ms -> 200ms -> 100ms -> 50ms ->
        // 30ms - phụ đề chốt câu nhanh/nhạy hơn, đổi lại dễ cắt câu hơn nếu người nói ngừng lấy
        // hơi hơi lâu giữa câu (ở ngưỡng 30ms, gần như MỌI khoảng nghỉ tự nhiên khi nói, kể cả
        // giữa 2 âm tiết cùng 1 từ, cũng đủ để bị coi là hết câu - dễ vỡ câu vụn hơn hẳn so với
        // 50ms/100ms). Có thể chỉnh lại nếu thấy ngắt quá sớm/quá trễ.
        // internal: dùng trong SttReadLoop.kt (startVoskAndReadLoop).
        internal const val SMART_PAUSE_MS = 30L

        // ===== Cloud STT (Whisper qua groq-relay?op=transcribe) - cắt audio thành từng đoạn để
        // upload thay vì 1 file dài (giảm độ trễ + tránh timeout/kích thước quá lớn). Ngưỡng
        // pause CỐ ĐỊNH riêng cho cloud (KHÔNG dùng chung SMART_PAUSE_MS vốn quá ngắn - 30ms là
        // để phụ đề hiển thị tức thời từ Vosk, dùng cho cloud sẽ tạo hàng trăm request rất nhỏ,
        // tốn quota/tiền vô ích). Có thêm mốc cắt cứng nếu người nói liên tục không ngừng quá
        // lâu (tránh đệm audio quá dài trong RAM + Whisper cũng kém chính xác hơn với đoạn dài).
        // internal: dùng trong SttReadLoop.kt (startCloudSttReadLoop).
        internal const val CLOUD_SEGMENT_PAUSE_MS = 600L
        internal const val CLOUD_SEGMENT_MAX_MS = 12000L
        // ~0.25s audio 16kHz*16bit mono = 8000 bytes/s -> 2000 bytes cho 0.25s là số lý thuyết,
        // nhưng lấy dư ra (6000 bytes ~ 0.19s) làm ngưỡng "gần như chắc chắn có nội dung" - đoạn
        // ngắn hơn thường chỉ là VAD vừa bắt được vài chục ms giọng nói rồi tắt ngay (nhiễu/tiếng
        // click), gửi lên Whisper chỉ tốn request vô ích.
        internal const val CLOUD_SEGMENT_MIN_BYTES = 6000

        private const val PREFS_NAME = "audio_capture_state"
        private const val KEY_WAS_CAPTURING = "wasCapturing"
        private const val KEY_MODE = "mode"
        private const val KEY_LANG = "lang"
        private const val KEY_SMART_PAUSE = "smartPause"
        private const val KEY_CLOUD_STT = "cloudStt"
        private const val KEY_PREFER_EXTERNAL_MIC = "preferExternalMic"

        private fun prefs(ctx: android.content.Context): SharedPreferences =
            ctx.getSharedPreferences(PREFS_NAME, MODE_PRIVATE)

        // Nhận diện/mô tả micro ngoài: xem AudioInputDevices.kt (listExternalInputDevices,
        // findBestExternalInputDevice, describeInputDevice) - đã tách ra khỏi companion object
        // này vì là hàm thuần, không đụng field/instance của service.

        // Gọi từ JS/Activity khi mở lại app, để biết phiên SYSTEM có bị mất giữa chừng không
        // (không tự phục hồi được, phải hiện lại nút "Bắt đầu nghe" cho user bấm lại).
        fun consumeLostSystemSession(ctx: android.content.Context): Boolean {
            val p = prefs(ctx)
            val lost = p.getBoolean(KEY_WAS_CAPTURING, false) && p.getString(KEY_MODE, "") == MODE_SYSTEM
            return lost
        }

        fun clearSavedState(ctx: android.content.Context) {
            prefs(ctx).edit().clear().apply()
        }
    }

    // internal (thay vì private): CaptureSourceManager.kt gán/đọc lúc dựng nguồn thu,
    // SttReadLoop.kt đọc/gán trong vòng lặp đọc audio, stopCapture() ở dưới đây giải phóng.
    internal var mediaProjection: MediaProjection? = null
    internal var audioRecord: AudioRecord? = null
    internal var captureThread: Thread? = null
    @Volatile internal var isCapturing = false
    private var currentMode: String = MODE_SYSTEM

    // PARTIAL_WAKE_LOCK: chỉ giữ CPU chạy (không giữ màn hình sáng), để vòng lặp đọc
    // AudioRecord + Vosk không bị Doze/App Standby làm chậm/treo khi user tắt màn hình
    // giữa lúc đang nghe. Không giữ SCREEN wakelock vì không cần màn hình sáng liên tục.
    private var wakeLock: PowerManager.WakeLock? = null

    // SttEngine: VoskEngine (1 ngôn ngữ) ở chế độ thường, hoặc MultiLangVoskEngine (nhiều ngôn
    // ngữ chạy song song) khi sourceLang == "auto" - xem SttReadLoop.kt (startVoskAndReadLoop).
    // internal: SttReadLoop.kt gán engine, stopCapture() ở dưới đây giải phóng.
    internal var sttEngine: SttEngine? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when {
            intent?.action == ACTION_STOP -> {
                clearSavedState(applicationContext)
                stopCapture()
                stopSelf()
            }
            // intent == null xảy ra khi hệ thống tự khởi động lại service sau khi bị OS kill
            // (do trả về START_STICKY). Lúc này không còn resultCode/resultData gốc, nên chỉ
            // phục hồi được nếu phiên trước là MODE_MIC (không cần MediaProjection token).
            intent == null -> {
                val p = prefs(applicationContext)
                val wasCapturing = p.getBoolean(KEY_WAS_CAPTURING, false)
                val savedMode = p.getString(KEY_MODE, MODE_SYSTEM) ?: MODE_SYSTEM
                val savedLang = p.getString(KEY_LANG, "en") ?: "en"
                val savedSmartPause = p.getBoolean(KEY_SMART_PAUSE, true)
                val savedCloudStt = p.getBoolean(KEY_CLOUD_STT, false)
                val savedPreferExternalMic = p.getBoolean(KEY_PREFER_EXTERNAL_MIC, false)
                if (wasCapturing && savedMode == MODE_MIC) {
                    startForegroundNotification(MODE_MIC)
                    startMicCapture(savedLang, savedSmartPause, savedCloudStt, savedPreferExternalMic)
                    AudioCapturePlugin.instance?.emitCaptureResumed(MODE_MIC)
                } else {
                    // Phiên SYSTEM không tự phục hồi được - dừng hẳn, để lại cờ cho JS biết
                    // (consumeLostSystemSession) khi user mở lại app.
                    stopSelf()
                }
            }
            else -> {
                val mode = intent.getStringExtra(EXTRA_CAPTURE_MODE) ?: MODE_SYSTEM
                currentMode = mode
                startForegroundNotification(mode)
                val sourceLang = intent.getStringExtra(EXTRA_SOURCE_LANG) ?: "en"
                val smartPause = intent.getBooleanExtra(EXTRA_SMART_PAUSE, true)
                val cloudStt = intent.getBooleanExtra(EXTRA_CLOUD_STT, false)
                val preferExternalMic = intent.getBooleanExtra(EXTRA_PREFER_EXTERNAL_MIC, false)
                if (mode == MODE_MIC) {
                    startMicCapture(sourceLang, smartPause, cloudStt, preferExternalMic)
                } else {
                    val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                    val resultData = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
                    if (resultCode == Activity.RESULT_OK && resultData != null) {
                        startSystemCapture(resultCode, resultData, sourceLang, smartPause, cloudStt)
                    } else {
                        AudioCapturePlugin.instance?.emitError("Thiếu dữ liệu quyền MediaProjection.")
                        stopSelf()
                    }
                }
            }
        }
        // START_STICKY: xin hệ thống khởi động lại service (với intent = null) nếu bị kill
        // giữa chừng do bộ nhớ thấp/OEM diệt app. Xem nhánh intent == null ở trên để biết
        // giới hạn phục hồi (chỉ MODE_MIC phục hồi được tự động).
        return START_STICKY
    }

    // Bắt buộc có notification foreground TRƯỚC khi tạo MediaProjection/AudioRecord, nếu không
    // Android 14+ sẽ ném SecurityException (foregroundServiceType=mediaProjection). Hàm dựng
    // notification: xem CaptureNotification.kt (startForegroundNotification).

    // internal: gọi từ CaptureSourceManager.kt (startSystemCapture/startMicCapture) sau khi
    // đã dựng nguồn thu thành công.
    internal fun saveState(
        mode: String, lang: String, capturing: Boolean, smartPause: Boolean, cloudStt: Boolean,
        preferExternalMic: Boolean = false
    ) {
        prefs(applicationContext).edit()
            .putBoolean(KEY_WAS_CAPTURING, capturing)
            .putString(KEY_MODE, mode)
            .putString(KEY_LANG, lang)
            .putBoolean(KEY_SMART_PAUSE, smartPause)
            .putBoolean(KEY_CLOUD_STT, cloudStt)
            .putBoolean(KEY_PREFER_EXTERNAL_MIC, preferExternalMic)
            .apply()
    }

    // Giữ vô thời hạn (không set timeout) vì phiên dịch live có thể kéo dài vài giờ - nếu
    // set timeout ngắn (vd 30') sẽ tự hết hạn giữa chừng, gây lại đúng vấn đề WakeLock
    // muốn tránh. An toàn vì: mọi nhánh lỗi trong start*Capture() (CaptureSourceManager.kt),
    // stopCapture() (được gọi từ ACTION_STOP, MediaProjection.Callback.onStop, VÀ onDestroy)
    // đều gọi releaseWakeLock(); nếu process bị OS kill hoàn toàn thì WakeLock cũng tự mất
    // theo, không leak vĩnh viễn.
    // internal: gọi từ CaptureSourceManager.kt và SttReadLoop.kt (nhánh lỗi sớm thoát).
    internal fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "AtunTranslator:AudioCaptureWakeLock"
        ).apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    internal fun releaseWakeLock() {
        wakeLock?.let {
            if (it.isHeld) it.release()
        }
        wakeLock = null
    }

    // internal: MediaProjection.Callback.onStop() trong CaptureSourceManager.kt (startSystemCapture)
    // cũng cần gọi hàm này khi hệ thống tự dừng chia sẻ màn hình. CŨNG được gọi từ chính bên
    // TRONG captureThread khi vòng đọc AudioRecord tự bắt lỗi (xem catch trong SttReadLoop.kt) -
    // vì vậy PHẢI tự kiểm tra không tự join() chính mình (Thread.join() gọi bởi chính thread đó
    // không deadlock hẳn - vẫn trả về sau khi hết timeout - nhưng vô nghĩa và tốn 500ms chờ
    // suông mỗi lần, nên bỏ qua hẳn bước join trong trường hợp này).
    internal fun stopCapture() {
        isCapturing = false
        if (Thread.currentThread() !== captureThread) {
            captureThread?.join(500)
        }
        captureThread = null

        audioRecord?.let {
            try { it.stop() } catch (e: Exception) { /* đã stop rồi thì bỏ qua */ }
            it.release()
        }
        audioRecord = null

        sttEngine?.release()
        sttEngine = null

        mediaProjection?.stop()
        mediaProjection = null

        releaseWakeLock()
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }
}
