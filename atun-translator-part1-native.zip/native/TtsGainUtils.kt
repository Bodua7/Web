// Fix (audit Detekt - InvalidPackageDeclaration false-positive): file này nằm phẳng trong
// native/ ở gốc repo, không theo cấu trúc thư mục com/atun/translator/ - CÓ CHỦ ĐÍCH, vì bước
// build-debug (android-build.yml) tự copy file này vào đúng
// android/app/src/main/java/com/atun/translator/ trước khi biên dịch thật (xem step "Copy
// native Kotlin sources"). Detekt ở job validation chạy TRƯỚC bước copy đó (trên native/ phẳng)
// nên luôn báo package không khớp đường dẫn vật lý lúc đó - không phải lỗi thật, khai báo
// package vẫn đúng với vị trí SAU KHI copy (nơi thật sự biên dịch).
@file:Suppress("InvalidPackageDeclaration")

package com.atun.translator

// ===== Tách từ TtsBoostPlugin.kt (theo đúng cách AudioPcmUtils.kt/SttSegmentCutter.kt đã tách) -
// hàm THUẦN JVM (chỉ dùng kotlin.math, không đụng bất kỳ API android.* nào), test được bằng JUnit
// thuần (native-test/TtsGainUtilsTest.kt), không cần Robolectric.
//
// Lý do tồn tại: SpeechSynthesisUtterance.volume của Web Speech API (dùng trong www/app.js
// trước đây) chỉ nhận 0.0-1.0, trình duyệt/WebView tự kẹp về 1.0 nếu đặt cao hơn - không có cách
// nào khuếch đại giọng đọc vượt quá 100% qua đường đó (không có API kiểu
// speechSynthesis.captureStream() để JS lấy audio thật ra chỉnh gain). android.speech.tts.
// TextToSpeech.speak() + Bundle KEY_PARAM_VOLUME cũng bị kẹp y hệt ở 1.0f (giới hạn của chính
// framework Android, không phải do web) - nên khi cần >100%, CÁCH DUY NHẤT là tự tổng hợp ra file
// PCM (TextToSpeech.synthesizeToFile()), tự nhân biên độ từng mẫu lên rồi tự phát qua AudioTrack
// (né hẳn đường tts.speak() mặc định). Đây là kỹ thuật các app "Volume Booster" trên Android hay
// dùng, cùng lý do: âm lượng media/TTS hệ thống bị khoá cứng ở 100%. ===== =====
internal fun applyGainToPcm16(samples: ShortArray, gain: Float): ShortArray {
    val out = ShortArray(samples.size)
    for (i in samples.indices) {
        val amplified = kotlin.math.round(samples[i] * gain).toInt()
        // Clip cứng ở biên [-32768, 32767] - PHẢI clip (không được để tràn số/wrap-around),
        // tràn số tạo tiếng "rè" nghe ghê hơn nhiều so với clip thường (vỡ tiếng êm hơn). Gain
        // càng cao càng dễ nghe thấy vỡ tiếng (distortion) - đây là đánh đổi vật lý không tránh
        // được khi khuếch đại vượt biên độ gốc của mẫu, KHÔNG phải bug của hàm này.
        out[i] = amplified.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
    }
    return out
}
