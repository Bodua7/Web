package com.atun.translator

import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread

// Quản lý TOÀN BỘ model Vosk - tải zip trực tiếp từ URL chính chủ alphacephei.com (xem
// ModelCatalog.CATALOG), giải nén vào filesDir/models/<lang>/, dùng trực tiếp bằng Model(path)
// (xem VoskEngine.resolveModelSource).
//
// File này giờ CHỈ còn đúng phần @PluginMethod (điểm vào gọi từ JS qua Capacitor bridge) +
// theo dõi lượt tải đang chạy (activeDownloads) - 2 phần tách riêng vì lý do khác nhau:
//  - ModelCatalog.kt: catalog/hằng số/hàm tĩnh (CATALOG, readyLangsForAuto, isDownloaded...) -
//    được nơi khác trong code (AudioCaptureService, LidEngine, VoskEngine) gọi trực tiếp,
//    không liên quan gì tới việc là 1 Capacitor Plugin.
//  - ModelDownloader.kt: hàm tải/giải nén thuần (downloadWithRetry/downloadWithProgress/unzip)
//    - chỉ nhận File/String/callback làm tham số, không đụng gì tới PluginCall/context, tách
//    hẳn ra ngoài class Plugin cho gọn.
@CapacitorPlugin(name = "ModelManager")
class ModelManagerPlugin : com.getcapacitor.Plugin() {

    // Theo dõi các lượt tải đang chạy để hỗ trợ cancelDownload() - key = lang.
    // ConcurrentHashMap (không phải mutableMapOf/HashMap thường) vì map này được đọc/ghi từ
    // NHIỀU thread khác nhau không đồng bộ hoá: thread chính (Capacitor bridge, nơi các
    // @PluginMethod chạy) ghi activeDownloads[lang]/kiểm tra containsKey(), còn mỗi thread tải
    // nền tự remove(lang) chính nó trong finally{} khi xong. HashMap thường không đảm bảo an
    // toàn khi nhiều thread ghi đồng thời (có thể corrupt cấu trúc bucket nội bộ, hiếm gặp
    // nhưng có thật khi đủ nhiều lượt tải chồng lấn) - ConcurrentHashMap cho phép đọc/ghi đồng
    // thời an toàn mà không cần tự khoá thủ công quanh mỗi lần truy cập.
    private val activeDownloads = ConcurrentHashMap<String, Thread>()

    @PluginMethod
    fun listModels(call: PluginCall) {
        val arr = JSArray()

        for ((lang, info) in ModelCatalog.CATALOG) {
            val obj = JSObject()
            obj.put("lang", lang)
            obj.put("name", info.displayName)
            obj.put("sizeMB", info.sizeMB)
            obj.put("status", if (ModelCatalog.isDownloaded(context, lang)) "downloaded" else "not_downloaded")
            arr.put(obj)
        }

        val ret = JSObject()
        ret.put("models", arr)
        call.resolve(ret)
    }

    @PluginMethod
    fun downloadModel(call: PluginCall) {
        val lang = call.getString("lang")
        if (lang.isNullOrBlank()) {
            call.reject("Thiếu tham số lang.")
            return
        }
        val info = ModelCatalog.CATALOG[lang]
        if (info == null) {
            call.reject("Không có model cho lang=$lang trong catalog.")
            return
        }
        if (ModelCatalog.isDownloaded(context, lang)) {
            call.resolve(JSObject().apply { put("alreadyDownloaded", true) })
            return
        }
        if (activeDownloads.containsKey(lang)) {
            call.reject("Đang tải model cho lang=$lang rồi, đợi xong hoặc cancelDownload() trước.")
            return
        }

        // Kiểm tra dung lượng trống TRƯỚC khi tải - thiếu dung lượng là nguyên nhân phổ biến
        // gây "Lỗi tải - thử lại" (dù mạng vẫn dùng bình thường cho việc khác) mà RETRY KHÔNG
        // BAO GIỜ tự sửa được (không phải lỗi mạng thoáng qua), khiến vòng lặp downloadWithRetry() cứ chờ
        // backoff rồi thử lại vô ích cả 3 lần x 2 nguồn trước khi báo lỗi (tốn thời gian, và
        // thông báo lỗi cuối cùng thường chỉ là "No space left on device" khó hiểu với user).
        // Cần ~2x sizeMB (zip tải về TẠM + thư mục model giải nén ra, tồn tại song song đến
        // lúc unzip() xong mới xoá zip) + 100MB đệm an toàn.
        val requiredBytes = (info.sizeMB.toLong() * 2 + 100) * 1024 * 1024
        val freeBytes = context.filesDir.usableSpace
        if (freeBytes < requiredBytes) {
            val requiredGB = String.format("%.1f", requiredBytes / 1024.0 / 1024.0 / 1024.0)
            val freeGB = String.format("%.1f", freeBytes / 1024.0 / 1024.0 / 1024.0)
            call.reject("Không đủ dung lượng trống để tải model này (cần khoảng ${requiredGB}GB, máy còn ${freeGB}GB). Hãy giải phóng bớt bộ nhớ rồi thử lại.")
            return
        }

        val targetDir = ModelCatalog.modelDir(context, lang)
        val tmpZip = File(context.cacheDir, "model-$lang-download.zip")

        // Nguồn gốc trước, mirror (nếu có) sau - xem downloadWithRetry() để biết lúc nào
        // chuyển sang thử nguồn tiếp theo.
        val sources = listOfNotNull(info.url, info.mirrorUrl)

        val t = thread(name = "ModelDownload-$lang") {
            try {
                downloadWithRetry(sources, tmpZip) { downloadedBytes, totalBytes ->
                    emitProgress(lang, downloadedBytes, totalBytes)
                }
                unzip(tmpZip, targetDir)
                tmpZip.delete()

                if (!ModelCatalog.isDownloaded(context, lang)) {
                    throw IllegalStateException("Giải nén xong nhưng thư mục model rỗng - zip có thể sai cấu trúc.")
                }

                emitDone(lang, success = true, error = null)
            } catch (e: Exception) {
                // Dọn dẹp thư mục model dở dang (giải nén lỗi giữa chừng) để lần tải sau không
                // bị lẫn dữ liệu hỏng. KHÔNG xoá tmpZip ở đây nữa - downloadWithRetry() đã tự lo
                // giữ/xoá tmpZip tuỳ trường hợp (giữ lại để resume nếu còn khả năng thử lại,
                // xoá nếu đã bỏ cuộc hẳn - xem downloadWithRetry()).
                targetDir.deleteRecursively()
                // InterruptedException không có message hữu ích (từ cancelDownload() gọi
                // Thread.interrupt()) - thay bằng câu tiếng Việt rõ ràng thay vì để UI hiện
                // "LỖI tải model: java.lang.InterruptedException" khó hiểu.
                val errorMsg = if (e is InterruptedException) "Đã huỷ tải theo yêu cầu." else (e.message ?: e.toString())
                emitDone(lang, success = false, error = errorMsg, cancelled = e is InterruptedException)
            } finally {
                activeDownloads.remove(lang)
            }
        }
        activeDownloads[lang] = t

        // resolve ngay - tiến trình tải chạy nền, JS theo dõi qua sự kiện modelDownloadProgress
        // và modelDownloadDone (giống pattern audioLevel/partialText của AudioCapturePlugin).
        call.resolve(JSObject().apply { put("started", true) })
    }

    @PluginMethod
    fun cancelDownload(call: PluginCall) {
        val lang = call.getString("lang")
        val t = activeDownloads[lang]
        if (t != null) {
            t.interrupt()
            // BUG đã sửa: TRƯỚC ĐÂY remove(lang) khỏi activeDownloads NGAY tại đây - nhưng
            // t.interrupt() KHÔNG dừng thread ngay lập tức nếu nó đang block trong socket
            // read() bình thường (Thread.interrupt() không làm read() của luồng dữ liệu I/O
            // chặn thường (blocking plain socket) tự thoát - chỉ đặt cờ interrupted, thread vẫn
            // treo tới khi có dữ liệu/timeout/đóng stream). Với readTimeout=60s, thread cũ có
            // thể còn "sống" tới cả phút sau khi cancelDownload() đã resolve(). Nếu remove
            // khỏi map ngay, downloadModel() gọi lại NGAY SAU ĐÓ (vd user bấm Huỷ rồi bấm Tải
            // lại liền tay) sẽ không còn bị chặn bởi check activeDownloads.containsKey(lang) ở
            // downloadModel() - spawn 1 THREAD MỚI ghi đè CÙNG tmpZip/targetDir trong khi thread
            // cũ vẫn đang chạy dở, gây race ghi file (tải hỏng/lẫn dữ liệu 2 phiên). Giờ để
            // đúng finally{} của thread cũ (xem downloadModel()) tự remove(lang) khi nó THẬT SỰ
            // dừng hẳn - trong lúc đó downloadModel() gọi lại sẽ đúng đắn báo "Đang tải rồi" thay
            // vì âm thầm khởi 1 phiên tải chồng lấn.
        }
        call.resolve()
    }

    @PluginMethod
    fun deleteModel(call: PluginCall) {
        val lang = call.getString("lang")
        if (lang.isNullOrBlank()) {
            call.reject("Thiếu tham số lang.")
            return
        }
        ModelCatalog.modelDir(context, lang).deleteRecursively()
        call.resolve()
    }

    // ===== Model LID (nhận diện ngôn ngữ THẬT bằng đặc trưng âm học, xem LidEngine.kt) =====
    // KHÔNG nằm trong ModelCatalog.CATALOG ở trên - đây không phải 1 "ngôn ngữ" để chọn trong
    // dropdown STT, chỉ là 1 model phụ trợ dùng nội bộ để "phân xử" khi chế độ Tự động nhận
    // diện (nhiều Vosk song song) gặp trường hợp mù mờ. Tách hẳn khỏi CATALOG để
    // listModels()/readyLangsForAuto() không cần thêm logic lọc "_lid" ra khỏi danh sách ngôn
    // ngữ hiển thị cho người dùng.
    //
    // 3 file cần tải riêng lẻ (KHÔNG phải 1 zip - khác cách tải model Vosk): model .onnx +
    // 2 file .json ánh xạ index -> mã ngôn ngữ (dùng lang_dict_95.json ở LidEngine, giữ luôn
    // lang_group_dict_95.json dù hiện chưa dùng tới - đỡ phải tải lại riêng nếu sau này cần
    // đến phân loại theo NHÓM ngôn ngữ). Dùng lại đúng downloadWithRetry()/CONNECT_TIMEOUT_MS
    // đã có cho model Vosk, chỉ khác là ghi thẳng ra file đích, không unzip().
    @PluginMethod
    fun isLidModelDownloaded(call: PluginCall) {
        call.resolve(JSObject().apply { put("downloaded", LidEngine.isDownloaded(context)) })
    }

    @PluginMethod
    fun downloadLidModel(call: PluginCall) {
        val lidKey = "_lid" // dùng chung "lang" trong sự kiện modelDownloadProgress/Done để JS tái dùng đúng 1 kiểu listener
        if (LidEngine.isDownloaded(context)) {
            call.resolve(JSObject().apply { put("alreadyDownloaded", true) })
            return
        }
        if (activeDownloads.containsKey(lidKey)) {
            call.reject("Đang tải model LID rồi, đợi xong hoặc cancelDownload() trước.")
            return
        }

        val requiredBytes = (ModelCatalog.LID_MODEL_SIZE_MB.toLong() * 2 + 50) * 1024 * 1024
        val freeBytes = context.filesDir.usableSpace
        if (freeBytes < requiredBytes) {
            call.reject("Không đủ dung lượng trống để tải model LID (~${ModelCatalog.LID_MODEL_SIZE_MB}MB).")
            return
        }

        val dir = LidEngine.lidDir(context)

        val t = thread(name = "ModelDownload-lid") {
            try {
                dir.mkdirs()
                val onnxDest = File(dir, LidEngine.MODEL_FILE)
                val dictDest = File(dir, LidEngine.LANG_DICT_FILE)
                val groupDictDest = File(dir, "lang_group_dict_95.json")

                // 3 file tải TUẦN TỰ, không song song - progress emit dùng chung 1 sự kiện nên
                // gộp chung tiến độ theo tổng байte cả 3 file phức tạp không cần thiết cho 1
                // model phụ trợ nhỏ (~17MB), báo tiến độ theo TỪNG file là đủ rõ ràng cho UI.
                downloadWithRetry(listOf(ModelCatalog.LID_ONNX_URL), onnxDest) { downloaded, total ->
                    emitProgress(lidKey, downloaded, total)
                }
                downloadWithRetry(listOf(ModelCatalog.LID_LANG_DICT_URL), dictDest) { _, _ -> }
                downloadWithRetry(listOf(ModelCatalog.LID_LANG_GROUP_DICT_URL), groupDictDest) { _, _ -> }

                if (!LidEngine.isDownloaded(context)) {
                    throw IllegalStateException("Tải xong nhưng thiếu file model/lang_dict - kiểm tra lại nguồn tải.")
                }
                emitDone(lidKey, success = true, error = null)
            } catch (e: Exception) {
                dir.deleteRecursively()
                val errorMsg = if (e is InterruptedException) "Đã huỷ tải theo yêu cầu." else (e.message ?: e.toString())
                emitDone(lidKey, success = false, error = errorMsg, cancelled = e is InterruptedException)
            } finally {
                activeDownloads.remove(lidKey)
            }
        }
        activeDownloads[lidKey] = t
        call.resolve(JSObject().apply { put("started", true) })
    }

    @PluginMethod
    fun deleteLidModel(call: PluginCall) {
        LidEngine.lidDir(context).deleteRecursively()
        call.resolve()
    }

    private fun emitProgress(lang: String, downloadedBytes: Long, totalBytes: Long) {
        val data = JSObject()
        data.put("lang", lang)
        data.put("downloadedBytes", downloadedBytes)
        data.put("totalBytes", totalBytes)
        data.put("percent", if (totalBytes > 0) (downloadedBytes * 100 / totalBytes).toInt() else -1)
        notifyListeners("modelDownloadProgress", data)
    }

    private fun emitDone(lang: String, success: Boolean, error: String?, cancelled: Boolean = false) {
        val data = JSObject()
        data.put("lang", lang)
        data.put("success", success)
        if (error != null) data.put("error", error)
        // cancelled: JS dùng để KHÔNG hiện dòng "LỖI tải model..." đỏ trong log (huỷ theo yêu
        // cầu người dùng không phải lỗi thật) - xem plugin_downloadModel() ở www/index.html.
        data.put("cancelled", cancelled)
        notifyListeners("modelDownloadDone", data)
    }
}
