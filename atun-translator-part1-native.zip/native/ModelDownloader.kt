package com.atun.translator

import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

// Tách ra từ ModelManagerPlugin.kt - phần tải + giải nén model, KHÔNG đụng gì tới
// PluginCall/context/notifyListeners (chỉ nhận File/String/callback tiến độ làm tham số), nên
// tách hẳn thành hàm top-level (không phải extension fun của ModelManagerPlugin) cho gọn -
// gọi trực tiếp downloadWithRetry(...)/unzip(...) từ ModelManagerPlugin (cùng package, không
// cần import).

// Bọc downloadWithProgress() bằng vòng lặp thử lại tự động - lỗi mạng thoáng qua (timeout,
// mất kết nối giữa chừng...) không còn bắt người dùng tự bấm "Tải về" lại thủ công từng lần.
// File tải dở (dest) được GIỮ LẠI giữa các lần thử CÙNG 1 NGUỒN (không xoá) để lần thử
// tiếp theo RESUME tiếp từ chỗ dở dang qua HTTP Range, không tải lại từ đầu - quan trọng
// nhất để đỡ tốn băng thông di động khi mạng chập chờn giữa chừng, dù model lớn nhất trong
// catalog hiện tại cũng chỉ ~128MB ("en").
//
// Nhận DANH SÁCH nguồn (urls) thay vì 1 URL cố định: đã ghi nhận thực tế alphacephei.com tự
// nó có lúc đủ chậm/chập chờn để MAX_ATTEMPTS_PER_SOURCE lần thử LIÊN TIẾP CÙNG HOST đó vẫn
// fail hết dù đã tăng timeout rộng rãi - tăng thêm số lần thử trên cùng 1 host không giải
// quyết được nếu bản thân host đang có sự cố. Nên hết lượt thử ở 1 nguồn thì CHUYỂN SANG
// NGUỒN KẾ TIẾP (mirror) trong danh sách thay vì tiếp tục thử nguồn cũ.
fun downloadWithRetry(urls: List<String>, dest: File, onProgress: (Long, Long) -> Unit) {
    var lastError: Exception? = null
    for ((sourceIndex, urlStr) in urls.withIndex()) {
        // Đổi sang nguồn khác (host khác) thì xoá phần tải dở của nguồn TRƯỚC đi - không
        // chắc 2 host phục vụ byte-for-byte giống hệt nhau (thứ tự nén, chunk...), resume
        // qua Range dựa trên phần dở của host khác có rủi ro nối rác vào file.
        if (sourceIndex > 0 && dest.exists()) dest.delete()

        for (attempt in 1..ModelCatalog.MAX_ATTEMPTS_PER_SOURCE) {
            try {
                downloadWithProgress(urlStr, dest, onProgress)
                return // thành công
            } catch (e: InterruptedException) {
                dest.delete() // user chủ động huỷ (cancelDownload) - dọn luôn, không giữ lại để resume
                throw e
            } catch (e: Exception) {
                // Hết dung lượng GIỮA CHỪNG (vd máy vừa đầy thêm do app khác) - lỗi này
                // retry/đổi nguồn không sửa được, dừng ngay thay vì lãng phí hết
                // MAX_ATTEMPTS_PER_SOURCE x số nguồn rồi mới báo lỗi khó hiểu.
                val msg = e.message?.lowercase() ?: ""
                if (e is java.io.IOException && (msg.contains("enospc") || msg.contains("no space left"))) {
                    dest.delete()
                    throw IllegalStateException("Hết dung lượng trống trên máy giữa lúc tải - hãy giải phóng bớt bộ nhớ rồi thử lại.")
                }
                lastError = e
                val isLastAttemptOfSource = attempt == ModelCatalog.MAX_ATTEMPTS_PER_SOURCE
                val isLastSource = sourceIndex == urls.lastIndex
                if (!(isLastAttemptOfSource && isLastSource)) {
                    // Backoff tăng dần: 2s, 5s, 10s - đủ để mạng chập chờn có thời gian ổn
                    // định lại mà không bắt người dùng chờ quá lâu giữa các lần thử.
                    val backoffMs = when (attempt) { 1 -> 2000L; 2 -> 5000L; else -> 10000L }
                    Thread.sleep(backoffMs)
                    // Nếu còn thử tiếp CÙNG nguồn này (chưa isLastAttemptOfSource): KHÔNG
                    // xoá dest - giữ lại phần đã tải để resume. Nếu sắp chuyển nguồn (đã hết
                    // lượt thử của nguồn này nhưng còn nguồn khác): việc xoá dest sẽ được xử
                    // lý ở đầu vòng lặp ngoài (sourceIndex > 0) lúc sang nguồn kế tiếp.
                }
            }
        }
    }
    dest.delete() // hết lượt thử ở MỌI nguồn, dọn file dở dang thật sự bỏ cuộc
    throw lastError ?: IllegalStateException("Tải thất bại không rõ lý do sau khi thử hết ${urls.size} nguồn.")
}

fun downloadWithProgress(urlStr: String, dest: File, onProgress: (Long, Long) -> Unit) {
    // Resume: nếu đã có file tải dở từ lần thử trước (cùng phiên downloadModel(), xem
    // downloadWithRetry()), tiếp tục từ đúng byte đã có bằng header Range - không tải lại
    // từ đầu. Server tĩnh như alphacephei.com/GitHub Releases đều hỗ trợ Range mặc định.
    val alreadyHave = if (dest.exists()) dest.length() else 0L

    val url = URL(urlStr)
    val conn = url.openConnection() as HttpURLConnection
    conn.connectTimeout = ModelCatalog.CONNECT_TIMEOUT_MS
    conn.readTimeout = ModelCatalog.READ_TIMEOUT_MS
    conn.instanceFollowRedirects = true // GitHub Releases redirect sang S3 - bắt buộc phải theo
    if (alreadyHave > 0) {
        conn.setRequestProperty("Range", "bytes=$alreadyHave-")
    }
    conn.connect()

    val isResuming = alreadyHave > 0 && conn.responseCode == 206
    if (conn.responseCode !in 200..299) {
        throw IllegalStateException("HTTP ${conn.responseCode} khi tải model từ $urlStr")
    }
    // Server không hỗ trợ Range (trả 200 thay vì 206 dù mình có gửi Range) -> nó sẽ gửi lại
    // TOÀN BỘ file từ đầu, nên phải bỏ phần cũ đi để không bị nối rác vào đầu file.
    if (alreadyHave > 0 && !isResuming) {
        dest.delete()
    }

    // totalBytes phải cộng lại phần đã có sẵn khi đang resume, vì Content-Length lúc này
    // chỉ tính phần CÒN LẠI server trả về (theo đúng ngữ nghĩa response 206 Partial Content).
    val remainingBytes = conn.contentLengthLong
    val totalBytes = if (isResuming && remainingBytes > 0) alreadyHave + remainingBytes else remainingBytes
    var downloadedBytes = if (isResuming) alreadyHave else 0L
    var lastEmitAt = 0L

    conn.inputStream.use { input ->
        FileOutputStream(dest, isResuming).use { output -> // append=true khi đang resume
            val buffer = ByteArray(64 * 1024)
            while (true) {
                if (Thread.currentThread().isInterrupted) throw InterruptedException("Đã huỷ tải model.")
                val read = input.read(buffer)
                if (read == -1) break
                output.write(buffer, 0, read)
                downloadedBytes += read

                val now = System.currentTimeMillis()
                if (now - lastEmitAt >= 300) { // throttle ~3 lần/giây, tránh spam bridge JS
                    onProgress(downloadedBytes, totalBytes)
                    lastEmitAt = now
                }
            }
        }
    }
    onProgress(downloadedBytes, totalBytes)
}

fun unzip(zipFile: File, targetDir: File) {
    targetDir.deleteRecursively()
    targetDir.mkdirs()

    // Zip gốc tải thẳng từ alphacephei.com bọc mọi thứ trong 1 thư mục cha (vd
    // "vosk-model-en-us-0.22/"), trong khi zip mình tự đóng gói lại (model-vi/ja/ko) thì
    // phẳng, không bọc. Tự phát hiện + bóc lớp đó ra khi giải nén, để catalog dùng được
    // CẢ 2 kiểu zip mà không cần re-zip thủ công từng model.
    val commonPrefix = detectCommonRootPrefix(zipFile)

    ZipInputStream(zipFile.inputStream()).use { zis ->
        var entry: ZipEntry? = zis.nextEntry
        val buffer = ByteArray(64 * 1024)
        while (entry != null) {
            val relativeName = if (commonPrefix != null && entry.name.startsWith(commonPrefix)) {
                entry.name.substring(commonPrefix.length)
            } else {
                entry.name
            }
            if (relativeName.isEmpty()) {
                zis.closeEntry()
                entry = zis.nextEntry
                continue
            }

            // Chặn path traversal (zip slip) - phòng trường hợp zip nguồn bị chỉnh sửa độc hại.
            val outFile = File(targetDir, relativeName)
            if (!outFile.canonicalPath.startsWith(targetDir.canonicalPath + File.separator)) {
                throw SecurityException("Zip entry bất thường: ${entry.name}")
            }
            if (entry.isDirectory) {
                outFile.mkdirs()
            } else {
                outFile.parentFile?.mkdirs()
                FileOutputStream(outFile).use { out ->
                    var read = zis.read(buffer)
                    while (read != -1) {
                        out.write(buffer, 0, read)
                        read = zis.read(buffer)
                    }
                }
            }
            zis.closeEntry()
            entry = zis.nextEntry
        }
    }
}

// Đọc qua danh sách tên entry (không giải nén) để tìm xem toàn bộ zip có nằm chung trong
// đúng 1 thư mục cha hay không. Đọc file zip 2 lần (lần này + lần unzip thật) chấp nhận
// được vì đây là file cục bộ đã tải xong, không phải đọc lại qua mạng.
private fun detectCommonRootPrefix(zipFile: File): String? {
    val topLevelDirs = mutableSetOf<String>()
    var hasRootLevelEntry = false
    ZipInputStream(zipFile.inputStream()).use { zis ->
        var entry: ZipEntry? = zis.nextEntry
        while (entry != null) {
            val name = entry.name.trimStart('/')
            val slashIdx = name.indexOf('/')
            if (slashIdx <= 0) {
                if (name.isNotEmpty()) hasRootLevelEntry = true
            } else {
                topLevelDirs.add(name.substring(0, slashIdx))
            }
            zis.closeEntry()
            entry = zis.nextEntry
        }
    }
    return if (!hasRootLevelEntry && topLevelDirs.size == 1) topLevelDirs.first() + "/" else null
}
