package com.atun.translator

// ===== Tách từ SttReadLoop.kt (đợt audit thêm test JUnit) =====
// 2 hàm dưới đây vốn đã THUẦN JVM (chỉ dùng java.nio/Charsets, không đụng bất kỳ API
// android.* nào) nhưng trước đây khai "private" ngay trong SttReadLoop.kt nên file test khác
// không gọi được. Chuyển ra file riêng + đổi "private" -> "internal" để native-test/
// AudioPcmUtilsTest.kt gọi thẳng được bằng JUnit thuần, không cần Robolectric (không có gì ở
// đây đụng tới Android framework thật để cần giả lập).
// Hành vi giữ NGUYÊN 100% so với bản gốc trong SttReadLoop.kt - chỉ đổi chỗ ở + độ hiển thị.

// PCM16 mono, little-endian - đúng thứ tự byte chuẩn của WAV/hầu hết API STT (kể cả Whisper).
internal fun shortsToBytesLE(samples: ShortArray, len: Int): ByteArray {
    val bb = java.nio.ByteBuffer.allocate(len * 2).order(java.nio.ByteOrder.LITTLE_ENDIAN)
    for (i in 0 until len) bb.putShort(samples[i])
    return bb.array()
}

// Đóng gói PCM16 mono thô thành file WAV hoàn chỉnh (header 44 byte chuẩn) - Whisper API
// (qua groq-relay) nhận file audio thật (có header), không nhận PCM thô.
internal fun buildWavFile(pcm: ByteArray, sampleRate: Int): ByteArray {
    val header = java.nio.ByteBuffer.allocate(44).order(java.nio.ByteOrder.LITTLE_ENDIAN)
    val byteRate = sampleRate * 2 // 16-bit mono: 2 byte/mẫu
    header.put("RIFF".toByteArray(Charsets.US_ASCII))
    header.putInt(36 + pcm.size)
    header.put("WAVE".toByteArray(Charsets.US_ASCII))
    header.put("fmt ".toByteArray(Charsets.US_ASCII))
    header.putInt(16) // Subchunk1Size cho PCM
    header.putShort(1) // AudioFormat = 1 (PCM)
    header.putShort(1) // NumChannels = 1 (mono)
    header.putInt(sampleRate)
    header.putInt(byteRate)
    header.putShort(2) // BlockAlign = NumChannels * BitsPerSample/8
    header.putShort(16) // BitsPerSample
    header.put("data".toByteArray(Charsets.US_ASCII))
    header.putInt(pcm.size)
    return header.array() + pcm
}
