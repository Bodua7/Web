package com.atun.translator

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.PowerManager
import com.getcapacitor.JSObject
import com.getcapacitor.PermissionState
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.ActivityCallback
import com.getcapacitor.annotation.CapacitorPlugin
import com.getcapacitor.annotation.Permission
import com.getcapacitor.annotation.PermissionCallback

// Cầu nối JS <-> AudioCaptureService.
// JS gọi requestCapture({ sourceLang, captureMode }) với captureMode = "system" | "mic":
// - "system": bật dialog hệ thống xin quyền MediaProjection (bắt audio phát ra từ app khác).
// - "mic": xin quyền RECORD_AUDIO (permission thường), ghi âm qua micro máy (nghe qua loa ngoài).
// Cả 2 đường đều start AudioCaptureService, native chỉ lo capture + cắt câu bằng VAD rồi bắn sự
// kiện "cloudSttSegment"/"captureError" - JS tự lo phần upload đoạn audio lên Whisper Cloud
// (qua groq-relay) và dịch.
@CapacitorPlugin(
    name = "AudioCapture",
    permissions = [
        Permission(strings = [Manifest.permission.RECORD_AUDIO], alias = "microphone"),
        Permission(strings = [Manifest.permission.POST_NOTIFICATIONS], alias = "notifications")
    ]
)
class AudioCapturePlugin : com.getcapacitor.Plugin() {

    companion object {
        // Service gọi các hàm này để đẩy kết quả STT lên JS.
        // Dùng weak-ish singleton đơn giản vì chỉ có 1 instance plugin sống theo Activity.
        var instance: AudioCapturePlugin? = null
    }

    // Lưu tạm giữa requestCapture() và callback xảy ra sau (dialog hệ thống HOẶC xin quyền
    // micro trả kết quả về sau) - PluginCall gốc không giữ field custom qua các bước này.
    private var pendingSourceLang: String = "en"
    // Nhớ lại captureMode đã yêu cầu qua requestCapture() để dùng lại ở các callback xảy ra SAU
    // (handleMicPermissionResult, handleProjectionResult) - PluginCall gốc không giữ field
    // custom qua các bước này (giống pendingSourceLang).
    private var pendingCaptureMode: String = AudioCaptureService.MODE_SYSTEM
    // true = khi captureMode="mic", cố định route sang micro NGOÀI đang kết nối (nếu có) thay vì
    // micro trong máy - xem AudioCaptureService.selectMicInputDevice(). Không có tác dụng gì với
    // captureMode="system" (không dùng AudioRecord thu qua micro).
    private var pendingPreferExternalMic: Boolean = false

    override fun load() {
        super.load()
        instance = this
    }

    // Dọn singleton tĩnh khi Activity/Bridge bị huỷ - nếu không, "instance" giữ tham chiếu tới
    // plugin instance CŨ (gắn với Activity/Bridge cũ) sau khi Android tái tạo Activity (xoay máy
    // không được configChanges che hết, hoặc process hồi sinh) -> mọi sự kiện service bắn lên
    // qua AudioCapturePlugin.instance?.xxx() sau đó gọi vào 1 instance không còn gắn với bridge
    // JS đang sống, JS không nhận được gì mà cũng không có lỗi nào báo ra để biết vì sao.
    override fun handleOnDestroy() {
        super.handleOnDestroy()
        if (instance === this) {
            instance = null
        }
    }

    @PluginMethod
    fun requestCapture(call: PluginCall) {
        pendingSourceLang = call.getString("sourceLang", "en") ?: "en"
        pendingPreferExternalMic = call.getBoolean("preferExternalMic", false) ?: false
        val mode = call.getString("captureMode", AudioCaptureService.MODE_SYSTEM)
            ?: AudioCaptureService.MODE_SYSTEM
        pendingCaptureMode = mode

        if (mode == AudioCaptureService.MODE_MIC) {
            if (getPermissionState("microphone") == PermissionState.GRANTED) {
                startMicCaptureService(call)
            } else {
                saveCall(call)
                requestPermissionForAlias("microphone", call, "handleMicPermissionResult")
            }
            return
        }

        // MODE_MIXED cần CẢ 2 quyền: xin RECORD_AUDIO trước (permission thường, xin nhanh),
        // rồi mới tới dialog hệ thống MediaProjection (nặng hơn, phải hiện UI riêng) - xin theo
        // thứ tự "nhẹ trước, nặng sau" để nếu user từ chối mic thì không phải tự dọn dẹp 1
        // MediaProjection token đã xin dở dang. handleMicPermissionResult sẽ tự đi tiếp sang
        // requestSystemCapture() khi pendingCaptureMode == MODE_MIXED (xem hàm đó bên dưới).
        if (mode == AudioCaptureService.MODE_MIXED && getPermissionState("microphone") != PermissionState.GRANTED) {
            saveCall(call)
            requestPermissionForAlias("microphone", call, "handleMicPermissionResult")
            return
        }

        requestSystemCapture(call)
    }

    private fun requestSystemCapture(call: PluginCall) {
        val projectionManager =
            context.getSystemService(android.content.Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        // Android 14+ mặc định hiện dialog cho user chọn "Toàn màn hình" hay "Một app".
        // Nếu chọn "Một app" (vd. chọn nhầm app khác, hoặc chọn chính app này), MediaProjection
        // bị giới hạn phạm vi (app-scoped) -> AudioPlaybackCaptureConfiguration dựng từ projection
        // đó CHỈ bắt được audio của app đã chọn, không bắt audio hệ thống/app khác (vd. YouTube).
        // build() vẫn thành công, không throw exception - chỉ đọc ra toàn silence (peak=0).
        // Ép chỉ cho chọn "toàn màn hình" để tránh đúng lỗi này.
        val intent = if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            projectionManager.createScreenCaptureIntent(
                android.media.projection.MediaProjectionConfig.createConfigForDefaultDisplay()
            )
        } else {
            projectionManager.createScreenCaptureIntent()
        }
        saveCall(call)
        startActivityForResult(call, intent, "handleProjectionResult")
    }

    @ActivityCallback
    private fun handleProjectionResult(call: PluginCall?, result: androidx.activity.result.ActivityResult) {
        if (call == null) return

        if (result.resultCode != Activity.RESULT_OK || result.data == null) {
            call.reject("Người dùng từ chối quyền chia sẻ/ghi âm màn hình (bắt buộc để bắt audio hệ thống).")
            return
        }

        val serviceIntent = Intent(context, AudioCaptureService::class.java).apply {
            action = AudioCaptureService.ACTION_START
            // pendingCaptureMode: luôn là MODE_SYSTEM (dialog này chỉ được gọi từ
            // requestSystemCapture()).
            putExtra(AudioCaptureService.EXTRA_CAPTURE_MODE, pendingCaptureMode)
            putExtra(AudioCaptureService.EXTRA_RESULT_CODE, result.resultCode)
            putExtra(AudioCaptureService.EXTRA_RESULT_DATA, result.data)
            putExtra(AudioCaptureService.EXTRA_SOURCE_LANG, pendingSourceLang)
            // Trước đây bỏ sót extra này (không cần vì MODE_SYSTEM đơn không dùng tới) - giờ
            // MODE_MIXED cần để route luồng mic đúng theo checkbox "Ưu tiên micro ngoài".
            // Vô hại với MODE_SYSTEM đơn (native chỉ đọc extra này ở nhánh MODE_MIC/MODE_MIXED).
            putExtra(AudioCaptureService.EXTRA_PREFER_EXTERNAL_MIC, pendingPreferExternalMic)
        }
        androidx.core.content.ContextCompat.startForegroundService(context, serviceIntent)

        val ret = JSObject()
        ret.put("started", true)
        call.resolve(ret)
    }

    @PermissionCallback
    private fun handleMicPermissionResult(call: PluginCall) {
        if (getPermissionState("microphone") != PermissionState.GRANTED) {
            val reason = if (pendingCaptureMode == AudioCaptureService.MODE_MIXED)
                "Người dùng từ chối quyền micro (bắt buộc cho chế độ hội thoại 2 chiều)."
            else "Người dùng từ chối quyền micro (bắt buộc để nghe qua micro)."
            call.reject(reason)
            return
        }
        // pendingCaptureMode được set từ requestCapture() trước khi gọi hàm này (giữ nguyên qua
        // bước xin quyền, PluginCall gốc không giữ field custom - xem ghi chú pendingCaptureMode).
        if (pendingCaptureMode == AudioCaptureService.MODE_MIXED) {
            requestSystemCapture(call)
        } else {
            startMicCaptureService(call)
        }
    }

    private fun startMicCaptureService(call: PluginCall) {
        val serviceIntent = Intent(context, AudioCaptureService::class.java).apply {
            action = AudioCaptureService.ACTION_START
            putExtra(AudioCaptureService.EXTRA_CAPTURE_MODE, AudioCaptureService.MODE_MIC)
            putExtra(AudioCaptureService.EXTRA_SOURCE_LANG, pendingSourceLang)
            putExtra(AudioCaptureService.EXTRA_PREFER_EXTERNAL_MIC, pendingPreferExternalMic)
        }
        androidx.core.content.ContextCompat.startForegroundService(context, serviceIntent)

        val ret = JSObject()
        ret.put("started", true)
        call.resolve(ret)
    }

    // Cho JS xem TRƯỚC (không cần đang capture) máy hiện có phát hiện micro ngoài nào đang cắm/
    // kết nối không - dùng để hiện dòng trạng thái cạnh checkbox "Ưu tiên micro ngoài" trong
    // Cài đặt nghe/dịch (vd "Đã phát hiện: Tai nghe USB ...") trước khi user bấm "Bắt đầu nghe".
    // Chỉ liệt kê, KHÔNG tự chọn/route gì - việc chọn thật sự xảy ra lúc AudioCaptureService bắt
    // đầu ghi (xem AudioCaptureService.selectMicInputDevice()).
    @PluginMethod
    fun listInputDevices(call: PluginCall) {
        val devices = AudioInputDevices.listExternalInputDevices(context)
        val arr = com.getcapacitor.JSArray()
        for (d in devices) {
            val obj = JSObject()
            obj.put("type", d.type)
            obj.put("label", AudioInputDevices.describeInputDevice(d))
            arr.put(obj)
        }
        val ret = JSObject()
        ret.put("devices", arr)
        call.resolve(ret)
    }

    @PluginMethod
    fun stopCapture(call: PluginCall) {
        AudioCaptureService.clearSavedState(context)
        val serviceIntent = Intent(context, AudioCaptureService::class.java).apply {
            action = AudioCaptureService.ACTION_STOP
        }
        context.startService(serviceIntent)
        call.resolve()
    }

    // Gọi từ JS khi app mở lại (vd. onResume), để biết phiên "system" trước đó có bị hệ thống
    // âm thầm dừng giữa chừng không (bị OS kill, không tự phục hồi được vì token MediaProjection
    // dùng 1 lần) - nhờ đó UI có thể báo cho user biết thay vì im lặng không hiểu vì sao mất phụ đề.
    @PluginMethod
    fun checkLostSession(call: PluginCall) {
        val lost = AudioCaptureService.consumeLostSystemSession(context)
        if (lost) {
            AudioCaptureService.clearSavedState(context)
        }
        val ret = JSObject()
        ret.put("lostSystemSession", lost)
        call.resolve(ret)
    }

    // ===== Quyền thông báo (Android 13+/TIRAMISU bắt buộc xin runtime, trước đó luôn granted) =====
    // Tách riêng khỏi luồng overlay/mic vì thuộc bước onboarding khác - JS gọi tuần tự:
    // overlay permission -> notification permission -> sẵn sàng bắt đầu nghe.

    @PluginMethod
    fun checkNotificationPermission(call: PluginCall) {
        val granted = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            getPermissionState("notifications") == PermissionState.GRANTED
        val ret = JSObject()
        ret.put("granted", granted)
        call.resolve(ret)
    }

    @PluginMethod
    fun requestNotificationPermission(call: PluginCall) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            val ret = JSObject()
            ret.put("granted", true)
            call.resolve(ret)
            return
        }
        if (getPermissionState("notifications") == PermissionState.GRANTED) {
            val ret = JSObject()
            ret.put("granted", true)
            call.resolve(ret)
        } else {
            saveCall(call)
            requestPermissionForAlias("notifications", call, "handleNotificationPermissionResult")
        }
    }

    @PermissionCallback
    private fun handleNotificationPermissionResult(call: PluginCall) {
        val granted = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            getPermissionState("notifications") == PermissionState.GRANTED
        val ret = JSObject()
        ret.put("granted", granted)
        call.resolve(ret)
    }

    // ===== Miễn trừ tối ưu pin (Ignore Battery Optimizations) =====
    // Nhiều OEM (Xiaomi/Oppo/Vivo/Samsung...) tự kill service chạy nền sau vài phút nếu app
    // không nằm trong danh sách miễn trừ Doze/App Standby, dù đã có foreground service +
    // notification đúng chuẩn. Xin miễn trừ này giúp phiên nghe dài (vài giờ) ổn định hơn
    // nhiều. Đây là dialog hệ thống đặc biệt (không phải runtime permission thường), phải mở
    // qua Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS.

    @PluginMethod
    fun checkBatteryOptimization(call: PluginCall) {
        val pm = context.getSystemService(android.content.Context.POWER_SERVICE) as PowerManager
        val ignoring = Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
            pm.isIgnoringBatteryOptimizations(context.packageName)
        val ret = JSObject()
        ret.put("ignoringOptimizations", ignoring)
        call.resolve(ret)
    }

    @PluginMethod
    fun requestIgnoreBatteryOptimizations(call: PluginCall) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            val ret = JSObject()
            ret.put("ignoringOptimizations", true)
            call.resolve(ret)
            return
        }
        val intent = Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
            data = android.net.Uri.parse("package:" + context.packageName)
        }
        saveCall(call)
        startActivityForResult(call, intent, "handleBatteryOptimizationResult")
    }

    @ActivityCallback
    private fun handleBatteryOptimizationResult(call: PluginCall?, result: androidx.activity.result.ActivityResult) {
        if (call == null) return
        // Dialog này không trả resultCode đáng tin cậy (tuỳ OEM/phiên bản Android) - luôn
        // đọc lại trạng thái thật qua PowerManager thay vì tin resultCode == RESULT_OK.
        val pm = context.getSystemService(android.content.Context.POWER_SERVICE) as PowerManager
        val ignoring = pm.isIgnoringBatteryOptimizations(context.packageName)
        val ret = JSObject()
        ret.put("ignoringOptimizations", ignoring)
        call.resolve(ret)
    }

    // ===== Gọi bởi AudioCaptureService (chạy trên thread nền -> phải post lên JS an toàn) =====

    // code: định danh máy-đọc-được cho JS phân loại lỗi (vd để tự động fallback), khác với
    // message vốn là câu tiếng Việt dành cho người đọc. null = lỗi chung chung, không có
    // hành động tự động nào tương ứng phía JS.
    // "SYSTEM_CAPTURE_BLOCKED": build AudioRecord thất bại rõ ràng (UnsupportedOperationException
    // hoặc state != INITIALIZED) khi ở MODE_SYSTEM - dấu hiệu chắc chắn app nguồn/thiết bị chặn
    // playback capture, JS có thể tự động chuyển sang MODE_MIC mà không sợ nhầm với im lặng thật.
    fun emitError(message: String, code: String? = null) {
        val data = JSObject()
        data.put("message", message)
        if (code != null) data.put("code", code)
        notifyListeners("captureError", data)
    }

    // Không có model local nào để tải với Cloud STT - luôn bắn ready=true ngay khi bắt đầu
    // capture, để JS ẩn luôn trạng thái "đang tải model" (xem onModelStatus trong www/index.html).
    fun emitModelLoading(ready: Boolean) {
        val data = JSObject()
        data.put("ready", ready)
        notifyListeners("modelStatus", data)
    }

    // Bắn khi service tự khởi động lại và phục hồi capture thành công sau khi bị OS kill
    // (chỉ xảy ra với MODE_MIC - xem AudioCaptureService.onStartCommand).
    fun emitCaptureResumed(mode: String) {
        val data = JSObject()
        data.put("mode", mode)
        notifyListeners("captureResumed", data)
    }

    // Bắn ngay sau khi MODE_MIC thật sự chọn xong thiết bị thu (usedExternal=true nếu route
    // thành công sang micro ngoài, false nếu dùng micro trong máy dù user có tick "ưu tiên
    // ngoài" hay không - xem AudioCaptureService.selectMicInputDevice()). label là chuỗi tiếng
    // Việt để hiện thẳng lên UI, không cần JS tự dịch type số.
    fun emitMicDeviceInfo(usedExternal: Boolean, label: String) {
        val data = JSObject()
        data.put("usedExternal", usedExternal)
        data.put("label", label)
        notifyListeners("micDeviceInfo", data)
    }

    // Cloud STT (Whisper qua groq-relay?op=transcribe) - xem AudioCaptureService.
    // startCloudSttReadLoop(). wavBase64 là 1 đoạn audio PCM16 mono 16kHz đã đóng gói WAV, cắt
    // theo câu bằng VAD (không cần model STT tải sẵn). Native chỉ lo capture/cắt đoạn - JS tự lo
    // phần mạng (upload lên groq-relay, giữ API key phía server) và tự đẩy text nhận được vào
    // pipeline dịch/hiển thị.
    // channel: "mic" | "system" - CHỈ có ý nghĩa phân biệt khi ở MODE_MIXED (2 luồng song song).
    // Ở MODE_MIC/MODE_SYSTEM đơn, channel trùng với mode hiện tại như trước đây (JS có thể bỏ
    // qua field này nếu không cần, giữ optional/null-checked để không phá code cũ nào đọc thiếu).
    // likelyMusic (phương án "nhận giọng ca sĩ khi hát"): true nếu đoạn này bị cắt sau ÍT NHẤT
    // CONTINUOUS_MUSIC_HINT_THRESHOLD lần liên tiếp chạm trần thời lượng mà KHÔNG hề có khoảng
    // lặng tự nhiên nào xen giữa - dấu hiệu audio hiện tại là nhạc/bài hát liên tục hơn là lời
    // nói bình thường (xem SttSegmentCutter.isLikelyContinuousMusic()). Native chỉ BÁO CÁO, JS
    // tự quyết định có gọi Whisper cho đoạn này hay không - xem onCloudSttSegment trong
    // app.module.js.
    fun emitCloudSttSegment(wavBase64: String, sourceLang: String, channel: String? = null, likelyMusic: Boolean = false) {
        val data = JSObject()
        data.put("wavBase64", wavBase64)
        data.put("sourceLang", sourceLang)
        if (channel != null) data.put("channel", channel)
        data.put("likelyMusic", likelyMusic)
        notifyListeners("cloudSttSegment", data)
    }

    // Bắn ĐÚNG 1 LẦN mỗi khi bộ đếm bên native vừa CHẠM ngưỡng "nghe giống nhạc liên tục" (xem
    // SttSegmentCutter.justCrossedContinuousMusicHint()) - JS dùng để hiện banner cảnh báo 1 lần
    // cho mỗi "đợt nhạc" (không lặp lại mỗi 12s), KHÔNG mang ý nghĩa "hãy dừng dịch ngay" - việc
    // có dịch tiếp đoạn nào hay không đã tự động nằm trong field likelyMusic của MỖI sự kiện
    // cloudSttSegment (xem emitCloudSttSegment ở trên), sự kiện này chỉ để cập nhật UI.
    fun emitPossibleMusicDetected(channel: String? = null) {
        val data = JSObject()
        if (channel != null) data.put("channel", channel)
        notifyListeners("possibleMusicDetected", data)
    }

    // Đo mức tín hiệu audio thực tế đọc được từ AudioRecord, bắn lên JS mỗi ~1s.
    // Dùng để phân biệt "capture chạy nhưng audio là silence" (peak ~ 0 liên tục) với
    // "capture không chạy" hay "không nhận diện được dù có audio thật".
    // channel: luôn là currentMode ("mic" hoặc "system") - xem AudioCaptureService.
    fun emitAudioLevel(peak: Int, readCalls: Int, silentReads: Int, badReads: Int, channel: String? = null) {
        val data = JSObject()
        data.put("peak", peak) // 0..32767, PCM16 mono
        data.put("readCalls", readCalls)
        data.put("silentReads", silentReads)
        data.put("badReads", badReads)
        if (channel != null) data.put("channel", channel)
        notifyListeners("audioLevel", data)
    }
}
