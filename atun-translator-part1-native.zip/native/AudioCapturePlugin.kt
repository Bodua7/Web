package com.atun.translator

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.PowerManager
import com.getcapacitor.JSObject
import com.getcapacitor.PermissionState
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.ActivityCallback
import com.getcapacitor.annotation.CapacitorPlugin
import com.getcapacitor.annotation.Permission
import com.getcapacitor.annotation.PermissionCallback

// Cầu nối JS <-> AudioCaptureService.
// JS gọi requestCapture({ sourceLang, captureMode }) với captureMode = "system" | "mic":
// - "system": bật dialog hệ thống xin quyền MediaProjection (bắt audio phát ra từ app khác).
// - "mic": xin quyền RECORD_AUDIO (permission thường), ghi âm qua micro máy (nghe qua loa ngoài).
// Cả 2 đường đều start AudioCaptureService và trả về sự kiện "partialText"/"finalText"/
// "captureError" mỗi khi Vosk nhận diện được câu nói.
@CapacitorPlugin(
    name = "AudioCapture",
    permissions = [
        Permission(strings = [Manifest.permission.RECORD_AUDIO], alias = "microphone"),
        Permission(strings = [Manifest.permission.POST_NOTIFICATIONS], alias = "notifications")
    ]
)
class AudioCapturePlugin : com.getcapacitor.Plugin() {

    companion object {
        // Service gọi các hàm này để đẩy kết quả STT lên JS.
        // Dùng weak-ish singleton đơn giản vì chỉ có 1 instance plugin sống theo Activity.
        var instance: AudioCapturePlugin? = null
    }

    // Lưu tạm giữa requestCapture() và callback xảy ra sau (dialog hệ thống HOẶC xin quyền
    // micro trả kết quả về sau) - PluginCall gốc không giữ field custom qua các bước này.
    private var pendingSourceLang: String = "en"
    private var pendingSmartPause: Boolean = true
    // true = bỏ qua Vosk hoàn toàn, dùng Whisper Cloud (Groq) qua groq-relay - xem
    // AudioCaptureService.startCloudSttReadLoop() và ghi chú cloudSttEl trong www/index.html.
    private var pendingCloudStt: Boolean = false

    override fun load() {
        super.load()
        instance = this
    }

    @PluginMethod
    fun requestCapture(call: PluginCall) {
        pendingSourceLang = call.getString("sourceLang", "en") ?: "en"
        pendingSmartPause = call.getBoolean("smartPause", true) ?: true
        pendingCloudStt = call.getBoolean("cloudStt", false) ?: false
        val mode = call.getString("captureMode", AudioCaptureService.MODE_SYSTEM)
            ?: AudioCaptureService.MODE_SYSTEM

        if (mode == AudioCaptureService.MODE_MIC) {
            if (getPermissionState("microphone") == PermissionState.GRANTED) {
                startMicCaptureService(call)
            } else {
                saveCall(call)
                requestPermissionForAlias("microphone", call, "handleMicPermissionResult")
            }
            return
        }

        requestSystemCapture(call)
    }

    private fun requestSystemCapture(call: PluginCall) {
        val projectionManager =
            context.getSystemService(android.content.Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        // Android 14+ mặc định hiện dialog cho user chọn "Toàn màn hình" hay "Một app".
        // Nếu chọn "Một app" (vd. chọn nhầm app khác, hoặc chọn chính app này), MediaProjection
        // bị giới hạn phạm vi (app-scoped) -> AudioPlaybackCaptureConfiguration dựng từ projection
        // đó CHỈ bắt được audio của app đã chọn, không bắt audio hệ thống/app khác (vd. YouTube).
        // build() vẫn thành công, không throw exception - chỉ đọc ra toàn silence (peak=0).
        // Ép chỉ cho chọn "toàn màn hình" để tránh đúng lỗi này.
        val intent = if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            projectionManager.createScreenCaptureIntent(
                android.media.projection.MediaProjectionConfig.createConfigForDefaultDisplay()
            )
        } else {
            projectionManager.createScreenCaptureIntent()
        }
        saveCall(call)
        startActivityForResult(call, intent, "handleProjectionResult")
    }

    @ActivityCallback
    private fun handleProjectionResult(call: PluginCall?, result: androidx.activity.result.ActivityResult) {
        if (call == null) return

        if (result.resultCode != Activity.RESULT_OK || result.data == null) {
            call.reject("Người dùng từ chối quyền chia sẻ/ghi âm màn hình (bắt buộc để bắt audio hệ thống).")
            return
        }

        val serviceIntent = Intent(context, AudioCaptureService::class.java).apply {
            action = AudioCaptureService.ACTION_START
            putExtra(AudioCaptureService.EXTRA_CAPTURE_MODE, AudioCaptureService.MODE_SYSTEM)
            putExtra(AudioCaptureService.EXTRA_RESULT_CODE, result.resultCode)
            putExtra(AudioCaptureService.EXTRA_RESULT_DATA, result.data)
            putExtra(AudioCaptureService.EXTRA_SOURCE_LANG, pendingSourceLang)
            putExtra(AudioCaptureService.EXTRA_SMART_PAUSE, pendingSmartPause)
            putExtra(AudioCaptureService.EXTRA_CLOUD_STT, pendingCloudStt)
        }
        androidx.core.content.ContextCompat.startForegroundService(context, serviceIntent)

        val ret = JSObject()
        ret.put("started", true)
        call.resolve(ret)
    }

    @PermissionCallback
    private fun handleMicPermissionResult(call: PluginCall) {
        if (getPermissionState("microphone") == PermissionState.GRANTED) {
            startMicCaptureService(call)
        } else {
            call.reject("Người dùng từ chối quyền micro (bắt buộc để nghe qua micro).")
        }
    }

    private fun startMicCaptureService(call: PluginCall) {
        val serviceIntent = Intent(context, AudioCaptureService::class.java).apply {
            action = AudioCaptureService.ACTION_START
            putExtra(AudioCaptureService.EXTRA_CAPTURE_MODE, AudioCaptureService.MODE_MIC)
            putExtra(AudioCaptureService.EXTRA_SOURCE_LANG, pendingSourceLang)
            putExtra(AudioCaptureService.EXTRA_SMART_PAUSE, pendingSmartPause)
            putExtra(AudioCaptureService.EXTRA_CLOUD_STT, pendingCloudStt)
        }
        androidx.core.content.ContextCompat.startForegroundService(context, serviceIntent)

        val ret = JSObject()
        ret.put("started", true)
        call.resolve(ret)
    }

    @PluginMethod
    fun stopCapture(call: PluginCall) {
        AudioCaptureService.clearSavedState(context)
        val serviceIntent = Intent(context, AudioCaptureService::class.java).apply {
            action = AudioCaptureService.ACTION_STOP
        }
        context.startService(serviceIntent)
        call.resolve()
    }

    // Gọi từ JS khi app mở lại (vd. onResume), để biết phiên "system" trước đó có bị hệ thống
    // âm thầm dừng giữa chừng không (bị OS kill, không tự phục hồi được vì token MediaProjection
    // dùng 1 lần) - nhờ đó UI có thể báo cho user biết thay vì im lặng không hiểu vì sao mất phụ đề.
    @PluginMethod
    fun checkLostSession(call: PluginCall) {
        val lost = AudioCaptureService.consumeLostSystemSession(context)
        if (lost) {
            AudioCaptureService.clearSavedState(context)
        }
        val ret = JSObject()
        ret.put("lostSystemSession", lost)
        call.resolve(ret)
    }

    // ===== Quyền thông báo (Android 13+/TIRAMISU bắt buộc xin runtime, trước đó luôn granted) =====
    // Tách riêng khỏi luồng overlay/mic vì thuộc bước onboarding khác - JS gọi tuần tự:
    // overlay permission -> notification permission -> sẵn sàng bắt đầu nghe.

    @PluginMethod
    fun checkNotificationPermission(call: PluginCall) {
        val granted = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            getPermissionState("notifications") == PermissionState.GRANTED
        val ret = JSObject()
        ret.put("granted", granted)
        call.resolve(ret)
    }

    @PluginMethod
    fun requestNotificationPermission(call: PluginCall) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            val ret = JSObject()
            ret.put("granted", true)
            call.resolve(ret)
            return
        }
        if (getPermissionState("notifications") == PermissionState.GRANTED) {
            val ret = JSObject()
            ret.put("granted", true)
            call.resolve(ret)
        } else {
            saveCall(call)
            requestPermissionForAlias("notifications", call, "handleNotificationPermissionResult")
        }
    }

    @PermissionCallback
    private fun handleNotificationPermissionResult(call: PluginCall) {
        val granted = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            getPermissionState("notifications") == PermissionState.GRANTED
        val ret = JSObject()
        ret.put("granted", granted)
        call.resolve(ret)
    }

    // ===== Miễn trừ tối ưu pin (Ignore Battery Optimizations) =====
    // Nhiều OEM (Xiaomi/Oppo/Vivo/Samsung...) tự kill service chạy nền sau vài phút nếu app
    // không nằm trong danh sách miễn trừ Doze/App Standby, dù đã có foreground service +
    // notification đúng chuẩn. Xin miễn trừ này giúp phiên nghe dài (vài giờ) ổn định hơn
    // nhiều. Đây là dialog hệ thống đặc biệt (không phải runtime permission thường), phải mở
    // qua Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS.

    @PluginMethod
    fun checkBatteryOptimization(call: PluginCall) {
        val pm = context.getSystemService(android.content.Context.POWER_SERVICE) as PowerManager
        val ignoring = Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
            pm.isIgnoringBatteryOptimizations(context.packageName)
        val ret = JSObject()
        ret.put("ignoringOptimizations", ignoring)
        call.resolve(ret)
    }

    @PluginMethod
    fun requestIgnoreBatteryOptimizations(call: PluginCall) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            val ret = JSObject()
            ret.put("ignoringOptimizations", true)
            call.resolve(ret)
            return
        }
        val intent = Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
            data = android.net.Uri.parse("package:" + context.packageName)
        }
        saveCall(call)
        startActivityForResult(call, intent, "handleBatteryOptimizationResult")
    }

    @ActivityCallback
    private fun handleBatteryOptimizationResult(call: PluginCall?, result: androidx.activity.result.ActivityResult) {
        if (call == null) return
        // Dialog này không trả resultCode đáng tin cậy (tuỳ OEM/phiên bản Android) - luôn
        // đọc lại trạng thái thật qua PowerManager thay vì tin resultCode == RESULT_OK.
        val pm = context.getSystemService(android.content.Context.POWER_SERVICE) as PowerManager
        val ignoring = pm.isIgnoringBatteryOptimizations(context.packageName)
        val ret = JSObject()
        ret.put("ignoringOptimizations", ignoring)
        call.resolve(ret)
    }

    // ===== Gọi bởi AudioCaptureService/VoskEngine (chạy trên thread nền -> phải post lên JS an toàn) =====

    fun emitPartial(text: String) {
        val data = JSObject()
        data.put("text", text)
        notifyListeners("partialText", data)
    }

    // detectedLang: chỉ có giá trị (khác null) khi đang ở chế độ "tự động nhận diện nhiều ngôn
    // ngữ" (sourceLang == "auto", xem MultiLangVoskEngine) - là ngôn ngữ mà bộ nhận diện song
    // song đã thắng cho đúng câu này. null ở chế độ 1 ngôn ngữ bình thường (JS đã biết chắc
    // ngôn ngữ qua sourceLangEl.value, không cần native lặp lại).
    fun emitFinal(text: String, confidence: Double, detectedLang: String? = null) {
        val data = JSObject()
        data.put("text", text)
        data.put("confidence", confidence) // -1.0 nếu không xác định được, xem VoskEngine
        if (detectedLang != null) data.put("detectedLang", detectedLang)
        notifyListeners("finalText", data)
    }

    // Câu bị VoskEngine lọc bỏ vì độ tin cậy quá thấp (nhiều khả năng nhận nhầm nhạc/nhiễu nền
    // thành lời nói) - KHÔNG đẩy vào luồng dịch chính, chỉ để hiển thị/log debug nếu JS muốn.
    fun emitLowConfidence(text: String, confidence: Double) {
        val data = JSObject()
        data.put("text", text)
        data.put("confidence", confidence)
        notifyListeners("lowConfidenceText", data)
    }

    // code: định danh máy-đọc-được cho JS phân loại lỗi (vd để tự động fallback), khác với
    // message vốn là câu tiếng Việt dành cho người đọc. null = lỗi chung chung, không có
    // hành động tự động nào tương ứng phía JS.
    // "SYSTEM_CAPTURE_BLOCKED": build AudioRecord thất bại rõ ràng (UnsupportedOperationException
    // hoặc state != INITIALIZED) khi ở MODE_SYSTEM - dấu hiệu chắc chắn app nguồn/thiết bị chặn
    // playback capture, JS có thể tự động chuyển sang MODE_MIC mà không sợ nhầm với im lặng thật.
    fun emitError(message: String, code: String? = null) {
        val data = JSObject()
        data.put("message", message)
        if (code != null) data.put("code", code)
        notifyListeners("captureError", data)
    }

    fun emitModelLoading(ready: Boolean) {
        val data = JSObject()
        data.put("ready", ready)
        notifyListeners("modelStatus", data)
    }

    // Chỉ bắn khi chế độ "Tự động nhận diện" đang load nhiều model Vosk song song (xem
    // MultiLangVoskEngine.maybeNotifyReady) - loaded/total để JS vẽ progress bar thật thay vì
    // text tĩnh "đang tải...". Chế độ 1 ngôn ngữ thường không bao giờ bắn sự kiện này.
    fun emitModelLoadingProgress(loaded: Int, total: Int) {
        val data = JSObject()
        data.put("loaded", loaded)
        data.put("total", total)
        notifyListeners("modelLoadingProgress", data)
    }

    // Bắn khi service tự khởi động lại và phục hồi capture thành công sau khi bị OS kill
    // (chỉ xảy ra với MODE_MIC - xem AudioCaptureService.onStartCommand).
    fun emitCaptureResumed(mode: String) {
        val data = JSObject()
        data.put("mode", mode)
        notifyListeners("captureResumed", data)
    }

    // Cloud STT (Whisper qua groq-relay?op=transcribe) - CHỈ bắn khi requestCapture() được gọi
    // với cloudStt=true (xem AudioCaptureService.startCloudSttReadLoop). wavBase64 là 1 đoạn
    // audio PCM16 mono 16kHz đã đóng gói WAV, cắt theo câu bằng VAD (không dùng Vosk nên không
    // cần model STT tải sẵn). Native chỉ lo capture/cắt đoạn - JS tự lo phần mạng (upload lên
    // groq-relay, giữ API key phía server) và tự đẩy text nhận được vào pipeline dịch/hiển thị
    // dùng chung với câu final của Vosk.
    fun emitCloudSttSegment(wavBase64: String, sourceLang: String) {
        val data = JSObject()
        data.put("wavBase64", wavBase64)
        data.put("sourceLang", sourceLang)
        notifyListeners("cloudSttSegment", data)
    }

    // Đo mức tín hiệu audio thực tế đọc được từ AudioRecord, bắn lên JS mỗi ~1s.
    // Dùng để phân biệt "capture chạy nhưng audio là silence" (peak ~ 0 liên tục) với
    // "capture không chạy" hay "Vosk không nhận diện được dù có audio thật".
    fun emitAudioLevel(peak: Int, readCalls: Int, silentReads: Int, badReads: Int) {
        val data = JSObject()
        data.put("peak", peak) // 0..32767, PCM16 mono
        data.put("readCalls", readCalls)
        data.put("silentReads", silentReads)
        data.put("badReads", badReads)
        notifyListeners("audioLevel", data)
    }
}
