// Fix (audit Detekt - InvalidPackageDeclaration false-positive): file này nằm phẳng trong
// native/ ở gốc repo, không theo cấu trúc thư mục com/atun/translator/ - CÓ CHỦ ĐÍCH, vì bước
// build-debug (android-build.yml) tự copy file này vào đúng
// android/app/src/main/java/com/atun/translator/ trước khi biên dịch thật (xem step "Copy
// native Kotlin sources"). Detekt ở job validation chạy TRƯỚC bước copy đó (trên native/ phẳng)
// nên luôn báo package không khớp đường dẫn vật lý lúc đó - không phải lỗi thật, khai báo
// package vẫn đúng với vị trí SAU KHI copy (nơi thật sự biên dịch).
@file:Suppress("InvalidPackageDeclaration")

package com.atun.translator

import android.content.Intent
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager

// ===== Tách từ AudioCaptureService.kt (phần dựng nguồn thu âm) =====
// Toàn bộ hàm dưới đây là extension function của AudioCaptureService - vẫn truy cập trực tiếp
// field/hàm "internal" của service (mediaProjection, audioRecord, isCapturing,
// acquireWakeLock/releaseWakeLock, saveState, stopCapture) và hàm ở SttReadLoop.kt
// (startCloudSttReadLoop) y hệt như khi còn nằm chung 1 file, KHÔNG đổi hành vi.

// ===== Dọn mediaProjection khi 1 nhánh lỗi xảy ra SAU khi field này đã được gán. Tách ra đây
// (audit kiểm duyệt): buildSystemAudioRecord() gán mediaProjection NGAY khi lấy được projection,
// TRƯỚC khi biết AudioRecord có build thành công hay không - các nhánh lỗi trước đây gọi
// stopSelf() mà KHÔNG tự dọn field này, dựa hoàn toàn vào onDestroy()->stopCapture() dọn muộn
// hơn (không leak vĩnh viễn vì stopSelf() rồi cũng tới onDestroy(), nhưng có 1 khoảng thời gian
// không xác định trước đó mediaProjection vẫn "sống" dù coi như đã huỷ - icon hệ thống "đang ghi
// màn hình" có thể còn hiện chớp nhoáng). Giờ MỌI nhánh lỗi tự dọn NGAY tại chỗ.
private fun AudioCaptureService.releaseMediaProjectionOnFailure() {
    mediaProjection?.stop()
    mediaProjection = null
}

// ===== Dựng AudioRecord bắt audio hệ thống (MediaProjection playback capture). TỰ báo lỗi qua
// emitError() và trả về null khi thất bại (gọi nơi return sớm).
private fun AudioCaptureService.buildSystemAudioRecord(resultCode: Int, resultData: Intent): AudioRecord? {
    // Extension function trên AudioCaptureService KHÔNG tự phân giải được hằng số tĩnh kế
    // thừa từ Context khi viết không đủ tên (khác hàm thành viên thật) - phải chỉ rõ
    // Context.MEDIA_PROJECTION_SERVICE, không thể viết MEDIA_PROJECTION_SERVICE suông.
    val projectionManager =
        getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    val projection = projectionManager.getMediaProjection(resultCode, resultData)
    mediaProjection = projection

    // Android 14+ yêu cầu đăng ký callback TRƯỚC khi gọi bất kỳ hàm capture nào.
    projection.registerCallback(object : MediaProjection.Callback() {
        override fun onStop() {
            // Hệ thống/user tự dừng chia sẻ màn hình (vd. qua nút Stop của Android trên
            // status bar) - đây là dừng có chủ đích, không phải bị OS kill, nên xoá luôn
            // cờ đã lưu để lần start service kế tiếp (nếu có) không cố phục hồi nhầm.
            AudioCaptureService.clearSavedState(applicationContext)
            stopCapture()
        }
    }, null)

    val config = android.media.AudioPlaybackCaptureConfiguration.Builder(projection)
        .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
        .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
        .build()

    val audioFormat = AudioFormat.Builder()
        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
        .setSampleRate(AudioCaptureService.SAMPLE_RATE)
        .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
        .build()

    val minBufferSize = AudioRecord.getMinBufferSize(
        AudioCaptureService.SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
    )
    if (minBufferSize <= 0) {
        AudioCapturePlugin.instance?.emitError(
            "Thiết bị không hỗ trợ cấu hình audio 16kHz mono.",
            code = "CAPTURE_START_FAILED"
        )
        releaseMediaProjectionOnFailure()
        return null
    }

    val record = try {
        AudioRecord.Builder()
            .setAudioFormat(audioFormat)
            .setBufferSizeInBytes(minBufferSize * 4)
            .setAudioPlaybackCaptureConfig(config)
            .build()
    } catch (e: UnsupportedOperationException) {
        // Xảy ra khi thiết bị/app nguồn chặn capture (allowAudioPlaybackCapture=false)
        // hoặc không có app nào đang phát audio khớp usage MEDIA lúc build().
        AudioCapturePlugin.instance?.emitError(
            "Không bắt được audio hệ thống - có thể app đang phát (vd. YouTube) đã chặn playback capture: " + e.message,
            code = "SYSTEM_CAPTURE_BLOCKED"
        )
        releaseMediaProjectionOnFailure()
        return null
    }

    if (record.state != AudioRecord.STATE_INITIALIZED) {
        AudioCapturePlugin.instance?.emitError(
            "AudioRecord khởi tạo thất bại (state != INITIALIZED).",
            code = "SYSTEM_CAPTURE_BLOCKED"
        )
        record.release()
        releaseMediaProjectionOnFailure()
        return null
    }

    return record
}

// ===== Dựng AudioRecord bắt audio qua micro (VOICE_COMMUNICATION, hưởng AEC/NS/AGC nếu máy hỗ
// trợ). DÙNG CHUNG cho startMicCapture() (mic đơn) VÀ startMixedCapture() (nửa mic của
// MODE_MIXED) - audit kiểm duyệt phát hiện 2 nơi này trước đây COPY-PASTE y hệt khối
// AudioRecord(...), tách ra đây để sửa 1 chỗ áp dụng cho cả 2, tránh lệch hành vi âm thầm về
// sau. TỰ báo lỗi qua emitError() và trả về null khi thất bại, cùng convention với
// buildSystemAudioRecord() ở trên.
// contextLabel: chèn vào thông điệp lỗi thiếu quyền để phân biệt "nghe qua micro" (MODE_MIC) với
// "nghe qua micro (bắt buộc cho chế độ hội thoại 2 chiều)" (MODE_MIXED) - CHỈ khác câu chữ hiển
// thị cho user, không đổi logic.
private fun AudioCaptureService.buildMicAudioRecord(minBufferSize: Int, contextLabel: String): AudioRecord? {
    val record = try {
        AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            AudioCaptureService.SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            minBufferSize * 4
        )
    } catch (e: SecurityException) {
        AudioCapturePlugin.instance?.emitError(
            "Thiếu quyền RECORD_AUDIO để $contextLabel: " + e.message,
            code = "CAPTURE_START_FAILED"
        )
        return null
    }
    if (record.state != AudioRecord.STATE_INITIALIZED) {
        AudioCapturePlugin.instance?.emitError(
            "AudioRecord (micro) khởi tạo thất bại (state != INITIALIZED).",
            code = "CAPTURE_START_FAILED"
        )
        // Fix (audit kiểm duyệt): trước đây nhánh này ở startMicCapture KHÔNG release() record
        // vừa tạo trước khi trả null/stopSelf() - AudioRecord không tự giải phóng tài nguyên
        // native ngay khi bị GC (chỉ có finalizer, không đảm bảo chạy sớm) - giờ release() tường
        // minh, khớp với cách startMixedCapture đã làm với micRecord ở nhánh tương tự.
        record.release()
        return null
    }
    return record
}

internal fun AudioCaptureService.startSystemCapture(resultCode: Int, resultData: Intent, sourceLang: String) {
    acquireWakeLock()

    val record = buildSystemAudioRecord(resultCode, resultData)
    if (record == null) {
        releaseWakeLock()
        stopSelf()
        return
    }
    // Gọi lại getMinBufferSize() lần 2 (đã gọi 1 lần trong buildSystemAudioRecord để build
    // record) - đây là hàm truy vấn thuần (không side-effect), gọi lại rẻ hơn nhiều so với đổi
    // chữ ký buildSystemAudioRecord() để trả kèm giá trị này ra ngoài.
    val minBufferSize = AudioRecord.getMinBufferSize(
        AudioCaptureService.SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
    )

    audioRecord = record
    saveState(AudioCaptureService.MODE_SYSTEM, sourceLang, capturing = true)
    startCloudSttReadLoop(record, sourceLang, minBufferSize)
}

// MODE_MIXED: "dịch hội thoại 2 chiều" - bắt ĐỒNG THỜI system (đối phương, cần MediaProjection,
// dịch sang tiếng Việt) + mic (mình nói tiếng Việt, dịch sang otherPartyLang) trong CÙNG 1 lần
// gọi. Nếu build luồng system thất bại thì dừng hẳn (không cố chạy 1 mình luồng mic - nếu chỉ
// cần mic đơn, user nên chọn MODE_MIC thường thay vì MODE_MIXED). Nếu luồng system build được
// nhưng luồng mic thất bại, dừng hẳn CẢ 2 (gọi stopCapture() dọn sạch luồng system vừa mở) - để
// tránh trạng thái nửa vời (chỉ nghe được 1 chiều mà user tưởng đang ở chế độ 2 chiều).
internal fun AudioCaptureService.startMixedCapture(
    resultCode: Int, resultData: Intent, otherPartyLang: String, preferExternalMic: Boolean,
) {
    acquireWakeLock()

    val systemRecord = buildSystemAudioRecord(resultCode, resultData)
    if (systemRecord == null) {
        // buildSystemAudioRecord() giờ TỰ dọn mediaProjection trong mọi nhánh lỗi của chính nó
        // (xem releaseMediaProjectionOnFailure()) - không cần làm gì thêm ở đây nữa.
        releaseWakeLock()
        stopSelf()
        return
    }
    val minBufferSize = AudioRecord.getMinBufferSize(
        AudioCaptureService.SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
    )
    if (minBufferSize <= 0) {
        AudioCapturePlugin.instance?.emitError(
            "Thiết bị không hỗ trợ cấu hình audio 16kHz mono.",
            code = "CAPTURE_START_FAILED"
        )
        systemRecord.release()
        releaseMediaProjectionOnFailure()
        releaseWakeLock()
        stopSelf()
        return
    }

    val micRecord = buildMicAudioRecord(minBufferSize, "nghe qua micro (bắt buộc cho chế độ hội thoại 2 chiều)") ?: run {
        systemRecord.release()
        releaseMediaProjectionOnFailure()
        releaseWakeLock()
        stopSelf()
        return
    }

    audioRecord = systemRecord
    audioRecordMic = micRecord
    selectMicInputDevice(micRecord, preferExternalMic)
    // Lưu otherPartyLang vào KEY_LANG như các mode khác - chỉ dùng để hiện lại UI đúng lựa chọn
    // trước đó, KHÔNG dùng để tự phục hồi (MODE_MIXED không tự phục hồi được, xem
    // consumeLostSystemSession).
    saveState(AudioCaptureService.MODE_MIXED, otherPartyLang, capturing = true, preferExternalMic = preferExternalMic)

    // Luồng system: STT theo otherPartyLang, channel="system" -> JS dịch sang tiếng Việt (y hệt
    // pipeline MODE_SYSTEM đơn hiện có, không đổi hướng dịch).
    startCloudSttReadLoop(
        systemRecord, otherPartyLang, minBufferSize,
        channel = AudioCaptureService.CHANNEL_SYSTEM,
        // assignThread mặc định (captureThread = it) đã đúng cho luồng system - viết tường
        // minh ra đây thay vì bỏ trống, để rõ ràng khi đọc code cạnh lời gọi luồng mic bên dưới.
        assignThread = { captureThread = it },
    )
    // Luồng mic: STT theo "vi" (mình nói tiếng Việt), channel="mic" -> JS dịch NGƯỢC hướng
    // (tiếng Việt -> otherPartyLang) - xem onCloudSttSegment trong app.module.js.
    startCloudSttReadLoop(
        micRecord, "vi", minBufferSize,
        channel = AudioCaptureService.CHANNEL_MIC,
        assignThread = { captureThreadMic = it },
    )
}

// MODE_MIC: dùng chính micro của máy, không cần MediaProjection -> không cần dialog hệ thống,
// chỉ cần quyền RECORD_AUDIO đã cấp trước (xin ở phía JS/Plugin). Nhờ vậy service có thể tự
// khởi động lại và tiếp tục nghe sau khi bị OS kill (xem onStartCommand, nhánh intent == null).
internal fun AudioCaptureService.startMicCapture(sourceLang: String, preferExternalMic: Boolean = false) {
    acquireWakeLock()

    val minBufferSize = AudioRecord.getMinBufferSize(
        AudioCaptureService.SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
    )
    if (minBufferSize <= 0) {
        AudioCapturePlugin.instance?.emitError(
            "Thiết bị không hỗ trợ cấu hình audio 16kHz mono.",
            code = "CAPTURE_START_FAILED"
        )
        releaseWakeLock()
        stopSelf()
        return
    }

    val record = buildMicAudioRecord(minBufferSize, "nghe qua micro") ?: run {
        releaseWakeLock()
        stopSelf()
        return
    }

    audioRecord = record
    selectMicInputDevice(record, preferExternalMic)
    saveState(AudioCaptureService.MODE_MIC, sourceLang, capturing = true, preferExternalMic = preferExternalMic)
    startCloudSttReadLoop(record, sourceLang, minBufferSize)
}

// Route AudioRecord sang micro NGOÀI nếu preferExternalMic=true VÀ máy đang có ít nhất 1
// thiết bị input ngoài kết nối - setPreferredDevice() (API 23+) chỉ đổi ĐƯỜNG THU (routing),
// không đổi AudioSource (vẫn giữ VOICE_COMMUNICATION để hưởng AEC/NS/AGC nếu thiết bị hỗ trợ).
// Không tìm thấy thiết bị ngoài, hoặc preferExternalMic=false -> giữ nguyên hành vi cũ
// (Android tự chọn route mặc định, thường là micro trong máy). Luôn bắn 1 sự kiện
// "micDeviceInfo" cho JS biết THẬT SỰ đang dùng thiết bị nào - kể cả khi fallback về máy
// trong, để UI hiện đúng trạng thái thay vì chỉ dựa vào checkbox user đã tick.
internal fun AudioCaptureService.selectMicInputDevice(record: AudioRecord, preferExternalMic: Boolean) {
    if (!preferExternalMic) {
        AudioCapturePlugin.instance?.emitMicDeviceInfo(false, "Micro trong máy")
        return
    }
    val device = AudioInputDevices.findBestExternalInputDevice(applicationContext)
    if (device == null) {
        AudioCapturePlugin.instance?.emitMicDeviceInfo(
            false, "Không phát hiện micro ngoài đang kết nối - dùng micro trong máy"
        )
        return
    }
    val ok = record.setPreferredDevice(device)
    if (ok) {
        AudioCapturePlugin.instance?.emitMicDeviceInfo(true, AudioInputDevices.describeInputDevice(device))
    } else {
        // setPreferredDevice() hiếm khi trả false (thường do device đã bị rút ra đúng lúc
        // gọi), nhưng vẫn xử lý để không báo sai cho user là đang dùng máy ngoài.
        AudioCapturePlugin.instance?.emitMicDeviceInfo(
            false, "Không đặt được route sang micro ngoài - dùng micro trong máy"
        )
    }
}
