package com.atun.translator

import android.content.Intent
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager

// ===== Tách từ AudioCaptureService.kt (phần dựng nguồn thu âm) =====
// Toàn bộ hàm dưới đây là extension function của AudioCaptureService - vẫn truy cập trực tiếp
// field/hàm "internal" của service (mediaProjection, audioRecord, sttEngine, isCapturing,
// acquireWakeLock/releaseWakeLock, saveState, stopCapture) và các hàm ở SttReadLoop.kt
// (startVoskAndReadLoop/startCloudSttReadLoop) y hệt như khi còn nằm chung 1 file, KHÔNG đổi
// hành vi.

internal fun AudioCaptureService.startSystemCapture(resultCode: Int, resultData: Intent, sourceLang: String, smartPause: Boolean, cloudStt: Boolean) {
    acquireWakeLock()

    // Extension function trên AudioCaptureService KHÔNG tự phân giải được hằng số tĩnh kế
    // thừa từ Context khi viết không đủ tên (khác hàm thành viên thật) - phải chỉ rõ
    // Context.MEDIA_PROJECTION_SERVICE, không thể viết MEDIA_PROJECTION_SERVICE suông.
    val projectionManager =
        getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    val projection = projectionManager.getMediaProjection(resultCode, resultData)
    mediaProjection = projection

    // Android 14+ yêu cầu đăng ký callback TRƯỚC khi gọi bất kỳ hàm capture nào.
    projection.registerCallback(object : MediaProjection.Callback() {
        override fun onStop() {
            // Hệ thống/user tự dừng chia sẻ màn hình (vd. qua nút Stop của Android trên
            // status bar) - đây là dừng có chủ đích, không phải bị OS kill, nên xoá luôn
            // cờ đã lưu để lần start service kế tiếp (nếu có) không cố phục hồi nhầm.
            AudioCaptureService.clearSavedState(applicationContext)
            stopCapture()
        }
    }, null)

    val config = android.media.AudioPlaybackCaptureConfiguration.Builder(projection)
        .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
        .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
        .build()

    val audioFormat = AudioFormat.Builder()
        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
        .setSampleRate(AudioCaptureService.SAMPLE_RATE)
        .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
        .build()

    val minBufferSize = AudioRecord.getMinBufferSize(
        AudioCaptureService.SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
    )
    if (minBufferSize <= 0) {
        AudioCapturePlugin.instance?.emitError("Thiết bị không hỗ trợ cấu hình audio 16kHz mono.")
        releaseWakeLock()
        stopSelf()
        return
    }

    val record = try {
        AudioRecord.Builder()
            .setAudioFormat(audioFormat)
            .setBufferSizeInBytes(minBufferSize * 4)
            .setAudioPlaybackCaptureConfig(config)
            .build()
    } catch (e: UnsupportedOperationException) {
        // Xảy ra khi thiết bị/app nguồn chặn capture (allowAudioPlaybackCapture=false)
        // hoặc không có app nào đang phát audio khớp usage MEDIA lúc build().
        AudioCapturePlugin.instance?.emitError(
            "Không bắt được audio hệ thống - có thể app đang phát (vd. YouTube) đã chặn playback capture: " + e.message,
            code = "SYSTEM_CAPTURE_BLOCKED"
        )
        releaseWakeLock()
        stopSelf()
        return
    }

    if (record.state != AudioRecord.STATE_INITIALIZED) {
        AudioCapturePlugin.instance?.emitError(
            "AudioRecord khởi tạo thất bại (state != INITIALIZED).",
            code = "SYSTEM_CAPTURE_BLOCKED"
        )
        releaseWakeLock()
        stopSelf()
        return
    }

    audioRecord = record
    saveState(AudioCaptureService.MODE_SYSTEM, sourceLang, capturing = true, smartPause = smartPause, cloudStt = cloudStt)
    if (cloudStt) {
        startCloudSttReadLoop(record, sourceLang, minBufferSize)
    } else {
        startVoskAndReadLoop(record, sourceLang, minBufferSize, smartPause)
    }
}

// MODE_MIC: dùng chính micro của máy, không cần MediaProjection -> không cần dialog hệ thống,
// chỉ cần quyền RECORD_AUDIO đã cấp trước (xin ở phía JS/Plugin). Nhờ vậy service có thể tự
// khởi động lại và tiếp tục nghe sau khi bị OS kill (xem onStartCommand, nhánh intent == null).
internal fun AudioCaptureService.startMicCapture(sourceLang: String, smartPause: Boolean, cloudStt: Boolean, preferExternalMic: Boolean = false) {
    acquireWakeLock()

    val minBufferSize = AudioRecord.getMinBufferSize(
        AudioCaptureService.SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
    )
    if (minBufferSize <= 0) {
        AudioCapturePlugin.instance?.emitError("Thiết bị không hỗ trợ cấu hình audio 16kHz mono.")
        releaseWakeLock()
        stopSelf()
        return
    }

    val record = try {
        AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            AudioCaptureService.SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            minBufferSize * 4
        )
    } catch (e: SecurityException) {
        AudioCapturePlugin.instance?.emitError("Thiếu quyền RECORD_AUDIO để nghe qua micro: " + e.message)
        releaseWakeLock()
        stopSelf()
        return
    }

    if (record.state != AudioRecord.STATE_INITIALIZED) {
        AudioCapturePlugin.instance?.emitError("AudioRecord (micro) khởi tạo thất bại (state != INITIALIZED).")
        releaseWakeLock()
        stopSelf()
        return
    }

    audioRecord = record

    // Ghi lại vào error log (Cài đặt > Chia sẻ log lỗi) kích thước buffer THẬT mà driver
    // âm thanh của máy này trả về - minBufferSize KHÔNG phải hằng số, mỗi dòng máy/HAL trả
    // về khác nhau, nên không thể biết trước "1 frame = bao nhiêu ms" cho một model máy cụ
    // thể (vd Samsung A16) mà không chạy thử. Frame ở đây = minBufferSize/2 mẫu (buffer đọc
    // mỗi lần record.read() trong vòng lặp bên dưới), hangover 4 frame là khoảng VAD vẫn
    // coi "đang nói" sau khi năng lượng đã tụt - cộng với SMART_PAUSE_MS mới ra tổng độ trễ
    // thật trước khi 1 câu bị chốt.
    val frameSamples = minBufferSize / 2
    val frameMs = frameSamples * 1000.0 / AudioCaptureService.SAMPLE_RATE
    val hangoverMs = frameMs * 4
    AppLog.append(
        this,
        "MicCapture: minBufferSize=$minBufferSize bytes, 1 frame=$frameSamples mẫu " +
            "(~${"%.1f".format(frameMs)}ms/frame @ ${AudioCaptureService.SAMPLE_RATE}Hz), hangover 4 frame≈" +
            "${"%.0f".format(hangoverMs)}ms, SMART_PAUSE_MS=${AudioCaptureService.SMART_PAUSE_MS}ms, " +
            "tổng độ trễ chốt câu ước tính≈${"%.0f".format(hangoverMs + AudioCaptureService.SMART_PAUSE_MS)}ms"
    )

    selectMicInputDevice(record, preferExternalMic)
    saveState(
        AudioCaptureService.MODE_MIC, sourceLang, capturing = true, smartPause = smartPause, cloudStt = cloudStt,
        preferExternalMic = preferExternalMic
    )
    if (cloudStt) {
        startCloudSttReadLoop(record, sourceLang, minBufferSize)
    } else {
        startVoskAndReadLoop(record, sourceLang, minBufferSize, smartPause)
    }
}

// Route AudioRecord sang micro NGOÀI nếu preferExternalMic=true VÀ máy đang có ít nhất 1
// thiết bị input ngoài kết nối - setPreferredDevice() (API 23+) chỉ đổi ĐƯỜNG THU (routing),
// không đổi AudioSource (vẫn giữ VOICE_RECOGNITION để hưởng AEC/NS nếu thiết bị hỗ trợ).
// Không tìm thấy thiết bị ngoài, hoặc preferExternalMic=false -> giữ nguyên hành vi cũ
// (Android tự chọn route mặc định, thường là micro trong máy). Luôn bắn 1 sự kiện
// "micDeviceInfo" cho JS biết THẬT SỰ đang dùng thiết bị nào - kể cả khi fallback về máy
// trong, để UI hiện đúng trạng thái thay vì chỉ dựa vào checkbox user đã tick.
internal fun AudioCaptureService.selectMicInputDevice(record: AudioRecord, preferExternalMic: Boolean) {
    if (!preferExternalMic) {
        AudioCapturePlugin.instance?.emitMicDeviceInfo(false, "Micro trong máy")
        return
    }
    val device = AudioInputDevices.findBestExternalInputDevice(applicationContext)
    if (device == null) {
        AudioCapturePlugin.instance?.emitMicDeviceInfo(
            false, "Không phát hiện micro ngoài đang kết nối - dùng micro trong máy"
        )
        return
    }
    val ok = record.setPreferredDevice(device)
    if (ok) {
        AudioCapturePlugin.instance?.emitMicDeviceInfo(true, AudioInputDevices.describeInputDevice(device))
    } else {
        // setPreferredDevice() hiếm khi trả false (thường do device đã bị rút ra đúng lúc
        // gọi), nhưng vẫn xử lý để không báo sai cho user là đang dùng máy ngoài.
        AudioCapturePlugin.instance?.emitMicDeviceInfo(
            false, "Không đặt được route sang micro ngoài - dùng micro trong máy"
        )
    }
}
