package com.atun.translator

// Cầu nối phụ đề dịch từ màn hình chính (www/index.html, chạy trong Capacitor Bridge WebView)
// sang "Web mini" (BrowserActivity, 1 WebView native RIÊNG BIỆT, không chung JS context với
// màn hình chính) - CÙNG process/app nên chỉ cần 1 singleton in-memory đơn giản, không cần
// Intent/Broadcast/SharedPreferences gì phức tạp.
//
// Luồng: applyCaptionSettings() trong www/index.html (chạy mỗi khi có câu dịch mới HOẶC người
// dùng chỉnh thanh trượt Rộng/Cao/cỡ chữ/độ trong suốt) gọi
// BrowserLauncher.updateCaption({text, opacity, fontSize, widthPercent, heightPercent}) ->
// BrowserLauncherPlugin gọi CaptionRelay.update(frame) -> mọi listener đang đăng ký (chỉ có
// BrowserActivity, và chỉ khi nó đang ở foreground - xem onResume/onPause ở đó) được gọi lại
// NGAY trên chính thread gọi update() (thường là main thread, vì @PluginMethod chạy trên main
// thread theo mặc định của Capacitor).
object CaptionRelay {
    // Gộp cả câu dịch lẫn "khung dịch" (opacity/cỡ chữ/tỉ lệ rộng-cao) vào 1 object thay vì chỉ
    // truyền text - để Web mini không chỉ hiện ĐÚNG câu đang dịch mà còn hiện GIỐNG khung đang
    // cấu hình ở màn hình chính (trước đây overlay của Web mini có style cố định cứng, không
    // đồng bộ theo tuỳ chỉnh của người dùng). widthPercent/heightPercent tính theo % kích thước
    // vùng WebView của CHÍNH Web mini (không phải % #videoStage của màn hình chính - 2 nơi có
    // kích thước màn hình khác nhau), giữ đúng TỈ LỆ người dùng đã chọn thay vì đúng số pixel.
    data class CaptionFrame(
        val text: String = "",
        val opacity: Float = 0.75f,
        val fontSize: String = "medium",
        val widthPercent: Int = 96,
        val heightPercent: Int = 30,
    )

    @Volatile
    private var lastFrame: CaptionFrame = CaptionFrame()

    private val listeners = mutableListOf<(CaptionFrame) -> Unit>()

    @Synchronized
    fun update(frame: CaptionFrame) {
        lastFrame = frame
        // Chụp lại danh sách trước khi gọi để tránh ConcurrentModificationException nếu 1
        // listener lỡ tự add/remove chính nó ngay trong callback.
        val snapshot = listeners.toList()
        snapshot.forEach { it(frame) }
    }

    // addListener() chủ động gọi ngay với giá trị hiện tại - để BrowserActivity mở lên (hoặc
    // quay lại foreground) khi ĐANG có sẵn 1 câu phụ đề thật thấy ngay, không phải đợi câu dịch
    // TIẾP THEO mới hiện ra.
    @Synchronized
    fun addListener(listener: (CaptionFrame) -> Unit) {
        listeners.add(listener)
        listener(lastFrame)
    }

    @Synchronized
    fun removeListener(listener: (CaptionFrame) -> Unit) {
        listeners.remove(listener)
    }
}
