package com.atun.translator

// Cầu nối phụ đề dịch từ màn hình chính (www/index.html, chạy trong Capacitor Bridge WebView)
// sang "Web mini" (BrowserActivity, 1 WebView native RIÊNG BIỆT, không chung JS context với
// màn hình chính) - CÙNG process/app nên chỉ cần 1 singleton in-memory đơn giản, không cần
// Intent/Broadcast/SharedPreferences gì phức tạp.
//
// Luồng: flushFinalBatch() trong www/index.html gọi BrowserLauncher.updateCaption({text}) mỗi
// khi có câu dịch mới (hoặc text rỗng khi dừng video/xoá phụ đề) -> BrowserLauncherPlugin gọi
// CaptionRelay.update(text) -> mọi listener đang đăng ký (chỉ có BrowserActivity, và chỉ khi nó
// đang ở foreground - xem onResume/onPause ở đó) được gọi lại NGAY trên chính thread gọi update()
// (thường là main thread, vì @PluginMethod chạy trên main thread theo mặc định của Capacitor).
object CaptionRelay {
    @Volatile
    private var lastText: String = ""

    private val listeners = mutableListOf<(String) -> Unit>()

    @Synchronized
    fun update(text: String) {
        lastText = text
        // Chụp lại danh sách trước khi gọi để tránh ConcurrentModificationException nếu 1
        // listener lỡ tự add/remove chính nó ngay trong callback.
        val snapshot = listeners.toList()
        snapshot.forEach { it(text) }
    }

    // addListener() chủ động gọi ngay với giá trị hiện tại - để BrowserActivity mở lên (hoặc
    // quay lại foreground) khi ĐANG có sẵn 1 câu phụ đề thật thấy ngay, không phải đợi câu dịch
    // TIẾP THEO mới hiện ra.
    @Synchronized
    fun addListener(listener: (String) -> Unit) {
        listeners.add(listener)
        listener(lastText)
    }

    @Synchronized
    fun removeListener(listener: (String) -> Unit) {
        listeners.remove(listener)
    }
}
