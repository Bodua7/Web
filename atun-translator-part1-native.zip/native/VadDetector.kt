// Fix (audit Detekt - InvalidPackageDeclaration false-positive): file này nằm phẳng trong
// native/ ở gốc repo, không theo cấu trúc thư mục com/atun/translator/ - CÓ CHỦ ĐÍCH, vì bước
// build-debug (android-build.yml) tự copy file này vào đúng
// android/app/src/main/java/com/atun/translator/ trước khi biên dịch thật (xem step "Copy
// native Kotlin sources"). Detekt ở job validation chạy TRƯỚC bước copy đó (trên native/ phẳng)
// nên luôn báo package không khớp đường dẫn vật lý lúc đó - không phải lỗi thật, khai báo
// package vẫn đúng với vị trí SAU KHI copy (nơi thật sự biên dịch).
@file:Suppress("InvalidPackageDeclaration")

package com.atun.translator

// VAD (Voice Activity Detection) dựa trên năng lượng tín hiệu (RMS) với ngưỡng THÍCH NGHI theo
// nhiễu nền, thay cho ngưỡng biên độ đỉnh (peak) cố định trước đây (SILENCE_PEAK_THRESHOLD=50
// cứng trong AudioCaptureService). Ngưỡng cố định không đáng tin vì mức nhiễu nền chênh lệch rất
// lớn giữa các nguồn: video YouTube có nhạc nền to, ghi âm qua micro có tiếng ồn phòng/quạt, v.v.
// -> cùng 1 ngưỡng=50 có thể coi nhạc nền là "giọng nói" (nhiễu > 50) ở nguồn này, hoặc bỏ sót
// giọng nói yếu (< 50) ở nguồn khác.
//
// Không dùng thư viện VAD ngoài (WebRTC VAD / Silero VAD qua TFLite) để tránh thêm dependency
// native/model chưa build-test được (không có máy Android thật, chỉ build qua GitHub Actions
// CI) - có thể vỡ build mà không phát hiện được tới khi cài lên máy thật. Cách tiếp cận ở đây:
// energy-based VAD thích nghi + hysteresis + hangover - kỹ thuật kinh điển (cùng họ với VAD của
// ETSI AMR, ITU-T G.729 Annex B), thuần Kotlin, không phụ thuộc ngoài, dễ tune bằng vài hằng số.
//
// Cách hoạt động:
// 1. Mỗi khung audio (mỗi lần AudioRecord.read() trả về mẫu), tính RMS energy (mượt hơn peak vì
//    không bị lệch bởi 1-2 mẫu đột biến kiểu click/pop).
// 2. Khi ĐANG im lặng: liên tục cập nhật ước lượng "nhiễu nền" (noiseFloor) bằng RMS các khung
//    im lặng - CHỈ cập nhật lúc im lặng, không cập nhật lúc đang nói (nếu không noiseFloor sẽ
//    "đuổi theo" giọng nói và ngưỡng leo thang dần trong câu dài, làm mất nhạy).
// 3. Ngưỡng vào tiếng nói = noiseFloor * hệ số cao hơn ngưỡng ra tiếng nói (hysteresis) - tránh
//    hiện tượng "rung" (flicker) liên tục bật/tắt quanh biên khi energy dao động nhẹ quanh ngưỡng.
// 4. Hangover: giữ trạng thái "voice" thêm vài khung sau khi energy tụt dưới ngưỡng exit, vì âm
//    cuối từ/câu thường nhỏ dần từ từ chứ không tắt đột ngột - tránh cắt cụt đuôi từ.
class VadDetector {
    companion object {
        // Tốc độ thích nghi noise floor (EMA alpha). Nhỏ = thích nghi chậm, ổn định hơn với
        // nhiễu đột biến ngắn; lớn = bám sát nhiễu nền thay đổi nhanh hơn nhưng dễ bị nhiễu bởi
        // các đợt ồn ngắn. 0.05 tương đương noise floor cập nhật đáng kể sau ~1-2s audio.
        private const val NOISE_ADAPT_RATE = 0.05

        // Hệ số nhân noise floor để ra ngưỡng VÀO tiếng nói - cao hơn ngưỡng RA (EXIT) tạo
        // hysteresis. Tăng ENTER nếu VAD quá nhạy (bắt nhầm nhạc nền/ồn thành giọng nói); giảm
        // nếu bỏ sót giọng nói nhỏ.
        private const val ENTER_SPEECH_RATIO = 2.5
        private const val EXIT_SPEECH_RATIO = 1.6

        // Chặn dưới cho noise floor - tránh trường hợp có đoạn im lặng số tuyệt đối (digital
        // silence, RMS ~ 0) làm noise floor tụt gần 0, khiến ngưỡng vào tiếng nói cũng gần 0
        // theo (VAD sẽ coi mọi rung động nhỏ nhất là "có giọng nói").
        private const val MIN_NOISE_FLOOR = 30.0

        // Chặn TRÊN cho noise floor - bug thực tế: video có đoạn đầu không phải giọng nói
        // nhưng cũng không im lặng tuyệt đối, mà TĂNG DẦN theo thời gian (nhạc dạo đầu to dần
        // kiểu crescendo, hiệu ứng âm thanh intro...). Với 1 mức nhiễu HẰNG SỐ thì noiseFloor
        // tự hội tụ về đúng mức đó rồi dừng (không vượt quá, do bản chất EMA) nên không đáng lo -
        // nhưng khi nhiễu nền tăng DẦN, ngưỡng vào tiếng nói (enterThreshold = noiseFloor *
        // ENTER_SPEECH_RATIO) luôn bám kịp NGAY DƯỚI rms hiện tại của đoạn tăng dần đó (miễn
        // rms tăng đủ chậm so với NOISE_ADAPT_RATE) -> không frame nào bị coi là voice trong cả
        // đoạn -> noiseFloor cứ thế bị "kéo" lên theo, có thể lên rất cao chỉ sau một đoạn nhạc
        // dạo vài giây. Ngưỡng vào tiếng nói khi đó có thể vượt quá RMS của giọng nói thật lúc
        // người nói bắt đầu -> isVoice không bao giờ thành true nữa cho CẢ PHIÊN -> smartPause
        // (AudioCaptureService) bị kẹt vì pauseHandled chỉ reset khi VAD báo có voice ->
        // forcePauseFinal() không gọi lại được nữa -> phụ đề phải chờ endpointer nội bộ (chậm
        // hơn, chốt câu trễ/dính nhiều câu vào nhau). Đã tái hiện + test lại đúng kịch bản này ở
        // native-test/VadDetectorTest.kt (`noise floor bi chan tran khi nen tang dan lien tuc,
        // khong duoc chay theo vo han`).
        // Fix (audit - "comment trỏ tới file test không tồn tại"): trước đây ghi
        // "tests/vad/test_vad_detector.py" - thư mục đó CHƯA BAO GIỜ tồn tại trong repo (không
        // phải bị xoá nhầm, chỉ là lời hứa chưa thực hiện). VadDetector không có port Python
        // riêng (chỉ có JUnit thuần vì không phụ thuộc Android API, xem comment đầu
        // VadDetectorTest.kt) nên quy ước tự nhiên là test JUnit, không phải test Python.
        // Chặn trên này giới hạn thiệt hại: dù nền tăng dần tới đâu, ngưỡng vào tiếng nói tối đa
        // vẫn ở mức hợp lý để giọng nói bình thường (nói to hơn nhạc nền, đặc điểm phổ biến của
        // video có lồng tiếng/thuyết minh) vẫn vượt qua được.
        private const val MAX_NOISE_FLOOR = 1500.0

        // Thời lượng (ms) giữ trạng thái "voice" sau khi energy đã tụt dưới ngưỡng exit - tính
        // theo MỐC THỜI GIAN, không đếm số khung.
        // Fix (audit VAD/môi trường): trước đây là HANGOVER_FRAMES=4 (đếm số lần gọi process()).
        // Đây là LỖI ĐƠN VỊ thật, không phải chỗ "tune cho hay hơn": thời lượng 1 khung phụ thuộc
        // minBufferSize của AudioRecord (kích thước buffer đọc mỗi lần record.read()), vốn KHÁC
        // NHAU giữa các thiết bị/cấu hình Android (AudioRecord.getMinBufferSize() không đảm bảo
        // trả về cùng 1 giá trị trên mọi máy) - cùng 1 hằng số "4 khung" có thể là ~150ms trên máy
        // này nhưng ~500ms+ trên máy khác, tức hành vi cắt câu (đuôi từ bị cụt hay không) thay đổi
        // theo THIẾT BỊ chứ không phải theo chủ ý - đúng loại lỗi "theo môi trường" nêu trong audit.
        // 250ms chọn dựa trên đặc tính phổ biến của tiếng nói (âm cuối từ/câu thường tắt dần trong
        // khoảng 150-300ms chứ không tắt đột ngột) - áp dụng NHẤT QUÁN trên mọi thiết bị từ giờ.
        private const val HANGOVER_MS = 250L

        // Fix (audit VAD đợt 3 - "kẹt voice=true vĩnh viễn"): noiseFloor chỉ được cập nhật ở
        // nhánh !isVoice (xem process()) - CỐ Ý, để không "đuổi theo" giọng nói giữa câu dài (xem
        // comment ở NOISE_ADAPT_RATE). Hệ quả phụ nếu không chặn thêm: nếu 1 khung đủ ồn
        // (RMS > enterThreshold tính từ noiseFloor khởi tạo 200 = 500) xảy ra NGAY từ đầu phiên -
        // trước khi noiseFloor kịp hội tụ về mức nền thật (ví dụ bấm ghi đúng lúc xe tải chạy qua,
        // quạt/điều hoà bật, tiếng pop của mic lúc mới mở) - VAD nhảy thẳng vào isVoice=true. Nếu
        // sau đó tiếng ồn NỀN (không phải giọng nói) duy trì RMS > exitThreshold (=noiseFloor*1.6,
        // ĐÓNG BĂNG ở 320 vì noiseFloor không còn được cập nhật khi isVoice=true) thì hangover cứ
        // tự refresh mãi mãi -> isVoice không bao giờ về false -> noiseFloor không bao giờ có cơ
        // hội cập nhật lại (2 điều kiện khoá lẫn nhau) -> VAD mất tác dụng CẢ PHIÊN, chỉ còn cắt
        // cứng theo maxSegmentMs ở lớp cắt đoạn phía trên. Khác hẳn kịch bản "nền tăng dần" đã có
        // MAX_NOISE_FLOOR chặn phía trên - ở đây noiseFloor không hề tăng, nó ĐÓNG BĂNG quá THẤP
        // so với thực tế.
        // Cách vá: 1 câu nói liên tục không nghỉ hiếm khi vượt vài giây trong sử dụng bình thường
        // (đây cũng là 1 phần lý do maxSegmentMs tồn tại ở lớp trên) - nên nếu isVoice=true kéo
        // dài quá mốc này, coi đó là dấu hiệu đáng ngờ rằng thứ đang được tính là "giọng nói" thực
        // chất là nhiễu nền bị mắc kẹt, và bắt đầu cho noiseFloor trôi CHẬM về phía RMS hiện tại
        // ngay cả khi isVoice=true. Chỉ kích hoạt sau ngưỡng này (không phải từ giây đầu) nên câu
        // nói có độ dài thông thường hoàn toàn không bị ảnh hưởng - giữ nguyên tinh thần "không
        // đuổi theo giọng nói giữa câu" cho các câu bình thường.
        private const val STUCK_VOICE_RESCUE_MS = 4000L

        // Tốc độ trôi CHẬM HƠN NOISE_ADAPT_RATE khi đang ở chế độ "giải cứu" - cố tình chậm để
        // không làm noiseFloor nhảy vọt ngay khi vừa chạm mốc STUCK_VOICE_RESCUE_MS (vẫn có thể là
        // giọng nói thật kéo dài hiếm gặp), mà để nó trôi dần trong khoảng 0.5-2s tiếp theo (xấp xỉ
        // 1/rate frame ở framerate điển hình) - đủ để tiếng ồn nền thực sự hết vượt được
        // exitThreshold, nhưng không tức thời.
        private const val STUCK_RESCUE_ADAPT_RATE = 0.02
    }

    // Giá trị khởi tạo hợp lý cho audio PCM16 nói chung - VAD tự điều chỉnh lại chỉ sau vài
    // trăm ms audio thật (im lặng đầu phiên rất phổ biến nên hội tụ nhanh).
    private var noiseFloor = 200.0
    private var isVoice = false
    // Mốc thời gian (System.currentTimeMillis()) lúc hangover sẽ hết hạn - thay cho đếm khung.
    private var hangoverUntil = 0L
    // Mốc thời gian lúc isVoice chuyển false -> true GẦN NHẤT - dùng để phát hiện "kẹt voice=true
    // bất thường lâu" (xem STUCK_VOICE_RESCUE_MS).
    private var voiceStartedAt = 0L

    // now: mốc thời gian hiện tại (System.currentTimeMillis()) - CÙNG nguồn thời gian với
    // SttSegmentCutter.onFrame()/shouldFlush() (caller nên dùng chung 1 giá trị `now` đọc 1 lần
    // mỗi vòng lặp, xem SttReadLoop.kt, tránh gọi currentTimeMillis() lệch nhau vài mili-giây
    // giữa các lời gọi không cần thiết).
    // Gọi 1 lần mỗi khung audio (mỗi lần AudioRecord.read() trả về length > 0 mẫu).
    // Trả về true nếu khung này được coi là có giọng nói (không phải noise nền/im lặng).
    fun process(samples: ShortArray, length: Int, now: Long): Boolean {
        if (length <= 0) return isVoice

        var sumSquares = 0.0
        for (i in 0 until length) {
            val v = samples[i].toDouble()
            sumSquares += v * v
        }
        val rms = kotlin.math.sqrt(sumSquares / length)

        if (isVoice && now - voiceStartedAt > STUCK_VOICE_RESCUE_MS) {
            // "Giải cứu" khỏi trạng thái kẹt - xem rationale đầy đủ ở comment STUCK_VOICE_RESCUE_MS
            // phía trên. Chặn trên vẫn dùng chung MAX_NOISE_FLOOR như nhánh !isVoice để nhất quán
            // với giới hạn đã test cho kịch bản "nền tăng dần".
            noiseFloor += (rms - noiseFloor) * STUCK_RESCUE_ADAPT_RATE
            if (noiseFloor > MAX_NOISE_FLOOR) noiseFloor = MAX_NOISE_FLOOR
        }

        // Tính lại threshold SAU bước giải cứu ở trên (nếu có chạy) để chính khung hiện tại cũng
        // được đánh giá công bằng theo noiseFloor mới nhất, thay vì phải chờ thêm 1 khung nữa.
        val enterThreshold = maxOf(noiseFloor * ENTER_SPEECH_RATIO, MIN_NOISE_FLOOR * ENTER_SPEECH_RATIO)
        val exitThreshold = maxOf(noiseFloor * EXIT_SPEECH_RATIO, MIN_NOISE_FLOOR * EXIT_SPEECH_RATIO)

        if (!isVoice) {
            if (rms > enterThreshold) {
                isVoice = true
                voiceStartedAt = now
                hangoverUntil = now + HANGOVER_MS
            } else {
                noiseFloor += (rms - noiseFloor) * NOISE_ADAPT_RATE
                if (noiseFloor > MAX_NOISE_FLOOR) noiseFloor = MAX_NOISE_FLOOR
            }
        } else {
            if (rms > exitThreshold) {
                hangoverUntil = now + HANGOVER_MS // vẫn đang nói - refresh hangover
            } else if (now < hangoverUntil) {
                // còn trong thời gian hangover - giữ nguyên isVoice=true, không làm gì thêm
            } else {
                isVoice = false
            }
        }

        return isVoice
    }

    fun reset() {
        noiseFloor = 200.0
        isVoice = false
        hangoverUntil = 0L
        voiceStartedAt = 0L
    }
}
