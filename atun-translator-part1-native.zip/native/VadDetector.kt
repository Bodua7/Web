package com.atun.translator

// VAD (Voice Activity Detection) dựa trên năng lượng tín hiệu (RMS) với ngưỡng THÍCH NGHI theo
// nhiễu nền, thay cho ngưỡng biên độ đỉnh (peak) cố định trước đây (SILENCE_PEAK_THRESHOLD=50
// cứng trong AudioCaptureService). Ngưỡng cố định không đáng tin vì mức nhiễu nền chênh lệch rất
// lớn giữa các nguồn: video YouTube có nhạc nền to, ghi âm qua micro có tiếng ồn phòng/quạt, v.v.
// -> cùng 1 ngưỡng=50 có thể coi nhạc nền là "giọng nói" (nhiễu > 50) ở nguồn này, hoặc bỏ sót
// giọng nói yếu (< 50) ở nguồn khác.
//
// Không dùng thư viện VAD ngoài (WebRTC VAD / Silero VAD qua TFLite) để tránh thêm dependency
// native/model chưa build-test được (không có máy Android thật, chỉ build qua GitHub Actions
// CI) - có thể vỡ build mà không phát hiện được tới khi cài lên máy thật. Cách tiếp cận ở đây:
// energy-based VAD thích nghi + hysteresis + hangover - kỹ thuật kinh điển (cùng họ với VAD của
// ETSI AMR, ITU-T G.729 Annex B), thuần Kotlin, không phụ thuộc ngoài, dễ tune bằng vài hằng số.
//
// Cách hoạt động:
// 1. Mỗi khung audio (mỗi lần AudioRecord.read() trả về mẫu), tính RMS energy (mượt hơn peak vì
//    không bị lệch bởi 1-2 mẫu đột biến kiểu click/pop).
// 2. Khi ĐANG im lặng: liên tục cập nhật ước lượng "nhiễu nền" (noiseFloor) bằng RMS các khung
//    im lặng - CHỈ cập nhật lúc im lặng, không cập nhật lúc đang nói (nếu không noiseFloor sẽ
//    "đuổi theo" giọng nói và ngưỡng leo thang dần trong câu dài, làm mất nhạy).
// 3. Ngưỡng vào tiếng nói = noiseFloor * hệ số cao hơn ngưỡng ra tiếng nói (hysteresis) - tránh
//    hiện tượng "rung" (flicker) liên tục bật/tắt quanh biên khi energy dao động nhẹ quanh ngưỡng.
// 4. Hangover: giữ trạng thái "voice" thêm vài khung sau khi energy tụt dưới ngưỡng exit, vì âm
//    cuối từ/câu thường nhỏ dần từ từ chứ không tắt đột ngột - tránh cắt cụt đuôi từ.
class VadDetector {
    companion object {
        // Tốc độ thích nghi noise floor (EMA alpha). Nhỏ = thích nghi chậm, ổn định hơn với
        // nhiễu đột biến ngắn; lớn = bám sát nhiễu nền thay đổi nhanh hơn nhưng dễ bị nhiễu bởi
        // các đợt ồn ngắn. 0.05 tương đương noise floor cập nhật đáng kể sau ~1-2s audio.
        private const val NOISE_ADAPT_RATE = 0.05

        // Hệ số nhân noise floor để ra ngưỡng VÀO tiếng nói - cao hơn ngưỡng RA (EXIT) tạo
        // hysteresis. Tăng ENTER nếu VAD quá nhạy (bắt nhầm nhạc nền/ồn thành giọng nói); giảm
        // nếu bỏ sót giọng nói nhỏ.
        private const val ENTER_SPEECH_RATIO = 2.5
        private const val EXIT_SPEECH_RATIO = 1.6

        // Chặn dưới cho noise floor - tránh trường hợp có đoạn im lặng số tuyệt đối (digital
        // silence, RMS ~ 0) làm noise floor tụt gần 0, khiến ngưỡng vào tiếng nói cũng gần 0
        // theo (VAD sẽ coi mọi rung động nhỏ nhất là "có giọng nói").
        private const val MIN_NOISE_FLOOR = 30.0

        // Chặn TRÊN cho noise floor - bug thực tế: video có đoạn đầu không phải giọng nói
        // nhưng cũng không im lặng tuyệt đối, mà TĂNG DẦN theo thời gian (nhạc dạo đầu to dần
        // kiểu crescendo, hiệu ứng âm thanh intro...). Với 1 mức nhiễu HẰNG SỐ thì noiseFloor
        // tự hội tụ về đúng mức đó rồi dừng (không vượt quá, do bản chất EMA) nên không đáng lo -
        // nhưng khi nhiễu nền tăng DẦN, ngưỡng vào tiếng nói (enterThreshold = noiseFloor *
        // ENTER_SPEECH_RATIO) luôn bám kịp NGAY DƯỚI rms hiện tại của đoạn tăng dần đó (miễn
        // rms tăng đủ chậm so với NOISE_ADAPT_RATE) -> không frame nào bị coi là voice trong cả
        // đoạn -> noiseFloor cứ thế bị "kéo" lên theo, có thể lên rất cao chỉ sau một đoạn nhạc
        // dạo vài giây. Ngưỡng vào tiếng nói khi đó có thể vượt quá RMS của giọng nói thật lúc
        // người nói bắt đầu -> isVoice không bao giờ thành true nữa cho CẢ PHIÊN -> smartPause
        // (AudioCaptureService) bị kẹt vì pauseHandled chỉ reset khi VAD báo có voice ->
        // forcePauseFinal() không gọi lại được nữa -> phụ đề phải chờ endpointer nội bộ (chậm
        // hơn, chốt câu trễ/dính nhiều câu vào nhau). Đã tái hiện + test lại đúng kịch bản này ở
        // tests/vad/test_vad_detector.py (test_noise_floor_capped_when_background_ramps_up_gradually).
        // Chặn trên này giới hạn thiệt hại: dù nền tăng dần tới đâu, ngưỡng vào tiếng nói tối đa
        // vẫn ở mức hợp lý để giọng nói bình thường (nói to hơn nhạc nền, đặc điểm phổ biến của
        // video có lồng tiếng/thuyết minh) vẫn vượt qua được.
        private const val MAX_NOISE_FLOOR = 1500.0

        // Thời lượng (ms) giữ trạng thái "voice" sau khi energy đã tụt dưới ngưỡng exit - tính
        // theo MỐC THỜI GIAN, không đếm số khung.
        // Fix (audit VAD/môi trường): trước đây là HANGOVER_FRAMES=4 (đếm số lần gọi process()).
        // Đây là LỖI ĐƠN VỊ thật, không phải chỗ "tune cho hay hơn": thời lượng 1 khung phụ thuộc
        // minBufferSize của AudioRecord (kích thước buffer đọc mỗi lần record.read()), vốn KHÁC
        // NHAU giữa các thiết bị/cấu hình Android (AudioRecord.getMinBufferSize() không đảm bảo
        // trả về cùng 1 giá trị trên mọi máy) - cùng 1 hằng số "4 khung" có thể là ~150ms trên máy
        // này nhưng ~500ms+ trên máy khác, tức hành vi cắt câu (đuôi từ bị cụt hay không) thay đổi
        // theo THIẾT BỊ chứ không phải theo chủ ý - đúng loại lỗi "theo môi trường" nêu trong audit.
        // 250ms chọn dựa trên đặc tính phổ biến của tiếng nói (âm cuối từ/câu thường tắt dần trong
        // khoảng 150-300ms chứ không tắt đột ngột) - áp dụng NHẤT QUÁN trên mọi thiết bị từ giờ.
        private const val HANGOVER_MS = 250L
    }

    // Giá trị khởi tạo hợp lý cho audio PCM16 nói chung - VAD tự điều chỉnh lại chỉ sau vài
    // trăm ms audio thật (im lặng đầu phiên rất phổ biến nên hội tụ nhanh).
    private var noiseFloor = 200.0
    private var isVoice = false
    // Mốc thời gian (System.currentTimeMillis()) lúc hangover sẽ hết hạn - thay cho đếm khung.
    private var hangoverUntil = 0L

    // now: mốc thời gian hiện tại (System.currentTimeMillis()) - CÙNG nguồn thời gian với
    // SttSegmentCutter.onFrame()/shouldFlush() (caller nên dùng chung 1 giá trị `now` đọc 1 lần
    // mỗi vòng lặp, xem SttReadLoop.kt, tránh gọi currentTimeMillis() lệch nhau vài mili-giây
    // giữa các lời gọi không cần thiết).
    // Gọi 1 lần mỗi khung audio (mỗi lần AudioRecord.read() trả về length > 0 mẫu).
    // Trả về true nếu khung này được coi là có giọng nói (không phải noise nền/im lặng).
    fun process(samples: ShortArray, length: Int, now: Long): Boolean {
        if (length <= 0) return isVoice

        var sumSquares = 0.0
        for (i in 0 until length) {
            val v = samples[i].toDouble()
            sumSquares += v * v
        }
        val rms = kotlin.math.sqrt(sumSquares / length)

        val enterThreshold = maxOf(noiseFloor * ENTER_SPEECH_RATIO, MIN_NOISE_FLOOR * ENTER_SPEECH_RATIO)
        val exitThreshold = maxOf(noiseFloor * EXIT_SPEECH_RATIO, MIN_NOISE_FLOOR * EXIT_SPEECH_RATIO)

        if (!isVoice) {
            if (rms > enterThreshold) {
                isVoice = true
                hangoverUntil = now + HANGOVER_MS
            } else {
                noiseFloor += (rms - noiseFloor) * NOISE_ADAPT_RATE
                if (noiseFloor > MAX_NOISE_FLOOR) noiseFloor = MAX_NOISE_FLOOR
            }
        } else {
            if (rms > exitThreshold) {
                hangoverUntil = now + HANGOVER_MS // vẫn đang nói - refresh hangover
            } else if (now < hangoverUntil) {
                // còn trong thời gian hangover - giữ nguyên isVoice=true, không làm gì thêm
            } else {
                isVoice = false
            }
        }

        return isVoice
    }

    fun reset() {
        noiseFloor = 200.0
        isVoice = false
        hangoverUntil = 0L
    }
}
