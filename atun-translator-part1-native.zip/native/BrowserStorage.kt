package com.atun.translator

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

// Lưu bookmark + lịch sử duyệt của BrowserActivity ("web mini") bằng SharedPreferences + JSON -
// đơn giản, không kéo thêm dependency Room/SQLite chỉ cho 1 tính năng phụ tách biệt hoàn toàn
// khỏi app dịch chính. Lịch sử giới hạn HISTORY_MAX mục gần nhất để tránh phình to vô hạn theo
// thời gian sử dụng.
class BrowserStorage(context: Context) {
    companion object {
        private const val PREFS_NAME = "browser_mini"
        private const val KEY_BOOKMARKS = "bookmarks"
        private const val KEY_HISTORY = "history"
        private const val HISTORY_MAX = 200
        private const val KEY_OPEN_TABS = "open_tabs"
        private const val KEY_ACTIVE_TAB_INDEX = "active_tab_index"
        private const val KEY_AD_BLOCK_ENABLED = "ad_block_enabled"
        private const val KEY_NIGHT_MODE_ENABLED = "night_mode_enabled"
    }

    data class Entry(val title: String, val url: String, val timestamp: Long = System.currentTimeMillis())

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private fun readArray(key: String): JSONArray {
        val raw = prefs.getString(key, null) ?: return JSONArray()
        return try {
            JSONArray(raw)
        } catch (e: Exception) {
            JSONArray()
        }
    }

    private fun writeArray(key: String, arr: JSONArray) {
        prefs.edit().putString(key, arr.toString()).apply()
    }

    private fun entryToJson(e: Entry) = JSONObject().apply {
        put("title", e.title)
        put("url", e.url)
        put("timestamp", e.timestamp)
    }

    private fun jsonToEntry(o: JSONObject) = Entry(
        title = o.optString("title", o.optString("url", "")),
        url = o.optString("url", ""),
        timestamp = o.optLong("timestamp", 0L)
    )

    // ===== History =====
    // Mục mới nhất luôn ở đầu danh sách; nếu URL đã có trong lịch sử thì gỡ bản cũ ra trước khi
    // chèn lại lên đầu, tránh cùng 1 trang lặp lại nhiều lần khi người dùng ghé đi ghé lại.
    fun addHistory(url: String, title: String) {
        if (url.isBlank()) return
        val old = readArray(KEY_HISTORY)
        val merged = JSONArray()
        merged.put(entryToJson(Entry(title.ifBlank { url }, url)))
        for (i in 0 until old.length()) {
            val o = old.getJSONObject(i)
            if (o.optString("url") != url) merged.put(o)
        }
        val trimmed = JSONArray()
        for (i in 0 until minOf(merged.length(), HISTORY_MAX)) trimmed.put(merged.get(i))
        writeArray(KEY_HISTORY, trimmed)
    }

    fun getHistory(): List<Entry> {
        val arr = readArray(KEY_HISTORY)
        return (0 until arr.length()).map { jsonToEntry(arr.getJSONObject(it)) }
    }

    fun clearHistory() = writeArray(KEY_HISTORY, JSONArray())

    // ===== Bookmarks =====
    fun isBookmarked(url: String): Boolean = getBookmarks().any { it.url == url }

    fun addBookmark(url: String, title: String) {
        if (url.isBlank() || isBookmarked(url)) return
        val arr = readArray(KEY_BOOKMARKS)
        arr.put(entryToJson(Entry(title.ifBlank { url }, url)))
        writeArray(KEY_BOOKMARKS, arr)
    }

    fun removeBookmark(url: String) {
        val arr = readArray(KEY_BOOKMARKS)
        val kept = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("url") != url) kept.put(o)
        }
        writeArray(KEY_BOOKMARKS, kept)
    }

    fun getBookmarks(): List<Entry> {
        val arr = readArray(KEY_BOOKMARKS)
        return (0 until arr.length()).map { jsonToEntry(arr.getJSONObject(it)) }
    }

    // ===== Phiên tab đang mở =====
    // Chỉ lưu URL hiện tại của từng tab + tab nào đang active - KHÔNG lưu lại được back/forward
    // stack chi tiết của WebView (cần Bundle/Parcel phức tạp hơn nhiều so với SharedPreferences
    // + JSON đang dùng cho cả file này) - đây là đánh đổi hợp lý: mất lịch sử back trong tab đó,
    // nhưng không mất trắng tab đang xem nếu Android kill Activity ở nền giữa lúc dùng.
    fun saveOpenTabs(urls: List<String>, activeIndex: Int) {
        val arr = JSONArray()
        urls.forEach { arr.put(it) }
        prefs.edit()
            .putString(KEY_OPEN_TABS, arr.toString())
            .putInt(KEY_ACTIVE_TAB_INDEX, activeIndex)
            .apply()
    }

    fun getOpenTabs(): Pair<List<String>, Int> {
        val raw = prefs.getString(KEY_OPEN_TABS, null) ?: return Pair(emptyList(), 0)
        val arr = try { JSONArray(raw) } catch (e: Exception) { JSONArray() }
        val urls = (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
        return Pair(urls, prefs.getInt(KEY_ACTIVE_TAB_INDEX, 0))
    }

    // ===== Chặn quảng cáo (web mini) =====
    // Mặc định BẬT. Có nút tắt trong menu vì chặn theo domain đôi khi khớp nhầm domain trang
    // thật cần dùng để hoạt động đúng (false positive) - cho người dùng tắt nhanh không cần
    // build lại app, thay vì cứng luôn không tắt được.
    fun isAdBlockEnabled(): Boolean = prefs.getBoolean(KEY_AD_BLOCK_ENABLED, true)

    fun setAdBlockEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_AD_BLOCK_ENABLED, enabled).apply()
    }

    // ===== Chế độ Ngày/Đêm (web mini) =====
    // Mặc định TẮT (giao diện sáng như trước đây) - chỉ áp dụng cho riêng "Web mini"
    // (BrowserActivity), không đụng tới màn hình dịch chính (www/index.html). Lưu lại để mở
    // web mini lần sau vẫn giữ đúng chế độ đã chọn, không phải bật lại tay mỗi lần.
    fun isNightModeEnabled(): Boolean = prefs.getBoolean(KEY_NIGHT_MODE_ENABLED, false)

    fun setNightModeEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_NIGHT_MODE_ENABLED, enabled).apply()
    }
}
