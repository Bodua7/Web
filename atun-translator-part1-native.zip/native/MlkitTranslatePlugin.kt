package com.atun.translator

import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions

// Dịch on-device bằng Google ML Kit Translate - thay thế 2 endpoint free hiện tại
// (Google Translate free hay bị 429, groq-relay phụ thuộc server ngoài + đổi model liên tục)
// bằng model chạy thẳng trên máy: không rate-limit, hoạt động cả khi mất mạng (SAU khi đã
// tải model 1 lần) - đúng triết lý "chạy trên máy" mà STT (Vosk) đang theo.
//
// KHÁC cơ chế ModelManagerPlugin (tự tải .zip từ URL GitHub Release do mình host, tự giải
// nén): ML Kit Translate TỰ quản lý việc tải/lưu model của nó qua RemoteModelManager, không
// qua URL mình cấu hình, và không có % tiến độ chi tiết (chỉ có callback thành công/thất
// bại) - nên plugin này không dùng lại được y nguyên downloadWithProgress() của
// ModelManagerPlugin, chỉ mô phỏng lại pattern sự kiện (mlkitDownloadDone) cho nhất quán
// phía JS.
@CapacitorPlugin(name = "MlkitTranslate")
class MlkitTranslatePlugin : com.getcapacitor.Plugin() {

    companion object {
        // Map mã ngôn ngữ app đang dùng (xem <select id="targetLang"/"sourceLang"> trong
        // index.html, và ModelManagerPlugin.CATALOG cho danh sách STT đầy đủ) sang hằng số
        // TranslateLanguage của ML Kit. "en-large"/"en-in" chỉ là biến thể model Vosk khác cho
        // STT (chính xác cao hơn / giọng Ấn Độ) - với dịch thì vẫn là tiếng Anh bình thường.
        //
        // BUG đã sửa: trước đây chỉ có 5 ngôn ngữ (vi/en/ja/ko/zh) trong khi CATALOG STT có
        // ~30 ngôn ngữ - nghe bằng các ngôn ngữ còn lại (fr, de, ru, ar...) thì dịch on-device
        // luôn fail (toMlkitLang() trả null) dù ML Kit Translate thực ra hỗ trợ hầu hết các
        // ngôn ngữ đó, khiến app luôn phải fallback qua mạng (Google Translate free/groq-relay)
        // một cách không cần thiết. Giờ mở rộng theo đúng danh sách ML Kit Translate hỗ trợ
        // (com.google.mlkit.nl.translate.TranslateLanguage, ~59 ngôn ngữ) - chỉ 5 mã trong
        // CATALOG hiện KHÔNG có trong ML Kit nên phải bỏ qua (vẫn tự fallback mạng như cũ, đúng
        // hành vi trước đây): "kz" (Kazakh), "uz" (Uzbek), "tg" (Tajik), "ky" (Kyrgyz), "br"
        // (Breton).
        private val LANG_MAP: Map<String, String> = mapOf(
            "vi" to TranslateLanguage.VIETNAMESE,
            // "en": từ khi ModelManagerPlugin.CATALOG gộp 3 biến thể "en"/"en-lgraph"/"en-large"
            // thành 1 mã "en" duy nhất (trỏ model lgraph ~128MB), 2 dòng map riêng "en-large" và
            // "en-lgraph" trước đây không còn cần thiết nữa (những mã đó không còn tồn tại trong
            // CATALOG) - chỉ giữ lại "en" và "en-in" (biến thể giọng Ấn Độ, vẫn còn trong CATALOG).
            "en" to TranslateLanguage.ENGLISH,
            "en-in" to TranslateLanguage.ENGLISH,
            "ja" to TranslateLanguage.JAPANESE,
            "ko" to TranslateLanguage.KOREAN,
            "zh-CN" to TranslateLanguage.CHINESE,
            "zh" to TranslateLanguage.CHINESE,
            "ru" to TranslateLanguage.RUSSIAN,
            "fr" to TranslateLanguage.FRENCH,
            "de" to TranslateLanguage.GERMAN,
            "es" to TranslateLanguage.SPANISH,
            "pt" to TranslateLanguage.PORTUGUESE,
            "tr" to TranslateLanguage.TURKISH,
            "it" to TranslateLanguage.ITALIAN,
            "nl" to TranslateLanguage.DUTCH,
            "ca" to TranslateLanguage.CATALAN,
            // "ar"/"sv"/"tl"/"el" đã bị xoá (theo cùng ModelManagerPlugin.CATALOG - 4 ngôn ngữ
            // STT này không có bản "small" dưới 200MB nên đã bỏ hẳn khỏi app, xem CATALOG). ML
            // Kit Translate tự nó vẫn hỗ trợ 4 ngôn ngữ này (TranslateLanguage.ARABIC/SWEDISH/
            // TAGALOG/GREEK vẫn tồn tại trong SDK) nhưng bỏ khỏi LANG_MAP vì app không còn đường
            // nào để tạo văn bản gốc ở các ngôn ngữ này nữa (không có STT) - giữ lại chỉ gây rối
            // UI "Quản lý mô hình ngôn ngữ" (mục dịch cho ngôn ngữ không nghe được).
            "fa" to TranslateLanguage.PERSIAN,
            "uk" to TranslateLanguage.UKRAINIAN,
            "eo" to TranslateLanguage.ESPERANTO,
            "hi" to TranslateLanguage.HINDI,
            "cs" to TranslateLanguage.CZECH,
            "pl" to TranslateLanguage.POLISH,
            "gu" to TranslateLanguage.GUJARATI,
            "te" to TranslateLanguage.TELUGU,
            "ka" to TranslateLanguage.GEORGIAN
        )

        fun toMlkitLang(appCode: String): String? = LANG_MAP[appCode]
    }

    // Cache Translator theo cặp "src-tgt" - tạo 1 lần dùng lại nhiều lần, vì mỗi Translator
    // giữ 1 phiên TFLite interpreter, tạo lại mỗi câu sẽ rất tốn thời gian/pin.
    private val translators = mutableMapOf<String, Translator>()

    private fun translatorFor(srcLang: String, tgtLang: String): Translator {
        val key = "$srcLang-$tgtLang"
        return translators.getOrPut(key) {
            val options = TranslatorOptions.Builder()
                .setSourceLanguage(srcLang)
                .setTargetLanguage(tgtLang)
                .build()
            Translation.getClient(options)
        }
    }

    @PluginMethod
    fun isLanguageSupported(call: PluginCall) {
        val lang = call.getString("lang") ?: ""
        val ret = JSObject()
        ret.put("supported", toMlkitLang(lang) != null)
        call.resolve(ret)
    }

    @PluginMethod
    fun listDownloadedModels(call: PluginCall) {
        RemoteModelManager.getInstance()
            .getDownloadedModels(TranslateRemoteModel::class.java)
            .addOnSuccessListener { models ->
                val arr = JSArray()
                for (m in models) arr.put(m.language)
                val ret = JSObject()
                ret.put("languages", arr)
                call.resolve(ret)
            }
            .addOnFailureListener { e -> call.reject(e.message ?: "listDownloadedModels lỗi", e) }
    }

    // Tải model dịch cho 1 ngôn ngữ app (vd "vi") - ML Kit tự dịch qua tiếng Anh làm trung
    // gian khi cặp nguồn/đích không hỗ trợ dịch thẳng, nên chỉ cần tải model của TỪNG ngôn
    // ngữ (không phải từng CẶP): gọi hàm này riêng cho cả sourceLang và targetLang trước khi
    // dịch, qua UI "Quản lý mô hình ngôn ngữ". requireWifi mặc định false vì model chỉ
    // ~30MB/ngôn ngữ, cho phép tải qua 4G/5G nếu cần.
    // Ngưỡng dung lượng trống tối thiểu trước khi tải model dịch ML Kit - model dịch ~30MB/ngôn
    // ngữ, nhưng downloadModelIfNeeded() có thể tự tải kèm model tiếng Anh trung gian (pivot,
    // xem comment ở downloadModel() bên dưới) nên tối đa cần ~2 model cùng lúc + đệm an toàn.
    private val MLKIT_REQUIRED_FREE_BYTES = 150L * 1024 * 1024

    @PluginMethod
    fun downloadModel(call: PluginCall) {
        val appLang = call.getString("lang")
        val requireWifi = call.getBoolean("requireWifi", false) ?: false
        val mlkitLang = appLang?.let { toMlkitLang(it) }
        if (mlkitLang == null) {
            call.reject("Ngôn ngữ không hỗ trợ dịch on-device: $appLang")
            return
        }

        // Cảnh báo dung lượng trống TRƯỚC khi tải - áp dụng cùng logic đã làm cho model Vosk
        // (xem ModelManagerPlugin.downloadModel) để tránh lỗi "No space left on device" khó
        // hiểu từ ML Kit giữa chừng, dù model ML Kit nhỏ hơn nhiều so với Vosk.
        val freeBytes = context.filesDir.usableSpace
        if (freeBytes < MLKIT_REQUIRED_FREE_BYTES) {
            val freeMB = freeBytes / 1024 / 1024
            call.reject("Không đủ dung lượng trống để tải model dịch (cần khoảng 150MB, máy còn ${freeMB}MB). Hãy giải phóng bớt bộ nhớ rồi thử lại.")
            return
        }

        val conditions = DownloadConditions.Builder().apply {
            if (requireWifi) requireWifi()
        }.build()

        // Dùng Translator.downloadModelIfNeeded() (không gọi RemoteModelManager.download()
        // trực tiếp) vì nó tự tải kèm model tiếng Anh trung gian (pivot) nếu ngôn ngữ này
        // không dịch thẳng được sang/từ ngôn ngữ còn lại trong cặp - RemoteModelManager
        // .download() một mình chỉ tải đúng 1 model lẻ, có thể thiếu model pivot cần thiết.
        val pivot = if (mlkitLang == TranslateLanguage.ENGLISH) TranslateLanguage.VIETNAMESE else TranslateLanguage.ENGLISH
        val translator = translatorFor(mlkitLang, pivot)

        translator.downloadModelIfNeeded(conditions)
            .addOnSuccessListener {
                emitDone(appLang, success = true, error = null)
                call.resolve(JSObject().apply { put("success", true) })
            }
            .addOnFailureListener { e ->
                emitDone(appLang, success = false, error = e.message ?: e.toString())
                call.reject(e.message ?: "Tải model dịch thất bại", e)
            }
    }

    @PluginMethod
    fun deleteModel(call: PluginCall) {
        val appLang = call.getString("lang")
        val mlkitLang = appLang?.let { toMlkitLang(it) }
        if (mlkitLang == null) {
            call.reject("Ngôn ngữ không hỗ trợ: $appLang")
            return
        }
        val model = TranslateRemoteModel.Builder(mlkitLang).build()
        RemoteModelManager.getInstance().deleteDownloadedModel(model)
            .addOnSuccessListener {
                // Đóng + bỏ cache mọi Translator có dùng ngôn ngữ này để lần dịch sau tạo lại
                // (tránh giữ tham chiếu tới model vừa xoá, dễ gây lỗi ngầm khi dịch tiếp).
                val toRemove = translators.keys.filter { it.startsWith("$mlkitLang-") || it.endsWith("-$mlkitLang") }
                for (k in toRemove) translators.remove(k)?.close()
                call.resolve()
            }
            .addOnFailureListener { e -> call.reject(e.message ?: "Xoá model thất bại", e) }
    }

    // Dịch 1 đoạn text (có thể là 1 cụm nhiều câu gộp lại, xem batching phía JS). GIẢ ĐỊNH
    // model của cả sourceLang và targetLang đã tải xong (gọi downloadModel() trước qua UI
    // "Quản lý mô hình ngôn ngữ"). Nếu chưa tải, ML Kit sẽ tự thử tải qua mạng ngay trong lúc
    // dịch (có thể chậm/lỗi nếu đang offline) - JS phía trên nên fallback sang Google
    // Translate free/groq-relay khi call này reject.
    @PluginMethod
    fun translate(call: PluginCall) {
        val text = call.getString("text")
        val sourceLang = call.getString("sourceLang")
        val targetLang = call.getString("targetLang")
        if (text.isNullOrEmpty() || sourceLang == null || targetLang == null) {
            call.reject("Thiếu tham số text/sourceLang/targetLang.")
            return
        }
        val src = toMlkitLang(sourceLang)
        val tgt = toMlkitLang(targetLang)
        if (src == null || tgt == null) {
            call.reject("Ngôn ngữ không hỗ trợ dịch on-device (source=$sourceLang, target=$targetLang).")
            return
        }
        if (src == tgt) {
            call.resolve(JSObject().apply { put("translated", text) })
            return
        }

        val translator = translatorFor(src, tgt)
        val conditions = DownloadConditions.Builder().build()
        translator.downloadModelIfNeeded(conditions)
            .addOnSuccessListener {
                translator.translate(text)
                    .addOnSuccessListener { translated ->
                        call.resolve(JSObject().apply { put("translated", translated) })
                    }
                    .addOnFailureListener { e -> call.reject(e.message ?: "Dịch lỗi", e) }
            }
            .addOnFailureListener { e -> call.reject("Model chưa sẵn sàng: " + (e.message ?: e.toString()), e) }
    }

    private fun emitDone(lang: String?, success: Boolean, error: String?) {
        val data = JSObject()
        data.put("lang", lang)
        data.put("success", success)
        if (error != null) data.put("error", error)
        notifyListeners("mlkitDownloadDone", data)
    }
}
