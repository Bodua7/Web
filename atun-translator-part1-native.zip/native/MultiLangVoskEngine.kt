package com.atun.translator

import android.content.Context

// ===== Chế độ "Tự động nhận diện" khi người nói xen kẽ nhiều ngôn ngữ trong cùng 1 phiên =====
// Vosk KHÔNG có model nhận diện ngôn ngữ (LID) riêng biệt. Cách khả thi với những gì Vosk cung
// cấp: chạy SONG SONG 1 Recognizer riêng cho MỖI ngôn ngữ đã tải (xem
// ModelCatalog.readyLangsForAuto), cùng nhận Y HỆT 1 luồng PCM, rồi ở mỗi lần "chốt câu"
// (final), so sánh độ tin cậy (confidence trung bình theo từ) mà TỪNG recognizer tự chấm cho kết
// quả của nó và chọn recognizer có confidence cao nhất - vì recognizer đúng ngôn ngữ thường cho
// confidence cao hẳn so với recognizer sai ngôn ngữ (model sai ngôn ngữ decode ra những từ nghe
// gần giống về âm nhưng không khớp ngữ cảnh, Vosk tự chấm confidence thấp cho các từ kiểu này).
//
// Đánh đổi: tốn CPU/RAM gấp N lần (N = số ngôn ngữ bật cùng lúc, xem MAX_AUTO_LANGS) vì phải
// chạy N Recognizer thật sự song song trên CÙNG 1 khung audio. Vì vậy danh sách langs truyền vào
// đây LUÔN được lọc trước ở ModelCatalog.readyLangsForAuto (loại model quá lớn, giới hạn
// số lượng) - class này không tự kiểm tra lại các ràng buộc đó.
//
// Quan trọng: feed()/forcePauseFinal() gọi engine.feed()/engine.forcePauseFinal() của TỪNG
// VoskEngine con TUẦN TỰ trên CÙNG 1 thread gọi vào (không spawn thread riêng cho mỗi ngôn ngữ) -
// nhờ vậy callback onEvent của mỗi engine con chạy ĐỒNG BỘ ngay trong lệnh gọi, cho phép gom hết
// kết quả Final của mọi ngôn ngữ trong đúng 1 lượt feed() rồi so sánh, KHÔNG cần khoá/hàng đợi gì
// thêm. Đánh đổi: tổng thời gian xử lý 1 khung audio = tổng thời gian của N recognizer cộng lại
// (không chạy thật sự song song trên nhiều lõi CPU) - chấp nhận được vì mỗi model "small" xử lý
// 1 khung rất nhanh (vài ms), N<=MAX_AUTO_LANGS nhỏ.
class MultiLangVoskEngine(
    context: Context,
    sampleRate: Float,
    langs: List<String>,
    private val onEvent: (VoskEngine.Event) -> Unit
) : SttEngine {

    private class Sub(val lang: String, val engine: VoskEngine) {
        @Volatile var ready = false
        // "Đã xong lượt load" - ready THÀNH CÔNG hoặc đã LỖI hẳn (model hỏng/tải dở dang).
        // Khác `ready`: `settled` chỉ báo "không còn chờ nữa", không đảm bảo dùng được.
        @Volatile var settled = false
        var lastPartial: String = ""
        // (text, confidence) của lượt feed()/forcePauseFinal() ĐANG XỬ LÝ - reset về null đầu
        // mỗi lượt gọi, chỉ tồn tại trong đúng 1 lượt để resolveFinalsIfAny() gom lại so sánh.
        var pendingFinal: Pair<String, Double>? = null
    }

    private val subs: List<Sub> = langs.mapNotNull { lang ->
        val source = VoskEngine.resolveModelSource(context, lang) ?: return@mapNotNull null
        lateinit var sub: Sub
        val engine = VoskEngine(context, sampleRate, source) { event -> handleSubEvent(sub, event) }
        sub = Sub(lang, engine)
        sub
    }

    @Volatile private var readyCount = 0
    // Số sub đã "settled" (ready hoặc lỗi hẳn) - xem maybeNotifyReady().
    @Volatile private var settledCount = 0
    @Volatile private var allReadyNotified = false
    // Ngôn ngữ "đang thắng" của câu final GẦN NHẤT - ưu tiên hiển thị partial của nó tiếp theo,
    // đỡ nhấp nháy đổi ngôn ngữ hiển thị liên tục giữa chừng 1 câu do các recognizer dao động
    // confidence khi câu chưa nói xong.
    @Volatile private var leadingLang: String? = null

    // ===== LID thật (xem LidEngine.kt) - CHỈ dùng làm trọng tài phụ khi 2+ candidate confidence
    // gần bằng nhau (xem TIE_CONFIDENCE_DELTA + resolveFinalsIfAny()), không thay thế cách phân
    // xử qua confidence hiện có. Tự động "có" nếu model đã được tải qua
    // ModelManagerPlugin.downloadLidModel() - không cần cờ bật/tắt riêng, tải model = bật tính
    // năng, xoá model (deleteLidModel) = tắt, giống đúng cách các model Vosk khác đang hoạt động
    // (isDownloaded quyết định sẵn sàng, không có toggle riêng biệt).
    private val lidEngine: LidEngine? = if (LidEngine.isDownloaded(context)) LidEngine(context) else null

    // Chênh lệch confidence tối đa giữa 2 candidate đứng đầu để còn coi là "mù mờ" (thang
    // confidence Vosk 0.0-1.0, xem VoskEngine.CONFIDENCE_DROP_THRESHOLD=0.35) - dưới ngưỡng này
    // mới đáng hỏi thêm LID (tốn thêm 1 lượt inference ONNX), cách nhau rõ ràng hơn thì tin
    // thẳng recognizer confidence cao hơn như cũ, không cần trọng tài.
    private companion object {
        const val TIE_CONFIDENCE_DELTA = 0.15
    }

    // Ring buffer PCM16 giữ lại ĐÚNG LidEngine.LID_WINDOW_SAMPLES mẫu gần nhất (xuyên suốt mọi
    // sub-engine, vì mọi sub nhận CÙNG 1 luồng audio - xem feed()) để có sẵn cửa sổ audio hỏi
    // LID ngay khi cần, không phải giữ lại audio "vô thời hạn" tốn RAM.
    private val recentPcm: ShortArray? = if (lidEngine != null) ShortArray(LidEngine.LID_WINDOW_SAMPLES) else null
    private var recentPcmWritePos = 0
    private var recentPcmFilled = 0

    override fun init() {
        subs.forEach { it.engine.init() }
        // Lỗi init LID (model hỏng, ONNX Runtime thiếu native lib...) không được làm treo/lỗi
        // cả phiên nghe - lidEngine.init() tự bọc try/catch trả false, ở đây chỉ đơn giản là
        // tính năng phụ trợ không khả dụng, mọi thứ khác chạy y hệt như trước khi có LID.
        lidEngine?.init()
    }

    private fun appendRecentPcm(pcm: ShortArray, length: Int) {
        val buf = recentPcm ?: return
        for (i in 0 until length) {
            buf[recentPcmWritePos] = pcm[i]
            recentPcmWritePos = (recentPcmWritePos + 1) % buf.size
        }
        recentPcmFilled = minOf(recentPcmFilled + length, buf.size)
    }

    // Trả về bản chụp cửa sổ audio gần nhất theo ĐÚNG thứ tự thời gian (cũ -> mới), hoặc null
    // nếu chưa đủ dữ liệu (đầu phiên nghe, chưa đủ 1.5s audio đã feed qua).
    private fun snapshotRecentPcm(): ShortArray? {
        val buf = recentPcm ?: return null
        if (recentPcmFilled < buf.size) return null // chưa đầy vòng - đơn giản hoá, đợi đủ 1.5s
        val out = ShortArray(buf.size)
        for (i in 0 until buf.size) out[i] = buf[(recentPcmWritePos + i) % buf.size]
        return out
    }

    private fun handleSubEvent(sub: Sub, event: VoskEngine.Event) {
        when (event) {
            is VoskEngine.Event.ModelReady -> {
                if (!sub.settled) {
                    sub.ready = true
                    sub.settled = true
                    readyCount++
                    settledCount++
                    maybeNotifyReady()
                }
            }
            is VoskEngine.Event.Partial -> sub.lastPartial = event.text
            is VoskEngine.Event.Final -> sub.pendingFinal = event.text to event.confidence
            // Vẫn gom vào để so sánh confidence tổng hợp - việc lọc "câu rác" ở mức tổng hợp làm
            // trong resolveFinalsIfAny(), không lọc riêng theo từng recognizer con ở đây (1
            // recognizer bị coi "low confidence" không có nghĩa recognizer khác cũng vậy).
            is VoskEngine.Event.LowConfidence -> sub.pendingFinal = event.text to event.confidence
            is VoskEngine.Event.Error -> {
                // BUG đã sửa: trước đây Error không được tính là "đã xử lý xong lượt load" -
                // nếu model của 1 ngôn ngữ hỏng/tải dở dang (constructor Model() throw ở thread
                // riêng trong VoskEngine.initFromPath()), sub đó `ready` mãi mãi là false,
                // readyCount không bao giờ chạm subs.size -> ModelReady tổng không bao giờ được
                // báo ra ngoài -> UI kẹt "Model: đang tải..." vĩnh viễn dù các ngôn ngữ còn lại
                // vẫn load xong bình thường. Giờ Error cũng tính vào settledCount (đã "xong lượt
                // load", dù không thành công) để không chặn các sub khác mãi mãi.
                if (!sub.settled) {
                    sub.settled = true
                    settledCount++
                    maybeNotifyReady()
                }
                onEvent(VoskEngine.Event.Error("[${sub.lang}] ${event.message}"))
            }
            is VoskEngine.Event.DetectedFinal -> Unit // không xảy ra: sub-engine là VoskEngine thường, không tự bắn cái này
            is VoskEngine.Event.LoadingProgress -> Unit // không xảy ra: sub-engine con không tự bắn cái này, chỉ MultiLangVoskEngine bắn ra ngoài (xem maybeNotifyReady)
        }
    }

    // Chỉ báo "sẵn sàng" ra ngoài (bật nút nghe) khi TẤT CẢ sub đã "settled" (ready hoặc lỗi hẳn)
    // - vẫn giữ đúng ý định gốc "đợi đủ mọi ngôn ngữ trước khi bắt đầu nghe" (bắt đầu sớm hơn sẽ
    // bỏ lỡ audio ở các recognizer còn đang load), nhưng KHÔNG còn treo vĩnh viễn nếu 1 (hoặc
    // nhiều, nhưng không phải tất cả) sub lỗi hẳn - chỉ cần settledCount == subs.size là đủ,
    // không bắt buộc readyCount == subs.size như trước.
    private fun maybeNotifyReady() {
        if (allReadyNotified) return
        // Báo tiến độ ra ngoài MỖI LẦN có thêm 1 sub settled (kể cả khi chưa đủ cả subs.size) -
        // để UI vẽ progress bar thật (vd "2/4 model đã sẵn sàng") thay vì text tĩnh "đang tải..."
        // suốt cả quá trình load nhiều model song song ở chế độ "Tự động nhận diện".
        onEvent(VoskEngine.Event.LoadingProgress(settledCount, subs.size))
        if (settledCount < subs.size) return // vẫn còn sub đang load dở, đợi tiếp

        allReadyNotified = true
        if (readyCount == 0) {
            // Trường hợp cực hiếm: TẤT CẢ ngôn ngữ đều lỗi - không còn recognizer nào dùng
            // được, báo lỗi rõ ràng thay vì im lặng treo mãi ở "đang tải...".
            onEvent(VoskEngine.Event.Error(
                "Không có model nào trong chế độ tự động nhận diện load được - kiểm tra lại " +
                    "các model đã tải ở mục \"Quản lý mô hình ngôn ngữ\"."
            ))
        } else {
            onEvent(VoskEngine.Event.ModelReady)
        }
    }

    override fun feed(pcm: ShortArray, length: Int) {
        for (sub in subs) sub.pendingFinal = null
        for (sub in subs) {
            // BUG đã sửa: trước đây bỏ qua feed() HOÀN TOÀN cho sub chưa `ready` (đang load
            // model) - audio đọc được trong lúc đó bị mất hẳn cho sub này, y hệt bug "mất câu
            // đầu" ở VoskEngine 1 ngôn ngữ. Giờ luôn gọi feed() cho mọi sub CHƯA lỗi hẳn (kể cả
            // đang load dở) - VoskEngine.feed() tự đệm (buffer) audio nội bộ trong lúc chưa
            // ready và tự phát lại đúng thứ tự ngay khi model của nó load xong (xem
            // VoskEngine.kt), nên không cần né gọi ở đây nữa. Chỉ thật sự bỏ qua sub đã
            // `settled` nhưng KHÔNG `ready` (tức lỗi hẳn, model hỏng) - feed cho sub này vĩnh
            // viễn không có tác dụng, chỉ tốn CPU/RAM đệm audio vô ích.
            if (sub.settled && !sub.ready) continue
            sub.engine.feed(pcm, length)
        }
        // Cập nhật ring buffer TRƯỚC resolveFinalsIfAny() - để nếu lượt feed() này chốt câu và
        // cần hỏi LID, cửa sổ audio "gần nhất" đã bao gồm cả khung vừa nhận.
        appendRecentPcm(pcm, length)
        resolveFinalsIfAny()
        emitBestPartial()
    }

    override fun forcePauseFinal() {
        for (sub in subs) sub.pendingFinal = null
        for (sub in subs) {
            if (!sub.ready) continue
            sub.engine.forcePauseFinal()
        }
        resolveFinalsIfAny()
    }

    // Trong 1 lượt feed()/forcePauseFinal(), CHỈ giữ lại candidate của recognizer nào vừa chốt
    // câu (pendingFinal != null, text không rỗng) và có confidence CAO NHẤT - các recognizer
    // khác dù có lỡ cũng chốt câu ở cùng thời điểm đều bị coi là "đoán sai ngôn ngữ" và bỏ qua.
    private fun resolveFinalsIfAny() {
        val candidates = subs.filter { it.pendingFinal != null && it.pendingFinal!!.first.isNotBlank() }
        if (candidates.isEmpty()) return
        val sorted = candidates.sortedByDescending { it.pendingFinal!!.second }
        var winner = sorted[0]

        // "Mù mờ": 2+ candidate confidence GẦN NHAU (xem TIE_CONFIDENCE_DELTA) - lúc này so
        // confidence 1 mình không còn đáng tin, hỏi thêm LID thật (nếu đã tải + init xong) trên
        // đúng cửa sổ audio gần nhất. CHỈ đổi winner nếu LID chỉ đích danh 1 trong CHÍNH các
        // candidate đang tranh chấp - không tự ý nhảy sang ngôn ngữ ngoài danh sách candidate
        // (vd LID có thể đoán ra 1 ngôn ngữ mà không recognizer nào đang chốt câu, do nhạc nền
        // hoặc ngôn ngữ chưa tải model - giữ nguyên kết quả gốc an toàn hơn trong trường hợp đó).
        val lid = lidEngine
        if (lid != null && lid.ready && sorted.size >= 2) {
            val gap = sorted[0].pendingFinal!!.second - sorted[1].pendingFinal!!.second
            if (gap < TIE_CONFIDENCE_DELTA) {
                val window = snapshotRecentPcm()
                if (window != null) {
                    val candidateLangs = sorted.map { it.lang }.toSet()
                    val lidResult = lid.identify(window, window.size)
                    val lidPick = lidResult?.firstOrNull { it.first in candidateLangs }
                    if (lidPick != null) {
                        winner = sorted.first { it.lang == lidPick.first }
                    }
                }
            }
        }

        val (text, confidence) = winner.pendingFinal!!
        leadingLang = winner.lang
        if (confidence in 0.0..VoskEngine.CONFIDENCE_DROP_THRESHOLD) {
            onEvent(VoskEngine.Event.LowConfidence(text, confidence))
        } else {
            onEvent(VoskEngine.Event.DetectedFinal(winner.lang, text, confidence))
        }
    }

    // Ưu tiên partial của ngôn ngữ đang "thắng" gần nhất nếu nó còn partial không rỗng; nếu rỗng
    // (vd người nói vừa đổi sang ngôn ngữ khác) thì chọn partial DÀI NHẤT trong số các recognizer
    // còn lại - recognizer đoán đúng ngôn ngữ thường tích luỹ partial dài hơn, còn recognizer sai
    // ngôn ngữ hay bị "đứt" giữa chừng vì không khớp từ vựng.
    private fun emitBestPartial() {
        val leading = leadingLang?.let { l -> subs.find { it.lang == l } }
        val candidate = if (leading != null && leading.lastPartial.isNotBlank()) leading
            else subs.filter { it.lastPartial.isNotBlank() }.maxByOrNull { it.lastPartial.length }
        if (candidate != null && candidate.lastPartial.isNotBlank()) {
            onEvent(VoskEngine.Event.Partial(candidate.lastPartial))
        }
    }

    override fun release() {
        subs.forEach { it.engine.release() }
        lidEngine?.release()
    }
}
