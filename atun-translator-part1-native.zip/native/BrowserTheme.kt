package com.atun.translator

import android.graphics.Color
import android.os.Build
import android.util.TypedValue
import android.webkit.WebSettings
import android.webkit.WebView

// ===== Tách từ BrowserActivity.kt (phần màu sắc/Ngày-Đêm) =====
// Toàn bộ hàm dưới đây là extension function của BrowserActivity - vẫn truy cập trực tiếp các
// field "internal" của Activity (nightMode, storage, rootLayout, topBar, tabStripScroll,
// addressBar, chromeTextViews, tabs) y hệt như khi còn nằm chung 1 file, KHÔNG đổi hành vi.

internal fun BrowserActivity.bgColor(): Int = if (nightMode) Color.parseColor("#121212") else Color.WHITE
internal fun BrowserActivity.topBarColor(): Int = if (nightMode) Color.parseColor("#2A2A2A") else Color.parseColor("#F5F5F5")
internal fun BrowserActivity.tabStripColor(): Int = if (nightMode) Color.parseColor("#242424") else Color.parseColor("#EEEEEE")
internal fun BrowserActivity.chromeTextColor(): Int = if (nightMode) Color.parseColor("#EEEEEE") else Color.BLACK
internal fun BrowserActivity.tabChipActiveColor(): Int = if (nightMode) Color.parseColor("#3A3A3A") else Color.WHITE
internal fun BrowserActivity.addressHintColor(): Int = if (nightMode) Color.parseColor("#888888") else Color.parseColor("#999999")

// API forceDark chỉ có từ Android 10 (Q) trở lên - máy cũ hơn vẫn dùng web mini bình
// thường, chỉ riêng nội dung trang web (không phải khung app) sẽ không tự tối được; khung
// app (top bar, tab strip, địa chỉ...) vẫn đổi màu bình thường vì phần đó tự vẽ bằng code,
// không phụ thuộc API này.
@Suppress("DEPRECATION")
internal fun BrowserActivity.applyForceDark(webView: WebView) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        webView.settings.forceDark =
            if (nightMode) WebSettings.FORCE_DARK_ON else WebSettings.FORCE_DARK_OFF
    }
}

// Bật/tắt chế độ Ngày/Đêm cho "Web mini" - đổi màu khung giao diện native (đã tự vẽ bằng
// code, không cần theme/resource riêng) + bật forceDark cho nội dung trang web đang mở ở
// MỌI tab hiện có (không chỉ tab đang xem), để khi người dùng chuyển qua tab khác cũng đã
// đúng chế độ luôn, không phải đợi load lại trang. Lưu lại lựa chọn để lần sau mở web mini
// vẫn giữ nguyên, không cần bật lại tay.
internal fun BrowserActivity.applyNightMode(enabled: Boolean) {
    nightMode = enabled
    storage.setNightModeEnabled(enabled)
    rootLayout.setBackgroundColor(bgColor())
    topBar.setBackgroundColor(topBarColor())
    tabStripScroll.setBackgroundColor(tabStripColor())
    addressBar.setHintTextColor(addressHintColor())
    chromeTextViews.forEach { it.setTextColor(chromeTextColor()) }
    tabs.forEach {
        rebuildTabChip(it)
        applyForceDark(it.webView)
    }
}

internal fun BrowserActivity.dp(v: Float): Int =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()
