package com.atun.translator

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

// ===== Tách từ AudioCaptureService.kt (phần dựng notification foreground) =====
// Hàm dưới đây là extension function của AudioCaptureService - vẫn dùng trực tiếp các hàm kế
// thừa từ Service/Context (getSystemService/startForeground) y hệt như khi còn nằm chung 1
// file, KHÔNG đổi hành vi. CHANNEL_ID/NOTIFICATION_ID đã đổi từ "private" sang "internal" trong
// companion object của AudioCaptureService để file này đọc được.
internal fun AudioCaptureService.startForegroundNotification(mode: String) {
    val manager = getSystemService(NotificationManager::class.java)
    manager.createNotificationChannel(
        NotificationChannel(
            AudioCaptureService.CHANNEL_ID, "Bắt âm thanh để dịch", NotificationManager.IMPORTANCE_LOW
        )
    )

    val stopIntent = Intent(this, AudioCaptureService::class.java).apply { action = AudioCaptureService.ACTION_STOP }
    val stopPendingIntentFlags = PendingIntent.FLAG_UPDATE_CURRENT or
        (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_IMMUTABLE else 0)
    val stopPendingIntent = PendingIntent.getService(this, 0, stopIntent, stopPendingIntentFlags)

    val contentText = if (mode == AudioCaptureService.MODE_MIC)
        "Đang nghe qua micro để dịch trực tiếp"
    else
        "Đang bắt âm thanh phát ra từ máy để dịch trực tiếp"

    val notification = NotificationCompat.Builder(this, AudioCaptureService.CHANNEL_ID)
        .setContentTitle("Đang nghe và dịch phụ đề")
        .setContentText(contentText)
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setOngoing(true)
        .addAction(android.R.drawable.ic_media_pause, "Dừng", stopPendingIntent)
        .build()

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
        val type = if (mode == AudioCaptureService.MODE_MIC)
            android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        else
            android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        startForeground(AudioCaptureService.NOTIFICATION_ID, notification, type)
    } else {
        startForeground(AudioCaptureService.NOTIFICATION_ID, notification)
    }
}
