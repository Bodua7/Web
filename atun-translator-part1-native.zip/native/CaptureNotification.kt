// Fix (audit Detekt - InvalidPackageDeclaration false-positive): file này nằm phẳng trong
// native/ ở gốc repo, không theo cấu trúc thư mục com/atun/translator/ - CÓ CHỦ ĐÍCH, vì bước
// build-debug (android-build.yml) tự copy file này vào đúng
// android/app/src/main/java/com/atun/translator/ trước khi biên dịch thật (xem step "Copy
// native Kotlin sources"). Detekt ở job validation chạy TRƯỚC bước copy đó (trên native/ phẳng)
// nên luôn báo package không khớp đường dẫn vật lý lúc đó - không phải lỗi thật, khai báo
// package vẫn đúng với vị trí SAU KHI copy (nơi thật sự biên dịch).
@file:Suppress("InvalidPackageDeclaration")

package com.atun.translator

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

// ===== Tách từ AudioCaptureService.kt (phần dựng notification foreground) =====
// Hàm dưới đây là extension function của AudioCaptureService - vẫn dùng trực tiếp các hàm kế
// thừa từ Service/Context (getSystemService/startForeground) y hệt như khi còn nằm chung 1
// file, KHÔNG đổi hành vi. CHANNEL_ID/NOTIFICATION_ID đã đổi từ "private" sang "internal" trong
// companion object của AudioCaptureService để file này đọc được.
internal fun AudioCaptureService.startForegroundNotification(mode: String) {
    val manager = getSystemService(NotificationManager::class.java)
    manager.createNotificationChannel(
        NotificationChannel(
            AudioCaptureService.CHANNEL_ID, "Bắt âm thanh để dịch", NotificationManager.IMPORTANCE_LOW
        )
    )

    val stopIntent = Intent(this, AudioCaptureService::class.java).apply { action = AudioCaptureService.ACTION_STOP }
    val stopPendingIntentFlags = PendingIntent.FLAG_UPDATE_CURRENT or
        (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_IMMUTABLE else 0)
    val stopPendingIntent = PendingIntent.getService(this, 0, stopIntent, stopPendingIntentFlags)

    val contentText = when (mode) {
        AudioCaptureService.MODE_MIC -> "Đang nghe qua micro để dịch trực tiếp"
        AudioCaptureService.MODE_MIXED -> "Đang nghe hội thoại 2 chiều (micro + âm thanh máy) để dịch trực tiếp"
        else -> "Đang bắt âm thanh phát ra từ máy để dịch trực tiếp"
    }

    val notification = NotificationCompat.Builder(this, AudioCaptureService.CHANNEL_ID)
        .setContentTitle("Đang nghe và dịch phụ đề")
        .setContentText(contentText)
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setOngoing(true)
        .addAction(android.R.drawable.ic_media_pause, "Dừng", stopPendingIntent)
        .build()

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
        val type = when (mode) {
            AudioCaptureService.MODE_MIC -> android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            // MODE_MIXED cần khai báo CẢ 2 type cùng lúc (OR bit-mask) - khớp với
            // foregroundServiceType="mediaProjection|microphone" đã có sẵn trong AndroidManifest
            // (scripts/patch-manifest.py, làm từ đợt Vosk MODE_MIXED cũ, chưa từng bị gỡ).
            AudioCaptureService.MODE_MIXED ->
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            else -> android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        }
        startForeground(AudioCaptureService.NOTIFICATION_ID, notification, type)
    } else {
        startForeground(AudioCaptureService.NOTIFICATION_ID, notification)
    }
}
