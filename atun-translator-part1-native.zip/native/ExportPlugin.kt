package com.atun.translator

import android.content.Intent
import android.net.Uri
import android.os.BatteryManager
import androidx.core.content.FileProvider
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import java.io.File

// Xuất nhật ký dịch ra file (.srt / .txt song ngữ) và chia sẻ qua Android Share Sheet.
// Không dùng <a download> + Blob URL phía JS vì trong Capacitor WebView cách đó không đáng
// tin cậy (im lặng "biến mất", không có đường mở Share Sheet). Ghi file thật bằng Kotlin,
// giống hệt cách MainActivity.installCrashLogger() đã ghi log crash vào Download.
@CapacitorPlugin(name = "ExportPlugin")
class ExportPlugin : Plugin() {

    // Ghi file vào cache riêng của app rồi mở Android Share Sheet qua FileProvider - KHÔNG
    // dùng ACTION_SEND với Uri file:// trực tiếp vì bị chặn (FileUriExposedException) từ
    // Android 7 trở lên. Share Sheet cho phép gửi Zalo/Telegram hoặc chọn "Lưu vào thiết bị"/
    // Drive ngay trong cùng 1 luồng.
    @PluginMethod
    fun shareFile(call: PluginCall) {
        val content = call.getString("content")
        if (content == null) {
            call.reject("Thiếu nội dung file (content)")
            return
        }
        val fileName = call.getString("fileName") ?: "atun-export.txt"
        val mimeType = call.getString("mimeType") ?: "text/plain"

        try {
            val exportDir = File(context.cacheDir, "exports")
            if (!exportDir.exists()) exportDir.mkdirs()
            val file = File(exportDir, fileName)
            file.writeText(content, Charsets.UTF_8)

            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            activity.startActivity(Intent.createChooser(shareIntent, "Chia sẻ nhật ký dịch"))

            call.resolve()
        } catch (e: Exception) {
            call.reject("Lỗi khi chia sẻ file: ${e.message}")
        }
    }

    // ===== Log lỗi cục bộ (Hạng mục D - độ tin cậy vận hành) =====
    // JS gọi appendErrorLog() mỗi khi ghi 1 dòng "LỖI ..." vào log kỹ thuật trong session,
    // để dòng đó còn sống sót sau khi tắt app (khác với logLines trong JS chỉ tồn tại
    // trong session hiện tại). Dùng chung 1 file với AppLog.append() bên MainActivity nên
    // log crash (fatal) và log lỗi thường (non-fatal) nằm chung 1 chỗ để xem/chia sẻ.
    @PluginMethod
    fun appendErrorLog(call: PluginCall) {
        val line = call.getString("line")
        if (line == null) {
            call.reject("Thiếu nội dung dòng log (line)")
            return
        }
        AppLog.append(context, line)
        call.resolve()
    }

    // Đọc toàn bộ log lỗi đã tích luỹ (crash + lỗi thường) để hiện hoặc chia sẻ.
    @PluginMethod
    fun getErrorLog(call: PluginCall) {
        val ret = JSObject()
        ret.put("content", AppLog.read(context))
        call.resolve(ret)
    }

    // Xoá log lỗi sau khi user đã chia sẻ xong, tránh gửi lại log cũ ở lần báo lỗi sau.
    @PluginMethod
    fun clearErrorLog(call: PluginCall) {
        AppLog.clear(context)
        call.resolve()
    }

    // ===== Đo pin thực tế (Hạng mục G - battery/perf) =====
    // JS gọi hàm này lúc bắt đầu VÀ lúc dừng 1 phiên nghe, rồi tự ghi chênh lệch % pin vào
    // log lỗi (dùng chung AppLog để cộng dồn qua nhiều phiên, xem lại bằng nút "Chia sẻ log
    // lỗi" đã có sẵn) - nhờ vậy có SỐ LIỆU PIN THẬT theo thời lượng phiên nghe mà không cần
    // cài thêm app đo pin ngoài hay nối máy vào Android Studio Profiler.
    @PluginMethod
    fun getBatteryPercent(call: PluginCall) {
        val bm = context.getSystemService(android.content.Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val ret = JSObject()
        ret.put("percent", pct)
        call.resolve(ret)
    }

}
