package com.atun.translator

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import org.json.JSONObject
import java.io.File
import java.nio.FloatBuffer

// ===== LID (Language IDentification) THẬT bằng model âm học rời rạc - chạy làm "trọng tài"
// cho MultiLangVoskEngine.resolveFinalsIfAny(), KHÔNG thay thế cách "phân xử qua confidence
// text-decode" đang có, chỉ dùng khi 2+ recognizer Vosk chốt câu cùng lúc với confidence GẦN
// BẰNG NHAU (xem TIE_CONFIDENCE_DELTA ở MultiLangVoskEngine.kt) - đúng tinh thần yêu cầu gốc
// "chỉ dùng để phân xử khi các recognizer Vosk mù mờ", không chạy mọi câu.
//
// Vì sao thêm việc này có ý nghĩa dù đã có cách phân xử qua confidence: LID model được HUẤN
// LUYỆN để nhận diện ngôn ngữ từ ĐẶC TRƯNG ÂM HỌC thuần tuý (cao độ, nhịp điệu, phổ tần...),
// KHÔNG qua bước decode ra "từ" như Vosk - nên vẫn phân biệt được ngôn ngữ tốt hơn với đoạn
// audio có nhạc nền to/nhiễu, nơi CẢ recognizer đúng lẫn sai ngôn ngữ của Vosk đều có xu hướng
// decode ra vài "từ" nghe gần giống, khiến so sánh confidence một mình không còn đáng tin.
//
// Model: silero_lang_detector_95 (tác giả snakers4/silero-vad, giấy phép MIT) bản export
// ONNX, ~17MB, phân loại 90 ngôn ngữ từ waveform 16kHz. Model gốc trên GitHub đã bị chính tác
// giả đánh dấu "deprecated" từ bản v4.0 (không còn cập nhật/maintain, nhưng trọng số không đổi
// và vẫn dùng được) - tải qua bản re-upload công khai (huggingface.co/deepghs/silero-lang95-onnx)
// vì repo gốc (models.silero.ai) không còn expose link tải trực tiếp cho model đã deprecated.
// Tải về qua ModelManagerPlugin.downloadLidModel() vào modelsDir/_lid/.
//
// Độ tin cậy chưa qua kiểm nghiệm thực tế trên thiết bị (không có máy Android thật để build-test
// - xem ghi chú tương tự trong VadDetector.kt) - toàn bộ hàm ở đây tự bọc try/catch, trả về
// null/false khi lỗi thay vì throw, để 1 lỗi ONNX Runtime (sai tên tensor, model hỏng, thiếu
// native lib .so...) không bao giờ làm crash cả phiên nghe hay chặn luồng Vosk chính đang ổn
// định - LID chỉ là tính năng "cộng thêm", hỏng thì tự động rơi về hành vi cũ (so confidence).
class LidEngine(private val context: Context) {

    companion object {
        const val LID_DIR_NAME = "_lid"
        const val MODEL_FILE = "lang_classifier_95.onnx"
        const val LANG_DICT_FILE = "lang_dict_95.json"

        // Silero LID train trên khung 16kHz mono - PHẢI khớp với SAMPLE_RATE dùng xuyên suốt
        // app (AudioCaptureService.SAMPLE_RATE = 16000), không tự resample ở đây.
        const val REQUIRED_SAMPLE_RATE = 16000

        // Độ dài cửa sổ audio "gần nhất" dùng để hỏi LID mỗi lần cần phân xử - 1.5s đủ dài để
        // model có đặc trưng âm học ổn định (tài liệu gốc: hoạt động tốt với audio ngắn hơn
        // 20s), nhưng đủ ngắn để vẫn phản ánh đúng ngôn ngữ của CÂU VỪA CHỐT (không lẫn quá
        // nhiều audio của câu trước đó nếu người nói vừa đổi ngôn ngữ).
        const val LID_WINDOW_SAMPLES = (REQUIRED_SAMPLE_RATE * 1.5).toInt()

        fun lidDir(context: Context): File = File(ModelCatalog.modelsDir(context), LID_DIR_NAME)

        fun isDownloaded(context: Context): Boolean {
            val dir = lidDir(context)
            return File(dir, MODEL_FILE).isFile && File(dir, LANG_DICT_FILE).isFile
        }
    }

    private var session: OrtSession? = null
    private var inputName: String? = null
    private var outputName: String? = null

    // Danh sách mã ngôn ngữ theo ĐÚNG thứ tự index output của model (đọc từ lang_dict_95.json)
    // - index i của output ứng với langCodes[i]. Mã ngôn ngữ ở đây là mã GỐC của Silero (không
    // hẳn khớp 100% với mã app tự đặt trong ModelCatalog.CATALOG, vd Silero dùng chuẩn
    // ISO-639-1 gần giống cách Whisper Cloud dùng - xem ghi chú mã "kk" vs "kz" trong
    // index.html) - so khớp ở MultiLangVoskEngine chỉ cần TRÙNG với "lang" của các sub-engine
    // đang tranh chấp, những ngôn ngữ Silero hỗ trợ mà app không dùng đơn giản không bao giờ
    // trùng candidate nên tự động bị bỏ qua, không cần ánh xạ 2 chiều đầy đủ.
    private var langCodes: List<String> = emptyList()

    @Volatile var ready = false
        private set

    // Khởi tạo ĐỒNG BỘ - caller (MultiLangVoskEngine.init(), vốn đã chạy off thread chính vì
    // còn phải load nhiều model Vosk nặng hơn nhiều) tự chịu trách nhiệm không gọi trên main
    // thread. Trả về false (không throw) nếu model chưa tải/hỏng - caller tự fallback im lặng.
    fun init(): Boolean {
        try {
            val dir = lidDir(context)
            val modelFile = File(dir, MODEL_FILE)
            val dictFile = File(dir, LANG_DICT_FILE)
            if (!modelFile.isFile || !dictFile.isFile) return false

            val codes = loadLangDict(dictFile)
            if (codes.isEmpty()) return false

            val ortEnv = OrtEnvironment.getEnvironment()
            val ortSession = ortEnv.createSession(modelFile.absolutePath, OrtSession.SessionOptions())

            // KHÔNG hardcode tên input/output tensor: model deprecated này không có tài liệu
            // chính thức xác nhận tên cố định qua các lần re-export/re-upload khác nhau - tự
            // đọc tên THẬT từ session để tránh crash "no input/output named X" nếu bản export
            // đang dùng khác tên so với lúc viết code này.
            val inName = ortSession.inputNames.firstOrNull()
            val outName = ortSession.outputNames.firstOrNull()
            if (inName == null || outName == null) {
                ortSession.close()
                return false
            }

            langCodes = codes
            inputName = inName
            outputName = outName
            session = ortSession
            ready = true
            return true
        } catch (e: Exception) {
            ready = false
            return false
        }
    }

    private fun loadLangDict(file: File): List<String> {
        // lang_dict_95.json gốc dạng {"0": "en", "1": "ru", ...} (index dạng string -> mã ngôn
        // ngữ) - đọc ra rồi xếp lại thành List theo đúng thứ tự index để tra O(1) bằng argmax
        // của output, không phải parse lại JSON mỗi lần identify().
        val obj = JSONObject(file.readText())
        val maxIndex = obj.keys().asSequence().mapNotNull { it.toIntOrNull() }.maxOrNull() ?: return emptyList()
        val arr = arrayOfNulls<String>(maxIndex + 1)
        obj.keys().forEach { key ->
            val idx = key.toIntOrNull() ?: return@forEach
            arr[idx] = obj.optString(key, "")
        }
        return arr.map { it ?: "" }
    }

    // pcm/length: khung audio PCM16 mono @16kHz gần nhất (xem LID_WINDOW_SAMPLES) - trả về
    // danh sách (mã ngôn ngữ, xác suất) sắp xếp GIẢM DẦN theo xác suất, hoặc null nếu chưa
    // init xong/lỗi khi chạy (caller tự fallback về kết quả confidence Vosk gốc).
    fun identify(pcm: ShortArray, length: Int): List<Pair<String, Float>>? {
        val ortSession = session ?: return null
        val name = inputName ?: return null
        val outName = outputName ?: return null
        if (length <= 0) return null

        try {
            val ortEnv = OrtEnvironment.getEnvironment()
            // PCM16 [-32768, 32767] -> float32 [-1.0, 1.0], đúng chuẩn input waveform mà các
            // model Silero (cả VAD lẫn LID) dùng chung.
            val floatBuf = FloatBuffer.allocate(length)
            for (i in 0 until length) floatBuf.put(pcm[i] / 32768f)
            floatBuf.rewind()

            OnnxTensor.createTensor(ortEnv, floatBuf, longArrayOf(1, length.toLong())).use { tensor ->
                ortSession.run(mapOf(name to tensor)).use { result ->
                    val outputOpt = result.get(outName)
                    if (!outputOpt.isPresent) return null
                    val raw = outputOpt.get().value
                    val scores: FloatArray = when (raw) {
                        is Array<*> -> (raw.getOrNull(0) as? FloatArray) ?: return null
                        is FloatArray -> raw
                        else -> return null
                    }
                    val probs = softmax(scores)
                    return langCodes.indices
                        .filter { langCodes[it].isNotEmpty() && it < probs.size }
                        .map { langCodes[it] to probs[it] }
                        .sortedByDescending { it.second }
                }
            }
        } catch (e: Exception) {
            return null
        }
    }

    // Không rõ output thô của bản export deprecated này đã qua softmax hay còn là logit (không
    // có tài liệu chính thức) - tự áp softmax để chắc chắn có phân bố hợp lệ dùng so sánh; nếu
    // output THẬT đã là xác suất rồi thì softmax lần 2 vẫn giữ ĐÚNG thứ tự xếp hạng tương đối
    // (softmax đơn điệu tăng theo giá trị đầu vào), chỉ đổi thang giá trị tuyệt đối - chấp nhận
    // được vì identify() chỉ dùng THỨ TỰ xếp hạng, không hiển thị số % xác suất cho người dùng.
    private fun softmax(scores: FloatArray): FloatArray {
        val max = scores.maxOrNull() ?: 0f
        val exps = FloatArray(scores.size) { kotlin.math.exp((scores[it] - max).toDouble()).toFloat() }
        val sum = exps.sum().coerceAtLeast(1e-9f)
        return FloatArray(exps.size) { exps[it] / sum }
    }

    fun release() {
        try {
            session?.close()
        } catch (e: Exception) {
            // im lặng bỏ qua - release() gọi lúc dọn dẹp phiên nghe, không có gì để làm thêm
            // nếu close() lỗi (session coi như đã mất hiệu lực).
        }
        session = null
        ready = false
        // KHÔNG gọi OrtEnvironment.close() ở đây: đây là singleton dùng chung toàn tiến trình
        // (OrtEnvironment.getEnvironment() trả về CÙNG 1 instance mỗi lần gọi) - đóng nó có thể
        // làm hỏng các OrtSession khác đang sống (vd nếu sau này app có thêm model ONNX khác).
    }
}
