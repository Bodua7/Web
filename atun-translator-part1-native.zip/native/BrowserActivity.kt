package com.atun.translator

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

// ===== "Web mini": trình duyệt web thu nhỏ =====
// Tách BIỆT HOÀN TOÀN khỏi www/index.html (app dịch chính, chạy trong Capacitor Bridge
// WebView) - đây là 1 Activity Android THUẦN (không phải BridgeActivity), tự dựng UI hoàn
// toàn bằng code (không cần thêm file layout .xml nào), mở từ nút trong app chính qua
// BrowserLauncherPlugin (Intent thường, VẪN CÙNG app/process).
//
// Mục đích: cho người dùng vào bất kỳ trang web nào để phát audio/video, phục vụ tính năng
// "Bắt âm thanh hệ thống" dịch trực tiếp của app chính. AudioCaptureService (MediaProjection)
// chạy nền hoàn toàn độc lập với Activity nào đang hiển thị trên màn hình, nên KHÔNG cần nối
// code trực tiếp giữa 2 màn hình - chỉ cần audio phát ra từ thiết bị (kể cả từ Activity này)
// là app chính bắt được, y hệt như bắt audio từ bất kỳ app nào khác.
//
// ===== Ghi chú tách module (file lớn >800 dòng đã được chia nhỏ) =====
// - BrowserTheme.kt      : màu sắc theo Ngày/Đêm + applyForceDark/applyNightMode/dp()
// - BrowserTabManager.kt : quản lý tab (mở/đóng/chuyển tab), tạo WebView, tải file, fullscreen
// - BrowserDialogs.kt    : bookmark/lịch sử/menu "⋮"
// Toàn bộ hàm ở 3 file trên là extension function của chính class này (khai báo "internal fun
// BrowserActivity.xxx(...)") - vẫn truy cập trực tiếp field của Activity như trước, KHÔNG đổi
// hành vi, chỉ tách vị trí code sang file riêng cho dễ đọc/maintain. Field nào được các file đó
// dùng đã đổi từ "private" sang "internal" (chỉ truy cập được trong cùng module app, không lộ ra
// ngoài) - xem ghi chú tại từng field bên dưới.
class BrowserActivity : Activity() {

    // internal (thay vì private) vì BrowserTabManager.kt và BrowserDialogs.kt cần tham chiếu type
    // này trong signature hàm của chúng (vd rebuildTabChip(tab: BrowserTab)).
    internal data class BrowserTab(
        val id: Long,
        val webView: WebView,
        val chip: TextView,
        val closeBtn: TextView,
        val row: LinearLayout,
        var title: String = "Trang mới"
    )

    companion object {
        // Giới hạn số tab đang mở cùng lúc - mỗi tab giữ 1 WebView sống hoàn toàn (không tab
        // nào bị suspend khi không dùng), mở vô hạn tab sẽ tốn RAM dần. 8 là đủ dùng cho nhu
        // cầu thực tế (mở vài trang để bắt audio hệ thống), không cần nhiều hơn.
        // internal: dùng trong BrowserTabManager.openNewTab().
        internal const val MAX_TABS = 8
    }

    internal val tabs = mutableListOf<BrowserTab>()
    internal var currentTabIndex = -1
    internal var nextTabId = 1L

    internal lateinit var storage: BrowserStorage
    internal lateinit var rootLayout: LinearLayout
    internal lateinit var topBar: LinearLayout
    internal lateinit var tabStripScroll: HorizontalScrollView
    internal lateinit var addressBar: EditText
    private lateinit var addressBarClearBtn: Button
    internal lateinit var securityIconView: TextView
    internal lateinit var progressBar: ProgressBar
    internal lateinit var tabStrip: LinearLayout
    private lateinit var webViewContainer: FrameLayout

    // ===== Chế độ Ngày/Đêm (chỉ riêng "Web mini", không ảnh hưởng màn hình dịch chính) =====
    // Đọc từ BrowserStorage lúc onCreate (trước khi buildTopBar()/buildTabStrip() chạy) nên
    // giao diện dựng lần đầu đã đúng màu ngay, không bị "sáng rồi tối lại" 1 nhịp.
    // internal: đọc/ghi từ BrowserTheme.kt và BrowserTabManager.kt (createWebView dùng gián tiếp
    // qua applyForceDark()).
    internal var nightMode = false
    // Danh sách các nút/TextView thuộc khung giao diện (top bar, tab strip) cần đổi màu chữ khi
    // bật/tắt đêm - Button ở Android vốn kế thừa TextView nên gộp chung được 1 danh sách, khỏi
    // phải giữ riêng từng lateinit var cho từng nút chỉ để tô lại màu.
    internal val chromeTextViews = mutableListOf<TextView>()

    // Container RIÊNG chỉ chứa WebView của tab đang active - switchToTab() xoá sạch container
    // này mỗi lần đổi tab. TÁCH khỏi webViewContainer (container cha) để không đụng tới
    // captionOverlay (xem bug đã sửa bên dưới).
    internal lateinit var tabsContainer: FrameLayout
    internal lateinit var btnBookmark: Button

    internal var customFullscreenView: View? = null
    internal var customFullscreenCallback: WebChromeClient.CustomViewCallback? = null

    // ===== Đồng bộ khung phụ đề dịch từ màn hình chính (xem CaptionRelay) - hiện y hệt câu
    // dịch đang hiện ở #inVideoCaption của www/index.html, ĐÈ LÊN WebView của "Web mini" này,
    // và giờ còn đồng bộ luôn cả "khung" (độ trong suốt, cỡ chữ, tỉ lệ rộng/cao) người dùng đã
    // tuỳ chỉnh ở màn hình chính - trước đây overlay này có style cố định cứng (không đổi theo
    // cài đặt), giờ applyCaptionFrame() bên dưới tự áp lại mỗi khi có frame mới từ CaptionRelay.
    // Cần vì AudioCaptureService bắt/dịch audio chạy nền độc lập Activity nào đang hiển thị,
    // nên nếu người dùng đang xem trang web ở đây (không phải màn hình chính) thì trước đây
    // hoàn toàn không thấy được câu dịch nào - phải tự chuyển qua lại 2 màn hình mới xem được. =====
    private lateinit var captionOverlay: TextView
    private val captionListener: (CaptionRelay.CaptionFrame) -> Unit = { frame ->
        runOnUiThread { applyCaptionFrame(frame) }
    }

    // widthPercent/heightPercent trong frame tính theo % kích thước THẬT của webViewContainer
    // (vùng chứa WebView của chính Web mini, KHÔNG phải % #videoStage của màn hình chính - 2 nơi
    // khác kích thước màn hình) - giữ đúng TỈ LỆ người dùng đã chọn thay vì đúng số pixel tuyệt
    // đối. heightPercent chỉ dùng làm TRẦN mềm (setMaxHeight), KHÔNG tự co chữ để vừa khung như
    // fitCaptionFontSize() bên màn hình chính đã làm - overlay ở đây cố ý đơn giản hơn (xem ghi
    // chú ở onCreate), và câu dịch tới đây vốn đã qua đúng logic fitCaptionFontSize() ở màn hình
    // chính nên hiếm khi tràn quá trần này.
    private fun applyCaptionFrame(frame: CaptionRelay.CaptionFrame) {
        if (frame.text.isBlank()) {
            captionOverlay.visibility = View.GONE
            return
        }
        captionOverlay.text = frame.text
        captionOverlay.visibility = View.VISIBLE

        val alpha = (frame.opacity.coerceIn(0f, 1f) * 255).toInt()
        captionOverlay.setBackgroundColor(Color.argb(alpha, 0, 0, 0))

        captionOverlay.textSize = when (frame.fontSize) {
            "small" -> 13f
            "large" -> 20f
            else -> 16f
        }

        // stageWidth/stageHeight chỉ có giá trị đúng SAU khi webViewContainer đã layout xong ít
        // nhất 1 lần - nếu chưa (vd đúng lúc Activity vừa mở, chưa kịp đo), bỏ qua bước
        // resize/cap lần này, giữ nguyên kích thước cũ; applyCaptionFrame() sẽ được gọi lại đúng
        // lúc có frame tiếp theo, lúc đó chắc chắn đã có kích thước thật.
        val stageWidth = webViewContainer.width
        val stageHeight = webViewContainer.height
        if (stageWidth > 0) {
            val params = captionOverlay.layoutParams as FrameLayout.LayoutParams
            params.width = stageWidth * frame.widthPercent.coerceIn(10, 100) / 100
            captionOverlay.layoutParams = params
        }
        if (stageHeight > 0) {
            captionOverlay.maxHeight = stageHeight * frame.heightPercent.coerceIn(5, 100) / 100
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        storage = BrowserStorage(applicationContext)
        nightMode = storage.isNightModeEnabled()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bgColor())
        }
        rootLayout = root

        root.addView(buildTopBar())
        root.addView(buildTabStrip())

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        root.addView(progressBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3f)))

        webViewContainer = FrameLayout(this)
        root.addView(
            webViewContainer,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )

        // BUG THẬT đã sửa: trước đây captionOverlay được add trực tiếp vào webViewContainer,
        // rồi switchToTab() gọi webViewContainer.removeAllViews() mỗi lần đổi tab (kể cả lần
        // đầu, ngay trong openNewTab() lúc onCreate) - xoá mất luôn captionOverlay vĩnh viễn vì
        // không có chỗ nào add lại nó. Kết quả: khung phụ đề không BAO GIỜ hiện ở "Web mini".
        // Sửa: tách riêng tabsContainer CHỈ chứa WebView của tab active, switchToTab() giờ chỉ
        // xoá/thêm bên trong tabsContainer - captionOverlay là con RIÊNG của webViewContainer,
        // không bao giờ bị đụng tới.
        tabsContainer = FrameLayout(this)
        webViewContainer.addView(
            tabsContainer,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        // Overlay phụ đề - thêm SAU tabsContainer vào webViewContainer nên luôn vẽ ĐÈ LÊN trên
        // WebView (thứ tự addView quyết định z-order trong FrameLayout, không cần set
        // z-index/elevation riêng). Khởi tạo với style/kích thước mặc định hợp lý - sẽ được
        // applyCaptionFrame() ghi đè ngay khi có frame đầu tiên từ CaptionRelay (xem
        // onResume()), nên các giá trị ban đầu ở đây chỉ là dự phòng, không phải style "cố
        // định" như trước.
        captionOverlay = TextView(this).apply {
            setBackgroundColor(Color.parseColor("#CC000000"))
            setTextColor(Color.WHITE)
            textSize = 15f
            setPadding(dp(10f), dp(6f), dp(10f), dp(6f))
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        webViewContainer.addView(
            captionOverlay,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                bottomMargin = dp(24f)
                marginStart = dp(16f)
                marginEnd = dp(16f)
            }
        )

        setContentView(root)

        // Nếu được mở kèm 1 URL cụ thể (BrowserLauncherPlugin.open({url: ...})) thì ưu tiên mở
        // đúng URL đó (phiên làm việc mới, không phục hồi tab cũ). Ngược lại (trường hợp thường
        // gặp nhất - bấm "🌐 Mở web mini" không kèm url nào) thì khôi phục lại các tab đã lưu từ
        // lần dùng trước, để không mất trắng nếu Android đã kill Activity ở nền giữa lúc dùng.
        val explicitUrl = intent.getStringExtra("url")?.takeIf { it.isNotBlank() }
        if (explicitUrl != null) {
            openNewTab(explicitUrl)
        } else {
            val (savedUrls, savedActiveIndex) = storage.getOpenTabs()
            if (savedUrls.isNotEmpty()) {
                savedUrls.forEach { openNewTab(it) }
                val restoreIndex = savedActiveIndex.coerceIn(0, tabs.size - 1)
                switchToTab(tabs[restoreIndex].id)
            } else {
                openNewTab("https://www.google.com")
            }
        }
    }

    // Lưu URL hiện tại của từng tab mỗi khi Activity ra nền (chuyển app khác, tắt màn hình...) -
    // đây là thời điểm hệ thống ĐẢM BẢO gọi trước khi có thể kill Activity, đúng lúc cần lưu.
    // Đăng ký nghe CaptionRelay CHỈ lúc đang hiển thị (foreground) - tránh cập nhật UI của 1
    // Activity đang ở nền (runOnUiThread vẫn "chạy được" nhưng vô nghĩa, chỉ tốn việc), và quan
    // trọng hơn là tránh giữ tham chiếu tới Activity đã onPause/onStop qua listener mãi mãi
    // (rò rỉ bộ nhớ) nếu người dùng rời màn hình này rất lâu mà không đóng hẳn nó.
    override fun onResume() {
        super.onResume()
        CaptionRelay.addListener(captionListener)
    }

    override fun onPause() {
        super.onPause()
        CaptionRelay.removeListener(captionListener)
        val urls = tabs.map { it.webView.url ?: "https://www.google.com" }
        storage.saveOpenTabs(urls, currentTabIndex.coerceAtLeast(0))
    }

    // ================= Top bar (địa chỉ + điều hướng) =================
    private fun buildTopBar(): LinearLayout {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4f), dp(6f), dp(4f), dp(6f))
            setBackgroundColor(topBarColor())
        }
        topBar = bar

        val btnBack = flatButton("←") { currentWebView()?.let { if (it.canGoBack()) it.goBack() } }
        val btnForward = flatButton("→") { currentWebView()?.let { if (it.canGoForward()) it.goForward() } }
        val btnReload = flatButton("⟳") { currentWebView()?.reload() }

        // Icon khoá báo trang an toàn (https) hay không (http) - cập nhật trong onPageFinished
        // của WebViewClient bên dưới mỗi khi trang load xong. "🌐" là trạng thái mặc định
        // trước khi có trang nào load (about:blank, chưa nhập gì...).
        securityIconView = TextView(this).apply {
            text = "🌐"
            textSize = 14f
            setPadding(dp(6f), 0, dp(2f), 0)
        }

        addressBar = EditText(this).apply {
            hint = "Nhập địa chỉ web hoặc từ khoá..."
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_GO
            setTextColor(chromeTextColor())
            setHintTextColor(addressHintColor())
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_GO) {
                    loadInCurrentTab(normalizeUrl(text.toString()))
                    true
                } else false
            }
            addTextChangedListener(object : android.text.TextWatcher {
                override fun afterTextChanged(s: android.text.Editable?) {
                    addressBarClearBtn.visibility = if (s.isNullOrEmpty()) View.GONE else View.VISIBLE
                }
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            })
        }
        chromeTextViews.add(addressBar)
        chromeTextViews.add(securityIconView)
        val addrParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(4f)
            marginEnd = dp(4f)
        }

        // Nút "×" xoá nhanh chữ đang gõ trong ô địa chỉ - trước đây phải tự bôi đen/xoá tay
        // từng ký tự. Ẩn mặc định, chỉ hiện khi ô địa chỉ đang có chữ (xem TextWatcher ở trên).
        addressBarClearBtn = flatButton("×") { addressBar.setText("") }
        addressBarClearBtn.visibility = View.GONE

        btnBookmark = flatButton("☆") { toggleBookmarkCurrentTab() }
        val btnMenu = flatButton("⋮") {}
        btnMenu.setOnClickListener { showMenu(btnMenu) }

        bar.addView(btnBack)
        bar.addView(btnForward)
        bar.addView(btnReload)
        bar.addView(securityIconView)
        bar.addView(addressBar, addrParams)
        bar.addView(addressBarClearBtn)
        bar.addView(btnBookmark)
        bar.addView(btnMenu)
        return bar
    }

    // internal: gọi từ BrowserTabManager.kt (openNewTab dùng cho nút "＋ Tab mới") lẫn bên trong
    // file này (buildTopBar).
    internal fun flatButton(label: String, onClick: () -> Unit): Button {
        // Dùng Button chữ/ký hiệu thay vì icon vector -> khỏi cần thêm resource drawable nào.
        return Button(this).apply {
            text = label
            textSize = 16f
            isAllCaps = false
            setPadding(dp(10f), 0, dp(10f), 0)
            minWidth = dp(40f)
            minimumWidth = dp(40f)
            background = null
            setTextColor(chromeTextColor())
            setOnClickListener { onClick() }
        }.also { chromeTextViews.add(it) }
    }

    // ================= Tab strip (nhiều tab, cuộn ngang) =================
    private fun buildTabStrip(): HorizontalScrollView {
        tabStrip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(tabStripColor())
            addView(tabStrip)
        }
        tabStripScroll = scroll
        val plusBtn = flatButton("＋ Tab mới") { openNewTab("https://www.google.com") }
        tabStrip.addView(plusBtn)
        return scroll
    }

    // ================= Back button =================
    override fun onBackPressed() {
        if (customFullscreenView != null) {
            hideCustomFullscreenView()
            return
        }
        val webView = currentWebView()
        if (webView != null && webView.canGoBack()) {
            webView.goBack()
            return
        }
        if (tabs.size > 1) {
            tabs.getOrNull(currentTabIndex)?.let { closeTab(it.id) }
            return
        }
        super.onBackPressed()
    }

    override fun onDestroy() {
        tabs.forEach { it.webView.destroy() }
        super.onDestroy()
    }
}
