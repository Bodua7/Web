package com.atun.translator

import android.app.AlertDialog
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.Toast

// ===== Tách từ BrowserActivity.kt (phần Bookmark/Lịch sử/Menu "⋮") =====
// Toàn bộ hàm dưới đây là extension function của BrowserActivity - vẫn truy cập trực tiếp các
// field/hàm "internal" của Activity (tabs, currentTabIndex, storage, btnBookmark, nightMode,
// currentWebView(), loadInCurrentTab(), closeTab(), applyNightMode()...) y hệt như khi còn nằm
// chung 1 file, KHÔNG đổi hành vi.

// ================= Bookmark / History / Menu =================
internal fun BrowserActivity.toggleBookmarkCurrentTab() {
    val tab = tabs.getOrNull(currentTabIndex) ?: return
    val url = tab.webView.url ?: return
    if (storage.isBookmarked(url)) {
        storage.removeBookmark(url)
        btnBookmark.text = "☆"
        Toast.makeText(this, "Đã bỏ đánh dấu", Toast.LENGTH_SHORT).show()
    } else {
        storage.addBookmark(url, tab.title)
        btnBookmark.text = "★"
        Toast.makeText(this, "Đã đánh dấu trang", Toast.LENGTH_SHORT).show()
    }
}

internal fun BrowserActivity.showMenu(anchor: View) {
    val popup = PopupMenu(this, anchor)
    popup.menu.add("Bookmark")
    popup.menu.add("Lịch sử")
    popup.menu.add("Xoá lịch sử")
    val adBlockLabel = if (storage.isAdBlockEnabled()) "Tắt chặn quảng cáo" else "Bật chặn quảng cáo"
    popup.menu.add(adBlockLabel)
    val nightModeLabel = if (nightMode) "☀️ Chế độ ngày" else "🌙 Chế độ đêm"
    popup.menu.add(nightModeLabel)
    popup.menu.add("Đóng tab này")
    popup.menu.add("Quay lại app dịch")
    popup.setOnMenuItemClickListener { item ->
        when (item.title) {
            "Bookmark" -> showBookmarksDialog()
            "Lịch sử" -> showHistoryDialog()
            "Xoá lịch sử" -> confirmClearHistory()
            adBlockLabel -> {
                storage.setAdBlockEnabled(!storage.isAdBlockEnabled())
                val nowOn = storage.isAdBlockEnabled()
                Toast.makeText(this, if (nowOn) "Đã bật chặn quảng cáo" else "Đã tắt chặn quảng cáo", Toast.LENGTH_SHORT).show()
                currentWebView()?.reload()
            }
            nightModeLabel -> {
                applyNightMode(!nightMode)
                Toast.makeText(this, if (nightMode) "Đã bật chế độ đêm" else "Đã bật chế độ ngày", Toast.LENGTH_SHORT).show()
            }
            "Đóng tab này" -> tabs.getOrNull(currentTabIndex)?.let { closeTab(it.id) }
            "Quay lại app dịch" -> finish()
        }
        true
    }
    popup.show()
}

internal fun BrowserActivity.showBookmarksDialog() {
    val entries = storage.getBookmarks()
    if (entries.isEmpty()) {
        Toast.makeText(this, "Chưa có bookmark nào", Toast.LENGTH_SHORT).show()
        return
    }
    showEntryListDialog("Bookmark", entries) { entry ->
        AlertDialog.Builder(this)
            .setTitle(entry.title)
            .setItems(arrayOf("Mở", "Xoá bookmark")) { d, which ->
                if (which == 0) {
                    loadInCurrentTab(entry.url)
                } else {
                    storage.removeBookmark(entry.url)
                    btnBookmark.text = if (storage.isBookmarked(currentWebView()?.url ?: "")) "★" else "☆"
                }
                d.dismiss()
            }
            .show()
    }
}

internal fun BrowserActivity.confirmClearHistory() {
    AlertDialog.Builder(this)
        .setTitle("Xoá lịch sử")
        .setMessage("Xoá toàn bộ lịch sử duyệt web mini? Không ảnh hưởng bookmark.")
        .setPositiveButton("Xoá") { d, _ ->
            storage.clearHistory()
            Toast.makeText(this, "Đã xoá lịch sử", Toast.LENGTH_SHORT).show()
            d.dismiss()
        }
        .setNegativeButton("Huỷ", null)
        .show()
}

internal fun BrowserActivity.showHistoryDialog() {
    val entries = storage.getHistory()
    if (entries.isEmpty()) {
        Toast.makeText(this, "Chưa có lịch sử duyệt web", Toast.LENGTH_SHORT).show()
        return
    }
    showEntryListDialog("Lịch sử", entries) { entry ->
        loadInCurrentTab(entry.url)
    }
}

internal fun BrowserActivity.showEntryListDialog(
    title: String,
    entries: List<BrowserStorage.Entry>,
    onPick: (BrowserStorage.Entry) -> Unit
) {
    val labels = entries.map { "${it.title}\n${it.url}" }.toTypedArray()
    val listView = ListView(this).apply {
        adapter = ArrayAdapter(this@showEntryListDialog, android.R.layout.simple_list_item_1, labels)
    }
    val dialog = AlertDialog.Builder(this)
        .setTitle(title)
        .setView(listView)
        .setNegativeButton("Đóng", null)
        .create()
    listView.setOnItemClickListener { _, _, position, _ ->
        onPick(entries[position])
        dialog.dismiss()
    }
    dialog.show()
}
