package com.atun.translator

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test
import java.nio.ByteBuffer
import java.nio.ByteOrder

// Test JUnit thuần cho 2 hàm thuần JVM tách từ SttReadLoop.kt sang AudioPcmUtils.kt - không cần
// Robolectric vì không đụng bất kỳ API android.* nào.
class AudioPcmUtilsTest {
    @Test
    fun `shortsToBytesLE tra ve dung thu tu byte little-endian`() {
        // 0x0102 little-endian = byte thấp trước: 0x02, 0x01.
        val samples = shortArrayOf(0x0102, -1, 0)
        val bytes = shortsToBytesLE(samples, samples.size)
        assertArrayEquals(
            byteArrayOf(0x02, 0x01, 0xFF.toByte(), 0xFF.toByte(), 0x00, 0x00),
            bytes
        )
    }

    @Test
    fun `shortsToBytesLE chi lay dung "len" mau dau, bo phan du cua mang`() {
        val samples = shortArrayOf(1, 2, 3, 4)
        val bytes = shortsToBytesLE(samples, 2) // chỉ lấy 2 mẫu đầu, bỏ 2 mẫu cuối
        assertEquals(4, bytes.size) // 2 mẫu * 2 byte/mẫu
    }

    @Test
    fun `buildWavFile tao dung header 44 byte chuan RIFF-WAVE`() {
        val pcm = ByteArray(100) { it.toByte() }
        val sampleRate = 16000
        val wav = buildWavFile(pcm, sampleRate)

        assertEquals(44 + pcm.size, wav.size)

        val header = ByteBuffer.wrap(wav, 0, 44).order(ByteOrder.LITTLE_ENDIAN)
        val riff = ByteArray(4).also { header.get(it) }
        assertEquals("RIFF", String(riff, Charsets.US_ASCII))
        assertEquals(36 + pcm.size, header.int) // ChunkSize

        val wave = ByteArray(4).also { header.get(it) }
        assertEquals("WAVE", String(wave, Charsets.US_ASCII))
        val fmt = ByteArray(4).also { header.get(it) }
        assertEquals("fmt ", String(fmt, Charsets.US_ASCII))

        assertEquals(16, header.int) // Subchunk1Size
        assertEquals(1, header.short.toInt()) // AudioFormat = PCM
        assertEquals(1, header.short.toInt()) // NumChannels = mono
        assertEquals(sampleRate, header.int) // SampleRate
        assertEquals(sampleRate * 2, header.int) // ByteRate (16-bit mono)
        assertEquals(2, header.short.toInt()) // BlockAlign
        assertEquals(16, header.short.toInt()) // BitsPerSample

        val dataTag = ByteArray(4).also { header.get(it) }
        assertEquals("data", String(dataTag, Charsets.US_ASCII))
        assertEquals(pcm.size, header.int) // Subchunk2Size

        // Phần thân sau header phải là đúng PCM gốc, không bị cắt/đổi thứ tự.
        val body = wav.copyOfRange(44, wav.size)
        assertArrayEquals(pcm, body)
    }

    @Test
    fun `buildWavFile voi pcm rong van tao header hop le, data size = 0`() {
        val wav = buildWavFile(ByteArray(0), 16000)
        assertEquals(44, wav.size) // chỉ có header, không có phần thân
    }
}
