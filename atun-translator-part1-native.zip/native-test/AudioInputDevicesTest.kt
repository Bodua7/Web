package com.atun.translator

// Test Robolectric cho AudioInputDevices - đây là phần LOGIC CHỌN THIẾT BỊ mà
// CaptureSourceManager.kt thực sự gọi (selectMicInputDevice() gọi thẳng
// AudioInputDevices.findBestExternalInputDevice()/describeInputDevice()), nên test file này
// tuy đặt tên khác nhưng chính là phần "não" testable của CaptureSourceManager.
//
// SttReadLoop.kt: phần logic THUẦN (state machine quyết định khi nào cắt đoạn audio để gửi lên
// Cloud STT) đã được test từ trước - KHÔNG bằng Robolectric mà bằng Python hand-port
// (tests/cloud_stt_segment/segment_cutter.py, theo đúng convention có sẵn của dự án: port tay
// sang Python rồi test, thay vì test trực tiếp Kotlin) - xem tests/cloud_stt_segment/README.md.
//
// CHƯA test được (và có khả năng KHÔNG BAO GIỜ test được bằng unit test JVM, kể cả với
// Robolectric): phần AudioRecord/MediaProjection THẬT trong CaptureSourceManager.kt
// (buildSystemAudioRecord/buildMicAudioRecord) và vòng lặp AudioRecord.read() thật trong
// SttReadLoop.kt. Lý do: AudioRecord không có constructor public tạo được instance "giả" có ý
// nghĩa (Robolectric shadow cho AudioRecord chỉ giả lập cấu trúc, không giả lập được hành vi
// đọc audio thật - test kiểu đó dễ ra "xanh giả": pass trên CI nhưng không phản ánh gì về việc
// máy thật có bắt được audio hay không). Đây là ranh giới hợp lý giữa unit test và test cần
// thiết bị thật - không cố gắng vượt qua ranh giới này bằng cách viết test hình thức.
import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.shadows.AudioDeviceInfoBuilder

@RunWith(RobolectricTestRunner::class)
class AudioInputDevicesTest {

    // Robolectric 4.13 đổi các field của ShadowAudioManager (trong đó có danh sách input
    // device) thành static (PR "Changes all members of ShadowAudioManager to be static"),
    // nên danh sách thiết bị KHÔNG tự reset giữa các @Test method trong cùng class - test chạy
    // trước để lại "rác" (vd findBestExternalInputDevice... thêm TYPE_USB_DEVICE) sẽ cộng dồn
    // vào test chạy sau, làm sai lệch listExternalInputDevices(). Reset tay ở đây để không phụ
    // thuộc thứ tự chạy test hay version Robolectric.
    @Before
    fun resetAudioDevices() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        shadowOf(audioManager).setInputDevices(emptyList())
    }

    // setProductName("") ép rõ ràng KHÔNG có tên thiết bị - AudioDeviceInfoBuilder mặc định
    // gán productName = "robolectric" (không phải null/rỗng như thiết bị thật đôi khi trả về),
    // nên nếu không ép rỗng thì describeInputDevice() sẽ luôn nối thêm "(robolectric)" vào
    // nhãn, làm sai lệch ý đồ ban đầu của các assertion bên dưới (kiểm tra nhánh không có tên).
    private fun deviceOfType(type: Int): AudioDeviceInfo =
        AudioDeviceInfoBuilder.newBuilder().setType(type).setProductName("").build()

    @Test
    fun `describeInputDevice tra ve dung nhan tieng Viet theo tung loai thiet bi`() {
        assertEquals(
            "Tai nghe USB",
            AudioInputDevices.describeInputDevice(deviceOfType(AudioDeviceInfo.TYPE_USB_HEADSET)),
        )
        assertEquals(
            "Micro USB",
            AudioInputDevices.describeInputDevice(deviceOfType(AudioDeviceInfo.TYPE_USB_DEVICE)),
        )
        assertEquals(
            "Tai nghe có dây (jack)",
            AudioInputDevices.describeInputDevice(deviceOfType(AudioDeviceInfo.TYPE_WIRED_HEADSET)),
        )
        assertEquals(
            "Tai nghe có dây (jack)",
            AudioInputDevices.describeInputDevice(deviceOfType(AudioDeviceInfo.TYPE_WIRED_HEADPHONES)),
        )
        assertEquals(
            "Tai nghe Bluetooth",
            AudioInputDevices.describeInputDevice(deviceOfType(AudioDeviceInfo.TYPE_BLUETOOTH_SCO)),
        )
        // Loại thiết bị không nằm trong danh sách xử lý riêng -> phải rơi vào nhánh mặc định.
        assertEquals(
            "Micro ngoài",
            AudioInputDevices.describeInputDevice(deviceOfType(AudioDeviceInfo.TYPE_DOCK)),
        )
    }

    @Test
    fun `listExternalInputDevices bo qua micro lien trong may va loa ngoai`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val shadowManager = shadowOf(audioManager)

        shadowManager.addInputDevice(deviceOfType(AudioDeviceInfo.TYPE_BUILTIN_MIC), false)
        shadowManager.addInputDevice(deviceOfType(AudioDeviceInfo.TYPE_BUILTIN_EARPIECE), false)
        shadowManager.addInputDevice(deviceOfType(AudioDeviceInfo.TYPE_USB_DEVICE), false)

        val list = AudioInputDevices.listExternalInputDevices(context)
        assertEquals(1, list.size)
        assertEquals(AudioDeviceInfo.TYPE_USB_DEVICE, list[0].type)
    }

    @Test
    fun `findBestExternalInputDevice uu tien USB truoc day co day truoc Bluetooth SCO`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val shadowManager = shadowOf(audioManager)

        // Cố tình thêm theo thứ tự KHÔNG phải thứ tự ưu tiên, để xác nhận hàm tự sắp xếp lại
        // đúng theo devicePriority(), không phải chỉ trả về phần tử thêm-đầu-tiên.
        shadowManager.addInputDevice(deviceOfType(AudioDeviceInfo.TYPE_BLUETOOTH_SCO), false)
        shadowManager.addInputDevice(deviceOfType(AudioDeviceInfo.TYPE_WIRED_HEADSET), false)
        shadowManager.addInputDevice(deviceOfType(AudioDeviceInfo.TYPE_USB_DEVICE), false)

        val best = AudioInputDevices.findBestExternalInputDevice(context)
        assertEquals(AudioDeviceInfo.TYPE_USB_DEVICE, best?.type)
    }

    @Test
    fun `findBestExternalInputDevice chon day co day khi khong co USB`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val shadowManager = shadowOf(audioManager)

        shadowManager.addInputDevice(deviceOfType(AudioDeviceInfo.TYPE_BLUETOOTH_SCO), false)
        shadowManager.addInputDevice(deviceOfType(AudioDeviceInfo.TYPE_WIRED_HEADSET), false)

        val best = AudioInputDevices.findBestExternalInputDevice(context)
        assertEquals(AudioDeviceInfo.TYPE_WIRED_HEADSET, best?.type)
    }

    @Test
    fun `findBestExternalInputDevice tra ve null khi khong co thiet bi ngoai nao`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        // Không add thiết bị nào cả (chỉ builtin mic mặc định, không tính là "thiết bị ngoài").
        val best = AudioInputDevices.findBestExternalInputDevice(context)
        assertNull(best)
    }
}
