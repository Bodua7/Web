package com.atun.translator

// Test Robolectric cho AudioCaptureService - lớp NÀY đụng android.app.Service thật nên cần
// Robolectric (giả lập khung Android trên JVM) mới load/gọi được, khác VadDetectorTest.kt (pure
// Kotlin, không cần Robolectric) - xem README mục "Kiểm thử" để biết vì sao chỉ có 2 kịch bản
// dưới đây, chưa test các nhánh sâu hơn (startMicCapture/startSystemCapture thật - đụng
// AudioRecord/MediaProjection, Robolectric có shadow cho các API này nhưng hành vi giả lập khác
// nhiều so với thiết bị thật, dễ viết test "xanh giả" (pass nhưng không phản ánh đúng thiết bị
// thật) nếu không có thiết bị thật để đối chiếu lại - CHƯA làm ở đợt này).
//
// 2 kịch bản chọn test vì đã đọc kỹ source và xác nhận được (qua đọc code, KHÔNG chạy thử thật
// được - môi trường soạn code này không có Android SDK/Robolectric để tự build-thử) là an toàn,
// không đụng AudioRecord/MediaProjection thật:
//   1) onStartCommand(null, ...) khi CHƯA từng lưu trạng thái đang capture (SharedPreferences
//      trống, đúng trạng thái cài app lần đầu) -> phải rơi vào nhánh "không phục hồi được" ->
//      gọi stopSelf(), KHÔNG throw.
//   2) onStartCommand(Intent(ACTION_STOP), ...) khi CHƯA từng start capture -> stopCapture() phải
//      an toàn khi mọi field (audioRecord/mediaProjection/captureThread) đều đang null (đã đọc
//      code xác nhận toàn bộ dùng ?. null-safe) -> KHÔNG throw.
import android.content.Intent
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class AudioCaptureServiceTest {

    @Test
    fun `hang so ACTION START va ACTION STOP dung format package`() {
        assertEquals("com.atun.translator.action.START_CAPTURE", AudioCaptureService.ACTION_START)
        assertEquals("com.atun.translator.action.STOP_CAPTURE", AudioCaptureService.ACTION_STOP)
    }

    @Test
    fun `onStartCommand voi intent null va chua tung luu trang thai capture thi tu dung, khong crash`() {
        val controller = Robolectric.buildService(AudioCaptureService::class.java)
        val service = controller.create().get()

        // Không throw là đủ để coi là pass - đây là nhánh "OS tự khởi động lại service sau khi
        // bị kill" nhưng KHÔNG có phiên nào đang chạy trước đó (SharedPreferences trống mặc định
        // trong môi trường test Robolectric, giống app cài lần đầu) - phải tự dừng êm, không crash.
        service.onStartCommand(null, 0, 1)

        controller.destroy()
    }

    @Test
    fun `onStartCommand voi ACTION STOP khi chua tung start capture thi khong crash`() {
        val controller = Robolectric.buildService(AudioCaptureService::class.java)
        val service = controller.create().get()

        val stopIntent = Intent(AudioCaptureService.ACTION_STOP)
        service.onStartCommand(stopIntent, 0, 1)

        controller.destroy()
    }
}
