package com.atun.translator

// Test cho VadDetector - class NÀY được chọn để viết unit test JUnit đầu tiên (đợt trước) vì là
// lớp DUY NHẤT trong native/ không phụ thuộc bất kỳ API Android nào (chỉ dùng kotlin.math) -
// chạy được bằng JUnit thuần trên JVM (./gradlew testDebugUnitTest) mà không cần Robolectric hay
// Android SDK thật.
//
// Cập nhật (audit đợt 2): SttSegmentCutterTest.kt + AudioPcmUtilsTest.kt đã bổ sung thêm - tách
// đúng phần logic THUẦN ra khỏi SttReadLoop.kt (xem SttSegmentCutter.kt/AudioPcmUtils.kt) để
// test được mà KHÔNG cần Robolectric, thay vì phải kéo thêm dependency mới vào dự án.
//
// Cập nhật (audit VAD/môi trường): process() giờ nhận thêm tham số `now` (mốc thời gian ms) -
// hangover chuyển từ đếm SỐ KHUNG (HANGOVER_FRAMES, lỗi đơn vị vì thời lượng 1 khung phụ thuộc
// thiết bị) sang đếm THỜI GIAN THẬT (HANGOVER_MS=250). Test dưới đây tự quản 1 biến `now` giả lập
// đồng hồ, tự tăng theo từng bước gọi thay vì đếm số lần gọi - test hangover được viết lại theo
// mốc thời gian tường minh (ví dụ: "còn true ở mốc 240ms", "chuyển false ở mốc 260ms") thay vì
// "còn true ở khung thứ 4".
//
// AudioCaptureService/CaptureSourceManager vẫn CHƯA có test - 2 lớp đó gọi trực tiếp
// AudioRecord/Service/MediaProjection thật (state machine lifecycle của Service, không tách
// được thành hàm thuần dễ dàng như SttSegmentCutter), Android Gradle Plugin mặc định chỉ cấp 1
// bản "throw stub" android.jar cho unit test (mọi method Android thật gọi vào sẽ ném
// RuntimeException "not mocked"), nên test có ý nghĩa cho 2 lớp đó cần thêm Robolectric (giả lập
// khung Android trên JVM) - đã thêm patch-robolectric.py với 2 test case an toàn (xem
// AudioCaptureServiceTest.kt), phần sâu hơn (AudioRecord/MediaProjection thật) kết luận không
// test thêm được qua JVM vì Robolectric shadow các API này khác quá xa thiết bị thật.
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class VadDetectorTest {

    private lateinit var vad: VadDetector

    @Before
    fun setUp() {
        vad = VadDetector()
    }

    // Sinh 1 khung mẫu có biên độ không đổi = amplitude, đủ dài (numSamples) để RMS xấp xỉ
    // đúng amplitude (RMS của tín hiệu hằng số = chính amplitude đó).
    private fun constantFrame(amplitude: Short, numSamples: Int = 320): ShortArray =
        ShortArray(numSamples) { amplitude }

    @Test
    fun `khung im lang bien do thap khong duoc coi la voice`() {
        // enterThreshold ban đầu = max(noiseFloor=200 * 2.5, MIN_NOISE_FLOOR=30 * 2.5) = 500,
        // amplitude 10 (RMS=10) thấp hơn nhiều -> phải là false.
        val frame = constantFrame(10)
        assertFalse(vad.process(frame, frame.size, now = 0L))
    }

    @Test
    fun `khung bien do lon vuot nguong duoc coi la voice ngay lan dau`() {
        // amplitude 1000 (RMS=1000) > enterThreshold=500 (tính từ noiseFloor khởi tạo mặc định
        // 200, chưa bị amplitude thấp nào làm trôi trước đó) -> phải là true ngay lần gọi đầu.
        val frame = constantFrame(1000)
        assertTrue(vad.process(frame, frame.size, now = 0L))
    }

    @Test
    fun `length 0 tra ve trang thai isVoice hien tai, khong lam gi them`() {
        // Trước khi có tiếng nói: length=0 phải trả về false (trạng thái ban đầu), không crash.
        assertFalse(vad.process(ShortArray(10), 0, now = 0L))

        // Sau khi đã vào trạng thái voice: length=0 phải giữ nguyên true (không tự tắt vì 1 lần
        // gọi length=0 - thường xảy ra khi AudioRecord.read() trả về 0 tạm thời).
        vad.process(constantFrame(1000), 320, now = 0L)
        assertTrue(vad.process(ShortArray(10), 0, now = 10L))
    }

    @Test
    fun `hangover giu trang thai voice dung 250ms im lang sau khi tieng noi dut, tat sau khi vuot moc do`() {
        // Kích hoạt voice trước (amplitude 1000, noiseFloor vẫn ở mức khởi tạo 200 vì chưa có
        // khung im lặng nào trước đó để làm trôi noiseFloor) tại mốc now=0.
        assertTrue(vad.process(constantFrame(1000), 320, now = 0L))
        // -> hangoverUntil (nội bộ) = 0 + HANGOVER_MS(250) = 250.

        // exitThreshold = max(200*1.6, 30*1.6) = 320 - khung im lặng amplitude=50 (RMS=50) thấp
        // hơn nhiều, đúng nhánh "dưới exit threshold, còn hangover".
        val quietFrame = constantFrame(50)

        // Các mốc thời gian TRƯỚC khi hangover hết hạn (< 250ms kể từ lúc tiếng nói dứt ở now=0)
        // vẫn phải còn true, bất kể gọi bao nhiêu LẦN - khác hẳn cách đếm-khung cũ (số lần gọi
        // không còn quyết định gì cả, chỉ mốc thời gian mới quyết định).
        assertTrue("còn trong hangover ở now=50ms", vad.process(quietFrame, quietFrame.size, now = 50L))
        assertTrue("còn trong hangover ở now=150ms", vad.process(quietFrame, quietFrame.size, now = 150L))
        assertTrue("còn trong hangover ở now=249ms (sát mốc, chưa hết)", vad.process(quietFrame, quietFrame.size, now = 249L))

        // Ngay tại/sau mốc 250ms: hangover đã hết hạn -> phải chuyển về false.
        assertFalse("hangover đã hết ở now=250ms - phải chuyển về false", vad.process(quietFrame, quietFrame.size, now = 250L))
    }

    @Test
    fun `tieng noi lien tuc lam moi lai hangover, khong tat som`() {
        var now = 0L
        assertTrue(vad.process(constantFrame(1000), 320, now))

        // Xen kẽ 1 khung im lặng (dùng bớt hangover, nhưng KHÔNG đủ 250ms để hết hạn) rồi lại 1
        // khung to (refresh lại hangoverUntil) - lặp lại nhiều lần phải luôn còn true, dù tổng
        // thời gian trôi qua CỘNG DỒN đã vượt xa 250ms (vì mỗi lần khung to xen vào đã đẩy lại
        // mốc hết hạn thêm 250ms kể từ thời điểm đó).
        repeat(10) {
            now += 100 // mỗi bước cách nhau 100ms < HANGOVER_MS=250ms - không đủ để hết hạn
            assertTrue(vad.process(constantFrame(50), 320, now)) // dùng bớt hangover
            now += 50
            assertTrue(vad.process(constantFrame(1000), 320, now)) // refresh lại hangover
        }
    }

    @Test
    fun `reset dua VadDetector ve trang thai ban dau nhu vua khoi tao`() {
        // Đưa vào trạng thái voice=true trước.
        assertTrue(vad.process(constantFrame(1000), 320, now = 0L))

        vad.reset()

        // Sau reset: hành vi phải giống hệt 1 instance MỚI - khung im lặng phải là false, khung
        // to (amplitude 1000, vượt enterThreshold=500 tính từ noiseFloor mặc định 200) lại phải
        // là true ngay lần gọi đầu, y hệt test "khung bien do lon..." ở trên. Dùng lại now=0 vì
        // reset() cũng xoá sạch state thời gian nội bộ (hangoverUntil=0L).
        assertFalse(vad.process(constantFrame(10), 320, now = 0L))
        vad.reset()
        assertTrue(vad.process(constantFrame(1000), 320, now = 0L))
    }

    @Test
    fun `noise floor thich nghi dan len tu cac khung im lang bien do trung binh`() {
        // Nhiều khung amplitude=300 liên tiếp (thấp hơn enterThreshold ban đầu=500 nên vẫn được
        // coi là "im lặng", noiseFloor sẽ trôi dần từ 200 lên gần 300 qua EMA) - sau đó
        // enterThreshold mới sẽ cao hơn 500 ban đầu, nghĩa là 1 khung amplitude=600 (đủ vượt
        // ngưỡng gốc 500) có thể KHÔNG còn đủ vượt ngưỡng mới đã trôi lên. Test này chỉ xác nhận
        // chuỗi khung amplitude=300 không tự nhảy thành voice=true (đúng thiết kế: nhiễu nền
        // trung bình không được coi là giọng nói dù lặp lại nhiều lần).
        val mediumNoise = constantFrame(300)
        var now = 0L
        repeat(50) {
            assertFalse(vad.process(mediumNoise, mediumNoise.size, now))
            now += 20
        }
    }
}
