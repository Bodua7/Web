package com.atun.translator

// Test cho VadDetector - class NÀY được chọn để viết unit test JUnit đầu tiên (đợt trước) vì là
// lớp DUY NHẤT trong native/ không phụ thuộc bất kỳ API Android nào (chỉ dùng kotlin.math) -
// chạy được bằng JUnit thuần trên JVM (./gradlew testDebugUnitTest) mà không cần Robolectric hay
// Android SDK thật.
//
// Cập nhật (audit đợt 2): SttSegmentCutterTest.kt + AudioPcmUtilsTest.kt đã bổ sung thêm - tách
// đúng phần logic THUẦN ra khỏi SttReadLoop.kt (xem SttSegmentCutter.kt/AudioPcmUtils.kt) để
// test được mà KHÔNG cần Robolectric, thay vì phải kéo thêm dependency mới vào dự án.
//
// Cập nhật (audit VAD/môi trường): process() giờ nhận thêm tham số `now` (mốc thời gian ms) -
// hangover chuyển từ đếm SỐ KHUNG (HANGOVER_FRAMES, lỗi đơn vị vì thời lượng 1 khung phụ thuộc
// thiết bị) sang đếm THỜI GIAN THẬT (HANGOVER_MS=250). Test dưới đây tự quản 1 biến `now` giả lập
// đồng hồ, tự tăng theo từng bước gọi thay vì đếm số lần gọi - test hangover được viết lại theo
// mốc thời gian tường minh (ví dụ: "còn true ở mốc 240ms", "chuyển false ở mốc 260ms") thay vì
// "còn true ở khung thứ 4".
//
// AudioCaptureService/CaptureSourceManager vẫn CHƯA có test - 2 lớp đó gọi trực tiếp
// AudioRecord/Service/MediaProjection thật (state machine lifecycle của Service, không tách
// được thành hàm thuần dễ dàng như SttSegmentCutter), Android Gradle Plugin mặc định chỉ cấp 1
// bản "throw stub" android.jar cho unit test (mọi method Android thật gọi vào sẽ ném
// RuntimeException "not mocked"), nên test có ý nghĩa cho 2 lớp đó cần thêm Robolectric (giả lập
// khung Android trên JVM) - đã thêm patch-robolectric.py với 2 test case an toàn (xem
// AudioCaptureServiceTest.kt), phần sâu hơn (AudioRecord/MediaProjection thật) kết luận không
// test thêm được qua JVM vì Robolectric shadow các API này khác quá xa thiết bị thật.
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class VadDetectorTest {

    private lateinit var vad: VadDetector

    @Before
    fun setUp() {
        vad = VadDetector()
    }

    // Sinh 1 khung mẫu có biên độ không đổi = amplitude, đủ dài (numSamples) để RMS xấp xỉ
    // đúng amplitude (RMS của tín hiệu hằng số = chính amplitude đó).
    private fun constantFrame(amplitude: Short, numSamples: Int = 320): ShortArray =
        ShortArray(numSamples) { amplitude }

    @Test
    fun `khung im lang bien do thap khong duoc coi la voice`() {
        // enterThreshold ban đầu = max(noiseFloor=200 * 2.5, MIN_NOISE_FLOOR=30 * 2.5) = 500,
        // amplitude 10 (RMS=10) thấp hơn nhiều -> phải là false.
        val frame = constantFrame(10)
        assertFalse(vad.process(frame, frame.size, now = 0L))
    }

    @Test
    fun `khung bien do lon vuot nguong duoc coi la voice ngay lan dau`() {
        // amplitude 1000 (RMS=1000) > enterThreshold=500 (tính từ noiseFloor khởi tạo mặc định
        // 200, chưa bị amplitude thấp nào làm trôi trước đó) -> phải là true ngay lần gọi đầu.
        val frame = constantFrame(1000)
        assertTrue(vad.process(frame, frame.size, now = 0L))
    }

    @Test
    fun `length 0 tra ve trang thai isVoice hien tai, khong lam gi them`() {
        // Trước khi có tiếng nói: length=0 phải trả về false (trạng thái ban đầu), không crash.
        assertFalse(vad.process(ShortArray(10), 0, now = 0L))

        // Sau khi đã vào trạng thái voice: length=0 phải giữ nguyên true (không tự tắt vì 1 lần
        // gọi length=0 - thường xảy ra khi AudioRecord.read() trả về 0 tạm thời).
        vad.process(constantFrame(1000), 320, now = 0L)
        assertTrue(vad.process(ShortArray(10), 0, now = 10L))
    }

    @Test
    fun `hangover giu trang thai voice dung 250ms im lang sau khi tieng noi dut, tat sau khi vuot moc do`() {
        // Kích hoạt voice trước (amplitude 1000, noiseFloor vẫn ở mức khởi tạo 200 vì chưa có
        // khung im lặng nào trước đó để làm trôi noiseFloor) tại mốc now=0.
        assertTrue(vad.process(constantFrame(1000), 320, now = 0L))
        // -> hangoverUntil (nội bộ) = 0 + HANGOVER_MS(250) = 250.

        // exitThreshold = max(200*1.6, 30*1.6) = 320 - khung im lặng amplitude=50 (RMS=50) thấp
        // hơn nhiều, đúng nhánh "dưới exit threshold, còn hangover".
        val quietFrame = constantFrame(50)

        // Các mốc thời gian TRƯỚC khi hangover hết hạn (< 250ms kể từ lúc tiếng nói dứt ở now=0)
        // vẫn phải còn true, bất kể gọi bao nhiêu LẦN - khác hẳn cách đếm-khung cũ (số lần gọi
        // không còn quyết định gì cả, chỉ mốc thời gian mới quyết định).
        assertTrue("còn trong hangover ở now=50ms", vad.process(quietFrame, quietFrame.size, now = 50L))
        assertTrue("còn trong hangover ở now=150ms", vad.process(quietFrame, quietFrame.size, now = 150L))
        assertTrue("còn trong hangover ở now=249ms (sát mốc, chưa hết)", vad.process(quietFrame, quietFrame.size, now = 249L))

        // Ngay tại/sau mốc 250ms: hangover đã hết hạn -> phải chuyển về false.
        assertFalse("hangover đã hết ở now=250ms - phải chuyển về false", vad.process(quietFrame, quietFrame.size, now = 250L))
    }

    @Test
    fun `tieng noi lien tuc lam moi lai hangover, khong tat som`() {
        var now = 0L
        assertTrue(vad.process(constantFrame(1000), 320, now))

        // Xen kẽ 1 khung im lặng (dùng bớt hangover, nhưng KHÔNG đủ 250ms để hết hạn) rồi lại 1
        // khung to (refresh lại hangoverUntil) - lặp lại nhiều lần phải luôn còn true, dù tổng
        // thời gian trôi qua CỘNG DỒN đã vượt xa 250ms (vì mỗi lần khung to xen vào đã đẩy lại
        // mốc hết hạn thêm 250ms kể từ thời điểm đó).
        repeat(10) {
            now += 100 // mỗi bước cách nhau 100ms < HANGOVER_MS=250ms - không đủ để hết hạn
            assertTrue(vad.process(constantFrame(50), 320, now)) // dùng bớt hangover
            now += 50
            assertTrue(vad.process(constantFrame(1000), 320, now)) // refresh lại hangover
        }
    }

    @Test
    fun `reset dua VadDetector ve trang thai ban dau nhu vua khoi tao`() {
        // Đưa vào trạng thái voice=true trước.
        assertTrue(vad.process(constantFrame(1000), 320, now = 0L))

        vad.reset()

        // Sau reset: hành vi phải giống hệt 1 instance MỚI - khung im lặng phải là false, khung
        // to (amplitude 1000, vượt enterThreshold=500 tính từ noiseFloor mặc định 200) lại phải
        // là true ngay lần gọi đầu, y hệt test "khung bien do lon..." ở trên. Dùng lại now=0 vì
        // reset() cũng xoá sạch state thời gian nội bộ (hangoverUntil=0L).
        assertFalse(vad.process(constantFrame(10), 320, now = 0L))
        vad.reset()
        assertTrue(vad.process(constantFrame(1000), 320, now = 0L))
    }

    @Test
    fun `kich hoat voice tu khung on dau phien roi on nen duy tri KHONG duoc kẹt vinh vien`() {
        // Tái hiện đúng bug đã tìm thấy khi audit: khung ĐẦU TIÊN của phiên đã đủ ồn để vượt
        // enterThreshold=500 (tính từ noiseFloor khởi tạo 200) - mô phỏng bấm ghi đúng lúc có
        // tiếng ồn đột ngột (xe chạy qua, quạt bật, pop của mic lúc mới mở).
        var now = 0L
        assertTrue(vad.process(constantFrame(600), 320, now))

        // Tiếng ồn NỀN (không phải giọng nói) duy trì liên tục ở RMS=400 - thấp hơn enterThreshold
        // gốc (500) nhưng CAO HƠN exitThreshold gốc (320 = 200*1.6), nên nếu không có cơ chế giải
        // cứu, mỗi khung đều thoả rms > exitThreshold -> hangover tự refresh vô hạn -> isVoice
        // không bao giờ về false. Test này khẳng định điều đó KHÔNG xảy ra: cuối cùng VAD phải tự
        // thoát trạng thái voice, rõ ràng trước khi phiên kéo dài vô tận.
        val sustainedNoise = constantFrame(400)
        var becameFalse = false
        // Chạy khung 20ms liên tục tới 10s (400ms x 25 = vượt xa STUCK_VOICE_RESCUE_MS=4000ms,
        // nhưng vẫn có giới hạn rõ ràng - không phải "chạy mãi tới khi pass").
        repeat(500) {
            now += 20
            if (!vad.process(sustainedNoise, sustainedNoise.size, now)) {
                becameFalse = true
                return@repeat
            }
        }

        assertTrue(
            "VAD phải tự thoát isVoice=true trong vòng 10s dù nhiễu nền duy trì liên tục - " +
                "nếu fail ở đây nghĩa là bug 'kẹt vĩnh viễn' đã quay lại",
            becameFalse
        )
    }

    @Test
    fun `cau noi binh thuong duoi nguong giai cuu KHONG bi anh huong boi co che rescue`() {
        // Câu nói kéo dài dưới STUCK_VOICE_RESCUE_MS (4000ms) phải hoạt động y hệt trước khi có
        // cơ chế giải cứu - không có chuyện noiseFloor bị "kéo" lên giữa chừng làm giọng nói nhỏ
        // dần cuối câu bị cắt sớm hơn bình thường.
        var now = 0L
        assertTrue(vad.process(constantFrame(1000), 320, now)) // vào voice tại now=0

        // Duy trì "giọng nói" (RMS=1000, luôn > exitThreshold=320) trong 3s (< 4000ms) - vẫn phải
        // luôn true suốt, và không có rescue nào kích hoạt (chưa vượt mốc 4000ms).
        repeat(150) {
            now += 20
            assertTrue("vẫn phải là voice ở now=${now}ms (< mốc rescue)", vad.process(constantFrame(1000), 320, now))
        }

        // Giờ tiếng nói dứt (khung im lặng amplitude=50) - vì rescue chưa từng chạy, noiseFloor
        // vẫn nguyên 200 như thiết kế gốc, hangover 250ms phải hoạt động y hệt test hangover ở
        // trên, không bị rút ngắn hay kéo dài bất thường do rescue.
        val quietFrame = constantFrame(50)
        assertTrue("còn hangover ngay sau khi dứt tiếng", vad.process(quietFrame, quietFrame.size, now + 100))
        assertFalse("hangover phải hết đúng 250ms sau khung nói cuối", vad.process(quietFrame, quietFrame.size, now + 260))
    }

    @Test
    fun `noise floor thich nghi dan len tu cac khung im lang bien do trung binh`() {
        // Nhiều khung amplitude=300 liên tiếp (thấp hơn enterThreshold ban đầu=500 nên vẫn được
        // coi là "im lặng", noiseFloor sẽ trôi dần từ 200 lên gần 300 qua EMA) - sau đó
        // enterThreshold mới sẽ cao hơn 500 ban đầu, nghĩa là 1 khung amplitude=600 (đủ vượt
        // ngưỡng gốc 500) có thể KHÔNG còn đủ vượt ngưỡng mới đã trôi lên. Test này chỉ xác nhận
        // chuỗi khung amplitude=300 không tự nhảy thành voice=true (đúng thiết kế: nhiễu nền
        // trung bình không được coi là giọng nói dù lặp lại nhiều lần).
        val mediumNoise = constantFrame(300)
        var now = 0L
        repeat(50) {
            assertFalse(vad.process(mediumNoise, mediumNoise.size, now))
            now += 20
        }
    }

    @Test
    fun `noise floor bi chan tran khi nen tang dan lien tuc, khong duoc chay theo vo han`() {
        // Fix (audit - "comment claim test khong ton tai"): VadDetector.kt (khai báo
        // MAX_NOISE_FLOOR) khẳng định kịch bản "nền tăng dần" (nhạc dạo đầu to dần kiểu
        // crescendo) đã được tái hiện + test - nhưng test đó CHƯA từng tồn tại (không có
        // tests/vad/, và bộ test JUnit này trước đây chỉ có test "trôi lên từ biên độ HẰNG SỐ",
        // không phải "tăng dần liên tục"). Test này lấp đúng chỗ trống đó.
        //
        // Mô phỏng: mỗi khung có amplitude = noiseFloor HIỆN TẠI (ước lượng song song ở biến
        // simulatedNoiseFloor bên dưới, cùng công thức EMA + chặn trên trong VadDetector.process())
        // nhân 2.4 - LUÔN thấp hơn ENTER_SPEECH_RATIO=2.5 nên KHÔNG bao giờ tự kích hoạt voice
        // trong lúc tăng dần (đúng bản chất bug: "không frame nào bị coi là voice trong cả đoạn"),
        // nhưng đủ để kéo noiseFloor tăng theo cấp số nhân (hệ số ~1.07/khung nếu KHÔNG bị chặn -
        // tăng vô hạn dù chạy bao lâu). Nếu MAX_NOISE_FLOOR (1500.0, xem VadDetector.kt) vẫn hoạt
        // động đúng, noiseFloor thật sự KHÔNG thể vượt 1500 dù ramp chạy bao lâu - kiểm chứng gián
        // tiếp bằng cách: sau khi ramp xong, 1 khung amplitude=4000 (rms=4000) phải VƯỢT
        // enterThreshold đã bị chặn trần (max(1500*2.5, 30*2.5)=3750) và trở thành voice=true.
        // Nếu cơ chế chặn trần bị gỡ/hỏng, noiseFloor thật sự sẽ lớn hơn RẤT NHIỀU so với 1500 sau
        // 400 khung tăng theo cấp số nhân 1.07 (200 * 1.07^400 lớn hơn 4000/2.5 gấp nhiều bậc độ
        // lớn) -> enterThreshold thật cũng vượt xa 4000 -> assertTrue ở cuối sẽ FAIL, đúng ý nghĩa
        // của 1 test hồi quy (regression test) cho bug này.
        var now = 0L
        var simulatedNoiseFloor = 200.0
        repeat(400) {
            val amplitude = (simulatedNoiseFloor * 2.4).toInt().toShort()
            assertFalse(
                "ramp tang dan KHONG duoc tu kich hoat voice o khung thu $it (amplitude=$amplitude)",
                vad.process(constantFrame(amplitude), 320, now)
            )
            simulatedNoiseFloor += (amplitude - simulatedNoiseFloor) * 0.05
            if (simulatedNoiseFloor > 1500.0) simulatedNoiseFloor = 1500.0
            now += 20
        }

        // Sau ramp: 1 khung "giọng nói thật" rõ ràng (rms=4000, cao hơn cả mức crescendo vừa
        // ramp tới) phải VẪN được nhận ra là voice - đúng ý "chặn trên giới hạn thiệt hại" trong
        // comment MAX_NOISE_FLOOR, chứ không phải "VAD mất tác dụng cả phiên" như bug gốc.
        assertTrue(
            "sau khi nen tang dan, 1 khung giong noi that (rms=4000) van phai vuot nguong da " +
                "bi chan tran (~3750) - neu FAIL nghia la MAX_NOISE_FLOOR khong con hoat dung",
            vad.process(constantFrame(4000), 320, now)
        )
    }
}
