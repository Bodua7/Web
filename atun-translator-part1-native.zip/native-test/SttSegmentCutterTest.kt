package com.atun.translator

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// Test JUnit thuần (không Robolectric) cho SttSegmentCutter - tách ra từ vòng lặp thật trong
// SttReadLoop.kt để pin lại đúng 2 điều kiện cắt đoạn đã ghi trong comment gốc: (1) đã có giọng
// nói + vừa im lặng đủ lâu, HOẶC (2) đoạn quá dài dù chưa pause. Dùng mốc thời gian tự chọn
// (không phải System.currentTimeMillis() thật) để test không phụ thuộc tốc độ máy chạy CI.
class SttSegmentCutterTest {
    private val pauseMs = 800L
    private val maxSegmentMs = 15_000L

    @Test
    fun `chua co giong noi thi khong flush du da qua pauseMs`() {
        val cutter = SttSegmentCutter(pauseMs, maxSegmentMs)
        val t0 = 1_000_000L
        cutter.reset(t0)
        cutter.onFrame(t0, isVoiceFrame = false)
        // Toàn khung im lặng, chưa từng có giọng nói -> điều kiện (1) không thoả (cần
        // hasVoiceInSegment == true trước), và chưa đủ maxSegmentMs -> không flush.
        assertFalse(cutter.shouldFlush(t0 + pauseMs + 1))
        assertFalse(cutter.hasVoice())
    }

    @Test
    fun `co giong noi roi im lang du pauseMs thi flush`() {
        val cutter = SttSegmentCutter(pauseMs, maxSegmentMs)
        val t0 = 1_000_000L
        cutter.reset(t0)
        cutter.onFrame(t0, isVoiceFrame = true) // 1 khung có giọng nói tại t0
        // Ngay sau đó, chưa đủ pauseMs -> chưa flush.
        assertFalse(cutter.shouldFlush(t0 + pauseMs - 1))
        // Đủ đúng pauseMs kể từ khung giọng nói CUỐI CÙNG -> flush (dùng ">=", không phải ">").
        assertTrue(cutter.shouldFlush(t0 + pauseMs))
        assertTrue(cutter.hasVoice())
    }

    @Test
    fun `giong noi lien tuc khong pause nhung vuot maxSegmentMs van flush`() {
        val cutter = SttSegmentCutter(pauseMs, maxSegmentMs)
        val t0 = 1_000_000L
        cutter.reset(t0)
        // Giả lập người nói liên tục, không có khoảng lặng nào >= pauseMs: bắn khung giọng nói
        // đều đặn mỗi 100ms cho tới khi vượt maxSegmentMs.
        var t = t0
        while (t < t0 + maxSegmentMs) {
            cutter.onFrame(t, isVoiceFrame = true)
            assertFalse("chưa tới maxSegmentMs thì chưa nên flush dù nói liên tục", cutter.shouldFlush(t))
            t += 100
        }
        assertTrue("đã vượt maxSegmentMs thì phải flush dù không hề có pause nào", cutter.shouldFlush(t))
    }

    @Test
    fun `moi khung im lang xen giua khong lam reset dem pause`() {
        val cutter = SttSegmentCutter(pauseMs, maxSegmentMs)
        val t0 = 1_000_000L
        cutter.reset(t0)
        cutter.onFrame(t0, isVoiceFrame = true)
        // 1 khung im lặng ở giữa KHÔNG được coi là "giọng nói mới" - lastVoiceAt vẫn phải là t0,
        // không phải thời điểm khung im lặng này.
        cutter.onFrame(t0 + 100, isVoiceFrame = false)
        assertFalse(cutter.shouldFlush(t0 + pauseMs - 1))
        assertTrue(cutter.shouldFlush(t0 + pauseMs))
    }

    // ===== Test cho phương án "nhận giọng ca sĩ khi hát" =====

    @Test
    fun `cat lien tiep 3 lan vi het gio thi bao nghe giong nhac`() {
        val cutter = SttSegmentCutter(pauseMs, maxSegmentMs)
        val t0 = 1_000_000L
        cutter.reset(t0)

        // Giả lập 1 bài hát: giọng nói liên tục (VAD báo voice=true đều đặn), không hề có
        // khoảng lặng >= pauseMs nào - mô phỏng bằng cách gọi shouldFlush() lặp lại nhiều lần,
        // mỗi lần đều chỉ chạm maxSegmentMs (giống hệt cách test
        // "giong noi lien tuc khong pause nhung vuot maxSegmentMs van flush" ở trên làm cho 1 đoạn).
        var t = t0
        repeat(SttSegmentCutter.CONTINUOUS_MUSIC_HINT_THRESHOLD - 1) { i ->
            cutter.onFrame(t, isVoiceFrame = true)
            assertTrue("lần cắt thứ ${i + 1} phải xảy ra đúng lúc chạm maxSegmentMs", cutter.shouldFlush(t + maxSegmentMs))
            assertFalse("chưa đủ ${SttSegmentCutter.CONTINUOUS_MUSIC_HINT_THRESHOLD} lần thì chưa nên báo nhạc", cutter.justCrossedContinuousMusicHint())
            assertFalse(cutter.isLikelyContinuousMusic())
            cutter.reset(t + maxSegmentMs) // SttReadLoop.kt gọi reset() ngay sau mỗi lần flush
            t += maxSegmentMs
        }

        // Lần cắt thứ CONTINUOUS_MUSIC_HINT_THRESHOLD (thứ 3, mặc định) - vừa CHẠM ngưỡng.
        cutter.onFrame(t, isVoiceFrame = true)
        assertTrue(cutter.shouldFlush(t + maxSegmentMs))
        assertTrue("đúng lúc chạm ngưỡng phải báo true", cutter.justCrossedContinuousMusicHint())
        assertTrue(cutter.isLikelyContinuousMusic())
    }

    @Test
    fun `qua nguong roi thi khong bao lai moi lan cat tiep theo`() {
        val cutter = SttSegmentCutter(pauseMs, maxSegmentMs)
        val t0 = 1_000_000L
        cutter.reset(t0)
        var t = t0
        repeat(SttSegmentCutter.CONTINUOUS_MUSIC_HINT_THRESHOLD) {
            cutter.onFrame(t, isVoiceFrame = true)
            cutter.shouldFlush(t + maxSegmentMs)
            cutter.reset(t + maxSegmentMs)
            t += maxSegmentMs
        }
        assertTrue(cutter.isLikelyContinuousMusic())

        // Lần cắt thứ 4 (đã QUA ngưỡng, không phải VỪA chạm) - vẫn coi là "nghe giống nhạc"
        // (isLikelyContinuousMusic tiếp tục true, để JS tiếp tục bỏ qua đoạn này), nhưng KHÔNG
        // bắn cảnh báo lại (justCrossedContinuousMusicHint false) - tránh nhắc lại banner mỗi 12s
        // suốt cả bài hát.
        cutter.onFrame(t, isVoiceFrame = true)
        assertTrue(cutter.shouldFlush(t + maxSegmentMs))
        assertFalse("đã báo 1 lần rồi thì các lần cắt tiếp theo không nên báo lại", cutter.justCrossedContinuousMusicHint())
        assertTrue(cutter.isLikelyContinuousMusic())
    }

    @Test
    fun `co 1 lan pause that thi dem ve 0 va het bao nhac`() {
        val cutter = SttSegmentCutter(pauseMs, maxSegmentMs)
        val t0 = 1_000_000L
        cutter.reset(t0)
        var t = t0
        repeat(SttSegmentCutter.CONTINUOUS_MUSIC_HINT_THRESHOLD) {
            cutter.onFrame(t, isVoiceFrame = true)
            cutter.shouldFlush(t + maxSegmentMs)
            cutter.reset(t + maxSegmentMs)
            t += maxSegmentMs
        }
        assertTrue("phải đang ở trạng thái nghe giống nhạc trước khi test pause", cutter.isLikelyContinuousMusic())

        // Bây giờ có 1 câu nói thật, kết thúc bằng 1 khoảng lặng đủ pauseMs - đây là dấu hiệu
        // đây là lời nói bình thường, phải đưa bộ đếm về 0 ngay, tắt luôn cờ "nghe giống nhạc".
        cutter.onFrame(t, isVoiceFrame = true)
        assertTrue(cutter.shouldFlush(t + pauseMs))
        assertFalse("cắt do PAUSE thật thì không được coi là 'nghe giống nhạc'", cutter.isLikelyContinuousMusic())
        assertFalse(cutter.justCrossedContinuousMusicHint())
    }

    @Test
    fun `reset xoa het state cua doan truoc`() {
        val cutter = SttSegmentCutter(pauseMs, maxSegmentMs)
        val t0 = 1_000_000L
        cutter.reset(t0)
        cutter.onFrame(t0, isVoiceFrame = true)
        assertTrue(cutter.hasVoice())

        val t1 = t0 + 5_000L
        cutter.reset(t1) // như lúc flushSegment() gọi lại reset() cho đoạn mới
        assertFalse("reset() phải xoá hasVoiceInSegment của đoạn cũ", cutter.hasVoice())
        // maxSegmentMs phải tính lại từ t1, không phải t0.
        assertFalse(cutter.shouldFlush(t1 + maxSegmentMs - 1))
        assertTrue(cutter.shouldFlush(t1 + maxSegmentMs))
    }
}
