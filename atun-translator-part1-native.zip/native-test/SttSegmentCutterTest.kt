package com.atun.translator

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// Test JUnit thuần (không Robolectric) cho SttSegmentCutter - tách ra từ vòng lặp thật trong
// SttReadLoop.kt để pin lại đúng 2 điều kiện cắt đoạn đã ghi trong comment gốc: (1) đã có giọng
// nói + vừa im lặng đủ lâu, HOẶC (2) đoạn quá dài dù chưa pause. Dùng mốc thời gian tự chọn
// (không phải System.currentTimeMillis() thật) để test không phụ thuộc tốc độ máy chạy CI.
class SttSegmentCutterTest {
    private val pauseMs = 800L
    private val maxSegmentMs = 15_000L

    @Test
    fun `chua co giong noi thi khong flush du da qua pauseMs`() {
        val cutter = SttSegmentCutter(pauseMs, maxSegmentMs)
        val t0 = 1_000_000L
        cutter.reset(t0)
        cutter.onFrame(t0, isVoiceFrame = false)
        // Toàn khung im lặng, chưa từng có giọng nói -> điều kiện (1) không thoả (cần
        // hasVoiceInSegment == true trước), và chưa đủ maxSegmentMs -> không flush.
        assertFalse(cutter.shouldFlush(t0 + pauseMs + 1))
        assertFalse(cutter.hasVoice())
    }

    @Test
    fun `co giong noi roi im lang du pauseMs thi flush`() {
        val cutter = SttSegmentCutter(pauseMs, maxSegmentMs)
        val t0 = 1_000_000L
        cutter.reset(t0)
        cutter.onFrame(t0, isVoiceFrame = true) // 1 khung có giọng nói tại t0
        // Ngay sau đó, chưa đủ pauseMs -> chưa flush.
        assertFalse(cutter.shouldFlush(t0 + pauseMs - 1))
        // Đủ đúng pauseMs kể từ khung giọng nói CUỐI CÙNG -> flush (dùng ">=", không phải ">").
        assertTrue(cutter.shouldFlush(t0 + pauseMs))
        assertTrue(cutter.hasVoice())
    }

    @Test
    fun `giong noi lien tuc khong pause nhung vuot maxSegmentMs van flush`() {
        val cutter = SttSegmentCutter(pauseMs, maxSegmentMs)
        val t0 = 1_000_000L
        cutter.reset(t0)
        // Giả lập người nói liên tục, không có khoảng lặng nào >= pauseMs: bắn khung giọng nói
        // đều đặn mỗi 100ms cho tới khi vượt maxSegmentMs.
        var t = t0
        while (t < t0 + maxSegmentMs) {
            cutter.onFrame(t, isVoiceFrame = true)
            assertFalse("chưa tới maxSegmentMs thì chưa nên flush dù nói liên tục", cutter.shouldFlush(t))
            t += 100
        }
        assertTrue("đã vượt maxSegmentMs thì phải flush dù không hề có pause nào", cutter.shouldFlush(t))
    }

    @Test
    fun `moi khung im lang xen giua khong lam reset dem pause`() {
        val cutter = SttSegmentCutter(pauseMs, maxSegmentMs)
        val t0 = 1_000_000L
        cutter.reset(t0)
        cutter.onFrame(t0, isVoiceFrame = true)
        // 1 khung im lặng ở giữa KHÔNG được coi là "giọng nói mới" - lastVoiceAt vẫn phải là t0,
        // không phải thời điểm khung im lặng này.
        cutter.onFrame(t0 + 100, isVoiceFrame = false)
        assertFalse(cutter.shouldFlush(t0 + pauseMs - 1))
        assertTrue(cutter.shouldFlush(t0 + pauseMs))
    }

    @Test
    fun `reset xoa het state cua doan truoc`() {
        val cutter = SttSegmentCutter(pauseMs, maxSegmentMs)
        val t0 = 1_000_000L
        cutter.reset(t0)
        cutter.onFrame(t0, isVoiceFrame = true)
        assertTrue(cutter.hasVoice())

        val t1 = t0 + 5_000L
        cutter.reset(t1) // như lúc flushSegment() gọi lại reset() cho đoạn mới
        assertFalse("reset() phải xoá hasVoiceInSegment của đoạn cũ", cutter.hasVoice())
        // maxSegmentMs phải tính lại từ t1, không phải t0.
        assertFalse(cutter.shouldFlush(t1 + maxSegmentMs - 1))
        assertTrue(cutter.shouldFlush(t1 + maxSegmentMs))
    }
}
