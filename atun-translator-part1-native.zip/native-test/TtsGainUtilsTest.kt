package com.atun.translator

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test

class TtsGainUtilsTest {

    @Test
    fun `gain 1_0 giu nguyen mau khong doi`() {
        val input = shortArrayOf(100, -100, 0, 32000, -32000)
        assertArrayEquals(input, applyGainToPcm16(input, 1.0f))
    }

    @Test
    fun `gain 2_0 nhan doi bien do dung`() {
        val input = shortArrayOf(100, -100, 5000, -5000, 0)
        val expected = shortArrayOf(200, -200, 10000, -10000, 0)
        assertArrayEquals(expected, applyGainToPcm16(input, 2.0f))
    }

    @Test
    fun `gain le lam tron ve so nguyen gan nhat`() {
        // 100 * 1.234 = 123.4 -> làm tròn xuống 123; 100 * 1.236 = 123.6 -> làm tròn lên 124.
        // Cố tình tránh test đúng mốc .5 (vd 101 * 1.5 = 151.5) - quy ước làm tròn .5 khác nhau
        // giữa các hàm round (nửa lên vs nửa chẵn) nên tránh test đúng biên đó để không phụ
        // thuộc quy ước cụ thể nào.
        assertArrayEquals(shortArrayOf(123), applyGainToPcm16(shortArrayOf(100), 1.234f))
        assertArrayEquals(shortArrayOf(124), applyGainToPcm16(shortArrayOf(100), 1.236f))
    }

    @Test
    fun `vuot tran duong thi clip ve Short_MAX_VALUE khong wrap-around`() {
        val input = shortArrayOf(20000, 32767)
        val result = applyGainToPcm16(input, 3.0f)
        assertEquals(Short.MAX_VALUE, result[0])
        assertEquals(Short.MAX_VALUE, result[1])
    }

    @Test
    fun `vuot tran am thi clip ve Short_MIN_VALUE khong wrap-around`() {
        val input = shortArrayOf(-20000, -32768)
        val result = applyGainToPcm16(input, 3.0f)
        assertEquals(Short.MIN_VALUE, result[0])
        assertEquals(Short.MIN_VALUE, result[1])
    }

    @Test
    fun `gain 0 thi tat ca mau ve 0 (cau lang)`() {
        val input = shortArrayOf(12345, -12345, 32767, -32768)
        val result = applyGainToPcm16(input, 0f)
        assertArrayEquals(shortArrayOf(0, 0, 0, 0), result)
    }

    @Test
    fun `mang rong tra ve mang rong khong loi`() {
        val result = applyGainToPcm16(ShortArray(0), 2.0f)
        assertEquals(0, result.size)
    }
}
