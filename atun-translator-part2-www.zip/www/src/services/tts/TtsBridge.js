// Bridge gọi plugin native TtsPlugin (đọc to bản dịch tiếng Việt qua TextToSpeech có sẵn của
// Android) - chỉ hoạt động khi chạy trong app Android đã build.

function plugin() {
  return window.Capacitor?.Plugins?.TtsPlugin || null;
}

export function isTtsAvailable() {
  return plugin() !== null;
}

// flushMode: true = bỏ câu cũ chưa đọc xong, luôn đọc câu MỚI NHẤT ngay (tránh đọc trễ xa audio
// thật khi dịch ra nhanh); false (mặc định) = đọc đủ hết, có thể trễ dần nếu nói liên tục.
export async function speakTranslation(text, { flushMode = false } = {}) {
  const p = plugin();
  if (!p || !text) return;
  try {
    await p.speak({ text, flushMode });
  } catch (e) {
    // Lỗi đọc to (vd chưa cài giọng tiếng Việt) không được làm hỏng luồng dịch chính -
    // bên gọi tự kiểm tra checkVietnameseVoice() để báo cho user, ở đây chỉ im lặng bỏ qua.
  }
}

export async function stopSpeaking() {
  const p = plugin();
  if (!p) return;
  await p.stop().catch(() => {});
}

export async function setTtsRate(rate) {
  const p = plugin();
  if (!p) return;
  await p.setRate({ rate }).catch(() => {});
}

// volume: 0-1. Xem native/TtsPlugin.kt setVolume() - vừa set volume tương đối của utterance
// (KEY_PARAM_VOLUME) vừa tự nâng thẳng mức stream "Trợ năng" (Accessibility) mà TextToSpeech
// dùng, vì mức stream đó nhiều máy để mặc định rất thấp, khiến "âm lượng dịch nhỏ" dù volume
// tương đối đã set 100%.
export async function setTtsVolume(volume) {
  const p = plugin();
  if (!p) return;
  await p.setVolume({ volume }).catch(() => {});
}

// enabled: có tự hạ âm lượng gốc lúc đọc hay không. duckPercent: hạ âm lượng gốc còn bao
// nhiêu % mức hiện tại trong lúc đang đọc (0 = im hẳn, 100 = không hạ gì).
export async function setAutoDuck(enabled, duckPercent) {
  const p = plugin();
  if (!p) return;
  await p.setAutoDuck({ enabled, duckPercent }).catch(() => {});
}

// boostDb: 0-30. Khuếch đại THẬT biên độ tín hiệu TTS qua LoudnessEnhancer (native/TtsPlugin.kt
// setBoost()) - vượt trần 100% của setVolume thường, tách biệt hẳn với "Âm lượng bản dịch".
export async function setTtsBoost(boostDb) {
  const p = plugin();
  if (!p) return;
  await p.setBoost({ boostDb }).catch(() => {});
}

export async function checkVietnameseVoice() {
  const p = plugin();
  if (!p) return false;
  const res = await p.checkVietnameseVoice().catch(() => null);
  return !!res?.available;
}

export async function promptInstallVoiceData() {
  const p = plugin();
  if (!p) return;
  await p.promptInstallVoiceData().catch(() => {});
}
