// Bridge gọi plugin native MlkitTranslate (Google ML Kit Translate on-device) - chỉ hoạt
// động khi chạy trong app Android đã build (không có trên PWA/web thuần vì ML Kit là SDK
// Android). translateText() ở index.html sẽ ưu tiên thử bridge này trước, fail (hoặc không
// có plugin) mới rơi xuống groq-relay / Google Translate free như cũ.

function plugin() {
  return window.Capacitor?.Plugins?.MlkitTranslate || null;
}

// true nếu đang chạy trong app native VÀ plugin đã đăng ký (không tự động nghĩa là model đã
// tải - chỉ nghĩa là CÓ THỂ gọi translate(), bản thân translate() sẽ tự báo lỗi nếu model
// chưa sẵn sàng và cần mạng để tải).
export function isMlkitAvailable() {
  return plugin() !== null;
}

export async function isMlkitLangSupported(lang) {
  const p = plugin();
  if (!p) return false;
  try {
    const res = await p.isLanguageSupported({ lang });
    return !!res?.supported;
  } catch {
    return false;
  }
}

export async function listMlkitDownloadedLanguages() {
  const p = plugin();
  if (!p) return [];
  const res = await p.listDownloadedModels();
  return res?.languages || [];
}

// requireWifi: mặc định false (model dịch chỉ ~30MB/ngôn ngữ, model Vosk STT lớn nhất trong
// catalog hiện tại cũng chỉ ~128MB - không cần ép Wi-Fi).
export async function downloadMlkitModel(lang, requireWifi = false) {
  const p = plugin();
  if (!p) throw new Error('Plugin MlkitTranslate chưa sẵn sàng (chưa chạy trong app native đã build?)');
  return p.downloadModel({ lang, requireWifi });
}

export async function deleteMlkitModel(lang) {
  const p = plugin();
  if (!p) throw new Error('Plugin MlkitTranslate chưa sẵn sàng.');
  return p.deleteModel({ lang });
}

// Dịch on-device. Ném lỗi nếu plugin không có hoặc model chưa tải xong (offline) - bên gọi
// (translateText() trong index.html) tự fallback sang groq-relay/Google Translate free.
export async function translateMlkit(text, sourceLang, targetLang) {
  const p = plugin();
  if (!p) throw new Error('Plugin MlkitTranslate chưa sẵn sàng.');
  const res = await p.translate({ text, sourceLang, targetLang });
  if (!res?.translated) throw new Error('MlkitTranslate: response rỗng');
  return res.translated;
}

