// Bắt audio hệ thống qua plugin native AudioCapture (MediaProjection +
// AudioPlaybackCaptureConfiguration + Vosk on-device). Đây là cách duy nhất còn dùng để
// nhận audio - hướng lấy audio qua fetch mạng (InnerTube/Piped/Invidious) đã bị gỡ bỏ vì
// bị YouTube chặn hết mọi nguồn công khai (28/8/2026).
//
// Yêu cầu: user mở YouTube (hoặc app bất kỳ) và tự phát video thật; app này chỉ nhận
// text đã được Vosk nhận diện từ audio đang phát ra loa/qua audio pipeline của máy.

export class NativeCaptureBridge {
  constructor({ onPartial, onFinal, onLowConfidence, onError, onModelStatus, onModelLoadingProgress, onAudioLevel, onCaptureResumed } = {}) {
    this.onPartial = onPartial || (() => {});
    // onFinal(text, confidence, detectedLang): confidence 0.0-1.0 (trung bình theo từ), hoặc -1
    // nếu không xác định được (xem VoskEngine.extractResultWithConfidence). Đây là câu ĐÃ QUA lọc
    // độ tin cậy native (VoskEngine.CONFIDENCE_DROP_THRESHOLD) - chỉ đẩy lên đây câu được coi là
    // đáng tin. detectedLang: undefined ở chế độ 1 ngôn ngữ bình thường; có giá trị (vd "vi",
    // "ja") CHỈ khi đang ở chế độ "Tự động nhận diện" (sourceLang == "auto") - là ngôn ngữ mà bộ
    // nhận diện song song native (MultiLangVoskEngine) đã chọn cho đúng câu này.
    this.onFinal = onFinal || (() => {});
    // onLowConfidence(text, confidence): câu bị native lọc bỏ vì độ tin cậy quá thấp (thường là
    // Vosk nghe nhầm nhạc/nhiễu nền thành lời nói) - không nằm trong luồng dịch chính, chỉ để
    // debug/hiển thị mờ nếu muốn.
    this.onLowConfidence = onLowConfidence || (() => {});
    // onError(message, code): code là định danh máy-đọc-được (vd 'SYSTEM_CAPTURE_BLOCKED')
    // dùng để tự động xử lý (auto-fallback...), khác message vốn chỉ để hiện cho người đọc.
    // code có thể là undefined với các lỗi chung chung không có hành động tự động tương ứng.
    this.onError = onError || (() => {});
    this.onModelStatus = onModelStatus || (() => {});
    // onModelLoadingProgress(loaded, total): CHỈ bắn ở chế độ "Tự động nhận diện" (nhiều model
    // Vosk load song song, xem MultiLangVoskEngine) - không bắn ở chế độ 1 ngôn ngữ thường.
    this.onModelLoadingProgress = onModelLoadingProgress || (() => {});
    this.onAudioLevel = onAudioLevel || (() => {}); // mức tín hiệu audio thực tế, xem NativeCaptureBridge/AudioCaptureService
    // Bắn khi service tự phục hồi capture sau khi bị OS kill (chỉ xảy ra ở chế độ mic).
    this.onCaptureResumed = onCaptureResumed || (() => {});
    this._listenersRegistered = false;
  }

  _plugin() {
    const plugin = window.Capacitor?.Plugins?.AudioCapture;
    if (!plugin) {
      throw new Error('Plugin AudioCapture chưa sẵn sàng (chưa chạy trong app native đã build?)');
    }
    return plugin;
  }

  _registerListenersOnce() {
    if (this._listenersRegistered) return;
    const plugin = this._plugin();

    plugin.addListener('partialText', (data) => this.onPartial(data.text));
    plugin.addListener('finalText', (data) => this.onFinal(data.text, data.confidence, data.detectedLang));
    plugin.addListener('lowConfidenceText', (data) => this.onLowConfidence(data.text, data.confidence));
    plugin.addListener('captureError', (data) => this.onError(data.message, data.code));
    plugin.addListener('modelStatus', (data) => this.onModelStatus(data.ready));
    plugin.addListener('modelLoadingProgress', (data) => this.onModelLoadingProgress(data.loaded, data.total));
    plugin.addListener('audioLevel', (data) => this.onAudioLevel(data));
    plugin.addListener('captureResumed', (data) => this.onCaptureResumed(data.mode));

    this._listenersRegistered = true;
  }

  // captureMode: 'system' (mặc định, bắt audio phát ra từ app khác - cần dialog MediaProjection)
  // hoặc 'mic' (ghi âm qua micro máy - dùng khi nghe qua loa ngoài, hoặc khi app nguồn tự chặn
  // playback capture). Với 'system', PHẢI gọi từ một user gesture (click/tap) - dialog hệ thống
  // sẽ không tự bật được. sourceLang: ngôn ngữ ĐANG được nói trong audio nguồn (vd 'en' nếu
  // YouTube đang nói tiếng Anh), không phải ngôn ngữ muốn dịch tới.
  // smartPause: bật/tắt chế độ ngắt câu thông minh (ép chốt câu ngay khi phát hiện người nói
  // tạm nghỉ ~30ms, xem AudioCaptureService.SMART_PAUSE_MS) thay vì đợi endpointer tự nhiên
  // của Vosk.
  async start(sourceLang = 'en', captureMode = 'system', smartPause = true) {
    this._registerListenersOnce();
    const plugin = this._plugin();
    return plugin.requestCapture({ sourceLang, captureMode, smartPause });
  }

  async stop() {
    const plugin = this._plugin();
    return plugin.stopCapture();
  }

  // Gọi khi app mở lại (vd. resume) để biết phiên "system" trước đó có bị OS âm thầm dừng
  // giữa chừng không (không tự phục hồi được) - trả về true nếu có, để UI báo cho user.
  async checkLostSession() {
    const plugin = this._plugin();
    const res = await plugin.checkLostSession();
    return !!res?.lostSystemSession;
  }

  // ===== Miễn trừ tối ưu pin - xem AudioCapturePlugin.kt =====
  async checkBatteryOptimization() {
    const plugin = this._plugin();
    const res = await plugin.checkBatteryOptimization();
    return !!res?.ignoringOptimizations;
  }

  async requestIgnoreBatteryOptimizations() {
    const plugin = this._plugin();
    const res = await plugin.requestIgnoreBatteryOptimizations();
    return !!res?.ignoringOptimizations;
  }
}
