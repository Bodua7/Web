// Bắt audio hệ thống/micro qua plugin native AudioCapture (MediaProjection +
// AudioPlaybackCaptureConfiguration, hoặc AudioRecord qua micro), cắt câu bằng VAD rồi upload
// đoạn audio lên Whisper Cloud (Groq, qua groq-relay) để lấy text - đây là cách duy nhất còn
// dùng để nhận diện giọng nói (đã bỏ hẳn nhánh Vosk on-device offline).
//
// Yêu cầu: user mở YouTube (hoặc app bất kỳ) và tự phát video thật, hoặc nói qua micro; app
// này chỉ nhận audio đang phát ra loa/qua audio pipeline của máy (hoặc qua micro).

export class NativeCaptureBridge {
  constructor({ onError, onModelStatus, onAudioLevel, onCaptureResumed, onCloudSttSegment, onMicDeviceInfo } = {}) {
    // onError(message, code): code là định danh máy-đọc-được (vd 'SYSTEM_CAPTURE_BLOCKED')
    // dùng để tự động xử lý (auto-fallback...), khác message vốn chỉ để hiện cho người đọc.
    // code có thể là undefined với các lỗi chung chung không có hành động tự động tương ứng.
    this.onError = onError || (() => {});
    // onModelStatus(ready): với Cloud STT luôn bắn ready=true ngay khi bắt đầu capture (không có
    // model local nào để tải) - dùng để JS ẩn trạng thái "đang tải model" nếu còn hiển thị.
    this.onModelStatus = onModelStatus || (() => {});
    this.onAudioLevel = onAudioLevel || (() => {}); // mức tín hiệu audio thực tế, xem AudioCaptureService
    // Bắn khi service tự phục hồi capture sau khi bị OS kill (chỉ xảy ra ở chế độ mic).
    this.onCaptureResumed = onCaptureResumed || (() => {});
    // onCloudSttSegment(wavBase64, sourceLang, channel): native chỉ dùng VAD để cắt audio theo
    // câu rồi đóng gói WAV/base64, đẩy sang đây để JS tự upload lên Whisper Cloud
    // (groq-relay?op=transcribe). Xem AudioCaptureService.startCloudSttReadLoop(). channel là
    // 'mic'|'system' khi captureMode='mixed' (2 luồng song song), undefined ở các mode đơn khác
    // (JS coi undefined như luồng chính, giữ hành vi cũ).
    this.onCloudSttSegment = onCloudSttSegment || (() => {});
    // onMicDeviceInfo(usedExternal, label): CHỈ bắn ở captureMode='mic', ngay sau khi native
    // thật sự chọn xong thiết bị thu (xem AudioCaptureService.selectMicInputDevice()).
    // usedExternal=true nếu đang thu qua micro NGOÀI (tai nghe dây/USB/Bluetooth SCO); false nếu
    // đang dùng micro trong máy (dù có tick "ưu tiên micro ngoài" hay không - vd không tìm thấy
    // thiết bị ngoài nào đang kết nối). label là chuỗi tiếng Việt hiện thẳng lên UI.
    this.onMicDeviceInfo = onMicDeviceInfo || (() => {});
    this._listenersRegistered = false;
  }

  _plugin() {
    const plugin = window.Capacitor?.Plugins?.AudioCapture;
    if (!plugin) {
      throw new Error('Plugin AudioCapture chưa sẵn sàng (chưa chạy trong app native đã build?)');
    }
    return plugin;
  }

  _registerListenersOnce() {
    if (this._listenersRegistered) return;
    const plugin = this._plugin();

    plugin.addListener('captureError', (data) => this.onError(data.message, data.code));
    plugin.addListener('modelStatus', (data) => this.onModelStatus(data.ready));
    plugin.addListener('audioLevel', (data) => this.onAudioLevel(data));
    plugin.addListener('captureResumed', (data) => this.onCaptureResumed(data.mode));
    plugin.addListener('cloudSttSegment', (data) => this.onCloudSttSegment(data.wavBase64, data.sourceLang, data.channel));
    plugin.addListener('micDeviceInfo', (data) => this.onMicDeviceInfo(data.usedExternal, data.label));

    this._listenersRegistered = true;
  }

  // captureMode: 'system' (mặc định, bắt audio phát ra từ app khác - cần dialog MediaProjection),
  // 'mic' (ghi âm qua micro máy - dùng khi nghe qua loa ngoài, hoặc khi app nguồn tự chặn
  // playback capture), hoặc 'mixed' ("hội thoại 2 chiều" - bắt ĐỒNG THỜI mic + system, cần CẢ 2
  // quyền, dialog MediaProjection + xin RECORD_AUDIO trước đó nếu chưa có). Với 'system'/'mixed',
  // PHẢI gọi từ một user gesture (click/tap) - dialog hệ thống sẽ không tự bật được. sourceLang:
  // ngôn ngữ ĐANG được nói trong audio nguồn (vd 'en' nếu YouTube đang nói tiếng Anh) - với
  // 'mixed', đây là ngôn ngữ của ĐỐI PHƯƠNG (luồng system); luồng mic luôn cố định STT/dịch theo
  // hướng tiếng Việt <-> sourceLang, không cần chọn riêng.
  // preferExternalMic: có tác dụng khi captureMode='mic' - true = cố định route sang micro
  // NGOÀI đang kết nối (tai nghe dây/USB/Bluetooth) nếu máy phát hiện được, xem onMicDeviceInfo
  // ở trên để biết kết quả THẬT SỰ (có thể fallback về máy trong nếu không tìm thấy gì).
  async start(sourceLang = 'en', captureMode = 'system', preferExternalMic = false) {
    this._registerListenersOnce();
    const plugin = this._plugin();
    return plugin.requestCapture({ sourceLang, captureMode, preferExternalMic });
  }

  // Xem trước (không cần đang capture) máy có phát hiện micro ngoài nào đang kết nối không -
  // trả về mảng { type, label }[], rỗng nếu không có gì ngoài micro trong máy. Dùng để hiện dòng
  // trạng thái cạnh checkbox "Ưu tiên micro ngoài" trước khi user bấm "Bắt đầu nghe".
  async listInputDevices() {
    const plugin = this._plugin();
    const res = await plugin.listInputDevices();
    return res?.devices || [];
  }

  async stop() {
    const plugin = this._plugin();
    return plugin.stopCapture();
  }

  // Gọi khi app mở lại (vd. resume) để biết phiên "system" trước đó có bị OS âm thầm dừng
  // giữa chừng không (không tự phục hồi được) - trả về true nếu có, để UI báo cho user.
  async checkLostSession() {
    const plugin = this._plugin();
    const res = await plugin.checkLostSession();
    return !!res?.lostSystemSession;
  }

  // ===== Miễn trừ tối ưu pin - xem AudioCapturePlugin.kt =====
  async checkBatteryOptimization() {
    const plugin = this._plugin();
    const res = await plugin.checkBatteryOptimization();
    return !!res?.ignoringOptimizations;
  }

  async requestIgnoreBatteryOptimizations() {
    const plugin = this._plugin();
    const res = await plugin.requestIgnoreBatteryOptimizations();
    return !!res?.ignoringOptimizations;
  }
}
