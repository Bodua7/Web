// Bridge gọi plugin native ExportPlugin (ghi file .srt/.txt và mở Android Share Sheet) -
// chỉ hoạt động khi chạy trong app Android đã build. Không dùng <a download> + Blob URL vì
// trong Capacitor WebView cách đó thường lưu "vô hình" (không rõ đi đâu, không mở được lại,
// và không có đường mở Share Sheet để gửi Zalo/Telegram/Drive như yêu cầu).

function plugin() {
  return window.Capacitor?.Plugins?.ExportPlugin || null;
}

export function isExportAvailable() {
  return plugin() !== null;
}

// Ghi file thẳng vào thư mục Download công khai (My Files > Download), không mở Share Sheet.
export async function saveExportToDownloads(content, fileName, mimeType) {
  const p = plugin();
  if (!p) throw new Error('Plugin ExportPlugin chưa sẵn sàng (chưa chạy trong app native đã build?)');
  return p.saveToDownloads({ content, fileName, mimeType });
}

// Ghi file vào cache riêng của app rồi mở Android Share Sheet (Zalo/Telegram/lưu Drive/lưu
// thiết bị...) qua FileProvider.
export async function shareExportFile(content, fileName, mimeType) {
  const p = plugin();
  if (!p) throw new Error('Plugin ExportPlugin chưa sẵn sàng (chưa chạy trong app native đã build?)');
  return p.shareFile({ content, fileName, mimeType });
}

// ===== Log lỗi cục bộ (Hạng mục D) =====
// Ghi 1 dòng log lỗi xuống file cục bộ (sống sót qua việc tắt/mở lại app), khác với
// log() trong index.html chỉ giữ trong bộ nhớ của session hiện tại. Im lặng bỏ qua nếu
// không chạy trong app native (vd. đang mở bằng trình duyệt thường) - đây chỉ là log phụ,
// không được phép làm hỏng luồng chính của app.
export async function appendErrorLog(line) {
  const p = plugin();
  if (!p) return;
  try {
    await p.appendErrorLog({ line });
  } catch (e) {
    // bỏ qua - ghi log lỗi thất bại thì cũng không nên tự nó gây thêm lỗi
  }
}

// Đọc toàn bộ log lỗi đã tích luỹ (rỗng nếu chưa có gì hoặc không chạy trong app native).
export async function getErrorLog() {
  const p = plugin();
  if (!p) return '';
  const res = await p.getErrorLog();
  return res?.content || '';
}

export async function clearErrorLog() {
  const p = plugin();
  if (!p) return;
  await p.clearErrorLog();
}

// ===== Phản hồi model dịch/nhận diện sai =====
// lang: mã model (vd 'vi', 'en-lgraph'); note: ghi chú tuỳ chọn của người dùng, có thể rỗng.
export async function submitModelFeedback(lang, note) {
  const p = plugin();
  if (!p) throw new Error('Plugin ExportPlugin chưa sẵn sàng (chưa chạy trong app native đã build?)');
  return p.submitModelFeedback({ lang, note: note || '' });
}

export async function getModelFeedback() {
  const p = plugin();
  if (!p) return '';
  const res = await p.getModelFeedback();
  return res?.content || '';
}

export async function clearModelFeedback() {
  const p = plugin();
  if (!p) return;
  await p.clearModelFeedback();
}

// Đọc % pin hiện tại - trả null nếu không chạy trong app native (không có ý nghĩa đo pin
// trên trình duyệt thường). Dùng ở đầu/cuối 1 phiên nghe để tính hao pin thực tế.
export async function getBatteryPercent() {
  const p = plugin();
  if (!p) return null;
  const res = await p.getBatteryPercent();
  return typeof res?.percent === 'number' ? res.percent : null;
}
