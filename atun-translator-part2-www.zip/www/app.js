// www/app.js - JS "thường" (không phải module) tách ra từ khối <script> đầu tiên trong
// index.html. Nạp qua <script src="app.js"></script> - đúng ngay vị trí cũ trong <body> nên
// thứ tự chạy/scope top-level (let/const/function) không đổi so với lúc còn inline. File
// app.module.js (khối <script type="module"> thứ 2) và file này KHÔNG chung scope - mọi cầu
// nối 2 chiều vẫn đi qua window.__xxx như trước, không đổi gì thêm ở đây.

    const logEl = document.getElementById('log');
    // Log phình vô hạn sau phiên chạy dài (đặc biệt log audio-level bắn mỗi giây) làm
    // WebView tốn RAM dần rồi crash app - giới hạn chỉ giữ tối đa 300 dòng gần nhất.
    // Gắn vào window để script type="module" bên dưới dùng chung, tránh 2 log rời rạc
    // cùng ghi đè lên nhau trên cùng 1 phần tử #log.
    const MAX_LOG_LINES = 300;
    let logLines = [];
    function log(msg) {
      const time = new Date().toLocaleTimeString();
      logLines.unshift(`[${time}] ${msg}`);
      if (logLines.length > MAX_LOG_LINES) logLines.length = MAX_LOG_LINES;
      // Chỉ ghi lại DOM (textContent) khi panel debug đang HIỆN - lúc ẩn (mặc định, và suốt
      // hầu hết thời gian chạy nền) build lại chuỗi 300 dòng + reflow mỗi lần log() (đặc biệt
      // audioLevel bắn đều đặn mỗi giây) chỉ tốn CPU/pin vô ích vì không ai nhìn thấy. Mảng
      // logLines vẫn được cập nhật đầy đủ nên bật debug lên bất kỳ lúc nào vẫn thấy đủ log.
      if (debugToggleEl?.checked) {
        logEl.textContent = logLines.join('\n');
      }
      persistIfError(msg);
    }
    window.__appLog = log;

    // Ghi riêng các dòng LỖI/ERROR/CRASH xuống file cục bộ qua ExportPlugin (sống sót qua
    // việc tắt/mở lại app) - KHÔNG ghi mọi dòng log (vd. audioLevel bắn mỗi giây) để tránh
    // ghi file liên tục làm hao pin/IO vô ích. Gọi trực tiếp qua window.Capacitor.Plugins
    // thay vì import module vì hàm log() này nằm ở script thường, chạy trước khi script
    // type="module" phía dưới load xong.
    function persistIfError(msg) {
      if (!/LỖI|ERROR|CRASH/i.test(msg)) return;
      try {
        const p = window.Capacitor?.Plugins?.ExportPlugin;
        if (!p) return;
        p.appendErrorLog({ line: msg }).catch(() => {});
      } catch (e) {
        // không để việc ghi log lỗi tự nó gây thêm lỗi
      }
    }

    window.addEventListener('error', (e) => {
      log('JS ERROR: ' + e.message);
    });

    // ===== Debug log: ẩn theo mặc định (Phase 2) - chỉ hiện khi user tự bật, và nhớ lựa
    // chọn đó cho lần mở app sau bằng localStorage. Người dùng thường không cần thấy log kỹ
    // thuật; log vẫn được ghi ngầm ở #log để bật lên xem khi cần báo lỗi. =====
    const DEBUG_KEY = 'atun_debug_enabled';
    const debugToggleEl = document.getElementById('debugToggle');
    function applyDebugVisibility() {
      logEl.style.display = debugToggleEl.checked ? 'block' : 'none';
      // Vì log() giờ chỉ ghi DOM khi đang hiện (xem log() ở trên), lúc BẬT debug lên phải tự
      // render lại 1 lần cho đủ nội dung tích luỹ trong lúc ẩn, không đợi tới dòng log() kế tiếp.
      if (debugToggleEl.checked) {
        logEl.textContent = logLines.join('\n');
      }
    }

    // ===== Nút thu nhỏ/mở rộng cho khung "Model ngôn ngữ" (STT + LID + ML Kit gộp chung 1
    // khối) và "Cài đặt nghe/dịch" - khung model ngôn ngữ chiếm khá nhiều chỗ nhưng user
    // thường chỉ cần tải model 1 lần lúc mới cài app, sau đó không cần mở lại thường xuyên.
    // Nhớ trạng thái đóng/mở qua localStorage (giống DEBUG_KEY ở trên) để lần sau mở app giữ
    // nguyên. =====
    // containerEl: tuỳ chọn - phần tử SẼ được toggle class "collapsed" lên. Bỏ trống thì tự dùng
    // headerEl.closest('.card') như trước (khối "Model ngôn ngữ"/"Cài đặt nghe/dịch" - mỗi khối
    // đúng là 1 .card riêng ở cấp ngoài cùng). Truyền containerEl RÕ RÀNG khi khối cần thu/mở
    // KHÔNG phải chính .card ngoài cùng mà là 1 khối con lồng bên trong .card khác (vd
    // #captionSettingsWrap lồng trong .card của mainSettingsHeader) - nếu để tự closest('.card')
    // sẽ lấy nhầm .card cha, thu nhỏ nhầm cả khối cha.
    function setupCollapsibleCard(headerId, toggleBtnId, storageKey, defaultCollapsed, containerEl) {
      const headerEl = document.getElementById(headerId);
      const toggleBtnEl = document.getElementById(toggleBtnId);
      if (!headerEl || !toggleBtnEl) return;
      const cardEl = containerEl || headerEl.closest('.card');
      if (!cardEl) return;

      function applyCollapsed(collapsed) {
        cardEl.classList.toggle('collapsed', collapsed);
        toggleBtnEl.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
        toggleBtnEl.title = collapsed ? 'Mở rộng' : 'Thu nhỏ';
      }

      const saved = localStorage.getItem(storageKey);
      const collapsed = saved === null ? !!defaultCollapsed : saved === '1';
      applyCollapsed(collapsed);

      function toggle() {
        const nowCollapsed = !cardEl.classList.contains('collapsed');
        applyCollapsed(nowCollapsed);
        localStorage.setItem(storageKey, nowCollapsed ? '1' : '0');
      }

      toggleBtnEl.addEventListener('click', (e) => {
        e.stopPropagation();
        toggle();
      });
      // Bấm vào cả phần tiêu đề (không chỉ riêng nút nhỏ) cũng thu/mở được cho dễ bấm trên máy.
      headerEl.addEventListener('click', toggle);
    }
    // Model ngôn ngữ (STT+LID+ML Kit gộp chung, trước đây là 2 khối .card riêng mỗi khối lại
    // có toggle CỦA RIÊNG NÓ - đã gộp làm 1 cho gọn UI/UX) mặc định ĐÓNG (defaultCollapsed=true,
    // khác 2 khối cũ trước đây mặc định MỞ) - việc tải model chỉ cần làm 1 lần lúc mới cài app,
    // đóng gọn từ đầu đỡ chiếm chỗ màn hình chính mỗi lần mở app sau đó.
    setupCollapsibleCard('langModelsHeader', 'langModelsToggleBtn', 'atun_lang_models_collapsed', true);
    setupCollapsibleCard('mainSettingsHeader', 'mainSettingsToggleBtn', 'atun_main_settings_collapsed', false);
    // Khối "Ngôn ngữ đang nói" tách riêng khỏi #mainSettingsBody (trước đây lộ thiên chung) -
    // mặc định MỞ (khác #langModelsBody/#captionSettingsWrap) vì đây là lựa chọn cần thấy ngay
    // mỗi lần bắt đầu 1 phiên nghe mới, chỉ khác là giờ gọn lại được khi không cần đụng tới nữa.
    setupCollapsibleCard('sourceLangHeader', 'sourceLangToggleBtn', 'atun_source_lang_collapsed', false, document.querySelector('.source-lang-wrap'));
    // Mặc định ĐÓNG (defaultCollapsed=true) - khác các khối trên (mặc định mở) - vì đây là
    // khối tuỳ chỉnh chi tiết ít khi cần đụng tới thường xuyên, đóng gọn từ đầu cho đỡ chiếm
    // chỗ màn hình chính; người dùng tự mở khi cần, trạng thái mở/đóng vẫn nhớ lại như thường.
    setupCollapsibleCard('captionSettingsHeader', 'captionSettingsToggleBtn', 'atun_caption_settings_collapsed', true, document.getElementById('captionSettingsWrap'));
    debugToggleEl.checked = localStorage.getItem(DEBUG_KEY) === '1';
    applyDebugVisibility();
    debugToggleEl.onchange = () => {
      localStorage.setItem(DEBUG_KEY, debugToggleEl.checked ? '1' : '0');
      applyDebugVisibility();
    };

    // ===== Lưu lựa chọn (ngôn ngữ đích, ngôn ngữ nguồn, nguồn audio, cỡ chữ overlay) qua
    // localStorage - persist trong bộ nhớ WebView riêng của app, không mất khi tắt/mở lại app,
    // không cần chọn lại mỗi lần (Phase 2). Dùng localStorage thay vì Capacitor Preferences vì
    // pipeline build hiện tại không chạy `cap sync` để autolink plugin native mới. =====
    const SETTINGS_KEY = 'atun_settings_v1';
    function loadSettings() {
      try {
        return JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}');
      } catch (e) {
        return {};
      }
    }
    function saveSettings(patch) {
      const current = loadSettings();
      localStorage.setItem(SETTINGS_KEY, JSON.stringify({ ...current, ...patch }));
    }

    const targetLangEl = document.getElementById('targetLang');
    const sourceLangEl = document.getElementById('sourceLang');
    const captureModeEl = document.getElementById('captureMode');
    const smartPauseEl = document.getElementById('smartPause');
    const cloudSttEl = document.getElementById('cloudSttEnabled');
    const preferExternalMicEl = document.getElementById('preferExternalMic');
    const externalMicRowEl = document.getElementById('externalMicRow');
    const externalMicStatusEl = document.getElementById('externalMicStatus');

    // #sourceLang chỉ có 1 <option> placeholder ("en") lúc trang vừa load - catalog thật (~30
    // ngôn ngữ) chỉ có sau khi ModelManager.listModels() trả về lần đầu (xem
    // rebuildSourceLangOptions()). Nếu user đã lưu sourceLang khác "en" từ trước, gán thẳng vào
    // sourceLangEl.value ở đây sẽ KHÔNG có tác dụng (option đó chưa tồn tại, DOM âm thầm bỏ qua) -
    // lưu tạm giá trị đã lưu vào biến này, rebuildSourceLangOptions() sẽ ưu tiên dùng nó ở lần
    // xây dựng ĐẦU TIÊN thay vì đọc sourceLangEl.value (lúc đó luôn là "en").
    let pendingSourceLangFromSettings = null;
    (function restoreSettings() {
      const s = loadSettings();
      if (s.targetLang) targetLangEl.value = s.targetLang;
      if (s.sourceLang) pendingSourceLangFromSettings = s.sourceLang;
      if (s.captureMode) captureModeEl.value = s.captureMode;
      if (typeof s.smartPause === 'boolean') smartPauseEl.checked = s.smartPause;
      if (typeof s.cloudStt === 'boolean') cloudSttEl.checked = s.cloudStt;
      if (typeof s.preferExternalMic === 'boolean') preferExternalMicEl.checked = s.preferExternalMic;
    })();
    targetLangEl.onchange = () => saveSettings({ targetLang: targetLangEl.value });
    sourceLangEl.onchange = () => saveSettings({ sourceLang: sourceLangEl.value });
    captureModeEl.onchange = () => { saveSettings({ captureMode: captureModeEl.value }); window.__updateExternalMicUi?.(); };
    smartPauseEl.onchange = () => saveSettings({ smartPause: smartPauseEl.checked });
    cloudSttEl.onchange = () => {
      saveSettings({ cloudStt: cloudSttEl.checked });
      // Đổi nguồn danh sách <option> ngay khi toggle (Vosk <-> WHISPER_LANGS, xem
      // rebuildSourceLangOptions()) - dùng lastVoskModels đã cache, khỏi gọi lại
      // plugin.listModels(). updateSourceLangHint() gọi sau để nút "Bắt đầu nghe"/gợi ý cập
      // nhật đúng theo sourceLang MỚI còn lại sau khi xây lại dropdown (rebuildSourceLangOptions
      // có thể đổi sourceLangEl.value nếu mã cũ không tồn tại ở nguồn mới - xem ghi chú
      // "kz"/"kk"/"ky"/"eo" ở WHISPER_LANGS).
      rebuildSourceLangOptions(lastVoskModels);
      updateSourceLangHint();
    };
    preferExternalMicEl.onchange = () => {
      saveSettings({ preferExternalMic: preferExternalMicEl.checked });
      window.__refreshExternalMicStatus?.();
    };
    // Hiện/ẩn khối "Ưu tiên micro ngoài" ngay từ lần load đầu theo captureMode đã khôi phục ở
    // trên (không đợi user tự đổi select mới thấy) - hàm thật (setupExternalMicUi) định nghĩa ở
    // dưới cùng file (sau khi khai báo `capture`/NativeCaptureBridge), gọi qua window.* vì thứ
    // tự script chạy từ trên xuống.
    window.__updateExternalMicUi?.();

    function getAudioCapturePlugin() {
      return window.Capacitor?.Plugins?.AudioCapture || null;
    }

    // ===== Phase 4: Quản lý model ngôn ngữ (tải on-demand) =====
    function getModelManagerPlugin() {
      return window.Capacitor?.Plugins?.ModelManager || null;
    }

    const modelListEl = document.getElementById('modelList');
    const sourceLangHintEl = document.getElementById('sourceLangHint');

    function formatMB(bytes) {
      return (bytes / (1024 * 1024)).toFixed(1);
    }

    async function refreshModelList() {
      const plugin = getModelManagerPlugin();
      if (!plugin) {
        modelListEl.textContent = 'ModelManager chưa sẵn sàng (chưa chạy trong app native đã build?)';
        return;
      }
      let res;
      try {
        res = await plugin.listModels();
      } catch (err) {
        modelListEl.textContent = 'Lỗi tải danh sách model: ' + err.message;
        return;
      }
      renderModelList(res.models || []);
      rebuildSourceLangOptions(res.models || []);
      updateSourceLangHint();
    }

    // Ngưỡng để coi 1 model là "lớn" (nên tải qua Wi-Fi) - dùng chung giữa hint và confirm()
    // trước khi tải, xem plugin_downloadModel() bên dưới.
    const LARGE_MODEL_SIZE_MB = 250;

    // Số ngôn ngữ SẴN SÀNG (đã tải, không tính "auto") tối thiểu để chế độ "Tự động
    // nhận diện" có ý nghĩa - phải khớp với việc kiểm tra ở native (xem
    // AudioCaptureService.startVoskAndReadLoop, nhánh sourceLang == "auto").
    const AUTO_MODE_MIN_READY_LANGS = 2;

    // ===== Danh sách ngôn ngữ CHO WHISPER CLOUD (khi cloudSttEl.checked) - KHÁC HẲN catalog
    // Vosk (~29 ngôn ngữ, tải model on-demand) vì Whisper (groq-relay?op=transcribe, model
    // whisper-large-v3-turbo) không cần tải gì cả - mọi ngôn ngữ dưới đây dùng NGAY, không có
    // trạng thái "cần tải"/"đã tải" như dropdown Vosk. Danh sách lấy đúng theo mã ISO-639-1 mà
    // Whisper/Groq hỗ trợ (https://whisper-api.com/docs/languages/ - dựa theo LANGUAGES dict
    // gốc của openai/whisper, ~99 ngôn ngữ + "yue" Quảng Đông thêm ở whisper-large-v3).
    //
    // LƯU Ý mã KHÁC catalog Vosk cho cùng 1 ngôn ngữ (do Vosk dùng mã app tự đặt, không phải
    // luôn đúng chuẩn ISO-639-1): Kazakh Vosk="kz" nhưng ISO/Whisper="kk"; Kyrgyz có trong Vosk
    // ("ky") nhưng KHÔNG có trong Whisper (không hỗ trợ, bỏ qua); Esperanto có trong Vosk ("eo")
    // nhưng KHÔNG có trong Whisper. Ngược lại, dùng "kk" (Whisper) chứ không phải "kz" ở đây.
    // Đây là 2 catalog ĐỘC LẬP - không cố gộp chung 1 danh sách vì bản chất 2 engine hỗ trợ 2
    // tập ngôn ngữ khác nhau (không phải tập con của nhau).
    const WHISPER_LANGS = [
      { lang: 'af', name: 'Afrikaans' },
      { lang: 'am', name: 'አማርኛ (Amharic - Ethiopia)' },
      { lang: 'ar', name: 'العربية (Ả Rập)' },
      { lang: 'as', name: 'অসমীয়া (Assam)' },
      { lang: 'az', name: 'Azərbaycan (Azerbaijan)' },
      { lang: 'ba', name: 'Башҡорт (Bashkir)' },
      { lang: 'be', name: 'Беларуская (Belarus)' },
      { lang: 'bg', name: 'Български (Bulgaria)' },
      { lang: 'bn', name: 'বাংলা (Bengal)' },
      { lang: 'bo', name: 'བོད་སྐད (Tây Tạng)' },
      { lang: 'br', name: 'Brezhoneg (Breton)' },
      { lang: 'bs', name: 'Bosanski (Bosnia)' },
      { lang: 'ca', name: 'Català (Catalan)' },
      { lang: 'cs', name: 'Čeština (Séc)' },
      { lang: 'cy', name: 'Cymraeg (Wales)' },
      { lang: 'da', name: 'Dansk (Đan Mạch)' },
      { lang: 'de', name: 'Deutsch (Đức)' },
      { lang: 'el', name: 'Ελληνικά (Hy Lạp)' },
      { lang: 'en', name: 'English' },
      { lang: 'es', name: 'Español (Tây Ban Nha)' },
      { lang: 'et', name: 'Eesti (Estonia)' },
      { lang: 'eu', name: 'Euskara (Basque)' },
      { lang: 'fa', name: 'فارسی (Ba Tư/Iran)' },
      { lang: 'fi', name: 'Suomi (Phần Lan)' },
      { lang: 'fo', name: 'Føroyskt (Faroe)' },
      { lang: 'fr', name: 'Français (Pháp)' },
      { lang: 'gl', name: 'Galego (Galicia)' },
      { lang: 'gu', name: 'ગુજરાતી (Gujarat)' },
      { lang: 'ha', name: 'Hausa' },
      { lang: 'haw', name: 'ʻŌlelo Hawaiʻi (Hawaii)' },
      { lang: 'he', name: 'עברית (Do Thái)' },
      { lang: 'hi', name: 'हिन्दी (Ấn Độ - Hindi)' },
      { lang: 'hr', name: 'Hrvatski (Croatia)' },
      { lang: 'ht', name: 'Kreyòl Ayisyen (Haiti)' },
      { lang: 'hu', name: 'Magyar (Hungary)' },
      { lang: 'hy', name: 'Հայերեն (Armenia)' },
      { lang: 'id', name: 'Bahasa Indonesia' },
      { lang: 'is', name: 'Íslenska (Iceland)' },
      { lang: 'it', name: 'Italiano (Ý)' },
      { lang: 'ja', name: '日本語' },
      { lang: 'jw', name: 'Basa Jawa (Java)' },
      { lang: 'ka', name: 'ქართული (Georgia)' },
      { lang: 'kk', name: 'Қазақша (Kazakhstan)' },
      { lang: 'km', name: 'ខ្មែរ (Khmer/Campuchia)' },
      { lang: 'kn', name: 'ಕನ್ನಡ (Kannada)' },
      { lang: 'ko', name: '한국어' },
      { lang: 'la', name: 'Latina' },
      { lang: 'lb', name: 'Lëtzebuergesch (Luxembourg)' },
      { lang: 'ln', name: 'Lingála' },
      { lang: 'lo', name: 'ລາວ (Lào)' },
      { lang: 'lt', name: 'Lietuvių (Litva)' },
      { lang: 'lv', name: 'Latviešu (Latvia)' },
      { lang: 'mg', name: 'Malagasy (Madagascar)' },
      { lang: 'mi', name: 'Māori' },
      { lang: 'mk', name: 'Македонски (Macedonia)' },
      { lang: 'ml', name: 'മലയാളം (Malayalam)' },
      { lang: 'mn', name: 'Монгол (Mông Cổ)' },
      { lang: 'mr', name: 'मराठी (Marathi)' },
      { lang: 'ms', name: 'Bahasa Melayu' },
      { lang: 'mt', name: 'Malti (Malta)' },
      { lang: 'my', name: 'မြန်မာ (Myanmar)' },
      { lang: 'ne', name: 'नेपाली (Nepal)' },
      { lang: 'nl', name: 'Nederlands (Hà Lan)' },
      { lang: 'nn', name: 'Norsk Nynorsk' },
      { lang: 'no', name: 'Norsk (Na Uy)' },
      { lang: 'oc', name: 'Occitan' },
      { lang: 'pa', name: 'ਪੰਜਾਬੀ (Punjab)' },
      { lang: 'pl', name: 'Polski (Ba Lan)' },
      { lang: 'ps', name: 'پښتو (Pashto)' },
      { lang: 'pt', name: 'Português (Bồ Đào Nha)' },
      { lang: 'ro', name: 'Română (Romania)' },
      { lang: 'ru', name: 'Русский (Nga)' },
      { lang: 'sa', name: 'संस्कृत (Sanskrit)' },
      { lang: 'sd', name: 'سنڌي (Sindhi)' },
      { lang: 'si', name: 'සිංහල (Sri Lanka)' },
      { lang: 'sk', name: 'Slovenčina (Slovakia)' },
      { lang: 'sl', name: 'Slovenščina (Slovenia)' },
      { lang: 'sn', name: 'ChiShona (Zimbabwe)' },
      { lang: 'so', name: 'Soomaali (Somalia)' },
      { lang: 'sq', name: 'Shqip (Albania)' },
      { lang: 'sr', name: 'Српски (Serbia)' },
      { lang: 'su', name: 'Basa Sunda' },
      { lang: 'sv', name: 'Svenska (Thuỵ Điển)' },
      { lang: 'sw', name: 'Kiswahili (Swahili)' },
      { lang: 'ta', name: 'தமிழ் (Tamil)' },
      { lang: 'te', name: 'తెలుగు (Telugu)' },
      { lang: 'tg', name: 'Тоҷикӣ (Tajikistan)' },
      { lang: 'th', name: 'ไทย (Thái Lan)' },
      { lang: 'tk', name: 'Türkmençe (Turkmenistan)' },
      { lang: 'tl', name: 'Tagalog (Philippines)' },
      { lang: 'tr', name: 'Türkçe (Thổ Nhĩ Kỳ)' },
      { lang: 'tt', name: 'Татар (Tatar)' },
      { lang: 'uk', name: 'Українська (Ukraine)' },
      { lang: 'ur', name: 'اردو (Urdu)' },
      { lang: 'uz', name: "O'zbekcha (Uzbekistan)" },
      { lang: 'vi', name: 'Tiếng Việt' },
      { lang: 'yi', name: 'ייִדיש (Yiddish)' },
      { lang: 'yo', name: 'Yorùbá' },
      { lang: 'zh', name: '中文' },
      { lang: 'yue', name: '廣東話 (Quảng Đông)' },
    ];

    // Cache lần listModels() gần nhất - rebuildSourceLangOptions() cần lại danh sách này khi
    // user TẮT cloudStt (quay về dropdown Vosk) mà không phải gọi lại plugin.listModels() (đọc
    // filesystem, tuy rẻ nhưng không cần thiết nếu đã có sẵn dữ liệu vừa tải).
    let lastVoskModels = [];

    // Catalog STT giờ có ~30 ngôn ngữ (xem ModelManagerPlugin.CATALOG) - không còn liệt kê tay
    // từng <option> trong HTML nữa (xem placeholder tĩnh ở #sourceLang). Hàm này XÂY LẠI TOÀN BỘ
    // danh sách <option> - CÓ 2 NGUỒN tuỳ cloudSttEl.checked: bật thì dùng WHISPER_LANGS ở trên
    // (không cần tải, mọi mã dùng ngay); tắt thì dùng đúng dữ liệu native trả về (m.name đã là
    // tên hiển thị tiếng Việt sẵn), thêm hậu tố trạng thái tải. Luôn có 1 <option value="auto">
    // cố định ở cuối. Giữ lại lựa chọn hiện tại của user nếu giá trị đó vẫn còn tồn tại ở danh
    // sách mới (vd đổi cloudStt qua lại giữa 2 nguồn có thể làm mất lựa chọn cũ nếu mã đó chỉ
    // có ở 1 trong 2 - xem ghi chú "kz"/"kk"/"ky"/"eo" ở WHISPER_LANGS).
    function rebuildSourceLangOptions(models) {
      lastVoskModels = models;
      // Lần xây dựng ĐẦU TIÊN sau khi trang load: ưu tiên khôi phục giá trị đã lưu (xem
      // pendingSourceLangFromSettings ở restoreSettings()) thay vì sourceLangEl.value hiện tại
      // (lúc đó chỉ là "en" placeholder tĩnh). Các lần xây lại SAU (tải/xoá model) thì giữ đúng
      // lựa chọn user đang chọn trên UI (sourceLangEl.value lúc này đã đáng tin).
      const previousValue = pendingSourceLangFromSettings ?? sourceLangEl.value;
      pendingSourceLangFromSettings = null;
      sourceLangEl.innerHTML = '';

      let readyCount = 0;
      if (cloudSttEl.checked) {
        for (const w of WHISPER_LANGS) {
          const opt = document.createElement('option');
          opt.value = w.lang;
          opt.textContent = w.name;
          sourceLangEl.appendChild(opt);
        }
      } else {
        for (const m of models) {
          const opt = document.createElement('option');
          opt.value = m.lang;
          let suffix;
          if (m.status === 'downloaded') { suffix = 'đã tải'; readyCount++; }
          else suffix = m.sizeMB > LARGE_MODEL_SIZE_MB ? `cần tải ~${(m.sizeMB / 1024).toFixed(1)}GB` : 'cần tải';
          opt.textContent = `${m.name} (${suffix})`;
          sourceLangEl.appendChild(opt);
        }
      }

      const autoOpt = document.createElement('option');
      autoOpt.value = 'auto';
      autoOpt.textContent = cloudSttEl.checked
        // Whisper tự nhận diện ngôn ngữ khi không gửi 'language' (xem transcribeCloudSegment())
        // - không cần điều kiện "đã tải bao nhiêu ngôn ngữ" như chế độ auto của Vosk.
        ? '🌐 Tự động nhận diện (Whisper tự nhận diện ngôn ngữ)'
        : readyCount >= AUTO_MODE_MIN_READY_LANGS
          ? '🌐 Tự động nhận diện (nhiều ngôn ngữ đã tải)'
          : `🌐 Tự động nhận diện (cần tải thêm ${AUTO_MODE_MIN_READY_LANGS - readyCount} ngôn ngữ nữa)`;
      sourceLangEl.appendChild(autoOpt);

      if ([...sourceLangEl.options].some((o) => o.value === previousValue)) {
        sourceLangEl.value = previousValue;
      }
    }

    function renderModelList(models) {
      modelListEl.innerHTML = '';
      for (const m of models) {
        const row = document.createElement('div');
        row.className = 'model-row';
        row.dataset.lang = m.lang;

        const left = document.createElement('div');
        left.style.flex = '1';
        const nameEl = document.createElement('div');
        nameEl.className = 'model-name';
        nameEl.textContent = m.name + ' (~' + m.sizeMB + 'MB)';
        const statusEl = document.createElement('div');
        statusEl.className = 'model-status';
        statusEl.textContent = m.status === 'downloaded' ? 'Đã tải về máy' : 'Chưa tải';
        const progressOuter = document.createElement('div');
        progressOuter.className = 'model-progress-outer';
        progressOuter.style.display = 'none';
        const progressInner = document.createElement('div');
        progressInner.className = 'model-progress-inner';
        progressOuter.appendChild(progressInner);

        left.appendChild(nameEl);
        left.appendChild(statusEl);
        left.appendChild(progressOuter);
        row.appendChild(left);

        {
          const btn = document.createElement('button');
          btn.className = 'model-btn';
          if (m.status === 'downloaded') {
            btn.textContent = 'Xoá';
            btn.onclick = async () => {
              btn.disabled = true;
              try {
                await plugin_deleteModel(m.lang);
                log('Đã xoá model ' + m.lang + '.');
                await refreshModelList();
              } catch (err) {
                log('LỖI xoá model: ' + err.message);
                btn.disabled = false;
              }
            };
          } else {
            btn.textContent = 'Tải về';
            const startDownload = async () => {
              // Model lớn (vd Ả Rập 318MB, Thuỵ Điển 289MB, Hy Lạp 1.1GB, Filipino 320MB...) -
              // nhắc trước khi tải qua mạng di động, áp dụng chung theo ngưỡng kích thước.
              if (m.sizeMB > LARGE_MODEL_SIZE_MB) {
                const sizeLabel = m.sizeMB >= 1024 ? (m.sizeMB / 1024).toFixed(1) + 'GB' : m.sizeMB + 'MB';
                if (!confirm(`Model "${m.name}" khá lớn (~${sizeLabel}) - nên tải qua Wi-Fi để tránh tốn data di động. Tiếp tục tải?`)) {
                  return;
                }
              }
              // Trong lúc tải: đổi hẳn nút này thành "Huỷ" thay vì chỉ disable - trước đây
              // ModelManagerPlugin.cancelDownload() đã có sẵn phía native nhưng UI chưa gọi tới,
              // user lỡ bấm nhầm model to không có cách dừng giữa chừng.
              statusEl.textContent = 'Đang tải... 0%';
              progressOuter.style.display = 'block';
              btn.textContent = 'Huỷ';
              btn.disabled = false;
              btn.onclick = async () => {
                btn.disabled = true;
                try {
                  await plugin_cancelDownload(m.lang);
                } catch (err) {
                  log('LỖI huỷ tải model ' + m.lang + ': ' + err.message);
                  btn.disabled = false;
                }
                // modelDownloadDone (cancelled=true) sẽ tự bắn qua nhánh catch bên dưới - không
                // cần làm gì thêm ở đây, chỉ chờ.
              };
              const resetToDownloadBtn = () => {
                btn.textContent = 'Tải về';
                btn.disabled = false;
                btn.onclick = startDownload;
              };
              try {
                await plugin_downloadModel(m.lang, (percent) => {
                  progressInner.style.width = Math.max(0, percent) + '%';
                  statusEl.textContent = percent >= 0 ? ('Đang tải... ' + percent + '%') : 'Đang tải...';
                });
              } catch (err) {
                progressOuter.style.display = 'none';
                if (err.cancelled) {
                  log('Đã huỷ tải model ' + m.lang + '.');
                  statusEl.textContent = 'Chưa tải';
                } else {
                  log('LỖI tải model ' + m.lang + ': ' + err.message);
                  statusEl.textContent = 'Lỗi tải - thử lại';
                }
                resetToDownloadBtn();
              }
            };
            btn.onclick = startDownload;
          }
          row.appendChild(btn);
        }

        // Nút báo "model này dịch/nhận diện sai nhiều" - chỉ có ý nghĩa với model ĐÃ tải
        // (chưa tải thì chưa dùng thử để mà đánh giá được).
        if (m.status === 'downloaded') {
          const fbBtn = document.createElement('button');
          fbBtn.className = 'model-btn';
          fbBtn.title = 'Báo model này dịch/nhận diện sai nhiều';
          fbBtn.textContent = '👎';
          fbBtn.onclick = async () => {
            const note = prompt(
              `Ghi chú (tuỳ chọn) về model "${m.name}" - vd hay nhận sai chữ nào, dịch sai kiểu gì...`,
              ''
            );
            if (note === null) return; // user bấm Huỷ trên hộp thoại
            try {
              await submitModelFeedback(m.lang, note);
              log('Đã ghi nhận phản hồi cho model ' + m.lang + '.');
            } catch (err) {
              log('LỖI ghi phản hồi model: ' + err.message);
            }
          };
          row.appendChild(fbBtn);
        }

        modelListEl.appendChild(row);
      }
    }

    // Bọc downloadModel() thành Promise chờ tới khi có sự kiện modelDownloadDone khớp lang,
    // vì plugin.downloadModel() resolve ngay khi BẮT ĐẦU tải (chạy nền), không phải khi xong.
    //
    // addListener() BỌC trong Promise.resolve(...) thay vì gọi .then() thẳng - trên build hiện
    // tại, addListener() của native plugin (ModelManager) trả về THẲNG PluginListenerHandle
    // (đồng bộ), không phải Promise<PluginListenerHandle> như tài liệu Capacitor mô tả, nên gọi
    // .then() thẳng lên nó ném lỗi "plugin.addListener(...).then is not a function" và HUỶ
    // NGANG toàn bộ luồng tải trước khi kịp gắn listener. Promise.resolve(x) chấp nhận cả 2
    // trường hợp - nếu x đã là Promise thì giữ nguyên, nếu là giá trị thường (handle đồng bộ)
    // thì tự bọc lại thành Promise đã resolve - .then() sau đó luôn dùng được trong mọi trường
    // hợp.
    //
    // BUG đã sửa: TRƯỚC ĐÂY gọi plugin.downloadModel({ lang }) NGAY sau khi gắn 2 listener bằng
    // .then() (không await) - callback bên trong listener luôn được gắn đồng bộ (addListener tự
    // chạy callback ngay khi có event, không đợi .then() resolve), nhưng biến progressHandle/
    // doneHandle (dùng để cleanup() gọi .remove()) chỉ được gán ở microtask .then() phía sau, và
    // downloadModel() chạy trước khi cả 2 .then() đó kịp chạy. Nếu native emit modelDownloadDone
    // NGAY LẬP TỨC (lang đã tải sẵn xong từ trước do race khác, hoặc lỗi validate tức thời),
    // cleanup() có thể chạy trong khi progressHandle/doneHandle vẫn còn undefined -> optional
    // chaining (?.remove?.()) khiến lệnh remove() bị ÂM THẦM BỎ QUA thay vì lỗi, làm rò rỉ
    // listener (không giải phóng, mỗi lần tải sau lại cộng dồn thêm 1 listener chạy nền). Giờ
    // await Promise.all(...) đợi CẢ 2 addListener gán xong handle rồi mới gọi downloadModel(),
    // đảm bảo cleanup() luôn có handle thật để remove() khi được gọi.
    async function plugin_downloadModel(lang, onProgress) {
      const plugin = getModelManagerPlugin();
      let progressHandle, doneHandle;
      let resolvePromise, rejectPromise;
      const donePromise = new Promise((resolve, reject) => {
        resolvePromise = resolve;
        rejectPromise = reject;
      });
      const cleanup = () => {
        progressHandle?.remove?.();
        doneHandle?.remove?.();
      };

      [progressHandle, doneHandle] = await Promise.all([
        Promise.resolve(plugin.addListener('modelDownloadProgress', (data) => {
          if (data.lang === lang) onProgress(data.percent);
        })),
        Promise.resolve(plugin.addListener('modelDownloadDone', (data) => {
          if (data.lang !== lang) return;
          cleanup();
          if (data.success) {
            log('Tải model ' + lang + ' xong.');
            refreshModelList();
            resolvePromise();
          } else {
            const err = new Error(data.error || 'không rõ lỗi');
            err.cancelled = !!data.cancelled; // xem renderModelList() - không hiện là "lỗi" đỏ nếu do user tự huỷ
            rejectPromise(err);
          }
        })),
      ]);

      plugin.downloadModel({ lang }).catch((err) => {
        cleanup();
        rejectPromise(err);
      });

      return donePromise;
    }

    async function plugin_deleteModel(lang) {
      const plugin = getModelManagerPlugin();
      await plugin.deleteModel({ lang });
    }

    async function plugin_cancelDownload(lang) {
      const plugin = getModelManagerPlugin();
      await plugin.cancelDownload({ lang });
    }

    // ===== Model LID thật (xem native/LidEngine.kt + ModelManagerPlugin.downloadLidModel) =====
    // Dùng CHUNG sự kiện modelDownloadProgress/modelDownloadDone với model Vosk (lang="_lid"
    // do native emit), nên bọc Promise y hệt pattern plugin_downloadModel() ở trên - tách hàm
    // riêng vì gọi khác method native (downloadLidModel(), không nhận tham số lang) và không
    // cần refreshModelList() (model LID không nằm trong danh sách ngôn ngữ STT).
    const LID_EVENT_KEY = '_lid';

    // Cùng cách sửa race đăng ký listener như plugin_downloadModel() ở trên - await cả 2
    // addListener() trước khi gọi downloadLidModel(), tránh cleanup() gặp handle chưa gán.
    async function plugin_downloadLidModel(onProgress) {
      const plugin = getModelManagerPlugin();
      let progressHandle, doneHandle;
      let resolvePromise, rejectPromise;
      const donePromise = new Promise((resolve, reject) => {
        resolvePromise = resolve;
        rejectPromise = reject;
      });
      const cleanup = () => {
        progressHandle?.remove?.();
        doneHandle?.remove?.();
      };

      [progressHandle, doneHandle] = await Promise.all([
        Promise.resolve(plugin.addListener('modelDownloadProgress', (data) => {
          if (data.lang === LID_EVENT_KEY) onProgress(data.percent);
        })),
        Promise.resolve(plugin.addListener('modelDownloadDone', (data) => {
          if (data.lang !== LID_EVENT_KEY) return;
          cleanup();
          if (data.success) {
            log('Tải model LID xong.');
            resolvePromise();
          } else {
            const err = new Error(data.error || 'không rõ lỗi');
            err.cancelled = !!data.cancelled;
            rejectPromise(err);
          }
        })),
      ]);

      plugin.downloadLidModel().catch((err) => {
        cleanup();
        rejectPromise(err);
      });

      return donePromise;
    }

    async function refreshLidModelStatus() {
      const plugin = getModelManagerPlugin();
      const statusEl = document.getElementById('lidModelStatus');
      const downloadBtn = document.getElementById('lidModelDownloadBtn');
      const deleteBtn = document.getElementById('lidModelDeleteBtn');
      if (!plugin) {
        statusEl.textContent = 'ModelManager chưa sẵn sàng (chưa chạy trong app native đã build?)';
        return;
      }
      let res;
      try {
        res = await plugin.isLidModelDownloaded();
      } catch (err) {
        statusEl.textContent = 'Lỗi kiểm tra model LID: ' + err.message;
        return;
      }
      if (res.downloaded) {
        statusEl.textContent = '✅ Đã tải - đang bật tự động cho chế độ "Tự động nhận diện".';
        downloadBtn.style.display = 'none';
        deleteBtn.style.display = '';
      } else {
        statusEl.textContent = 'Chưa tải - chế độ "Tự động nhận diện" vẫn hoạt động bình thường (chỉ dùng confidence Vosk, không có LID hỗ trợ).';
        downloadBtn.style.display = '';
        deleteBtn.style.display = 'none';
      }
    }

    document.getElementById('lidModelDownloadBtn').onclick = async () => {
      const statusEl = document.getElementById('lidModelStatus');
      const btn = document.getElementById('lidModelDownloadBtn');
      btn.disabled = true;
      try {
        await plugin_downloadLidModel((percent) => {
          statusEl.textContent = `Đang tải model LID... ${percent >= 0 ? percent + '%' : ''}`;
        });
      } catch (err) {
        if (!err.cancelled) statusEl.textContent = 'Lỗi tải model LID: ' + err.message;
      } finally {
        btn.disabled = false;
        refreshLidModelStatus();
      }
    };

    document.getElementById('lidModelDeleteBtn').onclick = async () => {
      const plugin = getModelManagerPlugin();
      await plugin.deleteLidModel();
      refreshLidModelStatus();
    };

    refreshLidModelStatus();

    // Kiểm tra model của sourceLang đang chọn đã sẵn sàng chưa - dùng để disable nút
    // "Bắt đầu nghe" và hiện gợi ý thay vì để user bấm rồi nhận lỗi từ native. Gọi trực tiếp
    // listModels() mỗi lần thay vì dùng cache, vì đây chỉ là 1 lệnh đọc filesystem cục bộ, rẻ.
    //
    // BUG đã sửa: trước đây hàm này KHÔNG biết cloudSttEl.checked - luôn tra `lang` trong
    // catalog Vosk (models từ listModels()) dù đang ở chế độ Whisper Cloud, nơi `lang` thường
    // là mã Whisper-only không tồn tại trong catalog Vosk (vd "kk"/"yue"/"ar") -> models.find()
    // luôn trả undefined -> "not ready" -> nút "Bắt đầu nghe" bị disable SAI dù
    // startCaptureFlow() đã có bypass đúng cho cloudStt (chỉ updateSourceLangHint() bị bỏ sót).
    // Whisper Cloud không cần tải model gì trước (xem AudioCaptureService.startCloudSttReadLoop),
    // nên bypass thẳng về true khi cloudStt đang bật - khớp đúng bypass đã có ở startCaptureFlow().
    async function isSourceLangModelReady(lang) {
      if (cloudSttEl.checked) return true;
      const plugin = getModelManagerPlugin();
      if (!plugin) return true; // không chặn nếu plugin chưa load - để lỗi thật hiện ra lúc start
      try {
        const res = await plugin.listModels();
        const models = res.models || [];
        if (lang === 'auto') {
          // Khớp điều kiện native (AudioCaptureService, nhánh sourceLang == "auto"): cần ít
          // nhất AUTO_MODE_MIN_READY_LANGS ngôn ngữ đã tải về.
          const readyCount = models.filter((m) => m.status === 'downloaded').length;
          return readyCount >= AUTO_MODE_MIN_READY_LANGS;
        }
        const entry = models.find((m) => m.lang === lang);
        return entry ? entry.status === 'downloaded' : false;
      } catch (e) {
        return true;
      }
    }
    window.__isSourceLangModelReady = isSourceLangModelReady;

    async function updateSourceLangHint() {
      const ready = await isSourceLangModelReady(sourceLangEl.value);
      sourceLangHintEl.textContent = sourceLangEl.value === 'auto'
        ? `Chế độ tự động nhận diện cần tải ít nhất ${AUTO_MODE_MIN_READY_LANGS} ngôn ngữ ở mục "Quản lý mô hình ngôn ngữ" phía trên.`
        : 'Ngôn ngữ này chưa tải model - tải ở mục "Quản lý mô hình ngôn ngữ" phía trên trước khi bắt đầu nghe.';
      sourceLangHintEl.style.display = ready ? 'none' : 'block';
      mainToggleBtnRef().disabled = !ready && !isCapturingRef();
    }
    // mainToggleBtn/isCapturing được khai báo ở module script bên dưới (load sau) - tra cứu
    // gián tiếp qua hàm để tránh lỗi "used before defined" giữa 2 <script> tách biệt.
    function mainToggleBtnRef() { return document.getElementById('mainToggleBtn'); }
    function isCapturingRef() { return window.__isCapturing === true; }

    sourceLangEl.addEventListener('change', updateSourceLangHint);

    // ===== Onboarding: notification permission -> battery optimization -> mainControlSection.
    // Đã bỏ bước overlay permission vì không còn dùng chữ nổi đè app khác. =====
    const stepNotificationEl = document.getElementById('stepNotification');
    const stepBatteryEl = document.getElementById('stepBattery');
    const mainControlSectionEl = document.getElementById('mainControlSection');

    // Bước pin có thể bị user bấm "Bỏ qua" - lưu lại để không ép hỏi lại mỗi lần mở app
    // (khác bước notification, vốn bắt buộc nên luôn kiểm tra lại thật từ hệ thống).
    const BATTERY_SKIPPED_KEY = 'batteryOptimizationSkipped';

    async function refreshOnboarding() {
      const audioPlugin = getAudioCapturePlugin();
      const notifRes = audioPlugin
        ? await audioPlugin.checkNotificationPermission().catch(() => ({ granted: true }))
        : { granted: true };
      if (!notifRes.granted) {
        stepNotificationEl.style.display = 'block';
        stepBatteryEl.style.display = 'none';
        mainControlSectionEl.style.display = 'none';
        return;
      }
      stepNotificationEl.style.display = 'none';

      const batterySkipped = localStorage.getItem(BATTERY_SKIPPED_KEY) === '1';
      const batteryRes = audioPlugin
        ? await audioPlugin.checkBatteryOptimization().catch(() => ({ ignoringOptimizations: true }))
        : { ignoringOptimizations: true };
      if (!batteryRes.ignoringOptimizations && !batterySkipped) {
        stepBatteryEl.style.display = 'block';
        mainControlSectionEl.style.display = 'none';
        return;
      }
      stepBatteryEl.style.display = 'none';
      mainControlSectionEl.style.display = 'block';
    }

    document.getElementById('grantNotificationBtn').onclick = async () => {
      const plugin = getAudioCapturePlugin();
      if (!plugin) return;
      try {
        const res = await plugin.requestNotificationPermission();
        log('Kết quả xin quyền thông báo: granted=' + res.granted);
        await refreshOnboarding();
      } catch (err) {
        log('LỖI khi xin quyền thông báo: ' + err.message);
      }
    };

    document.getElementById('grantBatteryBtn').onclick = async () => {
      const plugin = getAudioCapturePlugin();
      if (!plugin) return;
      try {
        const res = await plugin.requestIgnoreBatteryOptimizations();
        log('Kết quả xin miễn trừ tối ưu pin: ignoringOptimizations=' + res.ignoringOptimizations);
        await refreshOnboarding();
      } catch (err) {
        log('LỖI khi xin miễn trừ tối ưu pin: ' + err.message);
      }
    };

    document.getElementById('skipBatteryBtn').onclick = async () => {
      localStorage.setItem(BATTERY_SKIPPED_KEY, '1');
      await refreshOnboarding();
    };

    // App quay lại foreground -> kiểm tra lại onboarding để tự chuyển bước.
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) refreshOnboarding();
    });

    // ===== Dịch: ưu tiên ML Kit on-device (nếu có) -> groq-relay (openai/gpt-oss-120b) ->
    // Gemini (gemini-3.5-flash-lite, LLM dự phòng thứ 2, cũng phủ ~29 ngôn ngữ) -> DeepL (chất
    // lượng dịch rất cao cho các ngôn ngữ nó hỗ trợ, đặc biệt các cặp Âu-Âu, nhưng KHÔNG bao
    // phủ hết ~29 ngôn ngữ app đang hỗ trợ) -> Azure (chỉ 3 mã DeepL thiếu: kz/uz/ky) -> cuối
    // cùng mới rơi xuống Google Translate free (endpoint miễn phí, không cần API key, chất
    // lượng thấp nhất, hay bị 429) =====
    let lastTranslated = '';

    // Header bí mật gửi kèm groq-relay/youtube-extract để chặn bớt việc URL function bị lộ rồi
    // bị gọi thẳng tốn quota Groq/DeepL trả phí (server chỉ thật sự bắt buộc khi secret
    // APP_SHARED_SECRET đã được set trên Supabase - xem checkAppSecret() trong 2 file index.ts).
    // LƯU Ý: đây KHÔNG phải bảo mật thật vì www/ nằm nguyên trong APK dạng file tĩnh, ai unzip
    // APK cũng đọc được chuỗi này - chỉ chặn được việc scrape/gọi bừa qua URL công khai, KHÔNG
    // chặn được người cố tình lấy từ APK. Muốn chặn thật cần cấp secret riêng theo từng
    // user/thiết bị (vượt quá phạm vi 1 app cá nhân hiện tại).
    const APP_SHARED_SECRET_HEADER = '68c69b76a884e0c0be564275abac97b9d8f326c031be98de7bea9a2c9d461ba0';

    const GROQ_RELAY_TRANSLATE_URL =
      'https://clbddroyrueafygedycy.supabase.co/functions/v1/groq-relay?op=translate';
    const GROQ_TIMEOUT_MS = 8000;

    // groq-relay giờ có LANG_NAMES đủ ~29 ngôn ngữ (khớp ModelCatalog.CATALOG, xem index.ts) -
    // không còn giới hạn chỉ vi/en/zh nữa. Chỉ còn cắt hậu tố vùng/miền (vd 'zh-CN' -> 'zh')
    // để khớp đúng key trong LANG_NAMES, server cũng tự làm fallback này nhưng cắt sẵn ở đây
    // cho chắc + đỡ phải sửa cả 2 nơi mỗi khi thêm mã mới.
    function normalizeGroqLangCode(targetLang) {
      if (!targetLang) return null;
      return targetLang.split('-')[0];
    }

    // Ngữ cảnh (Hạng mục "dịch tốt hơn"): lưu vài câu NGUỒN gần nhất theo từng cặp
    // (sourceLang, targetLang) để gửi kèm cho CẢ groq-relay lẫn DeepL - giúp model/engine giải
    // quyết đại từ bị lược, thành ngữ nối câu, giữ xưng hô/thuật ngữ nhất quán giữa các câu
    // liên tiếp trong 1 đoạn hội thoại/video, thay vì mỗi câu bị dịch hoàn toàn độc lập như
    // trước. Không dùng chung 1 mảng toàn cục vì nhiều luồng gọi translateText song song với
    // các cặp ngôn ngữ khác nhau (live listen, lyrics, dịch thủ công) - trộn ngữ cảnh giữa các
    // luồng sẽ gây nhiễu. Đặt tên chung "translationContext" (không còn gắn riêng "groq") vì
    // DeepL cũng đọc/ghi cùng lịch sử này.
    const TRANSLATION_CONTEXT_MAX = 3;
    const translationContextHistory = {};

    function translationContextKey(sourceLang, targetLang) {
      return (sourceLang || '?') + '|' + targetLang;
    }

    function getTranslationContext(sourceLang, targetLang) {
      return translationContextHistory[translationContextKey(sourceLang, targetLang)] || [];
    }

    function pushTranslationContext(sourceLang, targetLang, text) {
      const key = translationContextKey(sourceLang, targetLang);
      const arr = translationContextHistory[key] || (translationContextHistory[key] = []);
      arr.push(text);
      if (arr.length > TRANSLATION_CONTEXT_MAX) arr.shift();
    }

    async function translateGroq(text, targetLang, sourceLang) {
      const langCode = normalizeGroqLangCode(targetLang);
      if (!langCode) throw new Error('groq-relay: thiếu targetLang');

      const context = getTranslationContext(sourceLang, targetLang);

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), GROQ_TIMEOUT_MS);
      let res;
      try {
        res = await fetch(GROQ_RELAY_TRANSLATE_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-App-Secret': APP_SHARED_SECRET_HEADER },
          body: JSON.stringify({ text, targetLangCode: langCode, context }),
          signal: controller.signal,
        });
      } finally {
        clearTimeout(timeoutId);
      }

      if (!res.ok) {
        const body = await res.text().catch(() => '');
        throw new Error('groq-relay HTTP ' + res.status + (body ? ': ' + body.slice(0, 200) : ''));
      }
      const data = await res.json();
      if (!data.translated) throw new Error('groq-relay: response rỗng');

      // Chỉ lưu vào ngữ cảnh SAU KHI dịch thành công - câu lỗi/rỗng không nên làm nhiễu
      // ngữ cảnh cho các câu dịch sau.
      pushTranslationContext(sourceLang, targetLang, text);

      // Chinese: groq-relay tự thêm Pinyin, gộp vào 1 dòng cho tiện hiển thị overlay
      return data.pinyin ? data.translated + '\n' + data.pinyin : data.translated;
    }

    // ===== Circuit breaker (Hạng mục "chống lỗi"): tránh việc MỖI câu dịch đều phải chờ hết
    // GROQ_TIMEOUT_MS (8s) rồi mới rơi xuống Gemini, trong lúc Groq đang hết quota/sập tạm thời
    // (401/429 hoặc timeout kéo dài liên tục) - rất hay xảy ra khi dùng free-tier. Sau
    // CIRCUIT_FAIL_THRESHOLD lần lỗi LIÊN TIẾP, "mở" breaker: bỏ qua thẳng lệnh gọi Groq trong
    // CIRCUIT_OPEN_MS tiếp theo (không tốn thời gian chờ timeout nữa), rồi tự "đóng" lại (thử
    // gọi Groq bình thường) sau khi hết thời gian đó - không cần khởi động lại app. Bất kỳ lần
    // gọi Groq nào thành công cũng reset breaker về trạng thái đóng (0 lỗi) ngay lập tức, vì
    // thành công nghĩa là Groq đã hoạt động bình thường trở lại.
    const CIRCUIT_FAIL_THRESHOLD = 3;
    const CIRCUIT_OPEN_MS = 60000; // 60s - đủ ngắn để không bỏ lỡ lâu khi Groq hồi phục nhanh
    const groqCircuit = { failCount: 0, openUntil: 0 };

    function isGroqCircuitOpen() {
      return Date.now() < groqCircuit.openUntil;
    }

    function recordGroqSuccess() {
      groqCircuit.failCount = 0;
      groqCircuit.openUntil = 0;
    }

    function recordGroqFailure() {
      groqCircuit.failCount += 1;
      if (groqCircuit.failCount >= CIRCUIT_FAIL_THRESHOLD) {
        groqCircuit.openUntil = Date.now() + CIRCUIT_OPEN_MS;
        log('Groq lỗi ' + groqCircuit.failCount + ' lần liên tiếp - tạm ngắt Groq ' +
          (CIRCUIT_OPEN_MS / 1000) + 's, chuyển thẳng sang Gemini...');
      }
    }

    // ===== Gemini - tầng dịch LLM dự phòng thứ 2, chen NGAY SAU Groq (trước DeepL). Gemini
    // cũng là LLM như Groq nên phủ được cả ~29 ngôn ngữ app hỗ trợ (dùng chung LANG_NAMES phía
    // server), trong khi DeepL chỉ có ~16/29 mã - đặt Gemini trước DeepL/Azure giữ được chất
    // lượng dịch LLM cho nhiều ngôn ngữ hơn trước khi phải rơi xuống Google Translate free.
    // Cần secret GEMINI_API_KEY set trong Supabase (xem README) - nếu chưa set, server tự trả
    // lỗi SERVER_MISSING_GEMINI_KEY, rơi tiếp xuống DeepL như bình thường, không chặn app.
    const GEMINI_RELAY_TRANSLATE_URL =
      'https://clbddroyrueafygedycy.supabase.co/functions/v1/groq-relay?op=translateGemini';
    const GEMINI_TIMEOUT_MS = 8000;

    async function translateGemini(text, targetLang, sourceLang) {
      const langCode = normalizeGroqLangCode(targetLang); // tái dùng cắt hậu tố vùng/miền
      if (!langCode) throw new Error('Gemini relay: thiếu targetLang');

      const context = getTranslationContext(sourceLang, targetLang);

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), GEMINI_TIMEOUT_MS);
      let res;
      try {
        res = await fetch(GEMINI_RELAY_TRANSLATE_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-App-Secret': APP_SHARED_SECRET_HEADER },
          body: JSON.stringify({ text, targetLangCode: langCode, context }),
          signal: controller.signal,
        });
      } finally {
        clearTimeout(timeoutId);
      }

      if (!res.ok) {
        const body = await res.text().catch(() => '');
        throw new Error('Gemini relay HTTP ' + res.status + (body ? ': ' + body.slice(0, 200) : ''));
      }
      const data = await res.json();
      if (!data.translated) throw new Error('Gemini relay: response rỗng');

      pushTranslationContext(sourceLang, targetLang, text);

      // Chinese: server tự thêm Pinyin giống op=translate (Groq), gộp vào 1 dòng cho tiện overlay
      return data.pinyin ? data.translated + '\n' + data.pinyin : data.translated;
    }

    // ===== DeepL - tầng dịch chen giữa Groq và Google Translate free. Chất lượng dịch DeepL
    // (đặc biệt các cặp ngôn ngữ Âu-Âu: en/de/fr/es/it/nl/pt/pl...) thường được đánh giá cao
    // hơn cả dịch máy NMT thông thường lẫn nhiều model LLM nhỏ, và free tier 500.000 ký
    // tự/tháng đủ dùng cho lượng dịch phụ đề bình thường. CHỈ dùng làm dự phòng khi Groq lỗi
    // (hết quota Groq/model lỗi) - không thay Groq làm ưu tiên số 1 vì DeepL không phủ hết
    // ~29 ngôn ngữ app hỗ trợ (xem DEEPL_TARGET_LANG_MAP - chỉ ~16/29 mã có mặt, phần còn lại
    // như fa/hi/ka/gu/te/ky/uz/kz/tg/eo/br/ca vẫn phải rơi tiếp xuống Google Translate free).
    const DEEPL_RELAY_TRANSLATE_URL =
      'https://clbddroyrueafygedycy.supabase.co/functions/v1/groq-relay?op=translateDeepl';
    const DEEPL_TIMEOUT_MS = 8000;

    // Mã đích DeepL (viết hoa, có biến thể vùng cho EN/PT theo đúng API DeepL) - chỉ liệt kê
    // các ngôn ngữ DeepL THỰC SỰ hỗ trợ tính đến 2026 (đã xác nhận Việt được thêm giữa 2025).
    // Không đoán mò thêm các ngôn ngữ hiếm (Gujarati, Telugu, Kyrgyz...) vì chưa xác minh được.
    const DEEPL_TARGET_LANG_MAP = {
      vi: 'VI', en: 'EN-US', 'en-in': 'EN-US', zh: 'ZH', ja: 'JA', ko: 'KO',
      ru: 'RU', fr: 'FR', de: 'DE', es: 'ES', pt: 'PT-PT', tr: 'TR',
      it: 'IT', nl: 'NL', uk: 'UK', cs: 'CS', pl: 'PL',
    };
    // Mã nguồn DeepL không có biến thể vùng (khác targetLang) - dùng để gợi ý source_lang,
    // KHÔNG bắt buộc: nếu sourceLang không có trong map này, bỏ qua source_lang, để DeepL tự
    // nhận diện ngôn ngữ nguồn (vẫn hoạt động bình thường, chỉ có thể chậm/kém chính xác hơn
    // 1 chút so với chỉ định thẳng).
    const DEEPL_SOURCE_LANG_MAP = {
      vi: 'VI', en: 'EN', 'en-in': 'EN', zh: 'ZH', ja: 'JA', ko: 'KO',
      ru: 'RU', fr: 'FR', de: 'DE', es: 'ES', pt: 'PT', tr: 'TR',
      it: 'IT', nl: 'NL', uk: 'UK', cs: 'CS', pl: 'PL',
    };

    async function translateDeepl(text, targetLang, sourceLang) {
      const deeplTarget = DEEPL_TARGET_LANG_MAP[targetLang];
      if (!deeplTarget) throw new Error('DeepL không hỗ trợ targetLang=' + targetLang);
      const deeplSource = DEEPL_SOURCE_LANG_MAP[sourceLang]; // có thể undefined -> DeepL tự nhận diện

      // Tái dùng đúng lịch sử ngữ cảnh với Groq (gộp thành 1 đoạn text, đúng định dạng
      // "context" dạng chuỗi của DeepL - khác context dạng mảng câu của groq-relay?op=translate).
      const context = getTranslationContext(sourceLang, targetLang).join(' ');

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), DEEPL_TIMEOUT_MS);
      let res;
      try {
        res = await fetch(DEEPL_RELAY_TRANSLATE_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-App-Secret': APP_SHARED_SECRET_HEADER },
          body: JSON.stringify({
            text,
            targetLangCode: deeplTarget,
            sourceLangCode: deeplSource,
            context,
          }),
          signal: controller.signal,
        });
      } finally {
        clearTimeout(timeoutId);
      }

      if (!res.ok) {
        const body = await res.text().catch(() => '');
        throw new Error('DeepL relay HTTP ' + res.status + (body ? ': ' + body.slice(0, 200) : ''));
      }
      const data = await res.json();
      if (!data.translated) throw new Error('DeepL relay: response rỗng');

      pushTranslationContext(sourceLang, targetLang, text);

      return data.translated;
    }

    // ===== Azure Translator - tầng chen giữa Groq và Google Translate free, CHỈ dùng riêng
    // cho 3 mã DeepL KHÔNG hỗ trợ: kz (Kazakh), uz (Uzbek), ky (Kyrgyz) - xem
    // AZURE_TARGET_LANG_MAP bên dưới. KHÔNG thay DeepL cho các mã DeepL đã dịch tốt (không cần
    // thêm 1 dependency mới cho thứ đã có sẵn). Free tier F0 của Azure Translator: 2 triệu ký
    // tự/tháng - lớn hơn nhiều DeepL free (500k/tháng), giảm áp lực quota riêng cho 3 mã này
    // khi Groq hết quota. Cần secret AZURE_TRANSLATOR_KEY + AZURE_TRANSLATOR_REGION set trong
    // Supabase (xem README) - nếu chưa set, server tự trả lỗi SERVER_MISSING_AZURE_KEY/REGION,
    // rơi tiếp xuống Google Translate free như bình thường, không chặn app.
    const AZURE_RELAY_TRANSLATE_URL =
      'https://clbddroyrueafygedycy.supabase.co/functions/v1/groq-relay?op=translateAzure';
    const AZURE_TIMEOUT_MS = 8000;

    // Chỉ 3 mã app đang thiếu ở DeepL - KHÔNG mở rộng thêm ra các mã DeepL đã hỗ trợ, tránh 2
    // tầng dịch chồng chéo cho cùng 1 ngôn ngữ mà không giải quyết gap thực tế nào thêm.
    const AZURE_TARGET_LANG_MAP = { kz: 'kk', uz: 'uz', ky: 'ky' };
    const AZURE_SOURCE_LANG_MAP = { kz: 'kk', uz: 'uz', ky: 'ky' };

    async function translateAzure(text, targetLang, sourceLang) {
      const azureTarget = AZURE_TARGET_LANG_MAP[targetLang];
      if (!azureTarget) throw new Error('Azure Translator không hỗ trợ targetLang=' + targetLang + ' (chỉ dùng cho kz/uz/ky)');
      const azureSource = AZURE_SOURCE_LANG_MAP[sourceLang]; // có thể undefined -> Azure tự nhận diện

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), AZURE_TIMEOUT_MS);
      let res;
      try {
        res = await fetch(AZURE_RELAY_TRANSLATE_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-App-Secret': APP_SHARED_SECRET_HEADER },
          body: JSON.stringify({ text, targetLangCode: azureTarget, sourceLangCode: azureSource }),
          signal: controller.signal,
        });
      } finally {
        clearTimeout(timeoutId);
      }

      if (!res.ok) {
        const body = await res.text().catch(() => '');
        throw new Error('Azure relay HTTP ' + res.status + (body ? ': ' + body.slice(0, 200) : ''));
      }
      const data = await res.json();
      if (!data.translated) throw new Error('Azure relay: response rỗng');

      return data.translated;
    }

    // ===== Whisper Cloud (Groq) - STT dự phòng khi Vosk offline chưa tốt cho ngôn ngữ đang
    // chọn. Native (AudioCaptureService.startCloudSttReadLoop) chỉ lo capture + VAD cắt câu,
    // tự đóng gói WAV + base64 rồi bắn sự kiện 'cloudSttSegment' - JS ở đây lo phần mạng (upload
    // lên groq-relay?op=transcribe, vốn đã có sẵn từ trước cho tính năng khác) và tự đẩy text
    // nhận được vào ĐÚNG pipeline dịch/hiển thị/log dùng chung với Vosk (pushFinalToBatch). =====
    const GROQ_RELAY_TRANSCRIBE_URL =
      'https://clbddroyrueafygedycy.supabase.co/functions/v1/groq-relay?op=transcribe';
    // Audio dài hơn 1 câu text nhiều - cho thời gian chờ rộng hơn GROQ_TIMEOUT_MS (dịch text).
    const GROQ_STT_TIMEOUT_MS = 20000;

    function base64ToBlob(base64, mimeType) {
      const binary = atob(base64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      return new Blob([bytes], { type: mimeType });
    }

    // sourceLang: bỏ qua (không set 'language') khi 'auto' - Whisper tự nhận diện ngôn ngữ theo
    // nội dung audio khi không được chỉ định trước, giống cách groq-relay?op=translate đã dùng
    // cho targetLang.
    async function transcribeCloudSegment(wavBase64, sourceLang) {
      const blob = base64ToBlob(wavBase64, 'audio/wav');
      const form = new FormData();
      form.append('file', blob, 'segment.wav');
      if (sourceLang && sourceLang !== 'auto') form.append('language', sourceLang);

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), GROQ_STT_TIMEOUT_MS);
      let res;
      try {
        res = await fetch(GROQ_RELAY_TRANSCRIBE_URL, {
          method: 'POST',
          // Không set 'Content-Type' thủ công (FormData tự set kèm boundary đúng) - chỉ thêm
          // header bí mật.
          headers: { 'X-App-Secret': APP_SHARED_SECRET_HEADER },
          body: form,
          signal: controller.signal,
        });
      } finally {
        clearTimeout(timeoutId);
      }

      if (!res.ok) {
        const body = await res.text().catch(() => '');
        throw new Error('groq-relay(transcribe) HTTP ' + res.status + (body ? ': ' + body.slice(0, 200) : ''));
      }
      const data = await res.json();
      return (data.text || '').trim();
    }

    // Endpoint free của Google rate-limit (HTTP 429) nếu bắn nhiều request dồn dập -
    // hay gặp khi Vosk chốt nhiều câu "final" liên tiếp lúc nói nhanh/liên tục.
    // Fix: (1) tự retry có chờ khi gặp 429, (2) xếp hàng tuần tự (không gọi song song)
    // riêng cho luồng tự động từ onFinal, để không bao giờ có 2 request cùng lúc.
    async function translateGoogleFree(text, targetLang, retriesLeft = 3) {
      const url = 'https://translate.googleapis.com/translate_a/single'
        + '?client=gtx&sl=auto&tl=' + encodeURIComponent(targetLang)
        + '&dt=t&q=' + encodeURIComponent(text);
      const res = await fetch(url);
      if (res.status === 429 && retriesLeft > 0) {
        const waitMs = (4 - retriesLeft) * 1000; // 1s, 2s, 3s
        log('Dịch bị rate-limit (429), thử lại sau ' + waitMs + 'ms...');
        await new Promise((resolve) => setTimeout(resolve, waitMs));
        return translateGoogleFree(text, targetLang, retriesLeft - 1);
      }
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();
      // data[0] là mảng các đoạn [dịch, gốc, ...]
      return data[0].map(seg => seg[0]).join('');
    }

    // ===== Cache câu đã dịch (Hạng mục J) - video dài hay lặp lại câu/cụm từ (lời chào,
    // filler, quảng cáo lặp...) -> cache theo (sourceLang, targetLang, text đã chuẩn hoá) để
    // tránh gọi mạng lại cho câu ĐÃ dịch y hệt trước đó, giảm tải Groq/Google free (đỡ 429
    // hơn) và trả kết quả tức thì cho câu lặp. Lưu vào localStorage để cache sống qua các
    // phiên nghe khác nhau, giới hạn TRANSLATION_CACHE_MAX_ENTRIES để không phình vô hạn -
    // khi đầy, xoá entry cũ nhất theo thứ tự chèn (giống LRU đơn giản, không cần cấu trúc
    // dữ liệu phức tạp vì tần suất truy cập cache thấp, không cần tối ưu tốc độ cao).
    const TRANSLATION_CACHE_KEY = 'atun_translation_cache_v1';
    const TRANSLATION_CACHE_MAX_ENTRIES = 500;
    let translationCache = {};
    try {
      translationCache = JSON.parse(localStorage.getItem(TRANSLATION_CACHE_KEY) || '{}');
    } catch (e) {
      translationCache = {};
    }

    function translationCacheKey(text, sourceLang, targetLang) {
      // Chuẩn hoá nhẹ: trim + gộp khoảng trắng thừa - "Hello  world" và "Hello world" nên
      // dùng chung 1 entry cache. KHÔNG lowercase vì có thể đổi nghĩa/độ trang trọng ở một số
      // ngôn ngữ (vd tên riêng viết hoa) - chấp nhận cache-miss nếu chỉ khác hoa/thường.
      const normalized = text.trim().replace(/\s+/g, ' ');
      return (sourceLang || '?') + '|' + targetLang + '|' + normalized;
    }

    function getCachedTranslation(text, sourceLang, targetLang) {
      const key = translationCacheKey(text, sourceLang, targetLang);
      return Object.prototype.hasOwnProperty.call(translationCache, key)
        ? translationCache[key]
        : null;
    }

    function setCachedTranslation(text, sourceLang, targetLang, translated) {
      const key = translationCacheKey(text, sourceLang, targetLang);
      const isNewKey = !Object.prototype.hasOwnProperty.call(translationCache, key);
      translationCache[key] = translated;

      if (isNewKey) {
        const keys = Object.keys(translationCache);
        if (keys.length > TRANSLATION_CACHE_MAX_ENTRIES) {
          // Object.keys() trả về theo thứ tự chèn (đúng chuẩn ES2015+ cho string key thường) -
          // xoá bớt các entry cũ nhất, giữ lại đúng TRANSLATION_CACHE_MAX_ENTRIES gần nhất.
          const toRemove = keys.length - TRANSLATION_CACHE_MAX_ENTRIES;
          for (let i = 0; i < toRemove; i++) delete translationCache[keys[i]];
        }
      }

      try {
        localStorage.setItem(TRANSLATION_CACHE_KEY, JSON.stringify(translationCache));
      } catch (e) {
        // localStorage đầy (hiếm, vì đã giới hạn 500 entry) - bỏ qua, cache chỉ là tối ưu,
        // không phải chức năng bắt buộc, mất cache không ảnh hưởng tính đúng của app.
      }
    }

    // sourceLang: optional - CHỈ có khi bên gọi biết chắc ngôn ngữ nguồn (vd luồng live từ
    // Vosk, nơi sourceLangEl.value chính là ngôn ngữ đang nghe). ML Kit Translate on-device
    // KHÔNG có auto-detect (khác Google Translate free dùng sl=auto), nên khi không có
    // sourceLang (dịch thủ công/dịch file) bỏ qua nhánh ML Kit, đi thẳng groq/google như cũ.
    async function translateText(text, targetLang, sourceLang) {
      const cached = getCachedTranslation(text, sourceLang, targetLang);
      if (cached !== null) return cached;

      let translated;
      if (sourceLang && window.__isMlkitAvailable?.()) {
        try {
          translated = await window.__translateMlkit(text, sourceLang, targetLang);
          setCachedTranslation(text, sourceLang, targetLang, translated);
          return translated;
        } catch (err) {
          log('ML Kit on-device dịch lỗi (' + err.message + '), fallback qua mạng...');
        }
      }
      try {
        if (isGroqCircuitOpen()) {
          throw new Error('groq-relay: đang tạm ngắt (circuit breaker mở)');
        }
        try {
          translated = await translateGroq(text, targetLang, sourceLang);
          recordGroqSuccess();
        } catch (errGroqAttempt) {
          recordGroqFailure(); // chỉ đếm lỗi khi THẬT SỰ có gọi Groq (không tính lần bị breaker chặn)
          throw errGroqAttempt;
        }
      } catch (errGroq) {
        log('Groq dịch lỗi (' + errGroq.message + '), thử Gemini...');
        try {
          translated = await translateGemini(text, targetLang, sourceLang);
        } catch (errGemini) {
          log('Gemini dịch lỗi (' + errGemini.message + '), thử DeepL...');
          try {
            translated = await translateDeepl(text, targetLang, sourceLang);
          } catch (errDeepl) {
            log('DeepL dịch lỗi (' + errDeepl.message + '), thử Azure Translator...');
            try {
              translated = await translateAzure(text, targetLang, sourceLang);
            } catch (errAzure) {
              log('Azure dịch lỗi (' + errAzure.message + '), fallback Google Translate free...');
              translated = await translateGoogleFree(text, targetLang);
            }
          }
        }
      }
      setCachedTranslation(text, sourceLang, targetLang, translated);
      return translated;
    }

    // Hàng đợi tuần tự: mỗi lần chỉ chạy 1 tác vụ dịch, tác vụ sau đợi tác vụ trước
    // xong (kể cả khi lỗi) rồi mới chạy - tránh nhiều request cùng lúc gây 429.
    let translateQueue = Promise.resolve();
    function queueTranslate(fn) {
      const run = () => fn();
      translateQueue = translateQueue.then(run, run);
      return translateQueue;
    }

    // ===== Nhật ký dịch: thay cho chữ nổi overlay. Lưu vào localStorage để không mất khi
    // tắt/mở lại app, giới hạn 200 dòng gần nhất để tránh phình bộ nhớ vô hạn. =====
    const TRANSLATION_LOG_KEY = 'atun_translation_log_v1';
    const MAX_TRANSLATION_LOG_ENTRIES = 200;
    const translationLogEl = document.getElementById('translationLog');
    let translationLog = [];

    function loadTranslationLog() {
      try {
        translationLog = JSON.parse(localStorage.getItem(TRANSLATION_LOG_KEY) || '[]');
      } catch (e) {
        translationLog = [];
      }
      // Nhật ký lưu từ bản trước khi có tính năng xuất .srt sẽ chưa có trường ts (epoch ms) -
      // gán tạm ts tăng dần theo thứ tự đã lưu để buildSrtContent() không bị NaN.
      let needsResave = false;
      let fallbackTs = Date.now() - translationLog.length * 1000;
      translationLog = translationLog.map((e) => {
        if (typeof e.ts !== 'number') {
          needsResave = true;
          fallbackTs += 1000;
          return { ...e, ts: fallbackTs };
        }
        return e;
      });
      if (needsResave) {
        localStorage.setItem(TRANSLATION_LOG_KEY, JSON.stringify(translationLog));
      }
      renderTranslationLog();
    }

    function renderTranslationLog() {
      if (translationLog.length === 0) {
        translationLogEl.innerHTML = '<div style="color:#999; font-size:13px;">Chưa có câu nào được dịch.</div>';
        return;
      }
      // Mới nhất lên trên cho dễ theo dõi khi đang nghe liên tục.
      translationLogEl.innerHTML = translationLog.slice().reverse().map((entry) => `
        <div style="padding:6px 0; border-bottom:1px solid #e0e0e0;">
          <div style="font-size:11px; color:#999;">${entry.time}</div>
          <div style="font-size:13px; color:#666;">${escapeHtml(entry.original)}</div>
          <div style="font-weight:500;">${escapeHtml(entry.translated)}</div>
        </div>
      `).join('');
    }

    function escapeHtml(text) {
      const div = document.createElement('div');
      div.textContent = text;
      return div.innerHTML;
    }

    function addTranslationLogEntry(original, translated) {
      // ts: epoch ms - dùng để tính timestamp .srt (thời điểm câu này xuất hiện, tính từ
      // câu đầu tiên trong log). time: chuỗi giờ hiển thị trong UI, giữ như cũ.
      translationLog.push({ time: new Date().toLocaleTimeString(), ts: Date.now(), original, translated });
      if (translationLog.length > MAX_TRANSLATION_LOG_ENTRIES) {
        translationLog = translationLog.slice(-MAX_TRANSLATION_LOG_ENTRIES);
      }
      localStorage.setItem(TRANSLATION_LOG_KEY, JSON.stringify(translationLog));
      renderTranslationLog();
    }

    document.getElementById('clearLogBtn').onclick = () => {
      translationLog = [];
      localStorage.removeItem(TRANSLATION_LOG_KEY);
      renderTranslationLog();
      log('Đã xoá nhật ký dịch.');
    };

    // ===== Xuất nhật ký dịch: .srt (timestamp theo đúng nhịp câu xuất hiện lúc nghe, xem lại
    // như phụ đề thật) hoặc .txt song ngữ (gốc + dịch, dễ đọc). Ghi file thật + mở Android
    // Share Sheet qua ExportPlugin native (KHÔNG dùng <a download>+Blob URL - không đáng tin
    // cậy trong Capacitor WebView, và không có đường gửi Zalo/Telegram/lưu Drive). =====
    function srtTimestamp(ms) {
      const h = String(Math.floor(ms / 3600000)).padStart(2, '0');
      const m = String(Math.floor((ms % 3600000) / 60000)).padStart(2, '0');
      const s = String(Math.floor((ms % 60000) / 1000)).padStart(2, '0');
      const msPart = String(Math.floor(ms % 1000)).padStart(3, '0');
      return `${h}:${m}:${s},${msPart}`;
    }

    // WebVTT dùng dấu "." thay vì "," ở phần mili giây - khác duy nhất so với srtTimestamp().
    function vttTimestamp(ms) {
      return srtTimestamp(ms).replace(',', '.');
    }

    // Timing suy ra từ nhịp câu xuất hiện thực tế lúc nghe (ts của mỗi câu, tính lệch so với
    // câu đầu tiên) - không có mốc video/audio gốc để đồng bộ tuyệt đối, nhưng đủ để xem lại
    // đúng thứ tự và nhịp độ như phụ đề thật khi mở lại video đã nghe cùng lúc.
    function buildSrtContent(entries) {
      const chrono = entries.slice().sort((a, b) => a.ts - b.ts);
      const base = chrono[0].ts;
      const DEFAULT_LAST_DURATION_MS = 4000;
      return chrono.map((entry, i) => {
        const start = entry.ts - base;
        const end = (i + 1 < chrono.length) ? (chrono[i + 1].ts - base) : (start + DEFAULT_LAST_DURATION_MS);
        return `${i + 1}\n${srtTimestamp(start)} --> ${srtTimestamp(end)}\n${entry.translated}\n`;
      }).join('\n');
    }

    // Cùng logic timing với buildSrtContent() (chỉ khác định dạng timestamp + header "WEBVTT"
    // bắt buộc ở đầu file) - .vtt để xem trực tiếp trong trình duyệt (thẻ <track kind="subtitles">)
    // hoặc app không hỗ trợ .srt.
    function buildVttContent(entries) {
      const chrono = entries.slice().sort((a, b) => a.ts - b.ts);
      const base = chrono[0].ts;
      const DEFAULT_LAST_DURATION_MS = 4000;
      const cues = chrono.map((entry, i) => {
        const start = entry.ts - base;
        const end = (i + 1 < chrono.length) ? (chrono[i + 1].ts - base) : (start + DEFAULT_LAST_DURATION_MS);
        return `${vttTimestamp(start)} --> ${vttTimestamp(end)}\n${entry.translated}\n`;
      }).join('\n');
      return `WEBVTT\n\n${cues}`;
    }

    function buildBilingualTxtContent(entries) {
      const chrono = entries.slice().sort((a, b) => a.ts - b.ts);
      return chrono
        .map((e) => `[${e.time}]\n${e.original}\n→ ${e.translated}\n`)
        .join('\n');
    }

    async function exportTranslationLog(kind) {
      if (translationLog.length === 0) {
        log('Nhật ký dịch đang trống, không có gì để xuất.');
        return;
      }
      const stamp = new Date().toISOString().replace(/[:.]/g, '-');
      const formats = {
        srt: { build: buildSrtContent, ext: 'srt', mimeType: 'application/x-subrip' },
        vtt: { build: buildVttContent, ext: 'vtt', mimeType: 'text/vtt' },
        txt: { build: buildBilingualTxtContent, ext: 'txt', mimeType: 'text/plain' },
      };
      const { build, ext, mimeType } = formats[kind];
      const content = build(translationLog);
      const fileName = `atun-nhat-ky-dich-${stamp}.${ext}`;

      if (window.__isExportAvailable?.()) {
        try {
          await window.__shareExportFile(content, fileName, mimeType);
          log('Đã xuất nhật ký dịch (' + translationLog.length + ' câu) ra ' + fileName + '.');
        } catch (e) {
          log('Lỗi khi xuất file: ' + e.message);
        }
      } else {
        // Fallback khi chạy ngoài app native (vd xem trước trên trình duyệt PC) - không có
        // Share Sheet, chỉ tải xuống theo cách trình duyệt thường.
        const blob = new Blob([content], { type: mimeType + ';charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
        log('Plugin ExportPlugin chưa sẵn sàng (không chạy trong app native) - đã tải xuống theo cách trình duyệt thường.');
      }
    }

    document.getElementById('exportSrtBtn').onclick = () => exportTranslationLog('srt');
    document.getElementById('exportVttBtn').onclick = () => exportTranslationLog('vtt');
    document.getElementById('exportTxtBtn').onclick = () => exportTranslationLog('txt');

    loadTranslationLog();
    window.__addTranslationLogEntry = addTranslationLogEntry;

    // ===== Phát video từ link dán vào, ngay trong app (iframe embed chính chủ YouTube,
    // KHÔNG phải scraping InnerTube). Hỗ trợ các dạng link phổ biến: watch?v=, youtu.be/,
    // shorts/, embed/, và link live (/live/VIDEOID). =====
    function extractYoutubeVideoId(input) {
      const trimmed = input.trim();
      // Link dạng watch?v=, youtu.be/, embed/, shorts/, live/, hoặc chỉ dán thẳng video ID (11 ký tự).
      const patterns = [
        /(?:youtube\.com\/watch\?v=|youtube\.com\/live\/|youtube\.com\/shorts\/|youtube\.com\/embed\/|youtu\.be\/)([A-Za-z0-9_-]{11})/,
        /^([A-Za-z0-9_-]{11})$/,
      ];
      for (const re of patterns) {
        const match = trimmed.match(re);
        if (match) return match[1];
      }
      return null;
    }

    const videoUrlInputEl = document.getElementById('videoUrlInput');
    const videoPlayerContainerEl = document.getElementById('videoPlayerContainer');
    const videoStageEl = document.getElementById('videoStage');
    const videoPlayerFrameEl = document.getElementById('videoPlayerFrame');

    // "Web mini" - gọi thẳng qua window.Capacitor.Plugins (giống ExportPlugin ở trên), không
    // cần module riêng vì chỉ có đúng 1 thao tác "mở màn hình". Nếu chạy ngoài Capacitor
    // (vd test trên trình duyệt máy tính) thì Plugins.BrowserLauncher sẽ undefined -> báo log
    // thay vì lỗi im lặng.
    document.getElementById('openBrowserMiniBtn').onclick = () => {
      const plugin = window.Capacitor?.Plugins?.BrowserLauncher;
      if (!plugin) {
        log('Không tìm thấy BrowserLauncher - chỉ chạy được trên bản Android build từ Capacitor.');
        return;
      }
      plugin.open({});
    };

    // Đồng bộ khung phụ đề dịch sang "Web mini" - gọi mỗi khi câu dịch thật ở #inVideoCaption
    // đổi (kể cả text='' để xoá) để BrowserActivity (nếu đang mở/foreground) hiện đúng câu đó
    // trong overlay riêng của nó, xem native/CaptionRelay.kt + BrowserLauncherPlugin.updateCaption().
    // Gửi kèm cả "khung dịch" (độ trong suốt/cỡ chữ/tỉ lệ rộng-cao) qua window.__getCaptionFrame
    // (expose từ module script bên dưới - 2 khối <script> không cùng scope nên phải đi vòng qua
    // window.__ giống window.__applyCaptionSettings đã làm) để overlay của Web mini không chỉ
    // hiện đúng CÂU mà còn hiện giống đúng KHUNG đang cấu hình ở màn hình chính.
    // Best-effort: im lặng bỏ qua nếu không chạy trong Capacitor (vd test trên trình duyệt máy
    // tính) hoặc lệnh gọi lỗi vì lý do gì đó - đây chỉ là tính năng "ăn theo", không được để nó
    // làm hỏng luồng hiện phụ đề chính ở màn hình chính nếu có trục trặc.
    function pushCaptionToWebMini(text) {
      const frame = window.__getCaptionFrame?.() || {};
      window.Capacitor?.Plugins?.BrowserLauncher?.updateCaption?.({ text, ...frame }).catch(() => {});
    }

    // ===== Lời bài hát: ưu tiên phụ đề có sẵn của chính video, fallback nhận dạng giọng hát
    // trực tiếp qua STT (luồng "Bắt audio hệ thống" đã có sẵn, không đổi gì) khi video không có
    // phụ đề nào. Gọi youtube-extract (đã mở rộng 1/9/2026 để trả kèm caption track + cue) mỗi
    // lần phát video mới; không cần bật/tắt gì thủ công - tự bám theo video đang phát. =====
    const YOUTUBE_EXTRACT_URL = 'https://clbddroyrueafygedycy.supabase.co/functions/v1/youtube-extract';
    const lyricsStatusEl = document.getElementById('lyricsStatus');
    let lyricsCues = [];         // [{start,dur,text}] theo giây, đã sort tăng dần theo start
    let lyricsSourceLang = null; // languageCode của track đã chọn (vd 'en','ko') - truyền cho translateText để ưu tiên ML Kit on-device
    let lyricsCueIndex = -1;     // index cue đang hiện, -1 = chưa hiện cue nào
    let lyricsSyncTimer = null;
    let lyricsFetchToken = 0;    // huỷ kết quả fetch cũ nếu người dùng phát video khác trước khi fetch xong
    let ytPlayer = null;         // instance YT.Player - null tới khi iframe_api sẵn sàng
    let ytApiLoading = false;

    function ensureYoutubeIframeApi() {
      if (window.YT?.Player || ytApiLoading) return;
      ytApiLoading = true;
      const tag = document.createElement('script');
      tag.src = 'https://www.youtube.com/iframe_api';
      document.head.appendChild(tag);
    }

    // Gắn YT.Player vào ĐÚNG iframe đã có sẵn (không tạo iframe mới) - iframe phải đã có src trỏ
    // .../embed/<id>?...&enablejsapi=1 TRƯỚC khi gọi hàm này (xem tài liệu IFrame Player API:
    // "If you already have an <iframe> element, ... the API will convert your existing iframe").
    // Tách riêng thành hàm dùng lại được (không chỉ gọi 1 lần từ onYouTubeIframeAPIReady) vì sau
    // khi "Dừng video" huỷ hẳn nội dung iframe (src=''), ytPlayer cũ không còn dùng được nữa -
    // lần phát tiếp theo cần TẠO LẠI player mới trên iframe vừa được set src lại, và lúc đó
    // window.YT.Player đã sẵn sàng từ trước (không cần đợi onYouTubeIframeAPIReady bắn lại - sự
    // kiện này CHỈ tự bắn đúng 1 lần trong suốt vòng đời trang, ngay sau khi script iframe_api
    // tải xong lần đầu).
    function createYtPlayer() {
      ytPlayer = new YT.Player('videoPlayerFrame', {
        events: {
          onStateChange: (e) => {
            // 1 = đang phát: chỉ chạy vòng đồng bộ khi thực sự đang phát, tránh gọi
            // getCurrentTime() liên tục lúc video đang tạm dừng/đệm (không đổi gì, tốn pin vô ích).
            if (e.data === 1) startLyricsSyncLoop(); else stopLyricsSyncLoop();
          },
        },
      });
    }
    // YouTube tự gọi hàm global này (đúng tài liệu chính thức) đúng 1 lần, ngay sau khi script
    // iframe_api vừa tải/khởi tạo xong lần đầu tiên trong trang.
    window.onYouTubeIframeAPIReady = () => { createYtPlayer(); };

    function resetLyricsState() {
      lyricsCues = [];
      lyricsSourceLang = null;
      lyricsCueIndex = -1;
      stopLyricsSyncLoop();
      lyricsStatusEl.textContent = '';
    }

    async function fetchYoutubeLyrics(videoId) {
      const myToken = ++lyricsFetchToken;
      lyricsStatusEl.textContent = '🎵 Đang tìm phụ đề có sẵn cho video này...';
      try {
        const res = await fetch(YOUTUBE_EXTRACT_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-App-Secret': APP_SHARED_SECRET_HEADER },
          body: JSON.stringify({ videoId }),
        });
        const data = await res.json();
        if (myToken !== lyricsFetchToken) return; // đã phát video khác trong lúc chờ - bỏ kết quả này
        if (!data.ok) {
          lyricsStatusEl.textContent = '🎤 Không tìm được phụ đề (video có thể bị hạn chế) - dùng "Bắt audio hệ thống" để nhận dạng giọng hát trực tiếp.';
          return;
        }
        if (!data.chosen || !data.cues || data.cues.length === 0) {
          lyricsStatusEl.textContent = '🎤 Video này không có phụ đề nào - dùng "Bắt audio hệ thống" để nhận dạng giọng hát trực tiếp (kể cả lời bài hát).';
          return;
        }
        lyricsCues = data.cues;
        lyricsSourceLang = data.chosen.languageCode || null;
        lyricsCueIndex = -1;
        lyricsStatusEl.textContent = '📝 Đã tìm thấy phụ đề ' + data.chosen.name
          + (data.chosen.isAuto ? ' (tự động)' : ' (chính chủ)')
          + ' - đang đồng bộ dịch lời theo video (' + lyricsCues.length + ' câu).';
        // Dịch trước vài câu đầu ngay để không phải chờ khi video vừa chạy tới đoạn có lời.
        prefetchLyricsTranslation(0);
      } catch (err) {
        if (myToken !== lyricsFetchToken) return;
        lyricsStatusEl.textContent = '🎤 Lỗi khi tìm phụ đề (' + err.message + ') - dùng "Bắt audio hệ thống" để nhận dạng giọng hát trực tiếp.';
      }
    }

    // Dịch trước LYRICS_PREFETCH_AHEAD câu kể từ fromIndex, xếp vào translateQueue (đã có sẵn,
    // dùng chung với luồng STT) nên không bắn dồn nhiều request dịch cùng lúc gây 429 - mỗi câu
    // dịch xong tự cache qua getCachedTranslation()/setCachedTranslation() (đã có sẵn) nên khi
    // vòng đồng bộ thật sự cần tới câu đó, chỉ là đọc cache, hiện ngay không phải chờ mạng.
    const LYRICS_PREFETCH_AHEAD = 6;
    function prefetchLyricsTranslation(fromIndex) {
      const target = lyricsSourceLang === 'vi' ? null : 'vi';
      for (let i = fromIndex; i < Math.min(fromIndex + LYRICS_PREFETCH_AHEAD, lyricsCues.length); i++) {
        const cue = lyricsCues[i];
        if (!target) break; // nguồn đã là tiếng Việt, không cần dịch
        if (getCachedTranslation(cue.text, lyricsSourceLang, target) !== null) continue;
        queueTranslate(() => translateText(cue.text, target, lyricsSourceLang).catch(() => {}));
      }
    }

    // Hiện 1 cue lời bài hát - dùng lại ĐÚNG cơ chế hiện phụ đề đã có (inVideoCaptionTextEl +
    // applyCaptionSettings() + nhật ký dịch + đồng bộ Web mini + TTS) thay vì viết lại đường
    // hiện caption riêng cho lyrics, để mọi cài đặt (kích thước khung, đọc to, Web mini...)
    // người dùng đã chỉnh cho STT vẫn áp dụng y hệt cho lyrics.
    async function showLyricCue(cue) {
      const original = cue.text;
      let translated = original;
      if (lyricsSourceLang && lyricsSourceLang !== 'vi') {
        try {
          translated = await translateText(original, 'vi', lyricsSourceLang);
        } catch (err) {
          translated = original; // dịch lỗi - vẫn hiện câu gốc còn hơn không hiện gì
        }
      }
      // inVideoCaption(Text) là phần tử DOM có thật ở trang này (không phải biến JS riêng) nên
      // lấy thẳng qua getElementById() - dùng chung được dù applyCaptionSettings() (hàm THẬT xử
      // lý kích thước/vị trí khung) sống ở <script type="module"> khác scope, gọi qua cầu nối
      // window.__applyCaptionSettings đã có sẵn (xem cách flushFinalBatch() cũng làm vậy).
      window.__clearCaptionPreviewPlaceholder?.();
      document.getElementById('inVideoCaptionText').textContent = translated;
      document.getElementById('inVideoCaption').style.display = 'block';
      window.__applyCaptionSettings?.();
      window.__speakIfTtsEnabled?.(translated);
      window.__addTranslationLogEntry?.(original, translated);
    }

    const LYRICS_SYNC_INTERVAL_MS = 300;
    function startLyricsSyncLoop() {
      if (lyricsSyncTimer || lyricsCues.length === 0 || !ytPlayer?.getCurrentTime) return;
      lyricsSyncTimer = setInterval(() => {
        let t;
        try { t = ytPlayer.getCurrentTime(); } catch (e) { return; }
        // Tìm cue mới nhất có start <= t (mảng đã sort tăng dần theo start, quét tuyến tính từ
        // vị trí hiện tại - đủ nhanh vì mỗi lần chỉ tiến vài bước, không cần binary search).
        let idx = lyricsCueIndex;
        while (idx + 1 < lyricsCues.length && lyricsCues[idx + 1].start <= t) idx++;
        // Người dùng tua lùi video (t < cue hiện tại) - lùi idx lại cho khớp thay vì đứng yên.
        while (idx > 0 && lyricsCues[idx].start > t) idx--;
        if (idx !== lyricsCueIndex && idx >= 0) {
          lyricsCueIndex = idx;
          showLyricCue(lyricsCues[idx]);
          prefetchLyricsTranslation(idx + 1);
        }
      }, LYRICS_SYNC_INTERVAL_MS);
    }
    function stopLyricsSyncLoop() {
      if (lyricsSyncTimer) { clearInterval(lyricsSyncTimer); lyricsSyncTimer = null; }
    }

    document.getElementById('playVideoBtn').onclick = () => {
      const videoId = extractYoutubeVideoId(videoUrlInputEl.value);
      if (!videoId) {
        log('Không nhận ra link/ID video YouTube hợp lệ.');
        return;
      }
      resetLyricsState();
      // cc_load_policy=0: xin YouTube KHÔNG tự bật mặc định phụ đề CC gốc (tránh đè/rối với
      // phụ đề dịch của app - 2 lớp chữ chồng lên nhau nếu để CC gốc bật). Đây LÀ tham số đúng
      // theo tài liệu chính thức của YouTube (0 = không tự bật, không có tham số "buộc tắt
      // hẳn"), NHƯNG có 2 giới hạn KHÔNG thể fix bằng code phía app:
      // 1) YouTube nhiều lần bị báo là không tôn trọng tuyệt đối cc_load_policy=0 trên embed
      //    (đặc biệt bản mobile/app WebView) - có lúc vẫn tự bật lại tuỳ phiên bản player phía
      //    YouTube, ngoài tầm kiểm soát của app.
      // 2) Nếu video gốc có phụ đề "cứng" (burned-in / hard-sub - chữ được ghi thẳng vào từng
      //    khung hình lúc dựng video, như video trong ảnh chụp màn hình gốc của Sổ Thu Chi/loại
      //    video kịch bản lồng tiếng) thì đó là PIXEL của chính video, không phải track CC thật
      //    - không có tham số URL hay API nào của YouTube tắt được, vì bản chất nó không phải
      //    "closed caption" theo nghĩa kỹ thuật.
      // enablejsapi=1 + origin: bắt buộc để YT.Player (IFrame Player API chính thức) điều khiển
      // được iframe này và cho getCurrentTime() hoạt động - chỉ dùng để ĐỌC thời gian phát nhằm
      // đồng bộ lyrics, không phải cách "hack" gì thêm ngoài API công khai YouTube cung cấp.
      //
      // 3 trường hợp:
      // 1) ytPlayer đang tồn tại VÀ còn dùng được (đổi link video trong khi video trước vẫn
      //    đang phát, chưa bấm "Dừng video") -> dùng loadVideoById(), KHÔNG set lại src trực
      //    tiếp (set src trực tiếp sau khi YT.Player đã "nhận" iframe dễ làm lệch handshake
      //    postMessage nội bộ, khiến getCurrentTime() không còn tin cậy).
      // 2) window.YT.Player đã sẵn sàng (đã phát video khác trước đó rồi bấm "Dừng video" - lúc
      //    đó ytPlayer bị đặt về null vì iframe cũ đã bị huỷ nội dung, xem stopVideoBtn) -> set
      //    src bootstrap lại rồi TẠO NGAY player mới (window.YT.Player có sẵn, không cần đợi
      //    onYouTubeIframeAPIReady - sự kiện này chỉ tự bắn 1 lần duy nhất trong đời trang).
      // 3) Lần đầu tiên tuyệt đối (window.YT chưa tồn tại) -> set src bootstrap rồi tải script
      //    iframe_api, onYouTubeIframeAPIReady sẽ tự tạo player khi sẵn sàng.
      if (ytPlayer && typeof ytPlayer.loadVideoById === 'function') {
        ytPlayer.loadVideoById(videoId);
      } else {
        videoPlayerFrameEl.src = 'https://www.youtube.com/embed/' + videoId
          + '?autoplay=1&playsinline=1&cc_load_policy=0&enablejsapi=1&origin=' + encodeURIComponent(location.origin);
        if (window.YT?.Player) createYtPlayer(); else ensureYoutubeIframeApi();
      }
      videoPlayerContainerEl.style.display = 'block';
      log('Đang phát video "' + videoId + '" trong app. Nếu dùng "Bắt audio hệ thống", '
        + 'nhiều khả năng sẽ bắt được audio này (khác app YouTube ngoài, có thể bị chặn capture).');
      fetchYoutubeLyrics(videoId);
    };

    document.getElementById('stopVideoBtn').onclick = () => {
      videoPlayerFrameEl.src = '';
      // src='' huỷ hẳn nội dung/document bên trong iframe (kể cả context JS player của YouTube) -
      // ytPlayer cũ (nếu có) không còn dùng loadVideoById() được nữa sau bước này. Đặt về null để
      // lần phát tiếp theo (playVideoBtn) tự nhận ra và bootstrap lại iframe + tạo player mới
      // thay vì gọi nhầm vào 1 iframe đã "chết" (xem nhánh xử lý trong playVideoBtn.onclick).
      ytPlayer = null;
      videoPlayerContainerEl.style.display = 'none';
      document.getElementById('inVideoCaption').style.display = 'none';
      pushCaptionToWebMini('');
      resetLyricsState();
      log('Đã dừng video trong app.');
    };

    // ===== Phóng to toàn màn hình - fullscreen videoStageEl (gồm iframe + phụ đề dịch,
    // KHÔNG gồm nút "Dừng video" - xem cấu trúc HTML), KHÔNG fullscreen mỗi iframe. Nút
    // fullscreen riêng của chính YouTube (trong iframe) chỉ fullscreen được mỗi iframe - phụ
    // đề (nằm NGOÀI iframe, không thể chèn vào trong vì iframe cross-origin) sẽ biến mất lúc
    // đó. fullscreenchange bên dưới BẮT mọi trường hợp fullscreen (kể cả tự YouTube gọi) rồi
    // tự chuyển hướng sang fullscreen videoStageEl thay vào - nhờ vậy dù bấm nút của YouTube
    // hay nút "Phóng to" của app, phụ đề vẫn luôn hiện.
    //
    // Đồng thời khoá xoay màn hình sang ngang khi vào fullscreen: nếu không, điện thoại vẫn ở
    // chiều dọc trong lúc video 16:9 fullscreen theo khung dọc đó -> video chỉ lấp được 1 dải
    // ngang mỏng ở giữa màn hình, 2 mảng đen lớn phía trên/dưới.
    //
    // BUG đã sửa: trước đây chỉ gọi screen.orientation.lock('landscape') (Web Screen
    // Orientation API) - API này KHÔNG hoạt động trong Android WebView (nơi Capacitor chạy
    // JS, khác Chrome/trình duyệt thật), luôn ném lỗi (thường "NotSupportedError" hoặc
    // "SecurityError") ngay khi gọi -> catch() nuốt lỗi âm thầm, video fullscreen không bao
    // giờ tự xoay ngang, chỉ lấp đầy khung dọc hẹp như mô tả ở trên. Giờ ưu tiên gọi plugin
    // native ScreenOrientationPlugin (khoá thật ở tầng Activity Android qua
    // requestedOrientation - luôn hoạt động, không phụ thuộc WebView có hỗ trợ Web API hay
    // không); vẫn giữ screen.orientation.lock() làm fallback khi KHÔNG chạy trong app native
    // (vd mở thẳng index.html bằng trình duyệt máy tính để test) - lúc đó không có plugin,
    // nhiều khả năng trình duyệt desktop vẫn không hỗ trợ nhưng không sao, không hỏng gì. =====
    function nativeOrientationPlugin() {
      return window.Capacitor?.Plugins?.ScreenOrientation || null;
    }

    function lockLandscape() {
      const p = nativeOrientationPlugin();
      if (p) {
        return p.lock({ orientation: 'landscape' }).catch(() => {
          // Không nên xảy ra (native luôn hỗ trợ) - nhưng vẫn bọc catch cho chắc, không để
          // lỗi ở đây làm hỏng luôn cả fullscreen.
        });
      }
      return Promise.resolve(screen.orientation?.lock?.('landscape').catch(() => {
        // Không chạy trong app native VÀ trình duyệt không hỗ trợ khoá xoay - vẫn fullscreen
        // bình thường, chỉ là người dùng phải tự xoay ngang điện thoại thủ công.
      }));
    }

    function unlockOrientation() {
      const p = nativeOrientationPlugin();
      if (p) {
        p.unlock().catch(() => {});
        return;
      }
      screen.orientation?.unlock?.();
    }

    function enterVideoFullscreen() {
      return videoStageEl.requestFullscreen?.().then(() => lockLandscape());
    }

    document.getElementById('videoFullscreenBtn').onclick = () => {
      enterVideoFullscreen()?.catch((err) => {
        log('Không phóng to được: ' + err.message);
      });
    };

    // Nút "Thu nhỏ" - chỉ hiện lúc fullscreen (xem CSS #videoStage:fullscreen ở trên). Thoát
    // fullscreen tường minh thay vì bắt user tự tìm nút fullscreen gốc của trình duyệt/cử chỉ
    // back - fullscreenchange bên dưới tự lo mở khoá xoay màn hình lại.
    document.getElementById('videoExitFullscreenBtn').onclick = () => {
      document.exitFullscreen?.().catch(() => {});
    };

    document.addEventListener('fullscreenchange', () => {
      if (document.fullscreenElement === videoPlayerFrameEl) {
        // YouTube tự gọi fullscreen trên CHÍNH iframe (bấm nút fullscreen của YouTube, không
        // phải nút "Phóng to" của app) - thoát ra rồi tự fullscreen lại đúng videoStageEl để
        // phụ đề không bị mất. Gọi requestFullscreen() NGAY trong handler này (cùng chuỗi sự
        // kiện do người dùng bấm) nên trình duyệt vẫn cho phép, không cần thêm cử chỉ chạm nào.
        document.exitFullscreen().then(() => {
          enterVideoFullscreen()?.catch(() => {});
        }).catch(() => {});
      } else if (!document.fullscreenElement) {
        // Thoát fullscreen (bấm nút thu nhỏ, bấm back, v.v.) - mở khoá xoay màn hình lại, trả
        // quyền xoay tự do về cho toàn app (không riêng gì lúc xem video).
        unlockOrientation();
      }
      // Vào/thoát fullscreen đổi hẳn kích thước #videoStage -> áp lại width/max-height khung
      // phụ đề theo đúng bộ cài đặt (thường/toàn màn hình) tương ứng. applyCaptionSettings()
      // sống ở <script type="module"> khác (dưới xa), không cùng scope với listener này (script
      // thường) - gọi qua window.__applyCaptionSettings đã expose (giống các window.__xxx khác
      // trong file, vd window.__addTranslationLogEntry).
      window.__applyCaptionSettings?.();
    });

    document.getElementById('translateBtn').onclick = async () => {
      const text = document.getElementById('srcText').value.trim();
      const targetLang = targetLangEl.value;
      const resultEl = document.getElementById('result');
      if (!text) {
        log('Chưa nhập văn bản.');
        return;
      }
      resultEl.textContent = 'Đang dịch...';
      try {
        const translated = await translateText(text, targetLang);
        lastTranslated = translated;
        resultEl.textContent = translated;
        addTranslationLogEntry(text, translated);
        log('Dịch xong (' + targetLang + ').');
      } catch (err) {
        resultEl.textContent = '';
        log('LỖI khi dịch: ' + err.message);
      }
    };

    // ===== Dịch file văn bản: cắt theo đoạn (dòng trống) để mỗi lần gọi API không quá dài
    // (endpoint Google Translate free giới hạn độ dài query), cắt cứng nếu 1 đoạn tự nó
    // đã dài hơn giới hạn. Dịch TUẦN TỰ qua queueTranslate - dùng chung hàng đợi với luồng
    // nghe live để không bắn 2 request Google Translate cùng lúc gây 429. =====
    const MAX_TRANSLATE_CHUNK_CHARS = 1800;

    function chunkTextForTranslate(text, maxLen) {
      const paragraphs = text.split(/\n\s*\n/);
      const chunks = [];
      let current = '';
      for (const p of paragraphs) {
        const candidate = current ? current + '\n\n' + p : p;
        if (candidate.length > maxLen && current) {
          chunks.push(current);
          current = p;
        } else {
          current = candidate;
        }
        while (current.length > maxLen) {
          chunks.push(current.slice(0, maxLen));
          current = current.slice(maxLen);
        }
      }
      if (current) chunks.push(current);
      return chunks;
    }

    let lastTranslatedFile = null; // { name, content } - giữ để nút "Tải file đã dịch" dùng

    document.getElementById('translateFileBtn').onclick = async () => {
      const fileInput = document.getElementById('srcFile');
      const statusEl = document.getElementById('fileTranslateStatus');
      const downloadBtn = document.getElementById('downloadTranslatedFileBtn');
      const resultEl = document.getElementById('result');
      const file = fileInput.files[0];
      if (!file) {
        log('Chưa chọn file để dịch.');
        return;
      }
      const targetLang = targetLangEl.value;
      downloadBtn.style.display = 'none';
      statusEl.textContent = 'Đang đọc file...';
      try {
        const content = await file.text();
        if (!content.trim()) {
          statusEl.textContent = 'File rỗng, không có gì để dịch.';
          return;
        }
        const chunks = chunkTextForTranslate(content, MAX_TRANSLATE_CHUNK_CHARS);
        const translatedChunks = [];
        for (let i = 0; i < chunks.length; i++) {
          statusEl.textContent = `Đang dịch phần ${i + 1}/${chunks.length}...`;
          const translated = await queueTranslate(() => translateText(chunks[i], targetLang));
          translatedChunks.push(translated);
        }
        const fullTranslated = translatedChunks.join('\n\n');
        lastTranslatedFile = { name: file.name, content: fullTranslated };

        resultEl.textContent = fullTranslated.length > 800
          ? fullTranslated.slice(0, 800) + '\n… (xem đầy đủ trong file tải về)'
          : fullTranslated;
        statusEl.textContent = `Đã dịch xong "${file.name}" (${chunks.length} phần).`;
        downloadBtn.style.display = 'inline-block';
        addTranslationLogEntry(
          '[File: ' + file.name + ']',
          'Đã dịch xong (' + chunks.length + ' phần) - bấm "Tải file đã dịch" để lưu.'
        );
        log('Dịch file "' + file.name + '" xong (' + chunks.length + ' phần).');
      } catch (err) {
        statusEl.textContent = '';
        log('LỖI khi dịch file: ' + err.message);
      }
    };

    document.getElementById('downloadTranslatedFileBtn').onclick = async () => {
      if (!lastTranslatedFile) return;
      const dotIndex = lastTranslatedFile.name.lastIndexOf('.');
      const base = dotIndex > 0 ? lastTranslatedFile.name.slice(0, dotIndex) : lastTranslatedFile.name;
      const ext = dotIndex > 0 ? lastTranslatedFile.name.slice(dotIndex) : '.txt';
      const fileName = base + '-dich' + ext;

      // BUG đã sửa: trước đây nút này luôn dùng <a download> + Blob URL, kể cả khi chạy trong
      // app native - nhưng chính app đã tự ghi chú ở ExportBridge.js là cách này "lưu vô hình"
      // trong Capacitor WebView (không rõ lưu vào đâu, không mở lại được). Các nút xuất khác
      // (exportSrtBtn/exportTxtBtn/exportVttBtn, xem exportTranslationLog() ở trên) đã tránh
      // đúng lỗi này bằng cách ưu tiên ExportPlugin native (Share Sheet) - giờ áp dụng lại đúng
      // pattern đó cho nút "Tải file đã dịch" để nhất quán và thực sự lưu được trên máy thật.
      if (window.__isExportAvailable?.()) {
        try {
          await window.__shareExportFile(lastTranslatedFile.content, fileName, 'text/plain');
          log('Đã xuất file đã dịch: ' + fileName);
        } catch (e) {
          log('Lỗi khi xuất file đã dịch: ' + e.message);
        }
        return;
      }
      // Fallback khi chạy ngoài app native (vd xem trước trên trình duyệt PC).
      const blob = new Blob([lastTranslatedFile.content], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      log('Plugin ExportPlugin chưa sẵn sàng (không chạy trong app native) - đã tải xuống theo cách trình duyệt thường: ' + fileName);
    };

    // Log ngay khi trang load để biết Capacitor có sẵn sàng từ đầu không
    window.addEventListener('load', () => {
      log('Trang đã load xong.');
      if (typeof Capacitor !== 'undefined') {
        log('Capacitor object OK. Plugins: ' + Object.keys(Capacitor.Plugins || {}).join(', '));
      } else {
        log('Capacitor CHƯA có ở thời điểm load - có thể app không chạy qua Capacitor WebView.');
      }
      refreshOnboarding();
      refreshModelList();
    });
