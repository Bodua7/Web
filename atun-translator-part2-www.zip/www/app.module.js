// www/app.module.js - JS module (import/export) tách ra từ khối <script type="module"> thứ 2
// trong index.html. Nạp qua <script type="module" src="app.module.js"></script>, cùng vị trí
// cũ trong <body> - import './src/services/...' vẫn đúng vì file này cũng nằm ở gốc www/ như
// index.html trước đây, base URL của import không đổi.
//
// Chỉ còn Cloud STT (Whisper qua groq-relay) + chuỗi dịch API (groq/gemini/deepl/azure/google
// free) - đã bỏ ML Kit translate on-device, TTS đọc to, "Web mini", export/chia sẻ log, "Dịch
// hội thoại 2 chiều" (captureMode='mixed').

    import { NativeCaptureBridge } from './src/services/audio/NativeCaptureBridge.js';

    // Dùng chung hàm log() đã giới hạn dòng khai báo ở script phía trên (window.__appLog),
    // tránh 2 logger độc lập cùng ghi đè lẫn nhau lên #log và tránh lặp lại bug phình bộ nhớ.
    const moduleLog = window.__appLog;

    // Khớp CHANNEL_MIC/CHANNEL_SYSTEM ở AudioCaptureService.kt (native) - chỉ có ý nghĩa khi
    // captureMode='mixed' (2 luồng song song), field data.channel undefined ở các mode đơn khác.
    const AUDIO_CHANNEL_MIC = 'mic';
    const AUDIO_CHANNEL_SYSTEM = 'system';

    const modelStatusEl = document.getElementById('modelStatus');
    const finalOriginalEl = document.getElementById('finalOriginal');
    const finalTranslatedEl = document.getElementById('finalTranslated');
    // Chỉ hiện/dùng khi captureMode='mixed' - khung riêng cho luồng mic (mình nói), xem
    // pushMicFinalToBatch/translateMicBatchAndDisplay bên dưới.
    const micFinalOriginalEl = document.getElementById('micFinalOriginal');
    const micFinalTranslatedEl = document.getElementById('micFinalTranslated');
    const micCaptionCardEl = document.getElementById('micCaptionCard');
    const inVideoCaptionEl = document.getElementById('inVideoCaption');
    const inVideoCaptionTextEl = document.getElementById('inVideoCaptionText');
    // Tự truy vấn lại #videoStage NGAY TRONG module script này, KHÔNG dùng biến videoStageEl
    // khai báo ở <script> thường phía trên - 2 khối <script> không cùng scope (module script có
    // scope riêng), const ở script kia không truy cập được từ đây. Cùng cách setupCaptionDrag()
    // bên dưới đã làm (tự document.getElementById('videoStage') riêng).
    const captionStageEl = document.getElementById('videoStage');
    const silenceWarningEl = document.getElementById('silenceWarning');
    const silenceSecondsEl = document.getElementById('silenceSeconds');
    const lostSessionWarningEl = document.getElementById('lostSessionWarning');
    // Phương án "nhận giọng ca sĩ khi hát" - xem onPossibleMusicDetected/onCloudSttSegment bên dưới.
    const musicDetectedWarningEl = document.getElementById('musicDetectedWarning');
    const keepTranslatingMusicBtnEl = document.getElementById('keepTranslatingMusicBtn');
    const mainToggleBtn = document.getElementById('mainToggleBtn');

    // ===== Tuỳ chỉnh phụ đề trong app: kéo-thả đổi vị trí, cỡ chữ, độ trong suốt nền - tất cả
    // lưu vào localStorage nên lần mở app sau giữ nguyên (thay cho tính năng tương tự vốn có
    // sẵn ở overlay hệ thống cũ, nay chuyển hẳn vào #inVideoCaption trong app). =====
    const CAPTION_SETTINGS_KEY = 'atun_caption_settings_v1';
    // widthPercent/heightPercent: khung phụ đề lúc video THƯỜNG (thu nhỏ trong trang).
    // widthPercentFs/heightPercentFs: khung phụ đề lúc video TOÀN MÀN HÌNH (phóng to) - tách
    // riêng vì tỉ lệ khung hình 2 chế độ khác hẳn nhau (xem ghi chú ở khối HTML slider phía
    // trên). height tính bằng % chiều cao #videoStage, quy đổi ra px thực qua
    // getBoundingClientRect() trong applyCaptionSettings() (không dùng % CSS trực tiếp vì
    // #videoStage không luôn có chiều cao "specified" hợp lệ cho phần trăm ở phần tử con
    // position:absolute lúc chưa fullscreen).
    const DEFAULT_CAPTION_SETTINGS = {
      fontSize: 'medium', opacity: 0.75, leftPercent: 50, bottomPercent: 4,
      widthPercent: 100, heightPercent: 30,
      widthPercentFs: 100, heightPercentFs: 22,
    };

    function loadCaptionSettings() {
      try {
        return { ...DEFAULT_CAPTION_SETTINGS, ...JSON.parse(localStorage.getItem(CAPTION_SETTINGS_KEY) || '{}') };
      } catch {
        return { ...DEFAULT_CAPTION_SETTINGS };
      }
    }
    function saveCaptionSettings() {
      localStorage.setItem(CAPTION_SETTINGS_KEY, JSON.stringify(captionSettings));
    }
    function clamp(v, min, max) {
      return Math.min(max, Math.max(min, v));
    }
    function fontPxFor(size) {
      return size === 'small' ? 13 : size === 'large' ? 20 : 16;
    }

    // ===== Auto co giãn cỡ chữ theo chiều cao khung đã đặt (Cao %) - cỡ chữ Nhỏ/Vừa/Lớn ở
    // trên là giá trị THẬT SỰ hiển thị, hàm này CHỈ có tác dụng bảo vệ chống tràn khung: nếu
    // khung quá THẤP so với cỡ chữ đã chọn (chữ bị tràn, scrollHeight > khung) thì tự thu nhỏ
    // dần tới khi vừa khung (hoặc chạm sàn MIN_CAPTION_FONT_PX).
    // ĐÃ BỎ vòng lặp "tự phóng to lấp khoảng trống thừa" từng có ở đây: với câu ngắn/khung còn
    // nhiều chỗ trống (rất thường gặp), vòng lặp đó luôn đẩy CẢ 3 cỡ Nhỏ/Vừa/Lớn tăng tới CÙNG
    // 1 ngưỡng "cỡ lớn nhất còn vừa khung" (ngưỡng này chỉ phụ thuộc chiều cao khung + nội dung
    // câu, không phụ thuộc cỡ gốc) -> cả 3 lựa chọn hội tụ về cùng 1 giá trị, nhìn giống hệt
    // nhau, khiến lựa chọn Nhỏ/Vừa/Lớn của user mất tác dụng. Giờ 3 cỡ luôn hiển thị đúng
    // 13/16/20px trừ khi câu dài thật sự tràn khung mới tự thu nhỏ.
    const MIN_CAPTION_FONT_PX = 10;
    function fitCaptionFontSize() {
      const maxH = parseFloat(inVideoCaptionEl.style.maxHeight);
      if (!maxH || !inVideoCaptionTextEl.textContent.trim()) return;
      const basePx = fontPxFor(captionSettings.fontSize);
      let px = basePx;
      inVideoCaptionTextEl.style.fontSize = px + 'px';
      let guard = 0;
      while (inVideoCaptionTextEl.scrollHeight > maxH && px > MIN_CAPTION_FONT_PX && guard < 40) {
        px -= 1;
        inVideoCaptionTextEl.style.fontSize = px + 'px';
        guard++;
      }
    }

    let captionSettings = loadCaptionSettings();

    // Đang toàn màn hình hay không - videoStage là phần tử được fullscreen (xem
    // enterVideoFullscreen()), không phải videoPlayerFrame/videoPlayerContainer.
    function isCaptionFullscreen() {
      return document.fullscreenElement === captionStageEl;
    }

    // forceFs: bình thường bỏ trống (undefined) - hàm tự phát hiện đang toàn màn hình thật hay
    // không (isCaptionFullscreen()). Truyền true/false để ÉP dùng bộ giá trị thường/toàn màn
    // hình bất kể trạng thái fullscreen thật - dùng cho preview lúc đang chỉnh thanh trượt ở
    // trang cài đặt (xem previewCaptionSize()), vì lúc đó không thể bật fullscreen thật được.
    function applyCaptionSettings(forceFs) {
      const fs = typeof forceFs === 'boolean' ? forceFs : isCaptionFullscreen();
      const widthPercent = fs ? captionSettings.widthPercentFs : captionSettings.widthPercent;
      const heightPercent = fs ? captionSettings.heightPercentFs : captionSettings.heightPercent;

      inVideoCaptionEl.style.background = 'rgba(0,0,0,' + captionSettings.opacity + ')';
      inVideoCaptionEl.style.left = captionSettings.leftPercent + '%';
      inVideoCaptionEl.style.bottom = captionSettings.bottomPercent + '%';
      inVideoCaptionEl.style.right = 'auto';
      inVideoCaptionEl.style.transform = 'translateX(-50%)';

      // ===== FIX bug "khung phụ đề ôm sát từng dòng" (khung hẹp hơn nhiều so với video): trước
      // đây set width bằng CSS % trực tiếp (style.width = widthPercent + '%'). Về lý thuyết %
      // của width trên phần tử position:absolute phải resolve theo chiều rộng #videoStage (là
      // containing block, vì #videoStage có position:relative) - nhưng #videoStage lại tự lấy
      // chiều rộng từ 1 phần tử con dùng width="100%" (iframe video), tạo ra 1 vòng phụ thuộc
      // chiều rộng (width phụ thuộc con, con lại phụ thuộc width) mà WebView Android xử lý không
      // nhất quán - có lúc resolve % theo containing block đúng như mong đợi, có lúc lại co khung
      // lại theo đúng bề ngang nội dung chữ bên trong (kết quả: khung phụ đề bị hẹp bất thường,
      // "ôm sát" 2-3 dòng chữ thay vì trải theo widthPercent đã đặt).
      // FIX tiếp (widthPercent=100 vẫn chưa sát mép màn hình thật): body có padding:16px 2 bên
      // (xem style.css) nên #videoStage KHÔNG BAO GIỜ rộng bằng màn hình thật - nếu quy đổi theo
      // stageRect.width (chiều rộng videoStage) thì widthPercent=100% chỉ rộng bằng (màn hình -
      // 32px), không sát mép. Quy đổi theo document.documentElement.clientWidth (chiều rộng THẬT
      // của màn hình) thay vì stageRect.width - vẫn giữ nguyên left:50%+translateX(-50%) tính
      // theo % của videoStage làm điểm neo canh giữa (tâm ngang videoStage trùng tâm ngang màn
      // hình vì padding body đối xứng 2 bên) nên khung tự tràn đều sang 2 bên khớp sát mép màn
      // hình. Chiều CAO vẫn giữ tính theo stageRect.height như cũ (không đổi sang viewport height,
      // vì video không cao hết màn hình lúc chế độ thường).
      const stageRect = captionStageEl.getBoundingClientRect();
      const viewportWidth = document.documentElement.clientWidth;
      if (viewportWidth > 0) {
        inVideoCaptionEl.style.width = Math.round(viewportWidth * widthPercent / 100) + 'px';
      } else if (stageRect.width > 0) {
        // Dự phòng cực hiếm (clientWidth không đọc được) - tạm quy đổi theo videoStage như bản cũ.
        inVideoCaptionEl.style.width = Math.round(stageRect.width * widthPercent / 100) + 'px';
      } else {
        // videoStage chưa có kích thước thật (chưa render/video chưa phát) - tạm dùng % làm giá
        // trị dự phòng; applyCaptionSettings() sẽ được gọi lại (vd. lúc có câu dịch đầu tiên tới,
        // xem flushFinalBatch()) và tính lại đúng bằng px lúc đó.
        inVideoCaptionEl.style.width = widthPercent + '%';
      }

      // Quy đổi heightPercent (% chiều cao videoStage) ra px thực - dùng getBoundingClientRect()
      // vì lúc chưa fullscreen #videoStage cao theo nội dung (iframe height=200), % CSS trực
      // tiếp trên phần tử con position:absolute không đảm bảo resolve đúng ở mọi trình duyệt.
      // Nếu videoStage chưa có kích thước thật (video chưa phát, rect.height=0) thì bỏ qua,
      // giữ nguyên max-height cũ - sẽ tự tính lại đúng ngay khi có câu dịch đầu tiên hiện ra
      // (xem chỗ gọi applyCaptionSettings() trong flushFinalBatch()).
      if (stageRect.height > 0) {
        inVideoCaptionEl.style.maxHeight = Math.round(stageRect.height * heightPercent / 100) + 'px';
      }

      // Đặt cỡ chữ NỀN (đúng lựa chọn Nhỏ/Vừa/Lớn) lên #inVideoCaptionText - fitCaptionFontSize()
      // bên dưới sẽ tự co giãn thêm quanh giá trị nền này cho khớp khung Cao % đã đặt (xem ghi
      // chú ở hàm đó) - gọi sau khi đã có maxHeight mới ở trên.
      inVideoCaptionTextEl.style.fontSize = fontPxFor(captionSettings.fontSize) + 'px';
      fitCaptionFontSize();
    }

    const captionFontSizeEl = document.getElementById('captionFontSize');
    const captionOpacityEl = document.getElementById('captionOpacity');
    const resetCaptionPosBtn = document.getElementById('resetCaptionPosBtn');
    const resetCaptionAllBtn = document.getElementById('resetCaptionAllBtn');
    const captionWidthNormalEl = document.getElementById('captionWidthNormal');
    const captionHeightNormalEl = document.getElementById('captionHeightNormal');
    const captionWidthFsEl = document.getElementById('captionWidthFs');
    const captionHeightFsEl = document.getElementById('captionHeightFs');
    const captionWidthNormalLabelEl = document.getElementById('captionWidthNormalLabel');
    const captionHeightNormalLabelEl = document.getElementById('captionHeightNormalLabel');
    const captionWidthFsLabelEl = document.getElementById('captionWidthFsLabel');
    const captionHeightFsLabelEl = document.getElementById('captionHeightFsLabel');
    captionFontSizeEl.value = captionSettings.fontSize;
    captionOpacityEl.value = captionSettings.opacity;
    captionWidthNormalEl.value = captionSettings.widthPercent;
    captionHeightNormalEl.value = captionSettings.heightPercent;
    captionWidthFsEl.value = captionSettings.widthPercentFs;
    captionHeightFsEl.value = captionSettings.heightPercentFs;
    captionWidthNormalLabelEl.textContent = captionSettings.widthPercent + '%';
    captionHeightNormalLabelEl.textContent = captionSettings.heightPercent + '%';
    captionWidthFsLabelEl.textContent = captionSettings.widthPercentFs + '%';
    captionHeightFsLabelEl.textContent = captionSettings.heightPercentFs + '%';

    // Áp toàn bộ cài đặt (kể cả icon/title nút thu nhỏ) lần đầu ngay khi mở trang.
    applyCaptionSettings();
    // Expose cho fullscreenchange ở <script> thường (không phải module) phía trên gọi được -
    // xem cùng cách window.__addTranslationLogEntry/window.__appLog đã dùng trong file.
    window.__applyCaptionSettings = applyCaptionSettings;

    // ===== Preview khung phụ đề lúc đang chỉnh Rộng/Cao - xem ghi chú dài ở khai báo hằng
    // CAPTION_PREVIEW_SAMPLE bên dưới. Đặt SAU applyCaptionSettings() lần đầu + SAU khi đã có
    // đủ các biến El phía trên vì hàm dùng chính các biến đó. =====
    const CAPTION_PREVIEW_SAMPLE = 'Đây là dòng phụ đề mẫu để xem trước kích thước khung';
    let captionPreviewHideTimer = null;
    // true khi #inVideoCaptionText đang hiện CHỮ MẪU (không phải câu dịch thật) - chỉ cho phép
    // tự xoá/ẩn lại khung khi cờ này còn true, tránh trường hợp trong lúc đang xem trước thì có
    // câu dịch thật vừa tới (flushFinalBatch ghi đè chữ mẫu bằng chữ thật) mà timer ẩn cũ vẫn
    // chạy - sẽ lỡ tay xoá mất câu dịch thật đang hiện. flushFinalBatch() tự tắt cờ này ngay khi
    // ghi chữ thật vào (xem chỗ gọi bên dưới, trong hàm đó).
    let captionPreviewUsingPlaceholder = false;
    function previewCaptionSize(forceFs) {
      const currentlyHidden = inVideoCaptionEl.style.display === 'none' || inVideoCaptionEl.style.display === '';
      if (currentlyHidden && !inVideoCaptionTextEl.textContent.trim()) {
        inVideoCaptionTextEl.textContent = CAPTION_PREVIEW_SAMPLE;
        captionPreviewUsingPlaceholder = true;
      }
      inVideoCaptionEl.style.display = 'block';
      applyCaptionSettings(forceFs);
      clearTimeout(captionPreviewHideTimer);
      captionPreviewHideTimer = setTimeout(() => {
        if (captionPreviewUsingPlaceholder) {
          inVideoCaptionTextEl.textContent = '';
          inVideoCaptionEl.style.display = 'none';
          captionPreviewUsingPlaceholder = false;
        }
      }, 1500);
    }
    window.__clearCaptionPreviewPlaceholder = () => {
      clearTimeout(captionPreviewHideTimer);
      captionPreviewUsingPlaceholder = false;
    };

    captionFontSizeEl.onchange = () => {
      captionSettings.fontSize = captionFontSizeEl.value;
      previewCaptionSize();
      saveCaptionSettings();
    };
    captionOpacityEl.oninput = () => {
      captionSettings.opacity = parseFloat(captionOpacityEl.value);
      applyCaptionSettings();
      saveCaptionSettings();
    };
    captionWidthNormalEl.oninput = () => {
      captionSettings.widthPercent = parseInt(captionWidthNormalEl.value, 10);
      captionWidthNormalLabelEl.textContent = captionSettings.widthPercent + '%';
      previewCaptionSize(false);
      saveCaptionSettings();
    };
    captionHeightNormalEl.oninput = () => {
      captionSettings.heightPercent = parseInt(captionHeightNormalEl.value, 10);
      captionHeightNormalLabelEl.textContent = captionSettings.heightPercent + '%';
      previewCaptionSize(false);
      saveCaptionSettings();
    };
    captionWidthFsEl.oninput = () => {
      captionSettings.widthPercentFs = parseInt(captionWidthFsEl.value, 10);
      captionWidthFsLabelEl.textContent = captionSettings.widthPercentFs + '%';
      previewCaptionSize(true);
      saveCaptionSettings();
    };
    captionHeightFsEl.oninput = () => {
      captionSettings.heightPercentFs = parseInt(captionHeightFsEl.value, 10);
      captionHeightFsLabelEl.textContent = captionSettings.heightPercentFs + '%';
      previewCaptionSize(true);
      saveCaptionSettings();
    };
    resetCaptionPosBtn.onclick = () => {
      captionSettings.leftPercent = DEFAULT_CAPTION_SETTINGS.leftPercent;
      captionSettings.bottomPercent = DEFAULT_CAPTION_SETTINGS.bottomPercent;
      previewCaptionSize();
      saveCaptionSettings();
    };
    // Nút "Đặt lại tất cả" - đặt lại vị trí + rộng + cao (CẢ 2 bộ thường/toàn màn hình) về mặc
    // định, đồng thời cập nhật lại luôn giá trị hiển thị trên 4 thanh trượt + nhãn % (nếu chỉ
    // đổi captionSettings mà không đổi input.value/label thì thanh trượt vẫn hiện vị trí CŨ dù
    // khung phụ đề thật đã đổi - gây lệch giữa UI và giá trị thật).
    resetCaptionAllBtn.onclick = () => {
      captionSettings.leftPercent = DEFAULT_CAPTION_SETTINGS.leftPercent;
      captionSettings.bottomPercent = DEFAULT_CAPTION_SETTINGS.bottomPercent;
      captionSettings.widthPercent = DEFAULT_CAPTION_SETTINGS.widthPercent;
      captionSettings.heightPercent = DEFAULT_CAPTION_SETTINGS.heightPercent;
      captionSettings.widthPercentFs = DEFAULT_CAPTION_SETTINGS.widthPercentFs;
      captionSettings.heightPercentFs = DEFAULT_CAPTION_SETTINGS.heightPercentFs;
      captionWidthNormalEl.value = captionSettings.widthPercent;
      captionHeightNormalEl.value = captionSettings.heightPercent;
      captionWidthFsEl.value = captionSettings.widthPercentFs;
      captionHeightFsEl.value = captionSettings.heightPercentFs;
      captionWidthNormalLabelEl.textContent = captionSettings.widthPercent + '%';
      captionHeightNormalLabelEl.textContent = captionSettings.heightPercent + '%';
      captionWidthFsLabelEl.textContent = captionSettings.widthPercentFs + '%';
      captionHeightFsLabelEl.textContent = captionSettings.heightPercentFs + '%';
      previewCaptionSize();
      saveCaptionSettings();
    };

    // ===== Preset cỡ nhanh (Gọn/Vừa/Rộng) - đọc data-preset-* trực tiếp từ nút bấm thay vì
    // hard-code 6 handler riêng (2 mode x 3 preset), gọn hơn và dễ thêm preset mới sau này chỉ
    // bằng cách thêm nút HTML, không cần sửa JS. mode 'normal' set widthPercent/heightPercent,
    // mode 'fs' set widthPercentFs/heightPercentFs - KHÔNG đụng tới bộ còn lại (giữ đúng 2 bộ
    // giá trị tách biệt như thiết kế cũ, xem ghi chú ở DEFAULT_CAPTION_SETTINGS).
    document.querySelectorAll('.caption-preset-btn').forEach((btn) => {
      btn.onclick = () => {
        const mode = btn.dataset.presetMode; // 'normal' | 'fs'
        const width = parseInt(btn.dataset.presetWidth, 10);
        const height = parseInt(btn.dataset.presetHeight, 10);
        if (mode === 'fs') {
          captionSettings.widthPercentFs = width;
          captionSettings.heightPercentFs = height;
          captionWidthFsEl.value = width;
          captionHeightFsEl.value = height;
          captionWidthFsLabelEl.textContent = width + '%';
          captionHeightFsLabelEl.textContent = height + '%';
          previewCaptionSize(true);
        } else {
          captionSettings.widthPercent = width;
          captionSettings.heightPercent = height;
          captionWidthNormalEl.value = width;
          captionHeightNormalEl.value = height;
          captionWidthNormalLabelEl.textContent = width + '%';
          captionHeightNormalLabelEl.textContent = height + '%';
          previewCaptionSize(false);
        }
        saveCaptionSettings();
      };
    });

    // ===== BUG đã sửa: enterVideoFullscreen() gọi requestFullscreen() RỒI MỚI lockLandscape()
    // (khoá xoay ngang qua plugin native) ở bước SAU - fullscreenchange bắn ra NGAY khi
    // requestFullscreen() resolve, tức là TRƯỚC KHI màn hình thật sự xoay ngang xong. Lúc đó
    // window.__applyCaptionSettings() (gọi từ fullscreenchange ở <script> thường phía trên) đã
    // tính max-height/width theo kích thước #videoStage CŨ (trước khi xoay), sai lệch cho tới
    // khi có tác động nào khác kích hoạt tính lại. Bắt thêm 'resize'/'orientationchange' ở đây
    // để tự tính lại đúng ngay khi kích thước thật đổi (bất kể do xoay màn hình lúc vào
    // fullscreen, xoay tay lúc đang xem, hay các thay đổi layout khác) - chỉ tính lại khi
    // caption đang hiển thị, tránh việc thừa lúc chưa phát video. debounce nhẹ (60ms) vì
    // 'resize' có thể bắn liên tục nhiều lần trong lúc xoay. =====
    let captionResizeTimer = null;
    function scheduleReapplyCaptionSettings() {
      if (inVideoCaptionEl.style.display === 'none') return;
      clearTimeout(captionResizeTimer);
      captionResizeTimer = setTimeout(applyCaptionSettings, 60);
    }
    window.addEventListener('resize', scheduleReapplyCaptionSettings);
    window.addEventListener('orientationchange', scheduleReapplyCaptionSettings);

    // Kéo-thả (1 ngón) + pinch-to-resize (2 ngón) bằng Pointer Events (gộp chung mouse + touch).
    // Giới hạn (clamp) vị trí trong khoảng an toàn để không kéo phụ đề ra ngoài khung video/
    // mất hẳn khỏi tầm nhìn - có nút "Đặt lại vị trí" ở trên phòng khi vẫn bị lệch khó tìm.
    (function setupCaptionDragAndPinch() {
      const videoContainerEl = document.getElementById('videoStage');
      // Map pointerId -> {x, y} - theo dõi TẤT CẢ ngón đang chạm trên #inVideoCaption cùng lúc,
      // để phân biệt 1 ngón (kéo-thả vị trí) vs 2 ngón (pinch đổi Rộng/Cao). Pointer Events báo
      // riêng từng ngón qua pointerId, không gộp sẵn như TouchEvent.touches - phải tự quản lý.
      const activePointers = new Map();

      let dragging = false;
      let startClientX = 0, startClientY = 0;
      let startLeftPercent = 0, startBottomPercent = 0;

      // Pinch dùng lại ĐÚNG các thanh trượt/preset Rộng-Cao đã có (captionWidthNormal(Fs)/
      // captionHeightNormal(Fs)) - áp vào đúng bộ giá trị "thường" hay "toàn màn hình" tuỳ
      // isCaptionFullscreen() lúc bắt đầu chụm (không đổi bộ giữa chừng nếu lỡ xoay màn hình
      // trong lúc đang pinch, tránh giật/nhảy giá trị).
      let pinching = false;
      let pinchFsMode = false;
      let pinchStartDist = 0;
      let pinchStartWidthPercent = 0;
      let pinchStartHeightPercent = 0;

      function pointerDistance() {
        const pts = [...activePointers.values()];
        if (pts.length < 2) return 0;
        const dx = pts[0].x - pts[1].x;
        const dy = pts[0].y - pts[1].y;
        return Math.sqrt(dx * dx + dy * dy);
      }

      // Đồng bộ thanh trượt + nhãn % theo captionSettings hiện tại, đúng bộ đang pinch (không
      // phải bộ theo trạng thái fullscreen THẬT lúc gọi hàm, vì lúc đang pinch có thể tạm khác -
      // xem pinchFsMode ở trên) - để UI trang cài đặt luôn khớp với khung phụ đề thật.
      function syncSliderUi(fsMode) {
        if (fsMode) {
          captionWidthFsEl.value = captionSettings.widthPercentFs;
          captionHeightFsEl.value = captionSettings.heightPercentFs;
          captionWidthFsLabelEl.textContent = captionSettings.widthPercentFs + '%';
          captionHeightFsLabelEl.textContent = captionSettings.heightPercentFs + '%';
        } else {
          captionWidthNormalEl.value = captionSettings.widthPercent;
          captionHeightNormalEl.value = captionSettings.heightPercent;
          captionWidthNormalLabelEl.textContent = captionSettings.widthPercent + '%';
          captionHeightNormalLabelEl.textContent = captionSettings.heightPercent + '%';
        }
      }

      inVideoCaptionEl.addEventListener('pointerdown', (e) => {
        try { inVideoCaptionEl.setPointerCapture(e.pointerId); } catch {}
        activePointers.set(e.pointerId, { x: e.clientX, y: e.clientY });

        if (activePointers.size === 2) {
          // Ngón thứ 2 vừa chạm xuống trong lúc đang kéo bằng ngón đầu -> huỷ kéo-thả, chuyển
          // hẳn sang pinch-resize (không làm cả 2 cùng lúc, dễ loạn giá trị).
          dragging = false;
          pinching = true;
          pinchFsMode = isCaptionFullscreen();
          pinchStartDist = pointerDistance();
          pinchStartWidthPercent = pinchFsMode ? captionSettings.widthPercentFs : captionSettings.widthPercent;
          pinchStartHeightPercent = pinchFsMode ? captionSettings.heightPercentFs : captionSettings.heightPercent;
        } else if (activePointers.size === 1 && !pinching) {
          dragging = true;
          inVideoCaptionEl.style.cursor = 'grabbing';
          startClientX = e.clientX;
          startClientY = e.clientY;
          startLeftPercent = captionSettings.leftPercent;
          startBottomPercent = captionSettings.bottomPercent;
        }
      });

      inVideoCaptionEl.addEventListener('pointermove', (e) => {
        if (!activePointers.has(e.pointerId)) return;
        activePointers.set(e.pointerId, { x: e.clientX, y: e.clientY });

        if (pinching && activePointers.size === 2) {
          if (pinchStartDist <= 0) return;
          const scale = pointerDistance() / pinchStartDist;
          const wKey = pinchFsMode ? 'widthPercentFs' : 'widthPercent';
          const hKey = pinchFsMode ? 'heightPercentFs' : 'heightPercent';
          // Giới hạn theo ĐÚNG min/max của 2 thanh trượt Rộng/Cao hiện có (30-100 / 10-60) -
          // pinch chỉ là cách nhập nhanh hơn cho cùng 1 khoảng giá trị, không mở rộng thêm.
          captionSettings[wKey] = Math.round(clamp(pinchStartWidthPercent * scale, 30, 100));
          captionSettings[hKey] = Math.round(clamp(pinchStartHeightPercent * scale, 10, 60));
          syncSliderUi(pinchFsMode);
          applyCaptionSettings(pinchFsMode);
          return;
        }

        if (dragging && activePointers.size === 1) {
          const rect = videoContainerEl.getBoundingClientRect();
          if (rect.width === 0 || rect.height === 0) return;
          const dxPercent = ((e.clientX - startClientX) / rect.width) * 100;
          // gravity bottom: kéo LÊN (dy âm, vì toạ độ màn hình tăng dần xuống) phải TĂNG bottomPercent.
          const dyPercent = ((e.clientY - startClientY) / rect.height) * 100;
          captionSettings.leftPercent = clamp(startLeftPercent + dxPercent, 10, 90);
          captionSettings.bottomPercent = clamp(startBottomPercent - dyPercent, 2, 88);
          applyCaptionSettings();
        }
      });

      const endPointer = (e) => {
        activePointers.delete(e.pointerId);
        if (pinching && activePointers.size < 2) {
          pinching = false;
          saveCaptionSettings();
        }
        if (dragging && activePointers.size === 0) {
          dragging = false;
          inVideoCaptionEl.style.cursor = 'grab';
          saveCaptionSettings();
        }
      };
      inVideoCaptionEl.addEventListener('pointerup', endPointer);
      inVideoCaptionEl.addEventListener('pointercancel', endPointer);
    })();


    // ===== Dịch theo CỤM câu thay vì từng câu final lẻ =====
    // Native chốt câu ("cloudSttSegment", VAD cắt theo pause) khá dày khi người nói liên tục -
    // dịch ngay từng câu vừa tốn nhiều request (dễ 429 với endpoint free, tốn quota với groq)
    // vừa mất ngữ cảnh giữa các câu liền kề (câu sau có thể phụ thuộc ý câu trước). Thay vào đó:
    // gom các câu final đến gần nhau thành 1 cụm, dịch 1 lần bằng 1 request rồi tách kết quả trở
    // lại theo dòng để log + hiển thị (quy tắc "gần nhau" cụ thể ra sao - xem khối comment ngay
    // dưới đây).
    // ===== Phương án "ngắt câu thông minh theo câu nói" (thay cho cửa sổ cố định cũ) =====
    // TRƯỚC ĐÂY FINAL_BATCH_WINDOW_MS=700 là 1 cửa sổ CỐ ĐỊNH tính từ lúc phần tử ĐẦU TIÊN vào
    // buffer. Vấn đề: cửa sổ này đo thời điểm TEXT về (SAU round-trip mạng gọi Whisper), không
    // phải thời điểm audio thực sự được nói ra - độ trễ mạng (0.5-2s+, dao động theo tải) khiến
    // 2 mảnh của CÙNG 1 câu rất hay bị rớt ra ngoài cửa sổ 700ms, dịch tách rời mất ngữ cảnh.
    // Đổi sang 2 quy tắc:
    //   1) Nếu đoạn Whisper vừa về KẾT THÚC bằng dấu câu kết câu (xem isSentenceEnd()) -> coi là
    //      ĐÃ CHẮC CHẮN xong 1 câu trọn vẹn -> chốt+dịch NGAY, không chờ debounce.
    //   2) Ngược lại (câu dang dở, hoặc Whisper không chấm câu được cho ngôn ngữ đó) -> debounce
    //      THẬT (mỗi phần tử mới vào tự RESET lại đồng hồ đếm, khác hành vi cũ chỉ đặt timer 1
    //      lần duy nhất), cộng thêm 1 trần thời gian tuyệt đối FINAL_BATCH_MAX_WAIT_MS tính từ
    //      phần tử ĐẦU TIÊN của cụm - để không đợi vô hạn nếu người nói liên tục không dừng hẳn.
    // Rủi ro chấp nhận: Whisper có thể chấm câu SAI CHỖ (đoán nhầm ngữ điệu) -> chốt sớm nhầm;
    // hệ quả tệ nhất giống hệt hành vi CŨ (dịch tách câu ra) - không tệ hơn baseline, nên chấp
    // nhận đánh đổi này thay vì giữ nguyên cửa sổ cố định vốn đã biết là không ăn khớp thực tế.
    //
    // Fix (tự phát hiện lúc audit lại - 2 vấn đề của bản đầu tiên):
    // (1) TRƯỚC ĐÂY isSentenceEnd()=true thì flush NGAY LẬP TỨC, không chờ gì cả - với hội thoại
    //     kiểu nhiều câu ngắn liên tiếp ("Yes." "No." "Maybe.") mỗi câu bắn 1 request dịch RIÊNG,
    //     ngược lại đúng mục tiêu gộp batch ban đầu (tránh 429). Giờ đổi sang: câu kết thúc rõ
    //     ràng vẫn chỉ chờ 1 khoảng NGẮN (SENTENCE_END_GRACE_MS) chứ không chờ 0 - đủ thời gian
    //     để 1 câu ngắn khác nói RẤT NHANH ngay sau đó vẫn kịp gộp chung, mà vẫn nhanh hơn hẳn
    //     debounce đầy đủ 700ms cho câu đứng 1 mình.
    // (2) isSentenceEnd() cũ không phân biệt được dấu "." kết câu với dấu "." của SỐ THẬP PHÂN bị
    //     cắt ngang do VAD cắt đúng lúc đó (vd audio segment kết thúc ở "...còn 98." trong khi
    //     câu thật là "...còn 98.6 độ") - chốt+dịch sớm nhầm còn TỆ HƠN hành vi cũ (trước đây ít
    //     nhất còn 700ms để có cơ hội gộp lại với phần còn thiếu). Thêm điều kiện loại trừ. Vẫn
    //     KHÔNG xử lý viết tắt kiểu "Mr." "e.g." - danh sách viết tắt khác nhau hoàn toàn giữa
    //     ~29 ngôn ngữ app hỗ trợ, làm nửa vời (chỉ bắt được tiếng Anh) dễ tạo ảo giác "đã xử lý"
    //     hơn là thực sự an toàn - để nguyên rủi ro này y như baseline cũ, không giả vờ khắc phục.
    const FINAL_BATCH_DEBOUNCE_MS = 700; // (tên cũ: FINAL_BATCH_WINDOW_MS - đổi tên cho đúng ý nghĩa mới: debounce, không phải cửa sổ cố định)
    const FINAL_BATCH_MAX_WAIT_MS = 2500;
    const SENTENCE_END_GRACE_MS = 300;
    // Dấu câu kết câu: Latin (.!?) + full-width CJK (。！？) - Whisper vẫn chấm câu kiểu full-width
    // cho tiếng Nhật/Trung dù transcript có lẫn ký tự Latin khác. KHÔNG coi "..."/"…" (bỏ lửng,
    // chưa xong ý) là kết câu dù ký tự cuối cùng cũng khớp "." - phải loại trừ RIÊNG, kiểm tra
    // TRƯỚC khi so regex.
    const SENTENCE_END_RE = /[.!?。！？]\s*$/;
    // "<chữ số>." ở cuối - rất có thể là số thập phân/số thứ tự bị VAD cắt ngang giữa chừng (vd
    // "98." trong "98.6 độ", "3." trong "3.5 triệu đồng") chứ không phải kết câu thật - coi như
    // câu dang dở (rơi vào nhánh debounce đầy đủ) AN TOÀN HƠN kết luận nhầm là đã xong câu. CHỈ
    // áp dụng cho "." (không phải "!"/"?" - số thập phân không bao giờ kết thúc bằng 2 dấu đó).
    const DIGIT_BEFORE_DOT_RE = /\d\.\s*$/;
    // "<từ ngắn ≤3 ký tự, viết HOA, có từ khác đứng TRƯỚC nó>." ở cuối - CÓ THỂ là viết tắt bị
    // hiểu nhầm là hết câu (vd "Please welcome Mr." "We visited St.") - coi như câu dang dở
    // (nhánh debounce đầy đủ) AN TOÀN HƠN kết luận nhầm, cùng tinh thần với DIGIT_BEFORE_DOT_RE
    // ở trên. Dùng "≤3 ký tự" thay vì liệt kê từng từ vì app hỗ trợ ~29 ngôn ngữ - liệt kê cứng
    // chỉ bắt được 1 ngôn ngữ, tạo ảo giác đã xử lý hơn là thực sự xử lý. CHỈ áp dụng cho dấu "."
    // kiểu Latin (không áp dụng cho "。" CJK - tiếng Trung/Nhật viết liền không có khoảng trắng
    // giữa từ nên không có kiểu viết tắt "chữ ngắn + chấm" tương tự).
    //
    // 2 điều kiện PHỤ bắt buộc phải có, cả 2 đều lộ ra khi tự viết test bảng chân trị
    // (isSentenceEnd() phía dưới) chứ không thấy được nếu chỉ đọc code:
    // (1) "viết HOA": nếu bỏ điều kiện này, câu tiếng Việt/Anh BÌNH THƯỜNG kết bằng 1 từ ngắn
    //     viết THƯỜNG (rất phổ biến trong tiếng Việt - đa số từ đơn âm tiết ≤3-4 ký tự, vd "đẹp"
    //     "tốt" "xa") bị loại NHẦM hàng loạt - phát hiện bằng case "Con mèo này rất đẹp.".
    // (2) "có từ khác đứng TRƯỚC": nếu chỉ có (1) mà thiếu điều kiện này, câu tiếng Việt CHỈ CÓ
    //     1 TỪ (rất phổ biến: "Ừ." "Rồi." "Vâng." "Không.") cũng bị loại nhầm - vì tiếng Việt
    //     viết hoa chữ ĐẦU CÂU theo đúng chính tả, với câu 1 từ thì chữ đó vừa là "đầu câu" vừa
    //     là "từ ngay trước dấu chấm", không thể phân biệt với viết tắt thật chỉ bằng viết hoa -
    //     phát hiện bằng case "Ừ.". Viết tắt thật hầu như luôn có từ khác đứng trước trong cùng
    //     câu (vd "Please welcome Mr."); câu 1 từ thì không có gì đứng trước.
    //
    // Đánh đổi CÒN LẠI (chấp nhận, đã cân nhắc và thấy hiếm hơn hẳn 2 vấn đề trên): bỏ sót viết
    // tắt viết THƯỜNG ("vs." "etc." nếu lỡ không viết hoa) và loại nhầm 1 số câu kết bằng danh từ
    // riêng/từ viết hoa ngắn thật sự hết ý, có từ khác đứng trước (vd "Tôi thích Bi.") - cả 2 hệ
    // quả đều chỉ là chờ thêm debounce, không sai nghĩa.
    const SHORT_WORD_BEFORE_DOT_RE = /\S\s\p{Lu}\p{L}{0,2}\.\s*$/u;
    function isSentenceEnd(text) {
      const trimmed = (text || '').trim();
      if (!trimmed || trimmed.endsWith('...') || trimmed.endsWith('…')) return false;
      if (DIGIT_BEFORE_DOT_RE.test(trimmed)) return false;
      if (trimmed.endsWith('.') && SHORT_WORD_BEFORE_DOT_RE.test(trimmed)) return false;
      return SENTENCE_END_RE.test(trimmed);
    }

    let finalBatchBuffer = [];
    let finalBatchTimer = null;
    // Mốc thời gian phần tử ĐẦU TIÊN của cụm hiện tại vào buffer - dùng để tính trần
    // FINAL_BATCH_MAX_WAIT_MS, KHÔNG đổi mỗi lần debounce reset (khác finalBatchTimer, vốn bị
    // huỷ/đặt lại liên tục mỗi phần tử mới).
    let finalBatchStartAt = 0;

    function pushFinalToBatch(text, detectedLang) {
      // detectedLang: chỉ có giá trị khi sourceLang == 'auto' (Whisper tự nhận diện, xem
      // onCloudSttSegment bên dưới) - lưu kèm từng câu (không chỉ dùng 1 giá trị chung cho cả
      // batch) vì người nói có thể đổi ngôn ngữ ngay giữa 1 cụm ngắn - xem flushFinalBatch().
      const now = Date.now();
      if (finalBatchBuffer.length === 0) finalBatchStartAt = now;
      finalBatchBuffer.push({ text, lang: detectedLang || null });

      if (finalBatchTimer) clearTimeout(finalBatchTimer);
      // Câu vừa vào kết thúc rõ ràng -> chỉ cần đợi 1 khoảng NGẮN (đủ để gộp thêm 1 câu ngắn
      // khác tới rất nhanh sau đó); câu dang dở -> debounce đầy đủ như trước. Cả 2 đều kẹp trong
      // trần MAX_WAIT tính từ đầu cụm (Math.max 0 để không đặt setTimeout số âm nếu đã trễ hơn
      // cả trần - chốt gần như ngay lập tức trong trường hợp đó).
      const baseDelay = isSentenceEnd(text) ? SENTENCE_END_GRACE_MS : FINAL_BATCH_DEBOUNCE_MS;
      const delay = Math.min(baseDelay, Math.max(0, FINAL_BATCH_MAX_WAIT_MS - (now - finalBatchStartAt)));
      finalBatchTimer = setTimeout(flushFinalBatch, delay);
    }
    // API cho hàng đợi thử lại trong app.js gọi lại khi 1 đoạn STT lỗi được nhận dạng thành công
    // ở lần thử lại (xem retryOneItem) - đẩy vào ĐÚNG batch pipeline như luồng trực tiếp, không
    // đi tắt qua chỗ khác.
    window.__pushFinalToBatch = pushFinalToBatch;

    // Tách riêng phần "dịch cụm + hiện caption + ghi log" ra khỏi flushFinalBatch() để hàng đợi
    // thử lại (app.js - retryOneItem) gọi lại được ĐÚNG logic này khi retry, thay vì viết lại 1
    // bản khác dễ lệch hành vi theo thời gian. Ném lỗi ra NGOÀI (không tự catch ở đây) - để cả
    // đường gọi "lần đầu" (flushFinalBatch) lẫn đường gọi "thử lại" (app.js) tự quyết định làm gì
    // khi lỗi (lần đầu: xếp vào hàng đợi; thử lại: tăng attempts, thử tiếp sau).
    async function translateBatchAndDisplay(texts, effectiveSourceLang) {
      const joined = texts.join('\n');
      // Nếu nguồn đã là tiếng Việt thì không cần dịch nữa.
      const translated = effectiveSourceLang === 'vi' ? joined : await window.__translateText(joined, 'vi', effectiveSourceLang);
      const translatedLines = translated.split('\n');

      // Caption hiện tại luôn là câu MỚI NHẤT trong cụm vừa dịch - CHỈ dùng
      // translatedLines[cuối] khi số dòng khớp batch.length (endpoint dịch có giữ \n
      // đúng). Nếu KHÔNG khớp (Google Translate free/groq gộp cả cụm nhiều câu lại thành 1
      // đoạn liền, không giữ xuống dòng - hay gặp với câu ngắn/ASR rời rạc) thì
      // translatedLines chỉ có 1 phần tử là NGUYÊN CỤM DÀI - tuyệt đối không lấy phần tử đó
      // làm caption (gây caption phình to che gần hết video). Dịch RIÊNG câu cuối cùng (1
      // lệnh dịch nhỏ, phụ) chỉ để có caption đúng kích thước 1 câu.
      let lastTranslated;
      if (translatedLines.length === texts.length) {
        lastTranslated = translatedLines[translatedLines.length - 1];
      } else {
        const lastOriginal = texts[texts.length - 1];
        try {
          lastTranslated = effectiveSourceLang === 'vi' ? lastOriginal : await window.__translateText(lastOriginal, 'vi', effectiveSourceLang);
        } catch {
          lastTranslated = lastOriginal; // dịch riêng cũng lỗi - hiện tạm câu gốc còn hơn hiện nguyên cụm dài
        }
      }
      finalTranslatedEl.textContent = lastTranslated;
      window.__speakTranslated?.(lastTranslated, 'vi');
      // Câu dịch THẬT vừa tới - nếu đúng lúc này khung đang hiện chữ mẫu do người dùng vừa
      // chỉnh thanh trượt Rộng/Cao (xem previewCaptionSize()), phải huỷ ngay cờ + timer ẩn
      // tạm đó - nếu không, timer cũ (đặt để tự xoá CHỮ MẪU sau 1.5s) sẽ chạy tới và xoá
      // luôn câu dịch thật này.
      window.__clearCaptionPreviewPlaceholder?.();
      inVideoCaptionTextEl.textContent = lastTranslated;
      inVideoCaptionEl.style.display = 'block';
      // Lần hiện đầu tiên (video vừa phát xong, trước đó #videoStage display:none nên
      // getBoundingClientRect() trong applyCaptionSettings() trả về height=0, bỏ qua bước
      // set max-height) - gọi lại đây để tính đúng max-height thật ngay khi có kích thước.
      applyCaptionSettings();

      // Log từng cặp gốc/dịch theo dòng khi số dòng dịch về khớp số câu gốc gửi đi; nếu
      // dịch máy gộp/tách dòng khác đi (số dòng lệch), log nguyên cụm gộp để không ghép
      // sai cặp gốc/dịch.
      if (translatedLines.length === texts.length) {
        texts.forEach((orig, i) => window.__addTranslationLogEntry?.(orig, translatedLines[i]));
      } else {
        window.__addTranslationLogEntry?.(texts.join(' / '), translated);
      }
    }
    // API cho hàng đợi thử lại trong app.js gọi lại (xem retryOneItem) - cùng convention
    // window.__ đã dùng cho các hook khác giữa 2 file.
    window.__retryTranslateBatch = translateBatchAndDisplay;

    function flushFinalBatch() {
      finalBatchTimer = null;
      finalBatchStartAt = 0;
      if (finalBatchBuffer.length === 0) return;
      const batch = finalBatchBuffer;
      finalBatchBuffer = [];
      const texts = batch.map((b) => b.text);
      // Ở chế độ "auto" (sourceLangEl.value === 'auto'), MỖI câu có thể được Whisper gắn 1
      // detectedLang KHÁC NHAU (người nói đổi ngôn ngữ giữa chừng) - chỉ coi cả cụm là 1
      // ngôn ngữ khi TẤT CẢ câu trong cụm cùng chung 1 detectedLang; nếu cụm lẫn nhiều ngôn
      // ngữ (hoặc chưa xác định được câu nào) thì để null - translateText() (Groq/Gemini/
      // DeepL/Azure/Google Translate free) đều tự nhận diện ngôn ngữ nguồn theo nội dung
      // văn bản trong trường hợp đó.
      const effectiveSourceLang = sourceLangEl.value === 'auto'
        ? (batch.every((b) => b.lang && b.lang === batch[0].lang) ? batch[0].lang : null)
        : sourceLangEl.value;

      // Xếp vào hàng đợi tuần tự (giống trước đây): nếu 2 batch liền kề vẫn dồn lại thì
      // chạy lần lượt, không cùng lúc, tránh bắn dồn request gây 429. Dùng CHUNG hàng đợi với
      // app.js (bắc cầu qua window.__queueTranslate) - không phải hàng đợi riêng - nếu không 2
      // hàng đợi độc lập vẫn có thể cùng bắn request lúc app.js VÀ app.module.js đều đang dịch.
      window.__queueTranslate(async () => {
        try {
          await translateBatchAndDisplay(texts, effectiveSourceLang);
        } catch (err) {
          // Fix (audit đợt 2 - "retry khi mất mạng"): trước đây lỗi ở bước này làm MẤT TRẮNG
          // luôn cụm câu đã nhận dạng được (chỉ log ra console debug) - giờ xếp vào hàng đợi thử
          // lại (app.js) thay vì bỏ hẳn. Lưu kèm effectiveSourceLang đã tính SẴN ở trên (không
          // tính lại lúc retry) vì lúc đó "batch"/sourceLangEl.value hiện tại có thể đã khác.
          moduleLog('LỖI khi dịch - đã xếp vào hàng đợi thử lại: ' + err.message);
          window.__enqueueFailedTranslateBatch?.(texts, effectiveSourceLang, AUDIO_CHANNEL_SYSTEM);
        }
      });
    }

    // ===== MODE_MIXED - luồng MIC (mình nói tiếng Việt) - pipeline dịch RIÊNG, hướng ngược lại
    // luồng system ở trên (vi -> otherPartyLang thay vì otherPartyLang -> vi). Dùng chung
    // FINAL_BATCH_DEBOUNCE_MS/FINAL_BATCH_MAX_WAIT_MS/isSentenceEnd/queueTranslate/translateText/cache - chỉ khác buffer/timer/khung
    // hiển thị. otherPartyLang lấy TRỰC TIẾP từ sourceLangEl.value lúc flush (y hệt cách
    // effectiveSourceLang đọc live ở luồng system, KHÔNG chốt cứng lúc bắt đầu nghe) - xem
    // startCaptureFlow() bên dưới: đã chặn không cho chọn 'auto' khi ở MODE_MIXED vì không có
    // ngôn ngữ đối phương cụ thể nào để dịch luồng mic tới. =====
    let micBatchBuffer = [];
    let micBatchTimer = null;
    // Đối xứng với finalBatchStartAt bên buffer hệ thống ở trên - xem comment "Phương án ngắt
    // câu thông minh" tại đó, áp dụng y hệt ở đây.
    let micBatchStartAt = 0;

    function pushMicFinalToBatch(text) {
      const now = Date.now();
      if (micBatchBuffer.length === 0) micBatchStartAt = now;
      micBatchBuffer.push(text);

      if (micBatchTimer) clearTimeout(micBatchTimer);
      // Xem comment đầy đủ ở pushFinalToBatch() (buffer hệ thống) - áp dụng y hệt ở đây.
      const baseDelay = isSentenceEnd(text) ? SENTENCE_END_GRACE_MS : FINAL_BATCH_DEBOUNCE_MS;
      const delay = Math.min(baseDelay, Math.max(0, FINAL_BATCH_MAX_WAIT_MS - (now - micBatchStartAt)));
      micBatchTimer = setTimeout(flushMicFinalBatch, delay);
    }
    window.__pushMicFinalToBatch = pushMicFinalToBatch;

    async function translateMicBatchAndDisplay(texts) {
      const otherPartyLang = sourceLangEl.value;
      const joined = texts.join('\n');
      // Cùng kiểu bảo vệ như translateBatchAndDisplay() ở trên - tránh gọi dịch vô nghĩa nếu
      // otherPartyLang lỡ để 'vi' (hiếm, nhưng UI không cấm chọn 'vi' cho luồng đối phương).
      const translated = otherPartyLang === 'vi' ? joined : await window.__translateText(joined, otherPartyLang, 'vi');
      const translatedLines = translated.split('\n');
      const lastOriginal = texts[texts.length - 1];
      const lastTranslated = translatedLines.length === texts.length
        ? translatedLines[translatedLines.length - 1]
        : translated; // gộp/tách dòng lệch - hiện tạm nguyên cụm còn hơn hiện sai câu
      if (micFinalOriginalEl) micFinalOriginalEl.textContent = lastOriginal;
      if (micFinalTranslatedEl) micFinalTranslatedEl.textContent = lastTranslated;
      window.__speakTranslated?.(lastTranslated, 'vi');
      window.__addTranslationLogEntry?.('🎤 ' + texts.join(' / '), translated);
    }
    window.__retryMicTranslateBatch = translateMicBatchAndDisplay;

    function flushMicFinalBatch() {
      micBatchTimer = null;
      micBatchStartAt = 0;
      if (micBatchBuffer.length === 0) return;
      const texts = micBatchBuffer;
      micBatchBuffer = [];
      window.__queueTranslate(async () => {
        try {
          await translateMicBatchAndDisplay(texts);
        } catch (err) {
          moduleLog('LỖI khi dịch (luồng mic) - đã xếp vào hàng đợi thử lại: ' + err.message);
          window.__enqueueFailedTranslateBatch?.(texts, 'vi', AUDIO_CHANNEL_MIC);
        }
      });
    }

    const sourceLangEl = document.getElementById('sourceLang');
    const captureModeEl = document.getElementById('captureMode');
    // Fix (audit CI - ESLint no-undef): 2 ref này trước đây bị dùng ở nhiều chỗ bên dưới
    // (refreshExternalMicStatus, startCaptureFlow, onMicDeviceInfo...) nhưng CHƯA từng được khai
    // báo riêng trong file này - app.js có khai 2 biến cùng tên nhưng đó là scope KHÁC (script
    // thường, không phải module này), không tự nhìn thấy được từ đây.
    const preferExternalMicEl = document.getElementById('preferExternalMic');
    const externalMicStatusEl = document.getElementById('externalMicStatus');
    // Fix (audit CI đợt 2 - ESLint no-undef): 2 ref này cũng bị dùng ở updateExternalMicUi()
    // bên dưới nhưng chưa từng khai báo riêng trong file này - cùng lý do như
    // preferExternalMicEl/externalMicStatusEl ở trên (app.js có khai nhưng khác scope).
    const externalMicRowEl = document.getElementById('externalMicRow');
    const mixedModeHintEl = document.getElementById('mixedModeHint');

    // Đếm số giây IM LẶNG liên tục dựa trên sự kiện audioLevel (bắn mỗi ~1s từ native).
    // Ngưỡng lấy theo AudioCaptureService.SILENCE_WARNING_SECONDS (giữ đồng bộ thủ công vì
    // native/JS không share hằng số) - quá ngưỡng thì hiện banner cảnh báo thay vì chỉ log console,
    // vì người dùng thường không mở log để biết vì sao không có phụ đề.
    const SILENCE_WARNING_SECONDS = 8;
    let consecutiveSilentSeconds = 0;
    // Phương án "nhận giọng ca sĩ khi hát" - true sau khi user bấm "Vẫn dịch tiếp đoạn này" trên
    // banner musicDetectedWarning: giữ nguyên hành vi gọi Whisper bình thường (bỏ qua field
    // likelyMusic) cho PHẦN CÒN LẠI của phiên nghe hiện tại, không chỉ 1 đoạn. Reset về false mỗi
    // khi bắt đầu phiên nghe mới - xem setCapturingUi().
    let musicOverrideForSession = false;
    let audioLevelTickCount = 0; // đếm số lần audioLevel bắn - dùng để throttle dòng log verbose (mỗi 5 lần mới in)
    let isCapturing = false;
    // Hàng đợi tuần tự riêng cho Whisper Cloud - giữ ĐÚNG THỨ TỰ câu (quan trọng cho phụ đề,
    // khác với dịch text vốn không lệch thứ tự nhiều). Cùng ý tưởng translateQueue nhưng tách
    // riêng vì đây là bước NHẬN DẠNG (trước dịch), không phải bước dịch.
    let cloudSttQueue = Promise.resolve();

    function setCapturingUi(capturing) {
      isCapturing = capturing;
      window.__isCapturing = capturing;
      mainToggleBtn.textContent = capturing ? '⏹️ Dừng nghe' : '▶️ Bắt đầu nghe';
      mainToggleBtn.classList.toggle('stopping', capturing);
      sourceLangEl.disabled = capturing;
      captureModeEl.disabled = capturing;
      preferExternalMicEl.disabled = capturing;
      if (micCaptionCardEl) {
        micCaptionCardEl.style.display = (capturing && captureModeEl.value === 'mixed') ? 'block' : 'none';
      }
      // Phương án "nhận giọng ca sĩ khi hát" - lựa chọn "vẫn dịch tiếp" chỉ có ý nghĩa cho ĐÚNG 1
      // phiên nghe; phiên mới (capturing chuyển sang true) phải hỏi lại từ đầu. Ẩn banner cả lúc
      // bắt đầu lẫn lúc dừng - không nên còn hiện lại banner cũ khi mới bấm "Bắt đầu nghe".
      musicOverrideForSession = false;
      if (musicDetectedWarningEl) musicDetectedWarningEl.style.display = 'none';
      if (!capturing) {
        // Dừng nghe - xoá batch mic còn dang dở (giống hành vi cũ: câu cuối chưa flush của luồng
        // system vẫn được native tự flushSegment() đẩy lên trước khi dừng hẳn, nhưng batch JS ở
        // ĐÂY là hàng chờ gộp câu trước khi DỊCH, không phải hàng chờ NHẬN DẠNG - hủy timer tương
        // tự cách finalBatchTimer không có xử lý đặc biệt lúc dừng, chấp nhận mất tối đa 1 cụm
        // <700ms cuối nếu dừng đúng lúc đang gộp).
        micBatchBuffer = [];
        micBatchStartAt = 0;
        if (micBatchTimer) {
          clearTimeout(micBatchTimer);
          micBatchTimer = null;
        }
      }
    }

    const switchToMicBtnEl = document.getElementById('switchToMicBtn');

    // ===== Khối "Ưu tiên micro ngoài" - chỉ hiện khi captureMode='mic'. externalMicStatusEl
    // hiện 2 loại thông tin khác nhau tuỳ thời điểm:
    // - Lúc CHƯA bắt đầu nghe: kết quả listInputDevices() (chỉ dò danh sách thiết bị đang cắm,
    //   KHÔNG chọn/route gì) - để user biết trước có nên tick hay không.
    // - Lúc ĐANG nghe: kết quả THẬT từ sự kiện micDeviceInfo (native đã chọn xong thiết bị) -
    //   ghi đè status ở trên vì đây mới là trạng thái chính xác nhất.
    async function refreshExternalMicStatus() {
      const micActive = captureModeEl.value === 'mic' || captureModeEl.value === 'mixed';
      if (!micActive || !preferExternalMicEl.checked) {
        externalMicStatusEl.textContent = '';
        return;
      }
      if (isCapturing) return; // đang nghe thì để nguyên status thật từ onMicDeviceInfo, không ghi đè bằng kết quả dò lại
      try {
        const devices = await capture.listInputDevices();
        externalMicStatusEl.textContent = devices.length
          ? 'Đã phát hiện: ' + devices.map((d) => d.label).join(', ')
          : 'Chưa phát hiện micro ngoài đang kết nối - sẽ tạm dùng micro trong máy.';
      } catch (e) {
        externalMicStatusEl.textContent = ''; // chạy ngoài app native (dev trên browser) - bỏ qua im lặng
      }
    }
    window.__refreshExternalMicStatus = refreshExternalMicStatus;

    function updateExternalMicUi() {
      const micActive = captureModeEl.value === 'mic' || captureModeEl.value === 'mixed';
      externalMicRowEl.style.display = micActive ? 'block' : 'none';
      mixedModeHintEl.style.display = (captureModeEl.value === 'mixed') ? 'block' : 'none';
      refreshExternalMicStatus();
    }
    window.__updateExternalMicUi = updateExternalMicUi;
    // KHÔNG gọi updateExternalMicUi() ngay ở đây - `capture` (NativeCaptureBridge) còn chưa
    // được khai báo (const phía dưới, temporal dead zone). Gọi lần đầu ngay sau khi khai báo
    // xong `capture` (xem đoạn `const capture = new NativeCaptureBridge(...)` bên dưới).

    // ===== Auto-fallback system -> mic khi phát hiện chặn chắc chắn (code SYSTEM_CAPTURE_BLOCKED
    // từ native), và chuyển tay khi user bấm nút trong banner cảnh báo im lặng kéo dài. Dùng
    // chung 1 hàm cho cả 2 trường hợp để không lặp code. autoFallbackInProgress chặn gọi
    // chồng nếu lỡ nhận nhiều sự kiện lỗi liên tiếp trong lúc đang chuyển. =====
    let autoFallbackInProgress = false;
    async function switchToMicAndRestart(reason) {
      if (autoFallbackInProgress) return;
      autoFallbackInProgress = true;
      try {
        moduleLog(
          reason === 'auto'
            ? 'Tự động chuyển sang ghi âm qua micro (audio hệ thống bị chặn).'
            : 'Đang chuyển sang ghi âm qua micro theo yêu cầu...'
        );
        try { await capture.stop(); } catch (e) { /* có thể chưa capture gì, bỏ qua */ }

        captureModeEl.value = 'mic';
        window.__saveSettings({ captureMode: 'mic' });
        silenceWarningEl.style.display = 'none';
        consecutiveSilentSeconds = 0;
        modelStatusEl.textContent = 'Model: đang tải...';

        await capture.start(sourceLangEl.value, 'mic', preferExternalMicEl.checked);
        setCapturingUi(true);
        moduleLog('Đã chuyển sang micro, đang nghe.');
      } catch (err) {
        moduleLog('LỖI khi chuyển sang micro: ' + err.message);
        setCapturingUi(false);
      } finally {
        autoFallbackInProgress = false;
      }
    }
    switchToMicBtnEl.onclick = () => switchToMicAndRestart('manual');

    // Phương án "nhận giọng ca sĩ khi hát" - user tự chọn bỏ qua cảnh báo, giữ hành vi dịch bình
    // thường (bỏ qua field likelyMusic) cho PHẦN CÒN LẠI của phiên nghe hiện tại - xem
    // musicOverrideForSession/setCapturingUi() ở trên và onCloudSttSegment bên dưới.
    if (keepTranslatingMusicBtnEl) {
      keepTranslatingMusicBtnEl.onclick = () => {
        musicOverrideForSession = true;
        musicDetectedWarningEl.style.display = 'none';
      };
    }

    const capture = new NativeCaptureBridge({
      onModelStatus: (ready) => {
        modelStatusEl.textContent = ready ? 'Model: đã sẵn sàng, đang nghe...' : 'Model: đang tải...';
      },
      onError: (message, code) => {
        moduleLog('LỖI capture: ' + message);
        // SYSTEM_CAPTURE_BLOCKED = native đã xác nhận chắc chắn build AudioRecord thất bại
        // (không phải chỉ im lặng nghi ngờ) - an toàn để tự động chuyển sang micro luôn,
        // không cần chờ user bấm nút. Chỉ tự động khi đang ở mode 'system' (tránh vòng lặp
        // vô nghĩa nếu lỗi này lỡ xảy ra khi đã ở mic).
        if (code === 'SYSTEM_CAPTURE_BLOCKED' && captureModeEl.value === 'system') {
          switchToMicAndRestart('auto');
        }
        // Các mã lỗi mà native ĐÃ TỰ dừng hẳn service (stopCapture()/stopSelf() - xem
        // SttReadLoop.kt/CaptureSourceManager.kt/AudioCaptureService.kt) trước khi kịp bắt đầu
        // ghi âm hoặc giữa chừng đang ghi - đưa UI về đúng trạng thái "đã dừng" NGAY, không thì
        // nút vẫn hiện "⏹️ Dừng nghe" dù thực tế native đã dừng từ lâu, user bấm "Dừng nghe" sẽ
        // chỉ gọi lại 1 lệnh stop vô nghĩa (đã dừng sẵn rồi) mà không hiểu vì sao đột nhiên hết
        // phụ đề. KHÔNG gồm SYSTEM_CAPTURE_BLOCKED ở mode 'system' (đã tự chuyển sang mic ở
        // nhánh trên, không nên reset UI về "đã dừng" giữa chừng đang tự chuyển).
        const stoppedCodes = ['MIC_READ_LOST', 'CAPTURE_START_FAILED'];
        if (stoppedCodes.includes(code) || (code === 'SYSTEM_CAPTURE_BLOCKED' && captureModeEl.value !== 'system')) {
          setCapturingUi(false);
        }
      },
      // Mỗi giây nhận mức tín hiệu audio thực tế AudioRecord đọc được, để biết capture có
      // đang nhận audio thật hay chỉ toàn silence (bị chặn/mute). peak thang PCM16: 0..32767.
      // peak < ~50 coi như im lặng. Logic đếm im lặng/banner cảnh báo vẫn chạy ĐỦ mỗi giây (an
      // toàn cho độ chính xác), nhưng dòng log() text chỉ in mỗi 5 lần (~5s) - in mỗi giây suốt
      // hàng giờ capture chỉ tốn CPU dựng chuỗi + IO liên tục cho 1 dòng gần như lặp lại giá trị.
      onAudioLevel: (data) => {
        audioLevelTickCount++;
        if (audioLevelTickCount % 5 === 0) {
          const status = data.peak < 50 ? '🔇 IM LẶNG' : '🔊 có audio';
          moduleLog(
            `[audio${data.channel ? ':' + data.channel : ''}] peak=${data.peak} (${status}) | `
            + `reads=${data.readCalls} silent=${data.silentReads} bad=${data.badReads}`
          );
        }

        // Ở MODE_MIXED, 2 luồng (mic/system) đều bắn audioLevel riêng - banner "im lặng" CHỈ
        // nên phản ánh luồng system (đối phương): nếu tính gộp cả 2, lúc mình đang nói mà đối
        // phương im lặng (hoặc ngược lại) sẽ làm bộ đếm không bao giờ tăng đúng, banner gần như
        // không bao giờ hiện đúng lúc (bug y hệt đã vá 1 lần trước đây ở bản Vosk MODE_MIXED cũ,
        // xem lịch sử dự án - giờ áp dụng lại cho bản Cloud STT).
        // Fix (tự phát hiện lúc audit lại, cùng đợt với bug tương tự ở musicDetectedWarning):
        // TRƯỚC ĐÂY so sánh data.channel === AUDIO_CHANNEL_MIC ở đây là SAI - channel ở chế độ
        // MIC ĐƠN (captureMode='mic') mặc định BẰNG currentMode = "mic" (xem SttReadLoop.kt:
        // channel = channel, tham số mặc định channel: String = currentMode), TRÙNG CHỮ với
        // CHANNEL_MIC của luồng mic MODE_MIXED dù 2 ngữ cảnh khác hẳn - khiến banner "im lặng"
        // bị tắt câm lặng cho MỌI phiên dùng chế độ mic đơn (comment cũ ở trên ghi "undefined ở
        // các mode đơn khác" cũng SAI theo - channel không bao giờ undefined). Phải kiểm tra
        // thêm captureModeEl.value === 'mixed' mới đúng ý "chỉ bỏ qua luồng MÌNH NÓI trong hội
        // thoại 2 chiều", không phải "bỏ qua bất cứ khi nào channel=='mic'".
        if (captureModeEl.value === 'mixed' && data.channel === AUDIO_CHANNEL_MIC) return;

        if (data.peak < 50) {
          consecutiveSilentSeconds++;
        } else {
          consecutiveSilentSeconds = 0;
        }

        if (consecutiveSilentSeconds >= SILENCE_WARNING_SECONDS) {
          silenceSecondsEl.textContent = String(consecutiveSilentSeconds);
          silenceWarningEl.style.display = 'block';
          // Nút "chuyển sang micro" chỉ có ý nghĩa khi đang ở mode 'system' - nếu đã ở mic
          // mà vẫn im lặng thì đây là im lặng thật (video không có tiếng), không phải bị chặn.
          switchToMicBtnEl.style.display = captureModeEl.value === 'system' ? 'inline-block' : 'none';
        } else {
          silenceWarningEl.style.display = 'none';
        }
      },
      // Phương án "nhận giọng ca sĩ khi hát" - bắn ĐÚNG 1 LẦN mỗi đợt nhạc, chỉ để hiện banner.
      // Việc THẬT SỰ bỏ qua đoạn nào (không gọi Whisper) nằm ở field likelyMusic trong
      // onCloudSttSegment bên dưới - handler này không tự ý làm gì hơn ngoài cập nhật UI.
      onPossibleMusicDetected: (channel) => {
        // Fix (tự phát hiện lúc audit lại): TRƯỚC ĐÂY so sánh channel === AUDIO_CHANNEL_MIC là
        // SAI - channel ở chế độ MIC ĐƠN (captureMode='mic', không phải 'mixed') mặc định BẰNG
        // currentMode = "mic" (xem SttReadLoop.kt: channel: String = currentMode), TRÙNG CHỮ với
        // CHANNEL_MIC dùng cho luồng mic của MODE_MIXED dù 2 ngữ cảnh khác hẳn nhau - khiến toàn
        // bộ tính năng "nhận nhạc" bị tắt câm lặng cho MỌI phiên dùng chế độ mic đơn (không tiết
        // kiệm quota, không cảnh báo gì). Phải kiểm tra thêm captureModeEl.value === 'mixed' mới
        // đúng ý "chỉ bỏ qua luồng MÌNH NÓI trong hội thoại 2 chiều".
        if (captureModeEl.value === 'mixed' && channel === AUDIO_CHANNEL_MIC) return;
        if (musicOverrideForSession) return; // user đã chọn "vẫn dịch tiếp" cho phiên này rồi
        if (musicDetectedWarningEl) musicDetectedWarningEl.style.display = 'block';
      },
      // Bắn khi service tự phục hồi capture sau khi bị OS kill (chỉ ở chế độ mic - chế độ
      // system không tự phục hồi được vì token MediaProjection chỉ dùng 1 lần).
      onCaptureResumed: (mode) => {
        moduleLog('Đã tự phục hồi capture sau khi bị hệ thống dừng (mode=' + mode + ').');
        modelStatusEl.textContent = 'Model: đã sẵn sàng, đang nghe... (vừa tự phục hồi)';
        setCapturingUi(true);
      },
      // 1 đoạn audio đã được native cắt theo câu (VAD) sẵn sàng để upload lên Whisper Cloud.
      // Xếp hàng tuần tự (cloudSttQueue) để giữ đúng thứ tự câu dù mạng có thể trả về không đều.
      // channel: LUÔN LÀ 'mic'|'system' (không bao giờ undefined - xem SttReadLoop.kt: tham số
      // channel mặc định = currentMode, tức "mic" ở MODE_MIC đơn, "system" ở MODE_SYSTEM đơn,
      // hoặc CHANNEL_MIC/CHANNEL_SYSTEM tường minh ở MODE_MIXED) - PHẢI kết hợp với
      // captureModeEl.value === 'mixed' nếu muốn phân biệt riêng luồng mic của hội thoại 2
      // chiều, không được suy ra chỉ từ channel === 'mic' (xem biến isMixedMicChannel bên dưới -
      // đã áp dụng cùng 1 quy tắc này cho CẢ 3 chỗ dùng channel trong handler này, xem fix "audit
      // đợt 4" bên dưới cho lần cuối còn thiếu).
      onCloudSttSegment: (wavBase64, sourceLang, channel, likelyMusic) => {
        cloudSttQueue = cloudSttQueue.then(async () => {
          if (!isCapturing) return; // đã dừng nghe giữa lúc đoạn cuối còn đang xếp hàng - bỏ qua
          // Fix (audit đợt 4 - "MIC đơn bị dịch sai hướng"): TRƯỚC ĐÂY biến "isMic" chỉ so sánh
          // channel === AUDIO_CHANNEL_MIC (không kèm captureModeEl.value === 'mixed') rồi dùng
          // NGUYÊN VĂN để chọn pipeline dịch bên dưới ("if (isMic) { pushMicFinalToBatch(...) }")
          // - đúng kiểu "suy ra chỉ từ channel === 'mic'" mà chính comment phía trên hàm này cảnh
          // báo phải tránh (channel mặc định = currentMode, tức "mic" ở CẢ MODE_MIC đơn lẫn nửa
          // mic của MODE_MIXED - xem SttReadLoop.kt). pushMicFinalToBatch()/translateMicBatchAndDisplay()
          // CHỈ đúng cho nửa mic của MODE_MIXED (dịch NGƯỢC: vi -> otherPartyLang) - áp dụng nhầm
          // cho MIC đơn (sourceLang do user chọn, có thể không phải 'vi') sẽ dịch sai hướng hoàn
          // toàn. Đổi tên "isMic" -> "isMixedMicChannel" và gắn kèm điều kiện 'mixed' NGAY TỪ LÚC
          // TÍNH, để không còn chỗ nào trong hàm này có thể dùng nhầm giá trị chưa gate như trước.
          const isMixedMicChannel = captureModeEl.value === 'mixed' && channel === AUDIO_CHANNEL_MIC;
          // Phương án "nhận giọng ca sĩ khi hát" - loại trừ ĐÚNG luồng mic của hội thoại 2
          // chiều (captureMode='mixed'), KHÔNG loại trừ chế độ mic đơn (captureMode='mic') - fix
          // bug tự phát hiện lúc audit lại, xem comment ở khai báo onCloudSttSegment phía trên.
          if (!isMixedMicChannel) {
            if (!likelyMusic && musicDetectedWarningEl && musicDetectedWarningEl.style.display !== 'none') {
              musicDetectedWarningEl.style.display = 'none';
            }
            if (likelyMusic && !musicOverrideForSession) {
              moduleLog('[whisper-cloud] Bỏ qua đoạn audio - nghe giống nhạc/bài hát liên tục, không gửi lên Whisper để đỡ tốn quota (xem banner cảnh báo).');
              return;
            }
          }
          try {
            modelStatusEl.textContent = 'Model: đã sẵn sàng, đang nghe... (🌩️ đang nhận dạng đoạn vừa nói)';
            const { text, language: whisperDetectedLang } = await window.__transcribeCloudSegment(wavBase64, sourceLang);
            if (isCapturing) modelStatusEl.textContent = 'Model: đã sẵn sàng, đang nghe...';
            if (!text) return;
            if (isMixedMicChannel) {
              // Luồng mic CỦA MODE_MIXED: STT luôn ép sẵn sourceLang='vi' (native, xem
              // startMixedCapture) - không có khái niệm 'auto'/detectedLang ở luồng này. MIC đơn
              // (captureMode='mic') KHÔNG rơi vào đây nữa (xem fix isMixedMicChannel phía trên) -
              // tự động rơi xuống nhánh dịch bình thường bên dưới, y hệt MODE_SYSTEM.
              moduleLog('[whisper-cloud:mic] ' + text);
              if (micFinalOriginalEl) micFinalOriginalEl.textContent = text;
              pushMicFinalToBatch(text);
              return;
            }
            // Ở chế độ ép sẵn 1 ngôn ngữ (sourceLang !== 'auto'), dùng thẳng sourceLang như cũ
            // (đáng tin hơn field Whisper trả về, vốn chỉ có ý nghĩa rõ khi KHÔNG ép sẵn). Ở chế
            // độ auto, dùng ngôn ngữ Whisper THẬT SỰ phát hiện (whisperDetectedLang).
            const detectedLang = sourceLang === 'auto' ? whisperDetectedLang : sourceLang;
            const langTag = sourceLang === 'auto' && detectedLang ? '[phát hiện: ' + detectedLang + '] ' : '';
            moduleLog('[whisper-cloud' + (channel ? ':' + channel : '') + '] ' + langTag + text);
            finalOriginalEl.textContent = text;
            pushFinalToBatch(text, detectedLang);
          } catch (err) {
            // Fix (audit đợt 2 - "retry khi mất mạng"): trước đây lỗi ở bước nhận dạng (mất
            // mạng, timeout GROQ_STT_TIMEOUT_MS, lỗi tạm thời từ groq-relay...) làm MẤT TRẮNG cả
            // đoạn audio đã nói - chỉ log ra console debug. Giờ xếp đoạn audio gốc (wavBase64)
            // vào hàng đợi thử lại (app.js) thay vì bỏ hẳn - tự thử lại định kỳ/khi có mạng lại.
            moduleLog('LỖI Whisper Cloud - đã xếp vào hàng đợi thử lại: ' + err.message);
            window.__enqueueFailedSttSegment?.(wavBase64, sourceLang, channel);
          }
        });
      },
      // Kết quả THẬT native đã chọn cho MODE_MIC (sau khi cân nhắc checkbox "Ưu tiên micro
      // ngoài" + thiết bị thực tế đang cắm) - ghi đè status vốn chỉ là dò trước
      // (refreshExternalMicStatus). usedExternal=false không phải lỗi - có thể do user không
      // tick, hoặc có tick nhưng không tìm thấy thiết bị ngoài nào lúc bắt đầu nghe.
      onMicDeviceInfo: (usedExternal, label) => {
        moduleLog('[micro] ' + label);
        if (captureModeEl.value === 'mic' || captureModeEl.value === 'mixed') {
          externalMicStatusEl.textContent = (usedExternal ? '🎧 Đang dùng: ' : '📱 Đang dùng: ') + label;
        }
      },
    });
    updateExternalMicUi(); // giờ `capture` đã sẵn sàng - áp dụng trạng thái hiện/ẩn + dò thiết bị lần đầu

    // Tách riêng luồng "bắt đầu nghe" khỏi onclick của mainToggleBtn để dùng chung được cho
    // nút "🔄 Kết nối lại ngay" trong banner lostSessionWarning (reconnect 1-click) - cả 2 chỗ
    // gọi cùng 1 hàm, luôn dùng lại ĐÚNG lựa chọn hiện tại của user trong sourceLang/captureMode
    // (không reset về mặc định), nên user không phải chỉnh lại gì trước khi bấm lại. Giới hạn
    // CỨNG không sửa được: chế độ "system" luôn cần Android hỏi lại quyền MediaProjection
    // (dialog hệ thống) - đây là 1-click PHÍA APP, dialog OS sau đó vẫn cần 1 lần chạm "Bắt đầu"
    // từ user (bảo mật OS, không có API nào bỏ qua được).
    async function startCaptureFlow() {
      const sourceLang = sourceLangEl.value;
      const captureMode = captureModeEl.value;
      const preferExternalMic = preferExternalMicEl.checked;

      // MODE_MIXED: luồng mic (mình nói) cần dịch tới 1 ngôn ngữ đối phương CỤ THỂ ngay từ đầu
      // (xem translateMicBatchAndDisplay ở trên) - "Tự động nhận diện" không cho ra ngôn ngữ cố
      // định nào để dịch tới nên chặn ngay tại đây, tránh phải xử lý edge-case rối ở tầng dịch.
      if (captureMode === 'mixed' && sourceLang === 'auto') {
        moduleLog('Chế độ "Hội thoại 2 chiều" không dùng được với "Tự động nhận diện" - hãy chọn đúng ngôn ngữ đối phương.');
        alert('Chế độ "Hội thoại 2 chiều" cần chọn đúng ngôn ngữ đối phương đang nói (không dùng được "Tự động nhận diện").');
        return;
      }

      modelStatusEl.textContent = 'Model: đang tải...';
      silenceWarningEl.style.display = 'none';
      lostSessionWarningEl.style.display = 'none';
      consecutiveSilentSeconds = 0;
      try {
        await capture.start(sourceLang, captureMode, preferExternalMic);
        setCapturingUi(true);
        moduleLog(
          'Đã start capture (mode=' + captureMode + ', sourceLang=' + sourceLang + ').'
          + (captureMode === 'system' ? ' Giờ mở YouTube (hoặc app khác) và phát video.'
            : ' Giờ phát audio qua loa ngoài.')
        );
      } catch (err) {
        moduleLog('LỖI khi start capture: ' + err.message);
        modelStatusEl.textContent = 'Model: lỗi - ' + err.message;
      }
    }

    // 1 nút duy nhất Start/Stop.
    mainToggleBtn.onclick = async () => {
      if (isCapturing) {
        try {
          await capture.stop();
          modelStatusEl.textContent = 'Model: đã dừng';
          silenceWarningEl.style.display = 'none';
          moduleLog('Đã dừng capture.');
        } catch (err) {
          moduleLog('LỖI khi dừng capture: ' + err.message);
        } finally {
          setCapturingUi(false);
          refreshExternalMicStatus(); // dò lại (status "Đang dùng: ..." của phiên vừa xong đã hết hiệu lực)
        }
        return;
      }
      await startCaptureFlow();
    };

    // Nút "🔄 Kết nối lại ngay" trong banner lostSessionWarning - 1 chạm gọi thẳng lại đúng
    // luồng start (giữ nguyên lựa chọn ngôn ngữ/nguồn audio hiện tại), không bắt user phải tự
    // tìm và bấm nút "Bắt đầu nghe" ở nơi khác trên trang.
    document.getElementById('reconnectNowBtn').onclick = async () => {
      lostSessionWarningEl.style.display = 'none';
      await startCaptureFlow();
    };

    // Kiểm tra ngay khi mở app: nếu lần chạy trước bị hệ thống âm thầm dừng giữa chừng
    // (mode=system, không tự phục hồi được), báo cho user biết thay vì im lặng.
    capture.checkLostSession().then((lost) => {
      if (lost) {
        lostSessionWarningEl.style.display = 'block';
        moduleLog('Phát hiện phiên nghe trước bị hệ thống dừng giữa chừng (chưa tự phục hồi được).');
        // Cuộn banner (có nút "Kết nối lại ngay" ngay trong đó) vào giữa màn hình. Vẫn giữ
        // hiệu ứng nhấp nháy 'attention-pulse' (xem CSS) trên chính banner để dễ nhận ra.
        lostSessionWarningEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
        lostSessionWarningEl.classList.add('attention-pulse');
        lostSessionWarningEl.addEventListener('animationend', () => {
          lostSessionWarningEl.classList.remove('attention-pulse');
        }, { once: true });
      }
    }).catch((err) => moduleLog('Lỗi checkLostSession: ' + err.message));
