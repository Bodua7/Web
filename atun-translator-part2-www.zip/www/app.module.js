// www/app.module.js - JS module (import/export) tách ra từ khối <script type="module"> thứ 2
// trong index.html. Nạp qua <script type="module" src="app.module.js"></script>, cùng vị trí
// cũ trong <body> - import './src/services/...' vẫn đúng vì file này cũng nằm ở gốc www/ như
// index.html trước đây, base URL của import không đổi.

    import { NativeCaptureBridge } from './src/services/audio/NativeCaptureBridge.js';
    import {
      isMlkitAvailable,
      translateMlkit,
      listMlkitDownloadedLanguages,
      downloadMlkitModel,
      deleteMlkitModel,
    } from './src/services/translation/MlkitTranslateBridge.js';
    import {
      isExportAvailable,
      shareExportFile,
      getErrorLog,
      submitModelFeedback,
      getModelFeedback,
      clearModelFeedback,
      clearErrorLog,
      appendErrorLog,
      getBatteryPercent,
    } from './src/services/export/ExportBridge.js';
    import {
      isTtsAvailable,
      speakTranslation,
      stopSpeaking,
      setTtsRate,
      setTtsVolume,
      setAutoDuck,
      setTtsBoost,
      checkVietnameseVoice,
      promptInstallVoiceData,
    } from './src/services/tts/TtsBridge.js';

    // Dùng chung hàm log() đã giới hạn dòng khai báo ở script phía trên (window.__appLog),
    // tránh 2 logger độc lập cùng ghi đè lẫn nhau lên #log và tránh lặp lại bug phình bộ nhớ.
    const moduleLog = window.__appLog;

    // Expose cho translateText() ở <script> thường (không phải module) phía trên gọi được -
    // 2 khối script khác scope module nên không import trực tiếp cho nhau được.
    window.__isMlkitAvailable = isMlkitAvailable;
    window.__translateMlkit = translateMlkit;

    // Xuất/chia sẻ nhật ký dịch (.srt / .txt song ngữ) - dùng ở <script> thường phía trên.
    window.__isExportAvailable = isExportAvailable;
    window.__shareExportFile = shareExportFile;

    // ===== Quản lý model dịch on-device (ML Kit Translate) - UI riêng, độc lập với model
    // STT (Vosk) ở card phía trên. Danh sách ngôn ngữ hiển thị lấy đúng theo các <option>
    // đang có ở #targetLang + #sourceLang, để không lệch với những gì app thực sự dùng. =====
    // BUG đã sửa: trước đây chỉ có 5 ngôn ngữ - khớp với LANG_MAP cũ (đã lỗi thời) bên
    // MlkitTranslatePlugin.kt. Giờ mở rộng theo đúng LANG_MAP đã mở rộng ở đó (theo danh sách
    // ML Kit Translate hỗ trợ, khớp với hầu hết ModelManagerPlugin.CATALOG bên STT) - để user
    // tải TRƯỚC model dịch cho các ngôn ngữ nghe không phải vi/en/ja/ko/zh, tránh luôn phải
    // rơi xuống dịch qua mạng cho các ngôn ngữ đó.
    const MLKIT_LANGS = [
      { lang: 'vi', name: 'Tiếng Việt' },
      { lang: 'en', name: 'English' },
      { lang: 'ja', name: '日本語' },
      { lang: 'ko', name: '한국어' },
      { lang: 'zh-CN', name: '中文' },
      { lang: 'ru', name: 'Русский (Nga)' },
      { lang: 'fr', name: 'Français (Pháp)' },
      { lang: 'de', name: 'Deutsch (Đức)' },
      { lang: 'es', name: 'Español (Tây Ban Nha)' },
      { lang: 'pt', name: 'Português (Bồ Đào Nha)' },
      { lang: 'tr', name: 'Türkçe (Thổ Nhĩ Kỳ)' },
      { lang: 'it', name: 'Italiano (Ý)' },
      { lang: 'nl', name: 'Nederlands (Hà Lan)' },
      { lang: 'ca', name: 'Català (Catalan)' },
      { lang: 'fa', name: 'فارسی (Ba Tư/Iran)' },
      { lang: 'uk', name: 'Українська (Ukraine)' },
      { lang: 'eo', name: 'Esperanto' },
      { lang: 'hi', name: 'हिन्दी (Ấn Độ - Hindi)' },
      { lang: 'cs', name: 'Čeština (Séc)' },
      { lang: 'pl', name: 'Polski (Ba Lan)' },
      { lang: 'gu', name: 'ગુજરાતી (Gujarat)' },
      { lang: 'te', name: 'తెలుగు (Telugu)' },
      { lang: 'ka', name: 'ქართული (Georgia)' },
    ];
    const mlkitModelListEl = document.getElementById('mlkitModelList');

    async function refreshMlkitModelList() {
      if (!mlkitModelListEl) return;
      if (!isMlkitAvailable()) {
        mlkitModelListEl.textContent = 'MlkitTranslate chưa sẵn sàng (chưa chạy trong app native đã build?)';
        return;
      }
      let downloaded;
      try {
        downloaded = await listMlkitDownloadedLanguages(); // mảng mã ML Kit (vd "vi","en") đã tải
      } catch (err) {
        mlkitModelListEl.textContent = 'Lỗi tải danh sách model dịch: ' + err.message;
        return;
      }
      // Map mã ML Kit (BCP-47 chuẩn ML Kit, vd "vi") về trạng thái đã tải cho từng mã app dùng.
      const downloadedSet = new Set(downloaded);
      renderMlkitModelList(downloadedSet);
    }

    function renderMlkitModelList(downloadedSet) {
      mlkitModelListEl.innerHTML = '';
      for (const { lang, name } of MLKIT_LANGS) {
        // "zh-CN" ở app map sang mã ML Kit "zh" - lang.split('-')[0] đã tự quy về đúng dạng
        // đó rồi (vd 'zh-CN' -> 'zh'), nên chỉ cần 2 điều kiện này là đủ.
        // BUG đã sửa: trước đây có thêm `|| downloadedSet.has('zh')` KHÔNG điều kiện, khiến
        // hễ tải xong model tiếng Trung là MỌI dòng khác (ja, ko, en...) cũng bị hiện nhầm
        // "Đã tải về máy" + nút "Xoá" dù model đó chưa hề tải, vì so sánh với 'zh' cố định
        // thay vì so với lang hiện tại của từng dòng.
        const isDownloaded = downloadedSet.has(lang) || downloadedSet.has(lang.split('-')[0]);
        const row = document.createElement('div');
        row.className = 'model-row';

        const left = document.createElement('div');
        left.style.flex = '1';
        const nameEl = document.createElement('div');
        nameEl.className = 'model-name';
        nameEl.textContent = name + ' (~30MB)';
        const statusEl = document.createElement('div');
        statusEl.className = 'model-status';
        statusEl.textContent = isDownloaded ? 'Đã tải về máy' : 'Chưa tải';
        left.appendChild(nameEl);
        left.appendChild(statusEl);
        row.appendChild(left);

        const btn = document.createElement('button');
        btn.className = 'model-btn';
        if (isDownloaded) {
          btn.textContent = 'Xoá';
          btn.onclick = async () => {
            btn.disabled = true;
            try {
              await deleteMlkitModel(lang);
              moduleLog('Đã xoá model dịch ' + lang + '.');
              await refreshMlkitModelList();
            } catch (err) {
              moduleLog('LỖI xoá model dịch: ' + err.message);
              btn.disabled = false;
            }
          };
        } else {
          btn.textContent = 'Tải về';
          btn.onclick = async () => {
            btn.disabled = true;
            statusEl.textContent = 'Đang tải...';
            try {
              await downloadMlkitModel(lang);
              moduleLog('Tải model dịch ' + lang + ' xong.');
              await refreshMlkitModelList();
            } catch (err) {
              moduleLog('LỖI tải model dịch ' + lang + ': ' + err.message);
              statusEl.textContent = 'Lỗi tải - thử lại';
              btn.disabled = false;
            }
          };
        }
        row.appendChild(btn);
        mlkitModelListEl.appendChild(row);
      }
    }

    refreshMlkitModelList();

    // ===== Bắt audio hệ thống + Vosk on-device + tự dịch sang tiếng Việt + đẩy overlay =====
    const modelStatusEl = document.getElementById('modelStatus');
    const modelLoadingProgressOuterEl = document.getElementById('modelLoadingProgressOuter');
    const modelLoadingProgressInnerEl = document.getElementById('modelLoadingProgressInner');
    // Chỉ có dữ liệu khi ở chế độ "Tự động nhận diện" (nhiều model Vosk load song song, xem
    // MultiLangVoskEngine + onModelLoadingProgress bên dưới) - ẩn hẳn progress bar khi bắt đầu
    // 1 lượt nghe mới và chưa nhận được sự kiện tiến độ nào (chế độ 1 ngôn ngữ không bắn sự
    // kiện này, giữ nguyên trạng thái ẩn suốt).
    function resetModelLoadingProgressUi() {
      modelLoadingProgressOuterEl.style.display = 'none';
      modelLoadingProgressInnerEl.style.width = '0%';
    }
    function onModelLoadingProgress(loaded, total) {
      if (!total) { resetModelLoadingProgressUi(); return; }
      modelLoadingProgressOuterEl.style.display = 'block';
      modelLoadingProgressInnerEl.style.width = Math.round((loaded / total) * 100) + '%';
      modelStatusEl.textContent = `Model: đang tải... (${loaded}/${total} ngôn ngữ đã sẵn sàng)`;
    }
    const partialEl = document.getElementById('partialText');
    const finalOriginalEl = document.getElementById('finalOriginal');
    const finalTranslatedEl = document.getElementById('finalTranslated');
    const inVideoCaptionEl = document.getElementById('inVideoCaption');
    const inVideoCaptionTextEl = document.getElementById('inVideoCaptionText');
    // Tự truy vấn lại #videoStage NGAY TRONG module script này, KHÔNG dùng biến videoStageEl
    // khai báo ở <script> thường phía trên (dòng ~1410) - 2 khối <script> không cùng scope
    // (module script có scope riêng), const ở script kia không truy cập được từ đây. Cùng
    // cách setupCaptionDrag() bên dưới đã làm (tự document.getElementById('videoStage') riêng).
    const captionStageEl = document.getElementById('videoStage');
    const silenceWarningEl = document.getElementById('silenceWarning');
    const silenceSecondsEl = document.getElementById('silenceSeconds');
    const lostSessionWarningEl = document.getElementById('lostSessionWarning');
    const mainToggleBtn = document.getElementById('mainToggleBtn');

    // ===== Tuỳ chỉnh phụ đề trong app: kéo-thả đổi vị trí, cỡ chữ, độ trong suốt nền - tất cả
    // lưu vào localStorage nên lần mở app sau giữ nguyên (thay cho tính năng tương tự vốn có
    // sẵn ở overlay hệ thống cũ, nay chuyển hẳn vào #inVideoCaption trong app). =====
    const CAPTION_SETTINGS_KEY = 'atun_caption_settings_v1';
    // widthPercent/heightPercent: khung phụ đề lúc video THƯỜNG (thu nhỏ trong trang).
    // widthPercentFs/heightPercentFs: khung phụ đề lúc video TOÀN MÀN HÌNH (phóng to) - tách
    // riêng vì tỉ lệ khung hình 2 chế độ khác hẳn nhau (xem ghi chú ở khối HTML slider phía
    // trên). height tính bằng % chiều cao #videoStage, quy đổi ra px thực qua
    // getBoundingClientRect() trong applyCaptionSettings() (không dùng % CSS trực tiếp vì
    // #videoStage không luôn có chiều cao "specified" hợp lệ cho phần trăm ở phần tử con
    // position:absolute lúc chưa fullscreen).
    const DEFAULT_CAPTION_SETTINGS = {
      fontSize: 'medium', opacity: 0.75, leftPercent: 50, bottomPercent: 4,
      widthPercent: 100, heightPercent: 30,
      widthPercentFs: 100, heightPercentFs: 22,
    };

    function loadCaptionSettings() {
      try {
        return { ...DEFAULT_CAPTION_SETTINGS, ...JSON.parse(localStorage.getItem(CAPTION_SETTINGS_KEY) || '{}') };
      } catch {
        return { ...DEFAULT_CAPTION_SETTINGS };
      }
    }
    function saveCaptionSettings() {
      localStorage.setItem(CAPTION_SETTINGS_KEY, JSON.stringify(captionSettings));
    }
    function clamp(v, min, max) {
      return Math.min(max, Math.max(min, v));
    }
    function fontPxFor(size) {
      return size === 'small' ? 13 : size === 'large' ? 20 : 16;
    }

    // ===== Auto co giãn cỡ chữ theo chiều cao khung đã đặt (Cao %) - cỡ chữ Nhỏ/Vừa/Lớn ở
    // trên là giá trị THẬT SỰ hiển thị, hàm này CHỈ có tác dụng bảo vệ chống tràn khung: nếu
    // khung quá THẤP so với cỡ chữ đã chọn (chữ bị tràn, scrollHeight > khung) thì tự thu nhỏ
    // dần tới khi vừa khung (hoặc chạm sàn MIN_CAPTION_FONT_PX).
    // ĐÃ BỎ vòng lặp "tự phóng to lấp khoảng trống thừa" từng có ở đây: với câu ngắn/khung còn
    // nhiều chỗ trống (rất thường gặp), vòng lặp đó luôn đẩy CẢ 3 cỡ Nhỏ/Vừa/Lớn tăng tới CÙNG
    // 1 ngưỡng "cỡ lớn nhất còn vừa khung" (ngưỡng này chỉ phụ thuộc chiều cao khung + nội dung
    // câu, không phụ thuộc cỡ gốc) -> cả 3 lựa chọn hội tụ về cùng 1 giá trị, nhìn giống hệt
    // nhau, khiến lựa chọn Nhỏ/Vừa/Lớn của user mất tác dụng. Giờ 3 cỡ luôn hiển thị đúng
    // 13/16/20px trừ khi câu dài thật sự tràn khung mới tự thu nhỏ.
    const MIN_CAPTION_FONT_PX = 10;
    function fitCaptionFontSize() {
      const maxH = parseFloat(inVideoCaptionEl.style.maxHeight);
      if (!maxH || !inVideoCaptionTextEl.textContent.trim()) return;
      const basePx = fontPxFor(captionSettings.fontSize);
      let px = basePx;
      inVideoCaptionTextEl.style.fontSize = px + 'px';
      let guard = 0;
      while (inVideoCaptionTextEl.scrollHeight > maxH && px > MIN_CAPTION_FONT_PX && guard < 40) {
        px -= 1;
        inVideoCaptionTextEl.style.fontSize = px + 'px';
        guard++;
      }
    }

    let captionSettings = loadCaptionSettings();

    // Đang toàn màn hình hay không - videoStage là phần tử được fullscreen (xem
    // enterVideoFullscreen()), không phải videoPlayerFrame/videoPlayerContainer.
    function isCaptionFullscreen() {
      return document.fullscreenElement === captionStageEl;
    }

    // forceFs: bình thường bỏ trống (undefined) - hàm tự phát hiện đang toàn màn hình thật hay
    // không (isCaptionFullscreen()). Truyền true/false để ÉP dùng bộ giá trị thường/toàn màn
    // hình bất kể trạng thái fullscreen thật - dùng cho preview lúc đang chỉnh thanh trượt ở
    // trang cài đặt (xem previewCaptionSize()), vì lúc đó không thể bật fullscreen thật được.
    function applyCaptionSettings(forceFs) {
      const fs = typeof forceFs === 'boolean' ? forceFs : isCaptionFullscreen();
      const widthPercent = fs ? captionSettings.widthPercentFs : captionSettings.widthPercent;
      const heightPercent = fs ? captionSettings.heightPercentFs : captionSettings.heightPercent;

      inVideoCaptionEl.style.background = 'rgba(0,0,0,' + captionSettings.opacity + ')';
      inVideoCaptionEl.style.left = captionSettings.leftPercent + '%';
      inVideoCaptionEl.style.bottom = captionSettings.bottomPercent + '%';
      inVideoCaptionEl.style.right = 'auto';
      inVideoCaptionEl.style.transform = 'translateX(-50%)';

      // ===== FIX bug "khung phụ đề ôm sát từng dòng" (khung hẹp hơn nhiều so với video): trước
      // đây set width bằng CSS % trực tiếp (style.width = widthPercent + '%'). Về lý thuyết %
      // của width trên phần tử position:absolute phải resolve theo chiều rộng #videoStage (là
      // containing block, vì #videoStage có position:relative) - nhưng #videoStage lại tự lấy
      // chiều rộng từ 1 phần tử con dùng width="100%" (iframe video), tạo ra 1 vòng phụ thuộc
      // chiều rộng (width phụ thuộc con, con lại phụ thuộc width) mà WebView Android xử lý không
      // nhất quán - có lúc resolve % theo containing block đúng như mong đợi, có lúc lại co khung
      // lại theo đúng bề ngang nội dung chữ bên trong (kết quả: khung phụ đề bị hẹp bất thường,
      // "ôm sát" 2-3 dòng chữ thay vì trải theo widthPercent đã đặt).
      // FIX tiếp (widthPercent=100 vẫn chưa sát mép màn hình thật): body có padding:16px 2 bên
      // (xem style.css) nên #videoStage KHÔNG BAO GIỜ rộng bằng màn hình thật - nếu quy đổi theo
      // stageRect.width (chiều rộng videoStage) thì widthPercent=100% chỉ rộng bằng (màn hình -
      // 32px), không sát mép. Quy đổi theo document.documentElement.clientWidth (chiều rộng THẬT
      // của màn hình) thay vì stageRect.width - vẫn giữ nguyên left:50%+translateX(-50%) tính
      // theo % của videoStage làm điểm neo canh giữa (tâm ngang videoStage trùng tâm ngang màn
      // hình vì padding body đối xứng 2 bên) nên khung tự tràn đều sang 2 bên khớp sát mép màn
      // hình. Chiều CAO vẫn giữ tính theo stageRect.height như cũ (không đổi sang viewport height,
      // vì video không cao hết màn hình lúc chế độ thường).
      const stageRect = captionStageEl.getBoundingClientRect();
      const viewportWidth = document.documentElement.clientWidth;
      if (viewportWidth > 0) {
        inVideoCaptionEl.style.width = Math.round(viewportWidth * widthPercent / 100) + 'px';
      } else if (stageRect.width > 0) {
        // Dự phòng cực hiếm (clientWidth không đọc được) - tạm quy đổi theo videoStage như bản cũ.
        inVideoCaptionEl.style.width = Math.round(stageRect.width * widthPercent / 100) + 'px';
      } else {
        // videoStage chưa có kích thước thật (chưa render/video chưa phát) - tạm dùng % làm giá
        // trị dự phòng; applyCaptionSettings() sẽ được gọi lại (vd. lúc có câu dịch đầu tiên tới,
        // xem flushFinalBatch()) và tính lại đúng bằng px lúc đó.
        inVideoCaptionEl.style.width = widthPercent + '%';
      }

      // Quy đổi heightPercent (% chiều cao videoStage) ra px thực - dùng getBoundingClientRect()
      // vì lúc chưa fullscreen #videoStage cao theo nội dung (iframe height=200), % CSS trực
      // tiếp trên phần tử con position:absolute không đảm bảo resolve đúng ở mọi trình duyệt.
      // Nếu videoStage chưa có kích thước thật (video chưa phát, rect.height=0) thì bỏ qua,
      // giữ nguyên max-height cũ - sẽ tự tính lại đúng ngay khi có câu dịch đầu tiên hiện ra
      // (xem chỗ gọi applyCaptionSettings() trong flushFinalBatch()).
      if (stageRect.height > 0) {
        inVideoCaptionEl.style.maxHeight = Math.round(stageRect.height * heightPercent / 100) + 'px';
      }

      // Đặt cỡ chữ NỀN (đúng lựa chọn Nhỏ/Vừa/Lớn) lên #inVideoCaptionText - fitCaptionFontSize()
      // bên dưới sẽ tự co giãn thêm quanh giá trị nền này cho khớp khung Cao % đã đặt (xem ghi
      // chú ở hàm đó) - gọi sau khi đã có maxHeight mới ở trên.
      inVideoCaptionTextEl.style.fontSize = fontPxFor(captionSettings.fontSize) + 'px';
      fitCaptionFontSize();

      // Đồng bộ khung dịch sang "Web mini" (xem pushCaptionToWebMini() ở <script> thường phía
      // trên, và window.__getCaptionFrame ngay dưới đây) - đặt CUỐI applyCaptionSettings() để
      // MỌI đường gọi hàm này (câu dịch mới tới, kéo thanh trượt Rộng/Cao/cỡ chữ/độ trong suốt,
      // bật/tắt fullscreen, các nút "Đặt lại"...) đều tự kéo theo đồng bộ, khỏi phải rải thêm
      // lời gọi riêng ở từng nơi. widthPercent/heightPercent đã tự chọn đúng bộ thường/toàn màn
      // hình theo "fs" tính ở đầu hàm này rồi, dùng lại luôn.
      window.pushCaptionToWebMini?.(inVideoCaptionTextEl.textContent);
    }

    // Trả về "khung dịch" hiện tại (độ trong suốt/cỡ chữ/tỉ lệ rộng-cao đang áp dụng, ĐÃ chọn
    // đúng bộ thường/toàn màn hình theo trạng thái fullscreen thật) để pushCaptionToWebMini() ở
    // <script> thường phía trên (khác scope module) gọi được qua window.__ - cùng cách
    // window.__applyCaptionSettings đã expose. widthPercent/heightPercent gửi nguyên dạng %,
    // KHÔNG quy đổi ra px như inVideoCaptionEl.style.width bên trên - vì "Web mini" có kích
    // thước vùng hiển thị của riêng nó (không phải #videoStage này), phải tự quy đổi % ra px
    // theo kích thước THẬT của chính nó (xem applyCaptionFrame() trong BrowserActivity.kt).
    window.__getCaptionFrame = function () {
      const fs = isCaptionFullscreen();
      return {
        opacity: captionSettings.opacity,
        fontSize: captionSettings.fontSize,
        widthPercent: fs ? captionSettings.widthPercentFs : captionSettings.widthPercent,
        heightPercent: fs ? captionSettings.heightPercentFs : captionSettings.heightPercent,
      };
    };

    const captionFontSizeEl = document.getElementById('captionFontSize');
    const captionOpacityEl = document.getElementById('captionOpacity');
    const resetCaptionPosBtn = document.getElementById('resetCaptionPosBtn');
    const resetCaptionAllBtn = document.getElementById('resetCaptionAllBtn');
    const captionWidthNormalEl = document.getElementById('captionWidthNormal');
    const captionHeightNormalEl = document.getElementById('captionHeightNormal');
    const captionWidthFsEl = document.getElementById('captionWidthFs');
    const captionHeightFsEl = document.getElementById('captionHeightFs');
    const captionWidthNormalLabelEl = document.getElementById('captionWidthNormalLabel');
    const captionHeightNormalLabelEl = document.getElementById('captionHeightNormalLabel');
    const captionWidthFsLabelEl = document.getElementById('captionWidthFsLabel');
    const captionHeightFsLabelEl = document.getElementById('captionHeightFsLabel');
    captionFontSizeEl.value = captionSettings.fontSize;
    captionOpacityEl.value = captionSettings.opacity;
    captionWidthNormalEl.value = captionSettings.widthPercent;
    captionHeightNormalEl.value = captionSettings.heightPercent;
    captionWidthFsEl.value = captionSettings.widthPercentFs;
    captionHeightFsEl.value = captionSettings.heightPercentFs;
    captionWidthNormalLabelEl.textContent = captionSettings.widthPercent + '%';
    captionHeightNormalLabelEl.textContent = captionSettings.heightPercent + '%';
    captionWidthFsLabelEl.textContent = captionSettings.widthPercentFs + '%';
    captionHeightFsLabelEl.textContent = captionSettings.heightPercentFs + '%';

    // Áp toàn bộ cài đặt (kể cả icon/title nút thu nhỏ) lần đầu ngay khi mở trang.
    applyCaptionSettings();
    // Expose cho fullscreenchange ở <script> thường (không phải module) phía trên gọi được -
    // xem cùng cách window.__addTranslationLogEntry/window.__appLog đã dùng trong file.
    window.__applyCaptionSettings = applyCaptionSettings;

    // ===== Preview khung phụ đề lúc đang chỉnh Rộng/Cao - xem ghi chú dài ở khai báo hằng
    // CAPTION_PREVIEW_SAMPLE bên dưới. Đặt SAU applyCaptionSettings() lần đầu + SAU khi đã có
    // đủ các biến El phía trên vì hàm dùng chính các biến đó. =====
    const CAPTION_PREVIEW_SAMPLE = 'Đây là dòng phụ đề mẫu để xem trước kích thước khung';
    let captionPreviewHideTimer = null;
    // true khi #inVideoCaptionText đang hiện CHỮ MẪU (không phải câu dịch thật) - chỉ cho phép
    // tự xoá/ẩn lại khung khi cờ này còn true, tránh trường hợp trong lúc đang xem trước thì có
    // câu dịch thật vừa tới (flushFinalBatch ghi đè chữ mẫu bằng chữ thật) mà timer ẩn cũ vẫn
    // chạy - sẽ lỡ tay xoá mất câu dịch thật đang hiện. flushFinalBatch() tự tắt cờ này ngay khi
    // ghi chữ thật vào (xem chỗ gọi bên dưới, trong hàm đó).
    let captionPreviewUsingPlaceholder = false;
    function previewCaptionSize(forceFs) {
      const currentlyHidden = inVideoCaptionEl.style.display === 'none' || inVideoCaptionEl.style.display === '';
      if (currentlyHidden && !inVideoCaptionTextEl.textContent.trim()) {
        inVideoCaptionTextEl.textContent = CAPTION_PREVIEW_SAMPLE;
        captionPreviewUsingPlaceholder = true;
      }
      inVideoCaptionEl.style.display = 'block';
      applyCaptionSettings(forceFs);
      clearTimeout(captionPreviewHideTimer);
      captionPreviewHideTimer = setTimeout(() => {
        if (captionPreviewUsingPlaceholder) {
          inVideoCaptionTextEl.textContent = '';
          inVideoCaptionEl.style.display = 'none';
          captionPreviewUsingPlaceholder = false;
        }
      }, 1500);
    }
    window.__clearCaptionPreviewPlaceholder = () => {
      clearTimeout(captionPreviewHideTimer);
      captionPreviewUsingPlaceholder = false;
    };

    captionFontSizeEl.onchange = () => {
      captionSettings.fontSize = captionFontSizeEl.value;
      previewCaptionSize();
      saveCaptionSettings();
    };
    captionOpacityEl.oninput = () => {
      captionSettings.opacity = parseFloat(captionOpacityEl.value);
      applyCaptionSettings();
      saveCaptionSettings();
    };
    captionWidthNormalEl.oninput = () => {
      captionSettings.widthPercent = parseInt(captionWidthNormalEl.value, 10);
      captionWidthNormalLabelEl.textContent = captionSettings.widthPercent + '%';
      previewCaptionSize(false);
      saveCaptionSettings();
    };
    captionHeightNormalEl.oninput = () => {
      captionSettings.heightPercent = parseInt(captionHeightNormalEl.value, 10);
      captionHeightNormalLabelEl.textContent = captionSettings.heightPercent + '%';
      previewCaptionSize(false);
      saveCaptionSettings();
    };
    captionWidthFsEl.oninput = () => {
      captionSettings.widthPercentFs = parseInt(captionWidthFsEl.value, 10);
      captionWidthFsLabelEl.textContent = captionSettings.widthPercentFs + '%';
      previewCaptionSize(true);
      saveCaptionSettings();
    };
    captionHeightFsEl.oninput = () => {
      captionSettings.heightPercentFs = parseInt(captionHeightFsEl.value, 10);
      captionHeightFsLabelEl.textContent = captionSettings.heightPercentFs + '%';
      previewCaptionSize(true);
      saveCaptionSettings();
    };
    resetCaptionPosBtn.onclick = () => {
      captionSettings.leftPercent = DEFAULT_CAPTION_SETTINGS.leftPercent;
      captionSettings.bottomPercent = DEFAULT_CAPTION_SETTINGS.bottomPercent;
      previewCaptionSize();
      saveCaptionSettings();
    };
    // Nút "Đặt lại tất cả" - đặt lại vị trí + rộng + cao (CẢ 2 bộ thường/toàn màn hình) về mặc
    // định, đồng thời cập nhật lại luôn giá trị hiển thị trên 4 thanh trượt + nhãn % (nếu chỉ
    // đổi captionSettings mà không đổi input.value/label thì thanh trượt vẫn hiện vị trí CŨ dù
    // khung phụ đề thật đã đổi - gây lệch giữa UI và giá trị thật).
    resetCaptionAllBtn.onclick = () => {
      captionSettings.leftPercent = DEFAULT_CAPTION_SETTINGS.leftPercent;
      captionSettings.bottomPercent = DEFAULT_CAPTION_SETTINGS.bottomPercent;
      captionSettings.widthPercent = DEFAULT_CAPTION_SETTINGS.widthPercent;
      captionSettings.heightPercent = DEFAULT_CAPTION_SETTINGS.heightPercent;
      captionSettings.widthPercentFs = DEFAULT_CAPTION_SETTINGS.widthPercentFs;
      captionSettings.heightPercentFs = DEFAULT_CAPTION_SETTINGS.heightPercentFs;
      captionWidthNormalEl.value = captionSettings.widthPercent;
      captionHeightNormalEl.value = captionSettings.heightPercent;
      captionWidthFsEl.value = captionSettings.widthPercentFs;
      captionHeightFsEl.value = captionSettings.heightPercentFs;
      captionWidthNormalLabelEl.textContent = captionSettings.widthPercent + '%';
      captionHeightNormalLabelEl.textContent = captionSettings.heightPercent + '%';
      captionWidthFsLabelEl.textContent = captionSettings.widthPercentFs + '%';
      captionHeightFsLabelEl.textContent = captionSettings.heightPercentFs + '%';
      previewCaptionSize();
      saveCaptionSettings();
    };

    // ===== Preset cỡ nhanh (Gọn/Vừa/Rộng) - đọc data-preset-* trực tiếp từ nút bấm thay vì
    // hard-code 6 handler riêng (2 mode x 3 preset), gọn hơn và dễ thêm preset mới sau này chỉ
    // bằng cách thêm nút HTML, không cần sửa JS. mode 'normal' set widthPercent/heightPercent,
    // mode 'fs' set widthPercentFs/heightPercentFs - KHÔNG đụng tới bộ còn lại (giữ đúng 2 bộ
    // giá trị tách biệt như thiết kế cũ, xem ghi chú ở DEFAULT_CAPTION_SETTINGS).
    document.querySelectorAll('.caption-preset-btn').forEach((btn) => {
      btn.onclick = () => {
        const mode = btn.dataset.presetMode; // 'normal' | 'fs'
        const width = parseInt(btn.dataset.presetWidth, 10);
        const height = parseInt(btn.dataset.presetHeight, 10);
        if (mode === 'fs') {
          captionSettings.widthPercentFs = width;
          captionSettings.heightPercentFs = height;
          captionWidthFsEl.value = width;
          captionHeightFsEl.value = height;
          captionWidthFsLabelEl.textContent = width + '%';
          captionHeightFsLabelEl.textContent = height + '%';
          previewCaptionSize(true);
        } else {
          captionSettings.widthPercent = width;
          captionSettings.heightPercent = height;
          captionWidthNormalEl.value = width;
          captionHeightNormalEl.value = height;
          captionWidthNormalLabelEl.textContent = width + '%';
          captionHeightNormalLabelEl.textContent = height + '%';
          previewCaptionSize(false);
        }
        saveCaptionSettings();
      };
    });

    // ===== BUG đã sửa: enterVideoFullscreen() gọi requestFullscreen() RỒI MỚI lockLandscape()
    // (khoá xoay ngang qua plugin native) ở bước SAU - fullscreenchange bắn ra NGAY khi
    // requestFullscreen() resolve, tức là TRƯỚC KHI màn hình thật sự xoay ngang xong. Lúc đó
    // window.__applyCaptionSettings() (gọi từ fullscreenchange ở <script> thường phía trên) đã
    // tính max-height/width theo kích thước #videoStage CŨ (trước khi xoay), sai lệch cho tới
    // khi có tác động nào khác kích hoạt tính lại. Bắt thêm 'resize'/'orientationchange' ở đây
    // để tự tính lại đúng ngay khi kích thước thật đổi (bất kể do xoay màn hình lúc vào
    // fullscreen, xoay tay lúc đang xem, hay các thay đổi layout khác) - chỉ tính lại khi
    // caption đang hiển thị, tránh việc thừa lúc chưa phát video. debounce nhẹ (60ms) vì
    // 'resize' có thể bắn liên tục nhiều lần trong lúc xoay. =====
    let captionResizeTimer = null;
    function scheduleReapplyCaptionSettings() {
      if (inVideoCaptionEl.style.display === 'none') return;
      clearTimeout(captionResizeTimer);
      captionResizeTimer = setTimeout(applyCaptionSettings, 60);
    }
    window.addEventListener('resize', scheduleReapplyCaptionSettings);
    window.addEventListener('orientationchange', scheduleReapplyCaptionSettings);

    // ===== Đọc to bản dịch tiếng Việt (TTS) - xem native/TtsPlugin.kt. Lưu cài đặt riêng
    // (không gộp vào captionSettings) vì đây là hành vi phát âm thanh, khác nhóm với
    // font/vị trí hiển thị chữ. =====
    const TTS_SETTINGS_KEY = 'atun_tts_settings_v1';
    // volume mặc định 100 (tối đa) - xem setTtsVolume() ở TtsBridge.js/TtsPlugin.kt tự nâng
    // thẳng mức stream Trợ năng theo % này luôn, không chỉ set volume tương đối. duckPercent 15
    // = tiếng gốc tự hạ còn 15% mức hiện tại trong lúc đang đọc dịch (hạ mạnh để bản dịch nổi
    // hẳn lên). boostDb 6 = khuếch đại thêm 6dB ngay từ đầu qua LoudnessEnhancer (setTtsBoost) -
    // cả 3 giá trị đổi để bản dịch to hơn âm gốc NGAY TỪ ĐẦU, không cần user tự chỉnh.
    const DEFAULT_TTS_SETTINGS = { enabled: false, rate: 1.0, flushMode: false, volume: 100, duckPercent: 15, boostDb: 6 };

    function loadTtsSettings() {
      try {
        return { ...DEFAULT_TTS_SETTINGS, ...JSON.parse(localStorage.getItem(TTS_SETTINGS_KEY) || '{}') };
      } catch (e) {
        return { ...DEFAULT_TTS_SETTINGS };
      }
    }
    function saveTtsSettings() {
      localStorage.setItem(TTS_SETTINGS_KEY, JSON.stringify(ttsSettings));
    }

    let ttsSettings = loadTtsSettings();

    // Cầu nối cho lyrics-sync ở <script> thường phía trên (showLyricCue()) gọi đọc-to được câu
    // dịch của lời bài hát - cùng cách các window.__xxx khác ở file này bắc cầu giữa 2 scope
    // script. Chỉ đọc ttsSettings TẠI THỜI ĐIỂM GỌI (không phải lúc khai báo hàm này) nên vẫn
    // theo đúng cài đặt bật/tắt TTS người dùng chỉnh sau đó.
    window.__speakIfTtsEnabled = (text) => {
      if (ttsSettings.enabled) speakTranslation(text, { flushMode: ttsSettings.flushMode });
    };

    const ttsEnabledEl = document.getElementById('ttsEnabled');
    const ttsControlsEl = document.getElementById('ttsControls');
    const ttsRateEl = document.getElementById('ttsRate');
    const ttsRateLabelEl = document.getElementById('ttsRateLabel');
    const ttsFlushModeEl = document.getElementById('ttsFlushMode');
    const ttsVolumeControlsEl = document.getElementById('ttsVolumeControls');
    const ttsVolumeEl = document.getElementById('ttsVolume');
    const ttsVolumeLabelEl = document.getElementById('ttsVolumeLabel');
    const ttsDuckPercentEl = document.getElementById('ttsDuckPercent');
    const ttsDuckPercentLabelEl = document.getElementById('ttsDuckPercentLabel');
    const ttsBoostDbEl = document.getElementById('ttsBoostDb');
    const ttsBoostDbLabelEl = document.getElementById('ttsBoostDbLabel');
    const ttsVoiceMissingWarningEl = document.getElementById('ttsVoiceMissingWarning');
    const installTtsVoiceBtn = document.getElementById('installTtsVoiceBtn');

    function applyTtsControlsVisibility() {
      // ttsControlsEl (tốc độ đọc, flush mode) vẫn ẩn/hiện theo checkbox "Đọc to bản dịch" vì
      // chỉ có ý nghĩa lúc TTS đang bật. ttsVolumeControlsEl (2 thanh trượt âm lượng) giờ LUÔN
      // hiện sẵn trong card này, không phụ thuộc checkbox - user cần chỉnh cả "âm lượng gốc lúc
      // đọc" (duckPercent) ngay cả khi tự đọc phụ đề, không riêng lúc bật TTS.
      ttsControlsEl.style.display = ttsEnabledEl.checked ? 'flex' : 'none';
    }

    ttsEnabledEl.checked = ttsSettings.enabled;
    ttsRateEl.value = ttsSettings.rate;
    ttsRateLabelEl.textContent = ttsSettings.rate.toFixed(1) + 'x';
    ttsFlushModeEl.checked = ttsSettings.flushMode;
    ttsVolumeEl.value = ttsSettings.volume;
    ttsVolumeLabelEl.textContent = ttsSettings.volume + '%';
    ttsDuckPercentEl.value = ttsSettings.duckPercent;
    ttsDuckPercentLabelEl.textContent = ttsSettings.duckPercent + '%';
    ttsBoostDbEl.value = ttsSettings.boostDb;
    ttsBoostDbLabelEl.textContent = ttsSettings.boostDb + 'dB';
    applyTtsControlsVisibility();

    // Không chạy trong app native (vd xem trước bằng trình duyệt) - ẩn hẳn phần TTS thay vì
    // hiện nút bấm không làm được gì.
    if (!isTtsAvailable()) {
      ttsEnabledEl.closest('div').style.display = 'none';
    }

    ttsEnabledEl.onchange = async () => {
      ttsSettings.enabled = ttsEnabledEl.checked;
      applyTtsControlsVisibility();
      saveTtsSettings();
      if (ttsSettings.enabled) {
        const available = await checkVietnameseVoice();
        ttsVoiceMissingWarningEl.style.display = available ? 'none' : 'block';
      } else {
        stopSpeaking();
      }
    };
    ttsRateEl.oninput = () => {
      ttsSettings.rate = parseFloat(ttsRateEl.value);
      ttsRateLabelEl.textContent = ttsSettings.rate.toFixed(1) + 'x';
      saveTtsSettings();
      setTtsRate(ttsSettings.rate);
    };
    ttsFlushModeEl.onchange = () => {
      ttsSettings.flushMode = ttsFlushModeEl.checked;
      saveTtsSettings();
    };
    ttsVolumeEl.oninput = () => {
      ttsSettings.volume = parseInt(ttsVolumeEl.value, 10);
      ttsVolumeLabelEl.textContent = ttsSettings.volume + '%';
      saveTtsSettings();
      setTtsVolume(ttsSettings.volume / 100);
    };
    ttsDuckPercentEl.oninput = () => {
      ttsSettings.duckPercent = parseInt(ttsDuckPercentEl.value, 10);
      ttsDuckPercentLabelEl.textContent = ttsSettings.duckPercent + '%';
      saveTtsSettings();
      setAutoDuck(true, ttsSettings.duckPercent);
    };
    ttsBoostDbEl.oninput = () => {
      ttsSettings.boostDb = parseInt(ttsBoostDbEl.value, 10);
      ttsBoostDbLabelEl.textContent = ttsSettings.boostDb + 'dB';
      saveTtsSettings();
      setTtsBoost(ttsSettings.boostDb);
    };
    installTtsVoiceBtn.onclick = () => promptInstallVoiceData();

    // Kiểm tra giọng đọc ngay lúc mở app nếu tính năng đang bật từ trước, để báo sớm thay vì
    // để user bật "Bắt đầu nghe" xong mới phát hiện không đọc được gì. Đồng thời đẩy lại
    // volume/duckPercent đã lưu xuống native ngay lúc mở app (native khởi tạo lại mặc định
    // mỗi lần app start, không tự nhớ giữa các phiên).
    if (isTtsAvailable()) {
      setTtsRate(ttsSettings.rate);
      setTtsVolume(ttsSettings.volume / 100);
      setAutoDuck(true, ttsSettings.duckPercent);
      setTtsBoost(ttsSettings.boostDb);
      if (ttsSettings.enabled) {
        checkVietnameseVoice().then((available) => {
          ttsVoiceMissingWarningEl.style.display = available ? 'none' : 'block';
        });
      }
    }

    // Kéo-thả (1 ngón) + pinch-to-resize (2 ngón) bằng Pointer Events (gộp chung mouse + touch).
    // Giới hạn (clamp) vị trí trong khoảng an toàn để không kéo phụ đề ra ngoài khung video/
    // mất hẳn khỏi tầm nhìn - có nút "Đặt lại vị trí" ở trên phòng khi vẫn bị lệch khó tìm.
    (function setupCaptionDragAndPinch() {
      const videoContainerEl = document.getElementById('videoStage');
      // Map pointerId -> {x, y} - theo dõi TẤT CẢ ngón đang chạm trên #inVideoCaption cùng lúc,
      // để phân biệt 1 ngón (kéo-thả vị trí) vs 2 ngón (pinch đổi Rộng/Cao). Pointer Events báo
      // riêng từng ngón qua pointerId, không gộp sẵn như TouchEvent.touches - phải tự quản lý.
      const activePointers = new Map();

      let dragging = false;
      let startClientX = 0, startClientY = 0;
      let startLeftPercent = 0, startBottomPercent = 0;

      // Pinch dùng lại ĐÚNG các thanh trượt/preset Rộng-Cao đã có (captionWidthNormal(Fs)/
      // captionHeightNormal(Fs)) - áp vào đúng bộ giá trị "thường" hay "toàn màn hình" tuỳ
      // isCaptionFullscreen() lúc bắt đầu chụm (không đổi bộ giữa chừng nếu lỡ xoay màn hình
      // trong lúc đang pinch, tránh giật/nhảy giá trị).
      let pinching = false;
      let pinchFsMode = false;
      let pinchStartDist = 0;
      let pinchStartWidthPercent = 0;
      let pinchStartHeightPercent = 0;

      function pointerDistance() {
        const pts = [...activePointers.values()];
        if (pts.length < 2) return 0;
        const dx = pts[0].x - pts[1].x;
        const dy = pts[0].y - pts[1].y;
        return Math.sqrt(dx * dx + dy * dy);
      }

      // Đồng bộ thanh trượt + nhãn % theo captionSettings hiện tại, đúng bộ đang pinch (không
      // phải bộ theo trạng thái fullscreen THẬT lúc gọi hàm, vì lúc đang pinch có thể tạm khác -
      // xem pinchFsMode ở trên) - để UI trang cài đặt luôn khớp với khung phụ đề thật.
      function syncSliderUi(fsMode) {
        if (fsMode) {
          captionWidthFsEl.value = captionSettings.widthPercentFs;
          captionHeightFsEl.value = captionSettings.heightPercentFs;
          captionWidthFsLabelEl.textContent = captionSettings.widthPercentFs + '%';
          captionHeightFsLabelEl.textContent = captionSettings.heightPercentFs + '%';
        } else {
          captionWidthNormalEl.value = captionSettings.widthPercent;
          captionHeightNormalEl.value = captionSettings.heightPercent;
          captionWidthNormalLabelEl.textContent = captionSettings.widthPercent + '%';
          captionHeightNormalLabelEl.textContent = captionSettings.heightPercent + '%';
        }
      }

      inVideoCaptionEl.addEventListener('pointerdown', (e) => {
        try { inVideoCaptionEl.setPointerCapture(e.pointerId); } catch {}
        activePointers.set(e.pointerId, { x: e.clientX, y: e.clientY });

        if (activePointers.size === 2) {
          // Ngón thứ 2 vừa chạm xuống trong lúc đang kéo bằng ngón đầu -> huỷ kéo-thả, chuyển
          // hẳn sang pinch-resize (không làm cả 2 cùng lúc, dễ loạn giá trị).
          dragging = false;
          pinching = true;
          pinchFsMode = isCaptionFullscreen();
          pinchStartDist = pointerDistance();
          pinchStartWidthPercent = pinchFsMode ? captionSettings.widthPercentFs : captionSettings.widthPercent;
          pinchStartHeightPercent = pinchFsMode ? captionSettings.heightPercentFs : captionSettings.heightPercent;
        } else if (activePointers.size === 1 && !pinching) {
          dragging = true;
          inVideoCaptionEl.style.cursor = 'grabbing';
          startClientX = e.clientX;
          startClientY = e.clientY;
          startLeftPercent = captionSettings.leftPercent;
          startBottomPercent = captionSettings.bottomPercent;
        }
      });

      inVideoCaptionEl.addEventListener('pointermove', (e) => {
        if (!activePointers.has(e.pointerId)) return;
        activePointers.set(e.pointerId, { x: e.clientX, y: e.clientY });

        if (pinching && activePointers.size === 2) {
          if (pinchStartDist <= 0) return;
          const scale = pointerDistance() / pinchStartDist;
          const wKey = pinchFsMode ? 'widthPercentFs' : 'widthPercent';
          const hKey = pinchFsMode ? 'heightPercentFs' : 'heightPercent';
          // Giới hạn theo ĐÚNG min/max của 2 thanh trượt Rộng/Cao hiện có (30-100 / 10-60) -
          // pinch chỉ là cách nhập nhanh hơn cho cùng 1 khoảng giá trị, không mở rộng thêm.
          captionSettings[wKey] = Math.round(clamp(pinchStartWidthPercent * scale, 30, 100));
          captionSettings[hKey] = Math.round(clamp(pinchStartHeightPercent * scale, 10, 60));
          syncSliderUi(pinchFsMode);
          applyCaptionSettings(pinchFsMode);
          return;
        }

        if (dragging && activePointers.size === 1) {
          const rect = videoContainerEl.getBoundingClientRect();
          if (rect.width === 0 || rect.height === 0) return;
          const dxPercent = ((e.clientX - startClientX) / rect.width) * 100;
          // gravity bottom: kéo LÊN (dy âm, vì toạ độ màn hình tăng dần xuống) phải TĂNG bottomPercent.
          const dyPercent = ((e.clientY - startClientY) / rect.height) * 100;
          captionSettings.leftPercent = clamp(startLeftPercent + dxPercent, 10, 90);
          captionSettings.bottomPercent = clamp(startBottomPercent - dyPercent, 2, 88);
          applyCaptionSettings();
        }
      });

      const endPointer = (e) => {
        activePointers.delete(e.pointerId);
        if (pinching && activePointers.size < 2) {
          pinching = false;
          saveCaptionSettings();
        }
        if (dragging && activePointers.size === 0) {
          dragging = false;
          inVideoCaptionEl.style.cursor = 'grab';
          saveCaptionSettings();
        }
      };
      inVideoCaptionEl.addEventListener('pointerup', endPointer);
      inVideoCaptionEl.addEventListener('pointercancel', endPointer);
    })();

    // ===== Dịch theo CỤM câu thay vì từng câu final lẻ =====
    // Vosk chốt câu "final" khá dày khi người nói liên tục - dịch ngay từng câu vừa tốn
    // nhiều request (dễ 429 với endpoint free, tốn quota với groq) vừa mất ngữ cảnh giữa các
    // câu liền kề (câu sau có thể phụ thuộc ý câu trước). Thay vào đó: gom các câu final đến
    // trong một cửa sổ ngắn (FINAL_BATCH_WINDOW_MS) thành 1 cụm, dịch 1 lần bằng 1 request rồi
    // tách kết quả trở lại theo dòng để log + hiển thị.
    const FINAL_BATCH_WINDOW_MS = 700;
    let finalBatchBuffer = [];
    let finalBatchTimer = null;

    function pushFinalToBatch(text, detectedLang) {
      // detectedLang: chỉ có giá trị ở chế độ "Tự động nhận diện" (xem onFinal) - lưu kèm từng
      // câu (không chỉ dùng 1 giá trị chung cho cả batch) vì người nói có thể đổi ngôn ngữ ngay
      // giữa 1 cửa sổ batch ngắn (FINAL_BATCH_WINDOW_MS=700ms) - xem flushFinalBatch().
      finalBatchBuffer.push({ text, lang: detectedLang || null });
      // Nếu đã có timer đang đợi thì không đặt thêm - câu mới sẽ tự được gộp vào cùng batch
      // khi timer đó bắn (tránh dịch bị trễ vô hạn nếu người nói liên tục không ngừng).
      if (!finalBatchTimer) {
        finalBatchTimer = setTimeout(flushFinalBatch, FINAL_BATCH_WINDOW_MS);
      }
    }

    function flushFinalBatch() {
      finalBatchTimer = null;
      if (finalBatchBuffer.length === 0) return;
      const batch = finalBatchBuffer;
      finalBatchBuffer = [];
      const texts = batch.map((b) => b.text);

      // Xếp vào hàng đợi tuần tự (giống trước đây): nếu 2 batch liền kề vẫn dồn lại thì
      // chạy lần lượt, không cùng lúc, tránh bắn dồn request gây 429.
      queueTranslate(async () => {
        try {
          const joined = texts.join('\n');
          // Ngôn ngữ nguồn dùng cho cả cụm: ở chế độ 1 ngôn ngữ cố định, dùng thẳng
          // sourceLangEl.value như trước. Ở chế độ "auto" (sourceLangEl.value === 'auto'), MỖI
          // câu có thể được native gắn 1 detectedLang KHÁC NHAU (người nói đổi ngôn ngữ giữa
          // chừng) - chỉ coi cả cụm là 1 ngôn ngữ (để dùng nhánh ML Kit on-device nhanh hơn) khi
          // TẤT CẢ câu trong cụm cùng chung 1 detectedLang; nếu cụm lẫn nhiều ngôn ngữ (hoặc
          // native chưa xác định được câu nào) thì để null - translateText() sẽ bỏ qua ML Kit
          // (vốn không tự nhận diện được ngôn ngữ) và đi thẳng Groq/Google Translate free, cả 2
          // đều tự nhận diện ngôn ngữ nguồn theo nội dung văn bản.
          const effectiveSourceLang = sourceLangEl.value === 'auto'
            ? (batch.every((b) => b.lang && b.lang === batch[0].lang) ? batch[0].lang : null)
            : sourceLangEl.value;
          // Nếu nguồn đã là tiếng Việt thì không cần dịch nữa.
          const translated = effectiveSourceLang === 'vi' ? joined : await translateText(joined, 'vi', effectiveSourceLang);
          const translatedLines = translated.split('\n');

          // Caption hiện tại luôn là câu MỚI NHẤT trong cụm vừa dịch - CHỈ dùng
          // translatedLines[cuối] khi số dòng khớp batch.length (endpoint dịch có giữ \n
          // đúng). Nếu KHÔNG khớp (Google Translate free/groq gộp cả cụm nhiều câu lại thành 1
          // đoạn liền, không giữ xuống dòng - hay gặp với câu ngắn/ASR rời rạc) thì
          // translatedLines chỉ có 1 phần tử là NGUYÊN CỤM DÀI - tuyệt đối không lấy phần tử đó
          // làm caption (gây caption phình to che gần hết video). Dịch RIÊNG câu cuối cùng (1
          // lệnh dịch nhỏ, phụ) chỉ để có caption đúng kích thước 1 câu.
          let lastTranslated;
          if (translatedLines.length === texts.length) {
            lastTranslated = translatedLines[translatedLines.length - 1];
          } else {
            const lastOriginal = texts[texts.length - 1];
            try {
              lastTranslated = effectiveSourceLang === 'vi' ? lastOriginal : await translateText(lastOriginal, 'vi', effectiveSourceLang);
            } catch {
              lastTranslated = lastOriginal; // dịch riêng cũng lỗi - hiện tạm câu gốc còn hơn hiện nguyên cụm dài
            }
          }
          finalTranslatedEl.textContent = lastTranslated;
          // Câu dịch THẬT vừa tới - nếu đúng lúc này khung đang hiện chữ mẫu do người dùng vừa
          // chỉnh thanh trượt Rộng/Cao (xem previewCaptionSize()), phải huỷ ngay cờ + timer ẩn
          // tạm đó - nếu không, timer cũ (đặt để tự xoá CHỮ MẪU sau 1.5s) sẽ chạy tới và xoá
          // luôn câu dịch thật này.
          window.__clearCaptionPreviewPlaceholder?.();
          inVideoCaptionTextEl.textContent = lastTranslated;
          inVideoCaptionEl.style.display = 'block';
          // Lần hiện đầu tiên (video vừa phát xong, trước đó #videoStage display:none nên
          // getBoundingClientRect() trong applyCaptionSettings() trả về height=0, bỏ qua bước
          // set max-height) - gọi lại đây để tính đúng max-height thật ngay khi có kích thước.
          // applyCaptionSettings() giờ tự đồng bộ luôn sang "Web mini" ở cuối hàm (xem
          // window.pushCaptionToWebMini bên trong) nên không cần gọi pushCaptionToWebMini()
          // riêng ở đây nữa như trước.
          applyCaptionSettings();

          // Đọc to TOÀN BỘ cụm vừa dịch (không chỉ lastTranslated) để không bỏ sót câu nào
          // nếu batch gộp nhiều câu lại (xem pushFinalToBatch/FINAL_BATCH_WINDOW_MS).
          if (ttsSettings.enabled) {
            speakTranslation(translated, { flushMode: ttsSettings.flushMode });
          }

          // Log từng cặp gốc/dịch theo dòng khi số dòng dịch về khớp số câu gốc gửi đi; nếu
          // dịch máy gộp/tách dòng khác đi (số dòng lệch), log nguyên cụm gộp để không ghép
          // sai cặp gốc/dịch.
          if (translatedLines.length === texts.length) {
            texts.forEach((orig, i) => window.__addTranslationLogEntry?.(orig, translatedLines[i]));
          } else {
            window.__addTranslationLogEntry?.(texts.join(' / '), translated);
          }
        } catch (err) {
          moduleLog('LỖI khi dịch: ' + err.message);
        }
      });
    }
    const sourceLangEl = document.getElementById('sourceLang');
    const captureModeEl = document.getElementById('captureMode');
    const smartPauseEl = document.getElementById('smartPause');

    // Đếm số giây IM LẶNG liên tục dựa trên sự kiện audioLevel (bắn mỗi ~1s từ native).
    // Ngưỡng lấy theo AudioCaptureService.SILENCE_WARNING_SECONDS (giữ đồng bộ thủ công vì
    // native/JS không share hằng số) - quá ngưỡng thì hiện banner cảnh báo thay vì chỉ log console,
    // vì người dùng thường không mở log để biết vì sao không có phụ đề.
    const SILENCE_WARNING_SECONDS = 8;
    let consecutiveSilentSeconds = 0;
    let audioLevelTickCount = 0; // đếm số lần audioLevel bắn - dùng để throttle dòng log verbose (mỗi 5 lần mới in)
    let isCapturing = false;
    // Hàng đợi tuần tự riêng cho Whisper Cloud - giữ ĐÚNG THỨ TỰ câu (quan trọng cho phụ đề,
    // khác với dịch text vốn không lệch thứ tự nhiều). Cùng ý tưởng translateQueue nhưng tách
    // riêng vì đây là bước NHẬN DẠNG (trước dịch), không phải bước dịch.
    let cloudSttQueue = Promise.resolve();

    function setCapturingUi(capturing) {
      isCapturing = capturing;
      window.__isCapturing = capturing; // đọc từ script không phải module (xem updateSourceLangHint)
      mainToggleBtn.textContent = capturing ? '⏹️ Dừng nghe' : '▶️ Bắt đầu nghe';
      mainToggleBtn.classList.toggle('stopping', capturing);
      sourceLangEl.disabled = capturing;
      captureModeEl.disabled = capturing;
      smartPauseEl.disabled = capturing;
      cloudSttEl.disabled = capturing;
      preferExternalMicEl.disabled = capturing;
    }

    const switchToMicBtnEl = document.getElementById('switchToMicBtn');

    // ===== Khối "Ưu tiên micro ngoài" - chỉ hiện khi captureMode='mic'. externalMicStatusEl
    // hiện 2 loại thông tin khác nhau tuỳ thời điểm:
    // - Lúc CHƯA bắt đầu nghe: kết quả listInputDevices() (chỉ dò danh sách thiết bị đang cắm,
    //   KHÔNG chọn/route gì) - để user biết trước có nên tick hay không.
    // - Lúc ĐANG nghe: kết quả THẬT từ sự kiện micDeviceInfo (native đã chọn xong thiết bị) -
    //   ghi đè status ở trên vì đây mới là trạng thái chính xác nhất.
    async function refreshExternalMicStatus() {
      if (captureModeEl.value !== 'mic' || !preferExternalMicEl.checked) {
        externalMicStatusEl.textContent = '';
        return;
      }
      if (isCapturing) return; // đang nghe thì để nguyên status thật từ onMicDeviceInfo, không ghi đè bằng kết quả dò lại
      try {
        const devices = await capture.listInputDevices();
        externalMicStatusEl.textContent = devices.length
          ? 'Đã phát hiện: ' + devices.map((d) => d.label).join(', ')
          : 'Chưa phát hiện micro ngoài đang kết nối - sẽ tạm dùng micro trong máy.';
      } catch (e) {
        externalMicStatusEl.textContent = ''; // chạy ngoài app native (dev trên browser) - bỏ qua im lặng
      }
    }
    window.__refreshExternalMicStatus = refreshExternalMicStatus;

    function updateExternalMicUi() {
      externalMicRowEl.style.display = captureModeEl.value === 'mic' ? 'block' : 'none';
      refreshExternalMicStatus();
    }
    window.__updateExternalMicUi = updateExternalMicUi;
    // KHÔNG gọi updateExternalMicUi() ngay ở đây - `capture` (NativeCaptureBridge) còn chưa
    // được khai báo (const phía dưới, temporal dead zone). Gọi lần đầu ngay sau khi khai báo
    // xong `capture` (xem đoạn `const capture = new NativeCaptureBridge(...)` bên dưới).

    // ===== Auto-fallback system -> mic khi phát hiện chặn chắc chắn (code SYSTEM_CAPTURE_BLOCKED
    // từ native), và chuyển tay khi user bấm nút trong banner cảnh báo im lặng kéo dài. Dùng
    // chung 1 hàm cho cả 2 trường hợp để không lặp code. autoFallbackInProgress chặn gọi
    // chồng nếu lỡ nhận nhiều sự kiện lỗi liên tiếp trong lúc đang chuyển. =====
    let autoFallbackInProgress = false;
    async function switchToMicAndRestart(reason) {
      if (autoFallbackInProgress) return;
      autoFallbackInProgress = true;
      try {
        moduleLog(
          reason === 'auto'
            ? 'Tự động chuyển sang ghi âm qua micro (audio hệ thống bị chặn).'
            : 'Đang chuyển sang ghi âm qua micro theo yêu cầu...'
        );
        try { await capture.stop(); } catch (e) { /* có thể chưa capture gì, bỏ qua */ }

        captureModeEl.value = 'mic';
        saveSettings({ captureMode: 'mic' });
        silenceWarningEl.style.display = 'none';
        consecutiveSilentSeconds = 0;
        modelStatusEl.textContent = 'Model: đang tải...';
        resetModelLoadingProgressUi();

        await capture.start(sourceLangEl.value, 'mic', smartPauseEl.checked, cloudSttEl.checked, preferExternalMicEl.checked);
        setCapturingUi(true);
        moduleLog('Đã chuyển sang micro, đang nghe.');
      } catch (err) {
        moduleLog('LỖI khi chuyển sang micro: ' + err.message);
        setCapturingUi(false);
      } finally {
        autoFallbackInProgress = false;
      }
    }
    switchToMicBtnEl.onclick = () => switchToMicAndRestart('manual');

    const capture = new NativeCaptureBridge({
      onModelStatus: (ready) => {
        modelStatusEl.textContent = ready ? 'Model: đã sẵn sàng, đang nghe...' : 'Model: đang tải...';
        if (ready) resetModelLoadingProgressUi(); // xong rồi thì ẩn progress bar (nếu có hiện)
      },
      onModelLoadingProgress,
      onPartial: (text) => {
        partialEl.textContent = text;
      },
      onFinal: (text, confidence, detectedLang) => {
        if (!text) return;
        finalOriginalEl.textContent = text; // hiện câu gốc ngay, không đợi dịch xong
        partialEl.textContent = '';
        const confPct = confidence >= 0 ? Math.round(confidence * 100) + '%' : '?';
        // detectedLang chỉ có giá trị ở chế độ "Tự động nhận diện" (sourceLang == 'auto') - log
        // kèm để user biết bộ nhận diện song song vừa chọn ngôn ngữ nào cho câu này.
        const langTag = detectedLang ? '[phát hiện: ' + detectedLang + '] ' : '';
        moduleLog('[final] (' + confPct + ') ' + langTag + text);
        pushFinalToBatch(text, detectedLang);
      },
      // Câu bị native lọc bỏ vì độ tin cậy quá thấp (VoskEngine.CONFIDENCE_DROP_THRESHOLD) -
      // thường là nghe nhầm nhạc/nhiễu nền thành lời nói. Chỉ log để biết VAD/lọc đang hoạt
      // động, KHÔNG đẩy vào pushFinalToBatch (không dịch, không hiện lên UI chính) - tránh dịch
      // rác tốn API và làm phụ đề nhiễu.
      onLowConfidence: (text, confidence) => {
        const confPct = confidence >= 0 ? Math.round(confidence * 100) + '%' : '?';
        moduleLog('[bỏ qua - độ tin cậy thấp ' + confPct + '] ' + text);
      },
      onError: (message, code) => {
        moduleLog('LỖI capture: ' + message);
        // SYSTEM_CAPTURE_BLOCKED = native đã xác nhận chắc chắn build AudioRecord thất bại
        // (không phải chỉ im lặng nghi ngờ) - an toàn để tự động chuyển sang micro luôn,
        // không cần chờ user bấm nút. Chỉ tự động khi đang ở mode 'system' (tránh vòng lặp
        // vô nghĩa nếu lỗi này lỡ xảy ra khi đã ở mic).
        if (code === 'SYSTEM_CAPTURE_BLOCKED' && captureModeEl.value === 'system') {
          switchToMicAndRestart('auto');
        }
      },
      // Mỗi giây nhận mức tín hiệu audio thực tế AudioRecord đọc được, để biết capture có
      // đang nhận audio thật hay chỉ toàn silence (bị chặn/mute). peak thang PCM16: 0..32767.
      // peak < ~50 coi như im lặng. Logic đếm im lặng/banner cảnh báo vẫn chạy ĐỦ mỗi giây (an
      // toàn cho độ chính xác), nhưng dòng log() text chỉ in mỗi 5 lần (~5s) - in mỗi giây suốt
      // hàng giờ capture chỉ tốn CPU dựng chuỗi + IO liên tục cho 1 dòng gần như lặp lại giá trị.
      onAudioLevel: (data) => {
        audioLevelTickCount++;
        if (audioLevelTickCount % 5 === 0) {
          const status = data.peak < 50 ? '🔇 IM LẶNG' : '🔊 có audio';
          moduleLog(
            `[audio] peak=${data.peak} (${status}) | reads=${data.readCalls} `
            + `silent=${data.silentReads} bad=${data.badReads}`
          );
        }

        if (data.peak < 50) {
          consecutiveSilentSeconds++;
        } else {
          consecutiveSilentSeconds = 0;
        }

        if (consecutiveSilentSeconds >= SILENCE_WARNING_SECONDS) {
          silenceSecondsEl.textContent = String(consecutiveSilentSeconds);
          silenceWarningEl.style.display = 'block';
          // Nút "chuyển sang micro" chỉ có ý nghĩa khi đang ở mode 'system' - nếu đã ở mic
          // mà vẫn im lặng thì đây là im lặng thật (video không có tiếng), không phải bị chặn.
          switchToMicBtnEl.style.display = captureModeEl.value === 'system' ? 'inline-block' : 'none';
        } else {
          silenceWarningEl.style.display = 'none';
        }
      },
      // Bắn khi service tự phục hồi capture sau khi bị OS kill (chỉ ở chế độ mic - chế độ
      // system không tự phục hồi được vì token MediaProjection chỉ dùng 1 lần).
      onCaptureResumed: (mode) => {
        moduleLog('Đã tự phục hồi capture sau khi bị hệ thống dừng (mode=' + mode + ').');
        modelStatusEl.textContent = 'Model: đã sẵn sàng, đang nghe... (vừa tự phục hồi)';
        setCapturingUi(true);
      },
      // 1 đoạn audio đã được native cắt theo câu (VAD) sẵn sàng để upload lên Whisper Cloud
      // (chỉ bắn khi cloudSttEnabled đang bật lúc start - xem AudioCaptureService). Xếp hàng
      // tuần tự (cloudSttQueue) để giữ đúng thứ tự câu dù mạng có thể trả về không đều.
      onCloudSttSegment: (wavBase64, sourceLang) => {
        cloudSttQueue = cloudSttQueue.then(async () => {
          if (!isCapturing) return; // đã dừng nghe giữa lúc đoạn cuối còn đang xếp hàng - bỏ qua
          try {
            modelStatusEl.textContent = 'Model: đã sẵn sàng, đang nghe... (🌩️ đang nhận dạng đoạn vừa nói)';
            const text = await transcribeCloudSegment(wavBase64, sourceLang);
            if (isCapturing) modelStatusEl.textContent = 'Model: đã sẵn sàng, đang nghe...';
            if (!text) return;
            moduleLog('[whisper-cloud] ' + text);
            pushFinalToBatch(text, sourceLang === 'auto' ? null : sourceLang);
          } catch (err) {
            moduleLog('LỖI Whisper Cloud: ' + err.message);
          }
        });
      },
      // Kết quả THẬT native đã chọn cho MODE_MIC (sau khi cân nhắc checkbox "Ưu tiên micro
      // ngoài" + thiết bị thực tế đang cắm) - ghi đè status vốn chỉ là dò trước
      // (refreshExternalMicStatus). usedExternal=false không phải lỗi - có thể do user không
      // tick, hoặc có tick nhưng không tìm thấy thiết bị ngoài nào lúc bắt đầu nghe.
      onMicDeviceInfo: (usedExternal, label) => {
        moduleLog('[micro] ' + label);
        if (captureModeEl.value === 'mic') {
          externalMicStatusEl.textContent = (usedExternal ? '🎧 Đang dùng: ' : '📱 Đang dùng: ') + label;
        }
      },
    });
    updateExternalMicUi(); // giờ `capture` đã sẵn sàng - áp dụng trạng thái hiện/ẩn + dò thiết bị lần đầu

    // Ghi % pin lúc bắt đầu/kết thúc 1 phiên nghe để có SỐ LIỆU HAO PIN THẬT tích luỹ qua
    // nhiều phiên trong file log (đọc lại bằng nút "Chia sẻ log lỗi") - không cần cắm máy vào
    // Android Studio Profiler hay cài app đo pin riêng. sessionStartBattery/sessionStartAt = null
    // khi không lấy được % pin (vd chạy ngoài app native) - bỏ qua ghi log trong trường hợp đó.
    let sessionStartBattery = null;
    let sessionStartAt = 0;

    // Trước đây % pin hao + thời lượng phiên CHỈ nằm trong file log lỗi (phải bấm "Chia sẻ log"
    // mới thấy) - giờ hiện trực tiếp ngay trên UI chính (#sessionInfo), tự cập nhật mỗi 30s
    // trong lúc đang nghe, không cần đợi phiên kết thúc mới biết.
    const sessionInfoEl = document.getElementById('sessionInfo');
    let sessionInfoTimer = null;

    function updateSessionInfoUi() {
      if (sessionStartBattery == null) { sessionInfoEl.textContent = ''; return; }
      const minutes = Math.round((Date.now() - sessionStartAt) / 60000);
      sessionInfoEl.textContent = `Phiên hiện tại: ${minutes} phút · pin lúc bắt đầu ${sessionStartBattery}%`;
    }

    function startSessionInfoTimer() {
      stopSessionInfoTimer();
      updateSessionInfoUi();
      sessionInfoTimer = setInterval(updateSessionInfoUi, 30000);
    }

    function stopSessionInfoTimer() {
      if (sessionInfoTimer) { clearInterval(sessionInfoTimer); sessionInfoTimer = null; }
    }

    async function logBatterySessionEnd() {
      stopSessionInfoTimer();
      if (sessionStartBattery == null) { sessionInfoEl.textContent = ''; return; } // không lấy được pin lúc start - bỏ qua
      const endBattery = await getBatteryPercent();
      if (endBattery == null) { sessionInfoEl.textContent = ''; return; }
      const minutes = Math.round((Date.now() - sessionStartAt) / 60000);
      const drop = sessionStartBattery - endBattery;
      const line = `PIN: phiên nghe ${minutes} phút, pin ${sessionStartBattery}% -> ${endBattery}%`
        + (drop > 0 ? ` (hao ${drop}%)` : drop < 0 ? ' (đang sạc trong lúc nghe)' : ' (không đổi)');
      moduleLog(line);
      sessionInfoEl.textContent = line; // để lại kết quả phiên vừa xong ngay trên UI chính, không phải mở log
      // Ghi thẳng vào file log cục bộ (cùng chỗ với log lỗi/crash) để tích luỹ số liệu qua
      // nhiều phiên/nhiều ngày - xem lại bằng nút "Chia sẻ log lỗi" đã có sẵn ở khung debug.
      await appendErrorLog(line);
      sessionStartBattery = null;
    }

    // Tách riêng luồng "bắt đầu nghe" khỏi onclick của mainToggleBtn để dùng chung được cho
    // nút "🔄 Kết nối lại ngay" trong banner lostSessionWarning (Điều kiện 9/10: reconnect
    // 1-click) - cả 2 chỗ gọi cùng 1 hàm, luôn dùng lại ĐÚNG lựa chọn hiện tại của user trong
    // sourceLang/captureMode/smartPause (không reset về mặc định), nên user không phải chỉnh
    // lại gì trước khi bấm lại. Giới hạn CỨNG không sửa được: chế độ "system" luôn cần Android
    // hỏi lại quyền MediaProjection (dialog hệ thống) - đây là 1-click PHÍA APP, dialog OS sau
    // đó vẫn cần 1 lần chạm "Bắt đầu" từ user (bảo mật OS, không có API nào bỏ qua được).
    async function startCaptureFlow() {
      const sourceLang = sourceLangEl.value;
      const captureMode = captureModeEl.value;
      const smartPause = smartPauseEl.checked;
      const cloudStt = cloudSttEl.checked;
      const preferExternalMic = preferExternalMicEl.checked;

      // Kiểm tra lại (phòng trường hợp UI chưa kịp disable nút, vd. vừa đổi sourceLang) -
      // tránh start service rồi mới nhận lỗi "chưa tải model" từ native. BỎ QUA khi cloudStt
      // bật: Whisper Cloud không cần model Vosk tải sẵn (xem ghi chú cloudSttEl trong markup).
      if (!cloudStt) {
        const modelReady = await (window.__isSourceLangModelReady?.(sourceLang) ?? true);
        if (!modelReady) {
          moduleLog('Chưa tải model cho "' + sourceLang + '" - tải ở mục "Quản lý mô hình ngôn ngữ" trước.');
          return;
        }
      }

      modelStatusEl.textContent = 'Model: đang tải...';
      resetModelLoadingProgressUi();
      silenceWarningEl.style.display = 'none';
      lostSessionWarningEl.style.display = 'none';
      consecutiveSilentSeconds = 0;
      try {
        await capture.start(sourceLang, captureMode, smartPause, cloudStt, preferExternalMic);
        setCapturingUi(true);
        moduleLog(
          'Đã start capture (mode=' + captureMode + ', sourceLang=' + sourceLang
          + ', cloudStt=' + cloudStt + ').'
          + (captureMode === 'system' ? ' Giờ mở YouTube (hoặc app khác) và phát video.' : ' Giờ phát audio qua loa ngoài.')
        );
        sessionStartBattery = await getBatteryPercent();
        sessionStartAt = Date.now();
      } catch (err) {
        moduleLog('LỖI khi start capture: ' + err.message);
        modelStatusEl.textContent = 'Model: lỗi - ' + err.message;
        resetModelLoadingProgressUi();
      }
    }

    // 1 nút duy nhất Start/Stop thay cho 2 nút rời rạc trước đây (Phase 2).
    mainToggleBtn.onclick = async () => {
      if (isCapturing) {
        try {
          await capture.stop();
          modelStatusEl.textContent = 'Model: đã dừng';
          resetModelLoadingProgressUi();
          silenceWarningEl.style.display = 'none';
          moduleLog('Đã dừng capture.');
          await logBatterySessionEnd();
          stopSpeaking();
        } catch (err) {
          moduleLog('LỖI khi dừng capture: ' + err.message);
        } finally {
          setCapturingUi(false);
          refreshExternalMicStatus(); // dò lại (status "Đang dùng: ..." của phiên vừa xong đã hết hiệu lực)
        }
        return;
      }
      await startCaptureFlow();
    };

    // Nút "🔄 Kết nối lại ngay" trong banner lostSessionWarning - 1 chạm gọi thẳng lại đúng
    // luồng start (giữ nguyên lựa chọn ngôn ngữ/nguồn audio hiện tại), không bắt user phải tự
    // tìm và bấm nút "Bắt đầu nghe" ở nơi khác trên trang.
    document.getElementById('reconnectNowBtn').onclick = async () => {
      lostSessionWarningEl.style.display = 'none';
      await startCaptureFlow();
    };

    // Kiểm tra ngay khi mở app: nếu lần chạy trước bị hệ thống âm thầm dừng giữa chừng
    // (mode=system, không tự phục hồi được), báo cho user biết thay vì im lặng.
    capture.checkLostSession().then((lost) => {
      if (lost) {
        lostSessionWarningEl.style.display = 'block';
        moduleLog('Phát hiện phiên nghe trước bị hệ thống dừng giữa chừng (chưa tự phục hồi được).');
        // Cuộn banner (có nút "Kết nối lại ngay" ngay trong đó) vào giữa màn hình - trước đây
        // cuộn tới mainToggleBtn ở nơi khác trên trang rồi bắt user tự nhớ lựa chọn cũ, giờ
        // banner tự chứa luôn hành động cần làm nên cuộn tới chính banner hợp lý hơn. Vẫn giữ
        // hiệu ứng nhấp nháy 'attention-pulse' (xem CSS) trên chính banner để dễ nhận ra.
        lostSessionWarningEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
        lostSessionWarningEl.classList.add('attention-pulse');
        lostSessionWarningEl.addEventListener('animationend', () => {
          lostSessionWarningEl.classList.remove('attention-pulse');
        }, { once: true });
      }
    }).catch((err) => moduleLog('Lỗi checkLostSession: ' + err.message));

    // ===== Chia sẻ / xoá log lỗi cục bộ (Hạng mục D) =====
    const errorLogStatusEl = document.getElementById('errorLogStatus');
    document.getElementById('shareErrorLogBtn').onclick = async () => {
      try {
        const content = await getErrorLog();
        if (!content || !content.trim()) {
          errorLogStatusEl.textContent = 'Chưa có lỗi/crash nào được ghi lại.';
          return;
        }
        await shareExportFile(content, 'atun_error_log.txt', 'text/plain');
        errorLogStatusEl.textContent = 'Đã mở hộp thoại chia sẻ log lỗi.';
      } catch (err) {
        errorLogStatusEl.textContent = 'Lỗi khi chia sẻ log: ' + err.message;
      }
    };
    document.getElementById('clearErrorLogBtn').onclick = async () => {
      try {
        await clearErrorLog();
        errorLogStatusEl.textContent = 'Đã xoá log lỗi cục bộ.';
      } catch (err) {
        errorLogStatusEl.textContent = 'Lỗi khi xoá log: ' + err.message;
      }
    };

    // Nếu lần mở trước app đã crash, AppLog sẽ có nội dung ngay khi mở app lần này -
    // chủ động báo cho user biết thay vì chờ họ tự nhớ ra để bấm nút chia sẻ.
    getErrorLog().then((content) => {
      if (content && content.trim()) {
        errorLogStatusEl.textContent = 'Có log lỗi/crash từ trước - bấm "Chia sẻ log lỗi" để gửi.';
      }
    }).catch(() => {});

    // ===== Chia sẻ / xoá phản hồi "model dịch sai" (nút 👎 trong danh sách model) =====
    const modelFeedbackStatusEl = document.getElementById('modelFeedbackStatus');
    document.getElementById('shareModelFeedbackBtn').onclick = async () => {
      try {
        const content = await getModelFeedback();
        if (!content || !content.trim()) {
          modelFeedbackStatusEl.textContent = 'Chưa có phản hồi model nào được ghi lại.';
          return;
        }
        await shareExportFile(content, 'atun_model_feedback.txt', 'text/plain');
        modelFeedbackStatusEl.textContent = 'Đã mở hộp thoại chia sẻ phản hồi model.';
      } catch (err) {
        modelFeedbackStatusEl.textContent = 'Lỗi khi chia sẻ phản hồi: ' + err.message;
      }
    };
    document.getElementById('clearModelFeedbackBtn').onclick = async () => {
      try {
        await clearModelFeedback();
        modelFeedbackStatusEl.textContent = 'Đã xoá phản hồi model cục bộ.';
      } catch (err) {
        modelFeedbackStatusEl.textContent = 'Lỗi khi xoá phản hồi: ' + err.message;
      }
    };
