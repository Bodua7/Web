package com.atun.translator

import android.content.Context
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.StorageService

// Bọc Vosk để nhận PCM đẩy trực tiếp từ AudioCaptureService (KHÔNG qua mic).
// Lưu ý quan trọng: dùng Recognizer trực tiếp thay vì SpeechService của Vosk,
// vì SpeechService tự mở AudioRecord từ mic bên trong - không nhận được audio
// mình tự bắt bằng AudioPlaybackCaptureConfiguration.
class VoskEngine(
    private val context: Context,
    private val sampleRate: Float,
    private val modelSource: ModelSource,
    private val onEvent: (Event) -> Unit
) {
    sealed class Event {
        data class Partial(val text: String) : Event()
        // confidence: trung bình conf theo từ (0.0-1.0) do Vosk trả về khi bật setWords(true).
        // -1.0 nếu không lấy được (JSON không có "result", hoặc lỗi parse) - coi như "không rõ",
        // KHÔNG bị lọc bỏ bởi ngưỡng CONFIDENCE_DROP_THRESHOLD (xem feed()/forcePauseFinal()).
        data class Final(val text: String, val confidence: Double) : Event()
        // Câu bị lọc bỏ vì độ tin cậy quá thấp (nhiều khả năng Vosk "nghe nhầm" nhạc nền/nhiễu
        // thành lời nói) - vẫn bắn lên để debug/hiển thị mờ nếu muốn, nhưng KHÔNG đẩy vào luồng
        // dịch chính (AudioCaptureService không gọi emitFinal cho case này).
        data class LowConfidence(val text: String, val confidence: Double) : Event()
        object ModelReady : Event()
        data class Error(val message: String) : Event()
    }

    // Nguồn model: Asset = bundled sẵn trong APK (chỉ "en" hiện tại, giải nén qua
    // StorageService.unpack); Path = đã tải về + giải nén sẵn trên filesystem qua
    // ModelManagerPlugin (mọi ngôn ngữ khác) - load thẳng bằng Model(path), không qua asset.
    sealed class ModelSource {
        data class Asset(val assetName: String) : ModelSource()
        data class Path(val dirPath: String) : ModelSource()
    }

    companion object {
        // Câu final có độ tin cậy trung bình (theo từ) THẤP HƠN ngưỡng này bị coi là rác/nhiễu
        // nghe nhầm, không đẩy vào luồng dịch (xem Event.LowConfidence). 0.35 là mức khá dè dặt
        // (chỉ chặn những câu RÕ RÀNG là rác) - model Vosk small thường cho conf 0.5-0.9 với
        // giọng nói nghe đúng, còn audio nhận nhầm từ nhạc/nhiễu nền thường rơi xuống rất thấp
        // (< 0.3). Tăng ngưỡng này nếu vẫn còn thấy nhiều câu rác lọt qua; giảm nếu thấy câu
        // đúng bị lọc oan (xem log confidence kèm mỗi câu final trong debug log của UI).
        const val CONFIDENCE_DROP_THRESHOLD = 0.35

        // "en" là ngôn ngữ duy nhất bundle sẵn trong APK (xem scripts/copy-model-assets.py +
        // assets-for-android/model-en) - các ngôn ngữ khác PHẢI tải về trước qua ModelManagerPlugin
        // (xem ModelManagerPlugin.CATALOG), không có asset dự phòng nào khác nữa.
        //
        // Trả về null nếu model chưa sẵn sàng (chưa tải về) - caller (AudioCaptureService) PHẢI
        // kiểm tra null và báo lỗi cho JS thay vì start capture với model rỗng.
        fun resolveModelSource(context: Context, sourceLang: String): ModelSource? {
            if (sourceLang == ModelManagerPlugin.BUNDLED_LANG) {
                return ModelSource.Asset("model-en")
            }
            return if (ModelManagerPlugin.isDownloaded(context, sourceLang)) {
                ModelSource.Path(ModelManagerPlugin.modelDir(context, sourceLang).absolutePath)
            } else {
                null
            }
        }
    }

    private var model: Model? = null
    private var recognizer: Recognizer? = null
    @Volatile private var ready = false

    // Theo dõi xem có "partial" đang dang dở (người nói chưa dứt câu, Vosk chưa tự chốt)
    // hay không - dùng cho forcePauseFinal() bên dưới, để không gọi ép chốt vô ích khi
    // không có gì để chốt (vd lúc đang im lặng hoàn toàn, chưa ai nói gì).
    @Volatile private var hasPendingPartial = false

    fun init() {
        when (val source = modelSource) {
            is ModelSource.Asset -> initFromAsset(source.assetName)
            is ModelSource.Path -> initFromPath(source.dirPath)
        }
    }

    // StorageService.unpack chạy async, copy model từ assets ra internal storage
    // (Vosk cần đường dẫn file thật trên filesystem, không đọc thẳng từ APK asset).
    private fun initFromAsset(assetName: String) {
        StorageService.unpack(
            context,
            assetName,
            "model",
            { unpackedModel -> onModelLoaded(unpackedModel) },
            { exception -> onEvent(Event.Error("Giải nén model Vosk thất bại: ${exception.message}")) }
        )
    }

    // Model(path) là hàm dựng ĐỒNG BỘ (blocking, có thể mất vài giây) - chạy trên thread riêng,
    // KHÔNG gọi trực tiếp trên main thread. Caller (AudioCaptureService) đã gọi init() từ
    // background service nên an toàn, nhưng vẫn tách thread riêng để không chặn luồng gọi vào.
    private fun initFromPath(dirPath: String) {
        Thread {
            try {
                val loadedModel = Model(dirPath)
                onModelLoaded(loadedModel)
            } catch (e: Exception) {
                onEvent(Event.Error("Load model từ $dirPath thất bại: ${e.message}"))
            }
        }.start()
    }

    private fun onModelLoaded(loadedModel: Model) {
        model = loadedModel
        try {
            recognizer = Recognizer(loadedModel, sampleRate)
            // Bật trả kèm danh sách từ + độ tin cậy (conf) trong JSON result - cần để tính
            // confidence trung bình cho lọc câu rác (xem extractResultWithConfidence()).
            recognizer?.setWords(true)
            ready = true
            onEvent(Event.ModelReady)
        } catch (e: Exception) {
            onEvent(Event.Error("Khởi tạo Recognizer thất bại: ${e.message}"))
        }
    }

    // Gọi liên tục từ thread đọc AudioRecord. Đây là hàm nóng (hot path) -> tránh alloc thừa.
    fun feed(pcm: ShortArray, length: Int) {
        val rec = recognizer ?: return
        if (!ready) return

        val finished = rec.acceptWaveForm(pcm, length)
        if (finished) {
            val (text, confidence) = extractResultWithConfidence(rec.result)
            hasPendingPartial = false
            emitFinalOrLowConfidence(text, confidence)
        } else {
            val text = extractField(rec.partialResult, "partial")
            hasPendingPartial = text.isNotBlank()
            if (text.isNotBlank()) onEvent(Event.Partial(text))
        }
    }

    // confidence == -1.0 nghĩa là "không xác định được" (JSON thiếu "result", câu quá ngắn để
    // Vosk gán conf theo từ...) - trường hợp này KHÔNG lọc bỏ, vì đây là hạn chế đọc dữ liệu chứ
    // không phải bằng chứng câu đó là rác.
    private fun emitFinalOrLowConfidence(text: String, confidence: Double) {
        if (text.isBlank()) return
        val isLowConfidence = confidence in 0.0..CONFIDENCE_DROP_THRESHOLD
        if (isLowConfidence) {
            onEvent(Event.LowConfidence(text, confidence))
        } else {
            onEvent(Event.Final(text, confidence))
        }
    }

    // ===== Chế độ ngắt câu thông minh khi người nói tạm nghỉ =====
    // Endpointer mặc định của Kaldi/Vosk (quyết định "finished" trong feed() ở trên) thường
    // chờ khá lâu hoặc phụ thuộc cấu trúc câu trong HCLG graph, gây cảm giác phụ đề bị "dính"
    // câu trước vào câu sau, hoặc chốt câu trễ. AudioCaptureService tự đo im lặng qua biên độ
    // audio (không qua Vosk) và gọi hàm này khi phát hiện người nói đã ngừng đủ lâu (mặc định
    // ~300ms, xem AudioCaptureService.SMART_PAUSE_MS) - ép Recognizer chốt NGAY phần đã nghe
    // được thành 1 câu final, thay vì đợi endpointer tự nhiên (có thể lâu hơn nhiều, hoặc
    // không bao giờ tự chốt nếu người nói im lặng hẳn giữa câu).
    //
    // rec.finalResult (khác rec.result ở feed() phía trên): buộc Kaldi trả về kết quả tốt nhất
    // cho phần audio đã nhận từ lần chốt câu gần nhất, RESET lại trạng thái nội bộ để câu tiếp
    // theo bắt đầu "sạch" - không bị lẫn từ của câu vừa chốt.
    fun forcePauseFinal() {
        val rec = recognizer ?: return
        if (!ready) return
        if (!hasPendingPartial) return // đang im lặng, chưa có gì để chốt - khỏi gọi finalResult vô ích

        val (text, confidence) = extractResultWithConfidence(rec.finalResult)
        hasPendingPartial = false
        emitFinalOrLowConfidence(text, confidence)
    }

    private fun extractField(json: String?, field: String): String {
        if (json.isNullOrBlank()) return ""
        return try {
            JSONObject(json).optString(field, "")
        } catch (e: Exception) {
            ""
        }
    }

    // Đọc text + tính confidence trung bình từ danh sách từ trong JSON result của Vosk (chỉ có
    // khi recognizer.setWords(true) đã bật - xem onModelLoaded()). Format JSON của Vosk:
    // {"result": [{"conf": 0.87, "start": 0.3, "end": 0.6, "word": "hello"}, ...], "text": "hello"}
    private fun extractResultWithConfidence(json: String?): Pair<String, Double> {
        if (json.isNullOrBlank()) return "" to -1.0
        return try {
            val obj = JSONObject(json)
            val text = obj.optString("text", "")
            val wordsArr = obj.optJSONArray("result")
            if (wordsArr == null || wordsArr.length() == 0) {
                text to -1.0 // không có info conf (câu rỗng, hoặc model/kết quả không trả words)
            } else {
                var sum = 0.0
                for (i in 0 until wordsArr.length()) {
                    sum += wordsArr.getJSONObject(i).optDouble("conf", 0.0)
                }
                text to (sum / wordsArr.length())
            }
        } catch (e: Exception) {
            "" to -1.0
        }
    }

    fun release() {
        ready = false
        recognizer?.close()
        recognizer = null
        model?.close()
        model = null
    }
}
