package com.atun.translator

import android.app.*
import android.content.Intent
import android.content.SharedPreferences
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlin.concurrent.thread

// Bắt audio để dịch, theo 1 trong 2 nguồn:
// - MODE_SYSTEM: audio đang phát bởi app khác trên máy (YouTube, VLC...) qua
//   AudioPlaybackCaptureConfiguration (Android 10+). Cần quyền MediaProjection (xin lại mỗi lần,
//   token dùng 1 lần - KHÔNG tự phục hồi được nếu service bị OS kill).
// - MODE_MIC: ghi âm qua micro máy (nghe audio phát ra loa ngoài). Chỉ cần quyền RECORD_AUDIO
//   (permission thường, xin 1 lần là xong) -> có thể tự khởi động lại sau khi bị OS kill.
class AudioCaptureService : Service() {

    companion object {
        const val ACTION_START = "com.atun.translator.action.START_CAPTURE"
        const val ACTION_STOP = "com.atun.translator.action.STOP_CAPTURE"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"
        const val EXTRA_SOURCE_LANG = "sourceLang"
        const val EXTRA_CAPTURE_MODE = "captureMode"
        const val EXTRA_SMART_PAUSE = "smartPause"

        const val MODE_SYSTEM = "system"
        const val MODE_MIC = "mic"

        // Vosk hoạt động tốt nhất ở 16kHz mono PCM16 - hầu hết model Vosk train ở sample rate này.
        const val SAMPLE_RATE = 16000
        private const val CHANNEL_ID = "audio_capture_channel"
        private const val NOTIFICATION_ID = 42

        // Ngưỡng peak cố định trước đây (SILENCE_PEAK_THRESHOLD=50) đã bị thay bằng VAD thích
        // nghi theo nhiễu nền - xem VadDetector.kt.

        // Ngưỡng im lặng liên tục (giây) trước khi cảnh báo UI - đếm ở JS qua sự kiện audioLevel,
        // hằng số này chỉ dùng phía native để quyết định khi nào cần bắn thêm sự kiện rõ ràng.
        const val SILENCE_WARNING_SECONDS = 8

        // ===== Chế độ ngắt câu thông minh khi người nói tạm nghỉ =====
        // Sau khi phát hiện im lặng liên tục >= khoảng thời gian này (kể từ mẫu có giọng nói
        // gần nhất), coi như người nói đã dứt câu -> ép Vosk chốt final ngay (xem
        // VoskEngine.forcePauseFinal()) thay vì đợi endpointer nội bộ (có thể trễ/không chốt).
        // Giảm dần theo yêu cầu người dùng: 700ms -> 500ms -> 300ms - phụ đề chốt câu nhanh/
        // nhạy hơn, đổi lại dễ cắt câu hơn nếu người nói ngừng lấy hơi hơi lâu giữa câu (ở
        // ngưỡng 300ms, gần như bất kỳ khoảng nghỉ tự nhiên nào khi nói cũng đủ để bị coi là
        // hết câu). Có thể chỉnh lại nếu thấy ngắt quá sớm/quá trễ.
        private const val SMART_PAUSE_MS = 300L

        private const val PREFS_NAME = "audio_capture_state"
        private const val KEY_WAS_CAPTURING = "wasCapturing"
        private const val KEY_MODE = "mode"
        private const val KEY_LANG = "lang"
        private const val KEY_SMART_PAUSE = "smartPause"

        private fun prefs(ctx: android.content.Context): SharedPreferences =
            ctx.getSharedPreferences(PREFS_NAME, MODE_PRIVATE)

        // Gọi từ JS/Activity khi mở lại app, để biết phiên SYSTEM có bị mất giữa chừng không
        // (không tự phục hồi được, phải hiện lại nút "Bắt đầu nghe" cho user bấm lại).
        fun consumeLostSystemSession(ctx: android.content.Context): Boolean {
            val p = prefs(ctx)
            val lost = p.getBoolean(KEY_WAS_CAPTURING, false) && p.getString(KEY_MODE, "") == MODE_SYSTEM
            return lost
        }

        fun clearSavedState(ctx: android.content.Context) {
            prefs(ctx).edit().clear().apply()
        }
    }

    private var mediaProjection: MediaProjection? = null
    private var audioRecord: AudioRecord? = null
    private var captureThread: Thread? = null
    @Volatile private var isCapturing = false
    private var currentMode: String = MODE_SYSTEM

    // PARTIAL_WAKE_LOCK: chỉ giữ CPU chạy (không giữ màn hình sáng), để vòng lặp đọc
    // AudioRecord + Vosk không bị Doze/App Standby làm chậm/treo khi user tắt màn hình
    // giữa lúc đang nghe. Không giữ SCREEN wakelock vì không cần màn hình sáng liên tục.
    private var wakeLock: PowerManager.WakeLock? = null

    private var voskEngine: VoskEngine? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when {
            intent?.action == ACTION_STOP -> {
                clearSavedState(applicationContext)
                stopCapture()
                stopSelf()
            }
            // intent == null xảy ra khi hệ thống tự khởi động lại service sau khi bị OS kill
            // (do trả về START_STICKY). Lúc này không còn resultCode/resultData gốc, nên chỉ
            // phục hồi được nếu phiên trước là MODE_MIC (không cần MediaProjection token).
            intent == null -> {
                val p = prefs(applicationContext)
                val wasCapturing = p.getBoolean(KEY_WAS_CAPTURING, false)
                val savedMode = p.getString(KEY_MODE, MODE_SYSTEM) ?: MODE_SYSTEM
                val savedLang = p.getString(KEY_LANG, "en") ?: "en"
                val savedSmartPause = p.getBoolean(KEY_SMART_PAUSE, true)
                if (wasCapturing && savedMode == MODE_MIC) {
                    startForegroundNotification(MODE_MIC)
                    startMicCapture(savedLang, savedSmartPause)
                    AudioCapturePlugin.instance?.emitCaptureResumed(MODE_MIC)
                } else {
                    // Phiên SYSTEM không tự phục hồi được - dừng hẳn, để lại cờ cho JS biết
                    // (consumeLostSystemSession) khi user mở lại app.
                    stopSelf()
                }
            }
            else -> {
                val mode = intent.getStringExtra(EXTRA_CAPTURE_MODE) ?: MODE_SYSTEM
                currentMode = mode
                startForegroundNotification(mode)
                val sourceLang = intent.getStringExtra(EXTRA_SOURCE_LANG) ?: "en"
                val smartPause = intent.getBooleanExtra(EXTRA_SMART_PAUSE, true)
                if (mode == MODE_MIC) {
                    startMicCapture(sourceLang, smartPause)
                } else {
                    val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                    val resultData = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
                    if (resultCode == Activity.RESULT_OK && resultData != null) {
                        startSystemCapture(resultCode, resultData, sourceLang, smartPause)
                    } else {
                        AudioCapturePlugin.instance?.emitError("Thiếu dữ liệu quyền MediaProjection.")
                        stopSelf()
                    }
                }
            }
        }
        // START_STICKY: xin hệ thống khởi động lại service (với intent = null) nếu bị kill
        // giữa chừng do bộ nhớ thấp/OEM diệt app. Xem nhánh intent == null ở trên để biết
        // giới hạn phục hồi (chỉ MODE_MIC phục hồi được tự động).
        return START_STICKY
    }

    // Bắt buộc có notification foreground TRƯỚC khi tạo MediaProjection/AudioRecord,
    // nếu không Android 14+ sẽ ném SecurityException (foregroundServiceType=mediaProjection).
    private fun startForegroundNotification(mode: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Bắt âm thanh để dịch", NotificationManager.IMPORTANCE_LOW)
        )

        val stopIntent = Intent(this, AudioCaptureService::class.java).apply { action = ACTION_STOP }
        val stopPendingIntentFlags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_IMMUTABLE else 0)
        val stopPendingIntent = PendingIntent.getService(this, 0, stopIntent, stopPendingIntentFlags)

        val contentText = if (mode == MODE_MIC)
            "Đang nghe qua micro để dịch trực tiếp"
        else
            "Đang bắt âm thanh phát ra từ máy để dịch trực tiếp"

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Đang nghe và dịch phụ đề")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Dừng", stopPendingIntent)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val type = if (mode == MODE_MIC)
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            else
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            startForeground(NOTIFICATION_ID, notification, type)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun saveState(mode: String, lang: String, capturing: Boolean, smartPause: Boolean) {
        prefs(applicationContext).edit()
            .putBoolean(KEY_WAS_CAPTURING, capturing)
            .putString(KEY_MODE, mode)
            .putString(KEY_LANG, lang)
            .putBoolean(KEY_SMART_PAUSE, smartPause)
            .apply()
    }

    private fun startSystemCapture(resultCode: Int, resultData: Intent, sourceLang: String, smartPause: Boolean) {
        acquireWakeLock()

        val projectionManager =
            getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = projectionManager.getMediaProjection(resultCode, resultData)
        mediaProjection = projection

        // Android 14+ yêu cầu đăng ký callback TRƯỚC khi gọi bất kỳ hàm capture nào.
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                // Hệ thống/user tự dừng chia sẻ màn hình (vd. qua nút Stop của Android trên
                // status bar) - đây là dừng có chủ đích, không phải bị OS kill, nên xoá luôn
                // cờ đã lưu để lần start service kế tiếp (nếu có) không cố phục hồi nhầm.
                clearSavedState(applicationContext)
                stopCapture()
            }
        }, null)

        val config = android.media.AudioPlaybackCaptureConfiguration.Builder(projection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()

        val audioFormat = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SAMPLE_RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()

        val minBufferSize = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBufferSize <= 0) {
            AudioCapturePlugin.instance?.emitError("Thiết bị không hỗ trợ cấu hình audio 16kHz mono.")
            releaseWakeLock()
            stopSelf()
            return
        }

        val record = try {
            AudioRecord.Builder()
                .setAudioFormat(audioFormat)
                .setBufferSizeInBytes(minBufferSize * 4)
                .setAudioPlaybackCaptureConfig(config)
                .build()
        } catch (e: UnsupportedOperationException) {
            // Xảy ra khi thiết bị/app nguồn chặn capture (allowAudioPlaybackCapture=false)
            // hoặc không có app nào đang phát audio khớp usage MEDIA lúc build().
            AudioCapturePlugin.instance?.emitError(
                "Không bắt được audio hệ thống - có thể app đang phát (vd. YouTube) đã chặn playback capture: " + e.message,
                code = "SYSTEM_CAPTURE_BLOCKED"
            )
            releaseWakeLock()
            stopSelf()
            return
        }

        if (record.state != AudioRecord.STATE_INITIALIZED) {
            AudioCapturePlugin.instance?.emitError(
                "AudioRecord khởi tạo thất bại (state != INITIALIZED).",
                code = "SYSTEM_CAPTURE_BLOCKED"
            )
            releaseWakeLock()
            stopSelf()
            return
        }

        audioRecord = record
        saveState(MODE_SYSTEM, sourceLang, capturing = true, smartPause = smartPause)
        startVoskAndReadLoop(record, sourceLang, minBufferSize, smartPause)
    }

    // MODE_MIC: dùng chính micro của máy, không cần MediaProjection -> không cần dialog hệ thống,
    // chỉ cần quyền RECORD_AUDIO đã cấp trước (xin ở phía JS/Plugin). Nhờ vậy service có thể tự
    // khởi động lại và tiếp tục nghe sau khi bị OS kill (xem onStartCommand, nhánh intent == null).
    private fun startMicCapture(sourceLang: String, smartPause: Boolean) {
        acquireWakeLock()

        val minBufferSize = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBufferSize <= 0) {
            AudioCapturePlugin.instance?.emitError("Thiết bị không hỗ trợ cấu hình audio 16kHz mono.")
            releaseWakeLock()
            stopSelf()
            return
        }

        val record = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                minBufferSize * 4
            )
        } catch (e: SecurityException) {
            AudioCapturePlugin.instance?.emitError("Thiếu quyền RECORD_AUDIO để nghe qua micro: " + e.message)
            releaseWakeLock()
            stopSelf()
            return
        }

        if (record.state != AudioRecord.STATE_INITIALIZED) {
            AudioCapturePlugin.instance?.emitError("AudioRecord (micro) khởi tạo thất bại (state != INITIALIZED).")
            releaseWakeLock()
            stopSelf()
            return
        }

        audioRecord = record
        saveState(MODE_MIC, sourceLang, capturing = true, smartPause = smartPause)
        startVoskAndReadLoop(record, sourceLang, minBufferSize, smartPause)
    }

    private fun startVoskAndReadLoop(record: AudioRecord, sourceLang: String, minBufferSize: Int, smartPause: Boolean) {
        // Chặn sớm nếu model của sourceLang chưa sẵn sàng (chưa bundle, chưa tải về qua
        // ModelManagerPlugin) - tránh việc AudioRecord đã start (tốn pin/CPU) nhưng Vosk
        // không bao giờ nhận diện được gì vì model null.
        val modelSource = VoskEngine.resolveModelSource(applicationContext, sourceLang)
        if (modelSource == null) {
            AudioCapturePlugin.instance?.emitError(
                "Chưa tải model cho ngôn ngữ '$sourceLang'. Vào phần Quản lý mô hình để tải về trước."
            )
            clearSavedState(applicationContext) // tránh service tự resume lại với model vẫn thiếu
            try { record.stop() } catch (e: Exception) { /* chưa start thì bỏ qua */ }
            record.release()
            audioRecord = null
            releaseWakeLock()
            stopSelf()
            return
        }

        voskEngine = VoskEngine(
            applicationContext,
            sampleRate = SAMPLE_RATE.toFloat(),
            modelSource = modelSource
        ) { event ->
            when (event) {
                is VoskEngine.Event.Partial -> AudioCapturePlugin.instance?.emitPartial(event.text)
                is VoskEngine.Event.Final -> AudioCapturePlugin.instance?.emitFinal(event.text, event.confidence)
                is VoskEngine.Event.LowConfidence -> AudioCapturePlugin.instance?.emitLowConfidence(event.text, event.confidence)
                is VoskEngine.Event.ModelReady -> AudioCapturePlugin.instance?.emitModelLoading(true)
                is VoskEngine.Event.Error -> AudioCapturePlugin.instance?.emitError(event.message)
            }
        }
        voskEngine?.init()

        isCapturing = true
        record.startRecording()
        captureThread = thread(name = "AudioCaptureReadLoop") {
            val buffer = ShortArray(minBufferSize / 2)
            // VAD thích nghi thay ngưỡng peak cố định (xem VadDetector.kt) - quyết định
            // isSilentRead cho cả thống kê audioLevel VÀ smartPause bên dưới.
            val vad = VadDetector()

            var lastLevelEmitAt = System.currentTimeMillis()
            var peakSinceLastEmit = 0
            var readCallsSinceLastEmit = 0
            var silentReadsSinceLastEmit = 0
            var badReadsSinceLastEmit = 0 // read() <= 0

            // ===== Chế độ ngắt câu thông minh: theo dõi mốc thời gian có giọng nói gần nhất
            // theo TỪNG lần read() (độ phân giải ~vài chục ms), KHÔNG dùng số liệu gộp mỗi giây
            // ở trên (quá thô để bắt pause ~700ms chính xác). pauseHandled chặn gọi
            // forcePauseFinal() lặp lại nhiều lần cho cùng 1 khoảng im lặng.
            var lastVoiceAt = System.currentTimeMillis()
            var pauseHandled = false

            while (isCapturing) {
                val read = record.read(buffer, 0, buffer.size)
                val now = System.currentTimeMillis()

                if (read > 0) {
                    voskEngine?.feed(buffer, read)

                    var peak = 0
                    for (i in 0 until read) {
                        val v = kotlin.math.abs(buffer[i].toInt())
                        if (v > peak) peak = v
                    }
                    if (peak > peakSinceLastEmit) peakSinceLastEmit = peak
                    readCallsSinceLastEmit++

                    // isSilentRead giờ do VAD quyết định (năng lượng + ngưỡng thích nghi theo
                    // nhiễu nền), không còn so peak với hằng số cố định - xem VadDetector.kt.
                    val isVoiceFrame = vad.process(buffer, read)
                    val isSilentRead = !isVoiceFrame
                    if (isSilentRead) silentReadsSinceLastEmit++

                    if (smartPause) {
                        if (isSilentRead) {
                            if (!pauseHandled && (now - lastVoiceAt) >= SMART_PAUSE_MS) {
                                voskEngine?.forcePauseFinal()
                                pauseHandled = true
                            }
                        } else {
                            lastVoiceAt = now
                            pauseHandled = false
                        }
                    }
                } else {
                    badReadsSinceLastEmit++
                }

                if (now - lastLevelEmitAt >= 1000) {
                    AudioCapturePlugin.instance?.emitAudioLevel(
                        peakSinceLastEmit, readCallsSinceLastEmit, silentReadsSinceLastEmit, badReadsSinceLastEmit
                    )
                    lastLevelEmitAt = now
                    peakSinceLastEmit = 0
                    readCallsSinceLastEmit = 0
                    silentReadsSinceLastEmit = 0
                    badReadsSinceLastEmit = 0
                }
            }
        }
    }

    // Giữ vô thời hạn (không set timeout) vì phiên dịch live có thể kéo dài vài giờ - nếu
    // set timeout ngắn (vd 30') sẽ tự hết hạn giữa chừng, gây lại đúng vấn đề WakeLock
    // muốn tránh. An toàn vì: mọi nhánh lỗi trong start*Capture(), stopCapture() (được gọi
    // từ ACTION_STOP, MediaProjection.Callback.onStop, VÀ onDestroy) đều gọi releaseWakeLock();
    // nếu process bị OS kill hoàn toàn thì WakeLock cũng tự mất theo, không leak vĩnh viễn.
    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "AtunTranslator:AudioCaptureWakeLock"
        ).apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.let {
            if (it.isHeld) it.release()
        }
        wakeLock = null
    }

    private fun stopCapture() {
        isCapturing = false
        captureThread?.join(500)
        captureThread = null

        audioRecord?.let {
            try { it.stop() } catch (e: Exception) { /* đã stop rồi thì bỏ qua */ }
            it.release()
        }
        audioRecord = null

        voskEngine?.release()
        voskEngine = null

        mediaProjection?.stop()
        mediaProjection = null

        releaseWakeLock()
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }
}
