// Bọc UI chính của app (www/index.html) thành app desktop Windows qua Electron.
//
// QUAN TRỌNG: đây chỉ là bản "vỏ" chạy được trên Windows, KHÔNG có tính năng
// nghe/dịch/overlay/đọc to thật - toàn bộ tính năng đó nằm trong plugin Kotlin viết
// riêng cho Android (native/*.kt), không tồn tại trên desktop. UI vẫn hiện đầy đủ (để xem/
// thử giao diện), nhưng bấm "Bắt đầu nghe", tải model, TTS... sẽ báo lỗi trong log kỹ thuật
// thay vì hoạt động thật - code JS trong www/index.html đã tự kiểm tra
// `window.Capacitor?.Plugins?.X` trước khi gọi nên KHÔNG crash, chỉ không làm được gì.
//
// Vì sao dựng server cục bộ thay vì loadFile() thẳng file://:
// www/index.html dùng <script type="module"> import nhiều file .js khác qua đường dẫn
// tương đối (./src/services/...). Chromium coi mỗi file mở qua file:// là 1 origin riêng
// biệt (opaque origin) nên import module chéo file dễ bị chặn bởi CORS module loading.
// Serve qua http://127.0.0.1 tránh hẳn vấn đề này, không cần thêm dependency ngoài Electron.
const { app, BrowserWindow } = require('electron');
const http = require('http');
const fs = require('fs');
const path = require('path');

const WWW_DIR = path.join(__dirname, '..', 'www');

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
};

function startStaticServer() {
  return new Promise((resolve, reject) => {
    const server = http.createServer((req, res) => {
      const urlPath = decodeURIComponent((req.url || '/').split('?')[0]);
      const relativePath = urlPath === '/' ? '/index.html' : urlPath;
      const filePath = path.normalize(path.join(WWW_DIR, relativePath));

      // Chặn path traversal (vd "..%2F..%2F") ra ngoài thư mục www/.
      if (!filePath.startsWith(WWW_DIR)) {
        res.writeHead(403);
        res.end('Forbidden');
        return;
      }

      fs.readFile(filePath, (err, data) => {
        if (err) {
          res.writeHead(404);
          res.end('Not found: ' + relativePath);
          return;
        }
        const ext = path.extname(filePath).toLowerCase();
        res.writeHead(200, { 'Content-Type': MIME_TYPES[ext] || 'application/octet-stream' });
        res.end(data);
      });
    });

    server.on('error', reject);
    // Port 0 = để hệ điều hành tự chọn cổng trống, tránh xung đột nếu máy đã dùng cổng cố định.
    server.listen(0, '127.0.0.1', () => resolve(server));
  });
}

let mainWindow = null;
let staticServer = null;

async function createWindow() {
  staticServer = await startStaticServer();
  const { port } = staticServer.address();

  mainWindow = new BrowserWindow({
    width: 420,
    height: 840,
    minWidth: 360,
    title: 'Atun Translator (bản desktop - chỉ xem giao diện, không nghe/dịch audio thật)',
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });

  mainWindow.loadURL(`http://127.0.0.1:${port}/index.html`);
  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (staticServer) staticServer.close();
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
