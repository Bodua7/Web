// supabase/functions/groq-relay/index.ts
//
// Proxy cho Groq API va DeepL API - giau API key phia server (Supabase Secrets).
//
// Gọi từ client:
//   POST https://<project-ref>.supabase.co/functions/v1/groq-relay?op=transcribe
//        body: FormData { file, language? }
//   POST https://<project-ref>.supabase.co/functions/v1/groq-relay?op=translate
//        body: JSON { text, targetLangCode, context? }         (Groq LLM)
//   POST https://<project-ref>.supabase.co/functions/v1/groq-relay?op=translateGemini
//        body: JSON { text, targetLangCode, context? }         (Gemini LLM - tang du phong
//        thu 2 sau Groq, xem comment o handleTranslateGemini() vi sao dat sau Groq chu khong
//        thay Groq lam uu tien so 1)
//   POST https://<project-ref>.supabase.co/functions/v1/groq-relay?op=translateDeepl
//        body: JSON { text, targetLangCode, sourceLangCode?, context? }   (DeepL)
//   POST https://<project-ref>.supabase.co/functions/v1/groq-relay?op=translateAzure
//        body: JSON { text, targetLangCode, sourceLangCode? }   (Azure Translator - chi dung
//        rieng cho kk/uz/ky, xem AZURE_TARGET_LANG_MAP trong app.js)
//   GET  https://<project-ref>.supabase.co/functions/v1/groq-relay?op=debug
//        (liet ke model that dang co tren tai khoan, mo truc tiep tren trinh duyet)
//
// Bang Postgres translate_quota_status (xem migration_translate_quota_status.sql) theo doi
// het quota THEO THANG cho DeepL/Azure (2 provider co free-tier reset theo billing period thang)
// - doc/ghi qua service role key (SUPABASE_URL + SUPABASE_SERVICE_ROLE_KEY, 2 bien nay Supabase
// TU DONG bom san cho moi Edge Function, khong can tu set secret).

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const supabaseAdmin = createClient(
  Deno.env.get("SUPABASE_URL") ?? "",
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
);

function currentMonthKey(): string {
  return new Date().toISOString().slice(0, 7); // "2026-09" (UTC)
}

// isQuotaBlocked: đọc lỗi -> false (KHÔNG chặn) thay vì throw - lỗi đọc DB tạm thời không nên
// làm hỏng cả luồng dịch, coi như "chưa biết trạng thái" thì cứ thử gọi provider bình thường,
// để chính request đó tự xác định lại (thành hoặc lại lỗi 456/quota, ghi lại bảng).
async function isQuotaBlocked(provider: string): Promise<boolean> {
  try {
    const { data, error } = await supabaseAdmin
      .from("translate_quota_status")
      .select("exhausted_month")
      .eq("provider", provider)
      .maybeSingle();
    if (error || !data) return false;
    return data.exhausted_month === currentMonthKey();
  } catch {
    return false;
  }
}

// markQuotaExhausted: upsert - lần lỗi 456/quota tiếp theo trong CÙNG tháng chỉ cập nhật lại
// exhausted_at/last_error mới nhất, không tạo thêm dòng (provider là primary key).
async function markQuotaExhausted(provider: string, errorMsg: string): Promise<void> {
  try {
    await supabaseAdmin.from("translate_quota_status").upsert({
      provider,
      exhausted_at: new Date().toISOString(),
      exhausted_month: currentMonthKey(),
      last_error: errorMsg.slice(0, 300),
    });
  } catch (e) {
    // Best-effort: ghi DB lỗi thì chỉ log, KHÔNG throw - không được để lỗi ghi log làm hỏng
    // response dịch chính (request vẫn nên trả lỗi provider gốc cho client như bình thường).
    console.error("markQuotaExhausted lỗi ghi DB:", String(e));
  }
}

async function getQuotaStatusForDebug(): Promise<unknown> {
  try {
    const { data, error } = await supabaseAdmin.from("translate_quota_status").select("*");
    if (error) return { error: error.message };
    return data;
  } catch (e) {
    return { error: String(e) };
  }
}

const GROQ_BASE_URL = "https://api.groq.com/openai/v1";
const GROQ_STT_MODEL = "whisper-large-v3-turbo";

// Cap nhat 28/8/2026 theo danh sach model THAT tra ve tu /models (tai khoan nay
// khong con llama-3.x/llama-4 nua). Uu tien: gpt-oss-120b (chat luong cao nhat,
// 120b) -> qwen3.8-27b (du phong) -> gpt-oss-20b (nhe, nhanh, du phong cuoi).
const GROQ_TRANSLATE_MODELS = [
  "openai/gpt-oss-120b",
  "qwen/qwen3.8-27b",
  "openai/gpt-oss-20b",
];

// Mo rong tu 3 ma (vi/en/zh) sang DAY DU cac ma trong ModelCatalog.kt (~29 ngon ngu) -
// truoc day cac ma con lai (ja, ko, fr, de...) bi normalizeGroqLangCode() phia client chan,
// roi thang xuong Google Translate free (chat luong thap hon, hay bi 429) dù Groq (LLM) hoan
// toan dich duoc cac ngon ngu nay. "en-in" khong can rieng - client tu cat ve "en" truoc khi
// goi (xem toMlkitLang-style fallback), nhung van them o day de an toan neu lo gui nguyen.
const LANG_NAMES: Record<string, string> = {
  vi: "Vietnamese",
  en: "English",
  "en-in": "English",
  zh: "Chinese",
  ja: "Japanese",
  ko: "Korean",
  ru: "Russian",
  fr: "French",
  de: "German",
  es: "Spanish",
  pt: "Portuguese",
  tr: "Turkish",
  it: "Italian",
  nl: "Dutch",
  ca: "Catalan",
  fa: "Persian",
  uk: "Ukrainian",
  kz: "Kazakh",
  eo: "Esperanto",
  hi: "Hindi",
  cs: "Czech",
  pl: "Polish",
  uz: "Uzbek",
  gu: "Gujarati",
  tg: "Tajik",
  te: "Telugu",
  ky: "Kyrgyz",
  ka: "Georgian",
  br: "Breton",
};

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, apikey, X-App-Secret",
};

// ===== Header bí mật riêng của app (KHÔNG thay thế cho auth thật - xem ghi chú ở app.js nơi
// gửi header này) - chỉ nhằm chặn bớt việc URL function bị lộ/scrape rồi bị gọi trực tiếp tốn
// quota Groq/DeepL trả phí. CHỈ bắt buộc khi secret APP_SHARED_SECRET đã được set trên Supabase
// (chưa set thì bỏ qua check, không phá deploy cũ). =====
function checkAppSecret(req: Request): Response | null {
  const expected = Deno.env.get("APP_SHARED_SECRET");
  if (!expected) return null; // chưa bật cơ chế này
  const got = req.headers.get("X-App-Secret");
  if (got !== expected) return jsonError("UNAUTHORIZED", 401);
  return null;
}

function getKeys(): string[] {
  const k1 = Deno.env.get("GROQ_API_KEY");
  const k2 = Deno.env.get("GROQ_API_KEY_2");
  return [k1, k2].filter((k): k is string => !!k && k.length > 0);
}

// ===== Circuit breaker phía SERVER cho Groq (bổ sung cho breaker phía client trong app.js -
// hai lớp độc lập, không thay thế nhau: breaker client tránh client phải CHỜ timeout mỗi câu;
// breaker này tránh chính function này liên tục bắn request vô ích tới Groq khi CẢ 2 key đều
// đang 401/429, giúp trả lỗi ngay cho client (nhanh hơn) thay vì lại đi hết vòng lặp key trong
// groqFetchWithFallback() mỗi lần. State là module-level (biến ngoài Deno.serve) nên sống
// được qua nhiều request TRONG CÙNG 1 isolate còn "ấm" (warm) - Supabase Edge Functions có thể
// tái dùng isolate giữa các lần gọi gần nhau, nhưng KHÔNG đảm bảo tuyệt đối (isolate có thể bị
// dọn/khởi tạo lại bất kỳ lúc nào) - vì vậy đây chỉ là tối ưu "best-effort", không phải cơ chế
// bắt buộc đúng 100%: worst-case (isolate mới) chỉ đơn giản là mất tác dụng tạm thời, không
// gây lỗi sai kết quả.
const GROQ_CIRCUIT_FAIL_THRESHOLD = 3;
const GROQ_CIRCUIT_OPEN_MS = 60_000; // 60s - khớp với breaker phía client (app.js: groqCircuit)
let groqCircuitFailCount = 0;
let groqCircuitOpenUntil = 0;

function isGroqCircuitOpen(): boolean {
  return Date.now() < groqCircuitOpenUntil;
}

function recordGroqCircuitSuccess(): void {
  groqCircuitFailCount = 0;
  groqCircuitOpenUntil = 0;
}

function recordGroqCircuitFailure(): void {
  groqCircuitFailCount += 1;
  if (groqCircuitFailCount >= GROQ_CIRCUIT_FAIL_THRESHOLD) {
    groqCircuitOpenUntil = Date.now() + GROQ_CIRCUIT_OPEN_MS;
  }
}

// ===== Gemini - tang du phong LLM thu 2, chen NGAY SAU Groq (truoc DeepL). Ly do dat o day
// (khong phai ngay sau DeepL/Azure): Gemini la LLM nhu Groq nen phu duoc CA ~29 ngon ngu app
// ho tro (dung chung LANG_NAMES ben tren), trong khi DeepL chi co ~16/29 ma - de Gemini lam
// tang du phong LLM thu 2 truoc khi roi xuong DeepL/Azure (von la NMT chuyen biet, chi phu 1
// phan ngon ngu) se giu duoc chat luong dich LLM cho nhieu ngon ngu hon truoc khi phai ha
// xuong Google Translate free. Model uu tien gemini-3.5-flash-lite (nhanh, re, du cho dich
// cau ngan real-time) -> du phong gemini-2.5-flash-lite (on dinh, da dung lau hon).
const GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models";
const GEMINI_TRANSLATE_MODELS = ["gemini-3.5-flash-lite", "gemini-2.5-flash-lite"];

function getGeminiKey(): string | null {
  const k = Deno.env.get("GEMINI_API_KEY");
  return k && k.length > 0 ? k : null;
}

async function handleTranslateGemini(req: Request): Promise<Response> {
  const body = await req.json().catch(() => null);
  const text = body?.text;
  const targetLangCode = body?.targetLangCode;
  // context: giong het dinh dang cua op=translate (Groq) - mang cau NGUON gan nhat, toi da 3
  // cau - tai dung chung translationContextHistory phia client (xem translateGemini() trong
  // app.js), khong can dinh dang rieng.
  const context: string[] = Array.isArray(body?.context)
    ? body.context.filter((c: unknown): c is string => typeof c === "string" && c.trim().length > 0).slice(-3)
    : [];

  if (!text || !targetLangCode) {
    return jsonError("MISSING_TEXT_OR_TARGET", 400);
  }

  const key = getGeminiKey();
  if (!key) throw new Error("SERVER_MISSING_GEMINI_KEY");

  const targetLangName =
    LANG_NAMES[targetLangCode] || LANG_NAMES[String(targetLangCode).split("-")[0]] || "English";

  const contextBlock = context.length > 0
    ? `\n\nContext: the following ${context.length} sentence(s) were said immediately before ` +
      `the message you need to translate (same speaker/scene, original language, for reference ` +
      `only - to resolve pronouns, ellipsis, and keep terminology consistent). Do NOT translate ` +
      `or repeat them in your output:\n` +
      context.map((c, i) => `${i + 1}. ${c}`).join("\n")
    : "";

  const systemPrompt =
    `You are a professional real-time interpreter. Translate the user's ` +
    `message into ${targetLangName}. ` +
    `Rules: output ONLY the translation of the message, no explanations, no quotes. ` +
    `If the target language is Chinese, also provide Pinyin on a new line prefixed ` +
    `with "PINYIN:". ` +
    `If not Chinese, do not include a PINYIN line.` +
    contextBlock;

  let lastErr: Error | null = null;
  for (const model of GEMINI_TRANSLATE_MODELS) {
    try {
      const res = await fetch(
        `${GEMINI_BASE_URL}/${model}:generateContent?key=${key}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            system_instruction: { parts: [{ text: systemPrompt }] },
            contents: [{ role: "user", parts: [{ text }] }],
            generationConfig: { temperature: 0.2 },
          }),
        },
      );

      if (!res.ok) {
        const bodyText = await res.text().catch(() => "");
        const err = new Error(`GEMINI_ERROR_${res.status}: ${bodyText.slice(0, 300)}`);
        (err as any).status = res.status;
        // 401/403 (key sai/het quota) hoac 429 (rate limit) -> thu model du phong tiep theo;
        // loi khac (vd 400 do prompt) thi dung lai, khong co ich khi thu lai model khac.
        if (res.status === 401 || res.status === 403 || res.status === 429) {
          lastErr = err;
          continue;
        }
        throw err;
      }

      const data = await res.json();
      const raw: string =
        data?.candidates?.[0]?.content?.parts?.map((p: any) => p.text || "").join("") || "";
      const trimmed = raw.trim();
      if (!trimmed) throw new Error("GEMINI_EMPTY_RESPONSE");

      let translated = trimmed;
      let pinyin = "";
      const pinyinMatch = trimmed.match(/PINYIN:\s*(.+)/i);
      if (pinyinMatch) {
        pinyin = pinyinMatch[1].trim();
        translated = trimmed.replace(/PINYIN:\s*.+/i, "").trim();
      }

      return jsonOk({ translated, pinyin, model });
    } catch (e) {
      lastErr = e instanceof Error ? e : new Error(String(e));
      continue;
    }
  }
  throw lastErr ?? new Error("GEMINI_ALL_MODELS_FAILED");
}

async function handleDebug(): Promise<Response> {
  const keys = getKeys();
  const circuitInfo = {
    open: isGroqCircuitOpen(),
    failCount: groqCircuitFailCount,
    openUntil: groqCircuitOpenUntil ? new Date(groqCircuitOpenUntil).toISOString() : null,
  };
  const monthlyQuotaStatus = await getQuotaStatusForDebug(); // DeepL/Azure - xem translate_quota_status
  if (keys.length === 0) {
    return jsonOk({
      ok: false,
      reason: "KHONG_TIM_THAY_SECRET",
      groqCircuit: circuitInfo,
      monthlyQuotaStatus,
    });
  }
  try {
    const res = await fetch(`${GROQ_BASE_URL}/models`, {
      headers: { Authorization: `Bearer ${keys[0]}` },
    });
    const data = await res.json();
    const ids: string[] = (data.data || []).map((m: any) => m.id).sort();
    return jsonOk({
      ok: true,
      httpStatus: res.status,
      totalModels: ids.length,
      modelIds: ids,
      currentTranslateModels: GROQ_TRANSLATE_MODELS,
      groqCircuit: circuitInfo,
      monthlyQuotaStatus,
    });
  } catch (e) {
    return jsonOk({ ok: false, error: String(e), groqCircuit: circuitInfo });
  }
}

async function groqFetchWithFallback(
  buildRequest: (key: string) => { url: string; init: RequestInit },
): Promise<Response> {
  const keys = getKeys();
  if (keys.length === 0) {
    throw new Error("SERVER_MISSING_GROQ_KEY");
  }

  // Breaker đang mở (đã lỗi liên tiếp gần đây) -> trả lỗi ngay, KHÔNG bắn request nào tới Groq -
  // để client rơi xuống Gemini nhanh hơn, đỡ tốn cả thời gian lẫn quota gọi vô ích trong lúc
  // Groq nhiều khả năng vẫn đang lỗi.
  if (isGroqCircuitOpen()) {
    const err = new Error("GROQ_CIRCUIT_OPEN");
    (err as any).status = 429;
    throw err;
  }

  let lastError: Error | null = null;
  for (const key of keys) {
    const { url, init } = buildRequest(key);
    try {
      const res = await fetch(url, init);
      if (res.ok) {
        recordGroqCircuitSuccess();
        return res;
      }
      if (res.status === 401 || res.status === 429) {
        lastError = new Error(`GROQ_${res.status}`);
        continue;
      }
      const body = await res.text().catch(() => "");
      const err = new Error(`GROQ_ERROR_${res.status}: ${body.slice(0, 300)}`);
      (err as any).status = res.status;
      // Lỗi không phải 401/429 (vd 400/500) không tính vào breaker - breaker chỉ nhắm tới
      // trường hợp "hết quota/rate-limit kéo dài", không nhắm lỗi request/server nhất thời.
      throw err;
    } catch (e) {
      lastError = e instanceof Error ? e : new Error(String(e));
      if ((lastError as any).status && (lastError as any).status !== 401 && (lastError as any).status !== 429) {
        throw lastError;
      }
      continue;
    }
  }
  // Đã thử HẾT các key (cả 2, nếu có) mà vẫn toàn 401/429 -> tính là 1 lần lỗi breaker.
  recordGroqCircuitFailure();
  throw lastError ?? new Error("GROQ_ALL_KEYS_FAILED");
}

async function handleTranscribe(req: Request): Promise<Response> {
  const incomingForm = await req.formData();
  const file = incomingForm.get("file");
  const language = incomingForm.get("language");

  if (!(file instanceof File)) {
    return jsonError("MISSING_FILE", 400);
  }

  const res = await groqFetchWithFallback((key) => {
    const form = new FormData();
    form.append("file", file, "speech.webm");
    form.append("model", GROQ_STT_MODEL);
    form.append("response_format", "json");
    if (language && language !== "auto") {
      form.append("language", String(language));
    }
    return {
      url: `${GROQ_BASE_URL}/audio/transcriptions`,
      init: {
        method: "POST",
        headers: { Authorization: `Bearer ${key}` },
        body: form,
      },
    };
  });

  const data = await res.json();
  return jsonOk({ text: (data.text || "").trim() });
}

async function handleTranslate(req: Request): Promise<Response> {
  const body = await req.json().catch(() => null);
  const text = body?.text;
  const targetLangCode = body?.targetLangCode;
  // context: vai cau NGUON (chua dich) noi/xuat hien NGAY TRUOC cau dang dich, do client tu
  // gui kem (xem groqContextHistory trong app.js) - giup model giai quyet dai tu bi luoc,
  // thanh ngu noi cau, xung ho nhat quan giua cac cau lien tiep trong 1 doan hoi thoai/video,
  // thay vi dich moi cau hoan toan doc lap nhu truoc. Toi da 3 cau, chi lay string hop le.
  const context: string[] = Array.isArray(body?.context)
    ? body.context.filter((c: unknown): c is string => typeof c === "string" && c.trim().length > 0).slice(-3)
    : [];

  if (!text || !targetLangCode) {
    return jsonError("MISSING_TEXT_OR_TARGET", 400);
  }

  // Fallback cat ve ma goc (vd "zh-CN" -> "zh") neu khong tra trung thang - phong truong hop
  // client gui nguyen ma co hau to vung/mien chua co trong LANG_NAMES.
  const targetLangName =
    LANG_NAMES[targetLangCode] || LANG_NAMES[String(targetLangCode).split("-")[0]] || "English";

  const contextBlock = context.length > 0
    ? `\n\nContext: the following ${context.length} sentence(s) were said immediately before ` +
      `the message you need to translate (same speaker/scene, original language, for reference ` +
      `only - to resolve pronouns, ellipsis, and keep terminology consistent). Do NOT translate ` +
      `or repeat them in your output:\n` +
      context.map((c, i) => `${i + 1}. ${c}`).join("\n")
    : "";

  const systemPrompt =
    `You are a professional real-time interpreter. Translate the user's ` +
    `message into ${targetLangName}. ` +
    `Rules: output ONLY the translation of the message, no explanations, no quotes. ` +
    `If the target language is Chinese, also provide Pinyin on a new line prefixed ` +
    `with "PINYIN:". ` +
    `If not Chinese, do not include a PINYIN line.` +
    contextBlock;

  let lastErr: Error | null = null;
  for (const model of GROQ_TRANSLATE_MODELS) {
    try {
      const res = await groqFetchWithFallback((key) => ({
        url: `${GROQ_BASE_URL}/chat/completions`,
        init: {
          method: "POST",
          headers: {
            Authorization: `Bearer ${key}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model,
            temperature: 0.2,
            messages: [
              { role: "system", content: systemPrompt },
              { role: "user", content: text },
            ],
          }),
        },
      }));

      const data = await res.json();
      const raw = data.choices?.[0]?.message?.content?.trim() || "";

      let translated = raw;
      let pinyin = "";
      const pinyinMatch = raw.match(/PINYIN:\s*(.+)/i);
      if (pinyinMatch) {
        pinyin = pinyinMatch[1].trim();
        translated = raw.replace(/PINYIN:\s*.+/i, "").trim();
      }

      return jsonOk({ translated, pinyin, model });
    } catch (e) {
      lastErr = e instanceof Error ? e : new Error(String(e));
      continue;
    }
  }
  throw lastErr ?? new Error("GROQ_ALL_MODELS_FAILED");
}

// DeepL - tang dich xen giua Groq va Google Translate free (xem comment o app.js:
// DEEPL_TARGET_LANG_MAP - vi sao chi dung lam du phong, khong thay Groq lam uu tien so 1).
// Free-tier key DeepL luon co hau to ":fx" va PHAI goi api-free.deepl.com (khac Pro key goi
// api.deepl.com) - tu phat hien qua hau to nay thay vi bat nguoi dung config them 1 bien moi.
async function handleTranslateDeepl(req: Request): Promise<Response> {
  const body = await req.json().catch(() => null);
  const text = body?.text;
  // targetLangCode/sourceLangCode: da la ma DEEPL chuan (vd "VI", "EN-US") do client tu map
  // san (DEEPL_TARGET_LANG_MAP/DEEPL_SOURCE_LANG_MAP trong app.js) - server khong tu doan/map
  // lai de tranh 2 noi co danh sach ngon ngu lech nhau.
  const targetLangCode = body?.targetLangCode;
  const sourceLangCode = typeof body?.sourceLangCode === "string" ? body.sourceLangCode : undefined;
  // context: 1 chuoi (khac context dang mang cau cua op=translate/Groq) - dung dinh dang
  // "context" cua DeepL API (tham khao de dich cau hien tai, KHONG duoc dich/tra ve).
  const context = typeof body?.context === "string" && body.context.trim() ? body.context : undefined;

  if (!text || !targetLangCode) {
    return jsonError("MISSING_TEXT_OR_TARGET", 400);
  }

  // Tháng này DeepL đã từng trả 456 (Quota Exceeded) -> chắc chắn vẫn còn hết cho tới khi
  // sang billing period mới, bỏ qua thẳng, không tốn round-trip gọi DeepL vô ích.
  if (await isQuotaBlocked("deepl")) {
    throw new Error("DEEPL_QUOTA_EXHAUSTED_THIS_MONTH");
  }

  const key = Deno.env.get("DEEPL_API_KEY");
  if (!key) throw new Error("SERVER_MISSING_DEEPL_KEY");

  const base = key.trim().endsWith(":fx") ? "https://api-free.deepl.com" : "https://api.deepl.com";

  const payload: Record<string, unknown> = { text: [text], target_lang: targetLangCode };
  if (sourceLangCode) payload.source_lang = sourceLangCode;
  if (context) payload.context = context;

  const res = await fetch(`${base}/v2/translate`, {
    method: "POST",
    headers: {
      Authorization: `DeepL-Auth-Key ${key}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const bodyText = await res.text().catch(() => "");
    // HTTP 456 = "Quota Exceeded" - tín hiệu RIÊNG của DeepL cho "đã dùng hết quota billing
    // period hiện tại" (khác 429 rate-limit thường, vốn chỉ là tạm thời trong vài giây/phút).
    if (res.status === 456) {
      await markQuotaExhausted("deepl", bodyText || "HTTP 456 Quota Exceeded");
    }
    throw new Error(`DEEPL_ERROR_${res.status}: ${bodyText.slice(0, 300)}`);
  }

  const data = await res.json();
  const translated = data?.translations?.[0]?.text || "";
  if (!translated) throw new Error("DEEPL_EMPTY_RESPONSE");

  return jsonOk({ translated });
}

// ===== Azure Translator - tang chen giua Groq va Google Translate free, RIENG cho 3 ma
// DeepL KHONG ho tro: kk (Kazakh, app dung ma "kz"), uz (Uzbek), ky (Kyrgyz) - xem
// AZURE_TARGET_LANG_MAP trong app.js. KHONG dung lam tang thay the DeepL cho cac ma DeepL da
// ho tro tot (khong can them 1 dependency moi cho thu da co san). Free tier F0 cua Azure
// Translator: 2 trieu ky tu/thang - lon hon nhieu DeepL free (500k/thang), giup giam ap luc
// quota rieng cho 3 ma nay khi Groq het quota.
async function handleTranslateAzure(req: Request): Promise<Response> {
  const body = await req.json().catch(() => null);
  const text = body?.text;
  // targetLangCode/sourceLangCode: da la ma AZURE chuan (vd "kk", "uz", "ky") do client tu map
  // san (AZURE_TARGET_LANG_MAP/AZURE_SOURCE_LANG_MAP trong app.js) - cung nguyen tac voi
  // handleTranslateDeepl(): server khong tu doan/map lai de tranh 2 noi co danh sach lech nhau.
  const targetLangCode = body?.targetLangCode;
  const sourceLangCode = typeof body?.sourceLangCode === "string" ? body.sourceLangCode : undefined;

  if (!text || !targetLangCode) {
    return jsonError("MISSING_TEXT_OR_TARGET", 400);
  }

  // Tháng này Azure đã từng báo hết quota -> bỏ qua thẳng, không gọi mạng vô ích.
  if (await isQuotaBlocked("azure")) {
    throw new Error("AZURE_QUOTA_EXHAUSTED_THIS_MONTH");
  }

  const key = Deno.env.get("AZURE_TRANSLATOR_KEY");
  if (!key) throw new Error("SERVER_MISSING_AZURE_KEY");
  // Region BAT BUOC voi resource Azure Translator tao theo vung (khac Global resource) - da
  // so tai khoan free F0 deu tao theo vung, nen coi day la bat buoc thay vi tuy chon de tranh
  // loi 401 kho hieu ("kho xac thuc") khi thieu header nay.
  const region = Deno.env.get("AZURE_TRANSLATOR_REGION");
  if (!region) throw new Error("SERVER_MISSING_AZURE_REGION");
  const endpoint = Deno.env.get("AZURE_TRANSLATOR_ENDPOINT") || "https://api.cognitive.microsofttranslator.com";

  const params = new URLSearchParams({ "api-version": "3.0", to: targetLangCode });
  if (sourceLangCode) params.set("from", sourceLangCode);

  const res = await fetch(`${endpoint}/translate?${params.toString()}`, {
    method: "POST",
    headers: {
      "Ocp-Apim-Subscription-Key": key,
      "Ocp-Apim-Subscription-Region": region,
      "Content-Type": "application/json",
    },
    // Azure nhan mang cau (khong phai 1 object) - chi gui 1 phan tu, giong cach dung 1 cau/lan
    // dich cua ca DeepL lan Groq trong file nay.
    body: JSON.stringify([{ Text: text }]),
  });

  if (!res.ok) {
    const bodyText = await res.text().catch(() => "");
    // Azure Translator KHÔNG có 1 mã HTTP riêng biệt cho "hết quota" như DeepL (456) - thường
    // trả về HTTP 403 (Forbidden) khi vượt hạn mức free-tier F0, nhưng chưa xác minh được số
    // mã lỗi con chính xác (vd 403001) qua tài liệu chính thức tại thời điểm viết. Vì vậy dùng
    // 2 tín hiệu HEURISTIC (best-effort, có thể đánh dấu nhầm 1 lần rồi tự sửa ở tháng sau):
    // (a) HTTP 403 (401 đã là lỗi sai key, không tính), HOẶC (b) chuỗi "quota" xuất hiện trong
    // response body bất kể status - nếu 1 trong 2 đúng thì coi là hết quota tháng.
    if (res.status === 403 || /quota/i.test(bodyText)) {
      await markQuotaExhausted("azure", bodyText || `HTTP ${res.status}`);
    }
    throw new Error(`AZURE_ERROR_${res.status}: ${bodyText.slice(0, 300)}`);
  }

  const data = await res.json();
  const translated = data?.[0]?.translations?.[0]?.text || "";
  if (!translated) throw new Error("AZURE_EMPTY_RESPONSE");

  return jsonOk({ translated });
}

function jsonOk(data: unknown): Response {
  return new Response(JSON.stringify(data, null, 2), {
    status: 200,
    headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
  });
}

function jsonError(code: string, status: number): Response {
  return new Response(JSON.stringify({ error: code }), {
    status,
    headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
  });
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: CORS_HEADERS });
  }

  const secretError = checkAppSecret(req);
  if (secretError) return secretError;

  const url = new URL(req.url);
  const op = url.searchParams.get("op");

  if (req.method === "GET" && op === "debug") {
    return handleDebug();
  }

  if (req.method !== "POST") {
    return jsonError("METHOD_NOT_ALLOWED", 405);
  }

  try {
    if (op === "transcribe") return await handleTranscribe(req);
    if (op === "translate") return await handleTranslate(req);
    if (op === "translateGemini") return await handleTranslateGemini(req);
    if (op === "translateDeepl") return await handleTranslateDeepl(req);
    if (op === "translateAzure") return await handleTranslateAzure(req);
    return jsonError("UNKNOWN_OP", 400);
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("groq-relay error:", msg);
    const status =
      msg === "SERVER_MISSING_GROQ_KEY" ||
      msg === "SERVER_MISSING_GEMINI_KEY" ||
      msg === "SERVER_MISSING_DEEPL_KEY" ||
      msg === "SERVER_MISSING_AZURE_KEY" ||
      msg === "SERVER_MISSING_AZURE_REGION"
        ? 500
        : 502;
    return jsonError(msg, status);
  }
});
