-- Chạy 1 lần trong Supabase Studio -> SQL Editor (hoặc supabase db push nếu dùng CLI).
-- Bảng lưu lịch sử "hết quota theo tháng" cho các provider dịch có giới hạn free-tier tính
-- theo THÁNG (DeepL 500k ký tự/tháng, Azure Translator F0 2 triệu ký tự/tháng) - KHÔNG dùng
-- cho Groq/Gemini vì free-tier 2 dịch vụ đó giới hạn theo phút/ngày, không phải theo tháng
-- (xem groqCircuit trong app.js + index.ts cho cơ chế ngắn hạn riêng của Groq).

create table if not exists translate_quota_status (
  provider text primary key,              -- 'deepl' | 'azure'
  exhausted_at timestamptz not null,       -- thời điểm PHÁT HIỆN hết quota (theo tín hiệu lỗi
                                            -- đặc trưng của provider đó, vd DeepL HTTP 456)
  exhausted_month text not null,           -- 'YYYY-MM' (UTC) tại thời điểm exhausted_at - so
                                            -- sánh chuỗi này với tháng hiện tại để biết còn bị
                                            -- chặn hay đã sang billing period mới
  last_error text                          -- nội dung lỗi gốc (cắt ngắn) để debug khi cần xem
                                            -- lại vì sao bị đánh dấu hết quota
);

comment on table translate_quota_status is
  'Theo dõi hết quota THEO THÁNG cho các provider dịch free-tier reset theo billing period '
  '(DeepL, Azure Translator). Đọc/ghi từ Edge Function groq-relay bằng service role key.';

-- Row Level Security: bảng này CHỈ được đọc/ghi bởi Edge Function qua service role key (tự
-- động bypass RLS) - không có client nào khác (app di động) truy cập bảng này trực tiếp, nên
-- bật RLS mà KHÔNG thêm policy nào (mặc định chặn hết mọi request qua anon/authenticated key,
-- chỉ service role mới qua được) là đủ an toàn.
alter table translate_quota_status enable row level security;
