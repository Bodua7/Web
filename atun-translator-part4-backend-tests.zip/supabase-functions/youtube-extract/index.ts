// Edge Function: youtube-extract
// Gọi trực tiếp InnerTube API của YouTube (API nội bộ mà app Android/iOS chính chủ dùng)
// thay vì phụ thuộc Piped/Invidious công khai (đang bị YouTube chặn diện rộng).
//
// Ưu tiên client "JS-less" (ANDROID_VR, IOS, ANDROID) vì các client này thường trả về
// hlsManifestUrl / audio url KHÔNG bị mã hoá signatureCipher -> không cần giải mã cipher
// (phần phức tạp nhất khi tự làm extractor, yt-dlp phải chạy JS deobfuscate cho việc này).
// WEB client để cuối vì thường cần PO Token mới hoạt động.
//
// LƯU Ý: clientVersion/apiKey là giá trị reverse-engineer từ cộng đồng (yt-dlp, Piped, Invidious).
// YouTube đổi version định kỳ -> nếu tất cả client đều fail, khả năng cao cần cập nhật version mới.
//
// ===== Phụ đề/lời bài hát (thêm 1/9/2026) =====
// Cùng 1 lệnh gọi player endpoint đã có sẵn ở trên (dùng để lấy streamingData trước đây)
// CŨNG trả về data.captions.playerCaptionsTracklistRenderer.captionTracks - danh sách track
// phụ đề (cả phụ đề chính chủ do kênh tự đăng lẫn phụ đề tự động "asr" của YouTube) kèm
// baseUrl để tải nội dung timedtext. Đây là dữ liệu YouTube tự trả về cho video của họ,
// không phải endpoint riêng phải scrape thêm - tận dụng luôn, không tốn thêm request tới
// player endpoint. Chỉ thêm 1 bước fetch phụ để tải NỘI DUNG timedtext (baseUrl) server-side
// (tránh CORS khi gọi thẳng từ WebView) và parse sẵn thành mảng cue {start,dur,text} cho gọn.

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

interface ClientConfig {
  name: string;
  version: string;
  apiKey: string;
  userAgent: string;
  extraClientFields?: Record<string, unknown>;
}

const CLIENTS: ClientConfig[] = [
  {
    name: 'ANDROID_VR',
    version: '1.60.19',
    apiKey: 'AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8',
    userAgent: 'com.google.android.apps.youtube.vr.oculus/1.60.19 (Linux; U; Android 12L) gzip',
    extraClientFields: { deviceMake: 'Oculus', deviceModel: 'Quest 3', androidSdkVersion: 32 },
  },
  {
    name: 'IOS',
    version: '19.45.4',
    apiKey: 'AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8',
    userAgent: 'com.google.ios.youtube/19.45.4 (iPhone16,2; U; CPU iOS 17_5 like Mac OS X)',
    extraClientFields: { deviceMake: 'Apple', deviceModel: 'iPhone16,2', osName: 'iOS', osVersion: '17.5.1.21F90' },
  },
  {
    name: 'ANDROID',
    version: '19.09.37',
    apiKey: 'AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w',
    userAgent: 'com.google.android.youtube/19.09.37 (Linux; U; Android 14) gzip',
    extraClientFields: { androidSdkVersion: 34 },
  },
  {
    name: 'WEB',
    version: '2.20240726.00.00',
    apiKey: 'AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8',
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
  },
];

function extractVideoId(input: string): string {
  const trimmed = input.trim();
  if (/^[a-zA-Z0-9_-]{11}$/.test(trimmed)) return trimmed;
  try {
    const url = new URL(trimmed);
    if (url.hostname.includes('youtu.be')) return url.pathname.slice(1);
    if (url.searchParams.has('v')) return url.searchParams.get('v')!;
    const liveMatch = url.pathname.match(/\/live\/([a-zA-Z0-9_-]{11})/);
    if (liveMatch) return liveMatch[1];
  } catch (_e) {
    // không phải URL
  }
  throw new Error('Không nhận diện được video ID từ: ' + input);
}

async function tryClient(client: ClientConfig, videoId: string) {
  const body = {
    context: {
      client: {
        clientName: client.name,
        clientVersion: client.version,
        hl: 'en',
        gl: 'US',
        ...(client.extraClientFields || {}),
      },
    },
    videoId,
    contentCheckOk: true,
    racyCheckOk: true,
  };

  const res = await fetch(`https://www.youtube.com/youtubei/v1/player?key=${client.apiKey}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'User-Agent': client.userAgent,
      'X-YouTube-Client-Name': client.name,
      'X-YouTube-Client-Version': client.version,
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    throw new Error(`HTTP ${res.status}`);
  }

  const data = await res.json();
  const status = data?.playabilityStatus?.status;
  if (status !== 'OK') {
    throw new Error(`playabilityStatus=${status}: ${data?.playabilityStatus?.reason || 'không rõ lý do'}`);
  }

  const streamingData = data.streamingData || {};
  const videoDetails = data.videoDetails || {};
  const isLive = Boolean(videoDetails.isLiveContent || streamingData.hlsManifestUrl);

  // Danh sách track phụ đề (nếu có) - tách riêng khỏi phần streamingData vì captions luôn
  // được trả về (khi tồn tại) bất kể client nào phía trên có lấy được stream audio hay không -
  // nên đọc trước, dùng chung cho cả 2 nhánh return bên dưới (hls/direct/lỗi-không-có-stream).
  const rawTracks: any[] = data?.captions?.playerCaptionsTracklistRenderer?.captionTracks || [];
  const captionTracks = rawTracks
    .filter((t) => typeof t?.baseUrl === 'string')
    .map((t) => ({
      languageCode: String(t.languageCode || ''),
      name: String(t.name?.simpleText || t.name?.runs?.map((r: any) => r.text).join('') || t.languageCode || ''),
      isAuto: t.kind === 'asr',
      baseUrl: String(t.baseUrl),
    }));
  const common = { client: client.name, title: videoDetails.title, isLive, captionTracks };

  // Ưu tiên HLS (live hoặc VOD của client ios) vì không bị signatureCipher
  if (streamingData.hlsManifestUrl) {
    return { ...common, kind: 'hls' as const, url: streamingData.hlsManifestUrl };
  }

  // Fallback: tìm audio format KHÔNG có signatureCipher (url mở trực tiếp)
  const adaptiveFormats: any[] = streamingData.adaptiveFormats || [];
  const openAudio = adaptiveFormats
    .filter((f) => typeof f.url === 'string' && String(f.mimeType || '').startsWith('audio/'))
    .sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0))[0];

  if (openAudio) {
    return { ...common, kind: 'direct' as const, url: openAudio.url, mimeType: openAudio.mimeType };
  }

  // Không lấy được stream audio mở (có thể do signatureCipher) - vẫn coi là THÀNH CÔNG nếu có
  // caption track, vì mục đích "lời bài hát" chỉ cần phụ đề, không cần phát được audio qua
  // client này. kind:'none' báo cho caller biết KHÔNG có url stream (chỉ dùng cho tính năng cũ
  // fetch-audio-via-network, hiện đã bỏ, giữ lại field cho tương thích ngược).
  if (captionTracks.length > 0) {
    return { ...common, kind: 'none' as const };
  }

  throw new Error('Không có hlsManifestUrl, audio format mở, lẫn caption track nào');
}

// Chọn track phụ đề phù hợp nhất: ưu tiên khớp preferLang (nếu có) trước, trong số khớp thì ưu
// tiên track chính chủ (không phải "asr" tự động) vì thường chính xác hơn ASR của YouTube; nếu
// không có preferLang hoặc không khớp track nào, lấy track chính chủ đầu tiên, cuối cùng mới
// tới track "asr" đầu tiên (còn hơn không có gì).
function pickCaptionTrack(tracks: { languageCode: string; isAuto: boolean; baseUrl: string; name: string }[], preferLang?: string) {
  if (tracks.length === 0) return null;
  const pool = preferLang ? tracks.filter((t) => t.languageCode === preferLang || t.languageCode.startsWith(preferLang + '-')) : tracks;
  const searchIn = pool.length > 0 ? pool : tracks;
  return searchIn.find((t) => !t.isAuto) || searchIn.find((t) => t.isAuto) || null;
}

interface Cue { start: number; dur: number; text: string }

// Tải + parse nội dung timedtext của 1 track thành mảng cue - làm server-side để tránh CORS
// (googlevideo.com không luôn cho phép gọi thẳng từ WebView) và để chuẩn hoá định dạng trả về
// client, không phụ thuộc client phải tự hiểu XML/JSON3 riêng của YouTube.
async function fetchCues(baseUrl: string): Promise<Cue[]> {
  const url = baseUrl.includes('fmt=') ? baseUrl : baseUrl + '&fmt=json3';
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Tải timedtext lỗi HTTP ${res.status}`);
  const data = await res.json();
  const events: any[] = data?.events || [];
  const cues: Cue[] = [];
  for (const ev of events) {
    const segs: any[] = ev?.segs || [];
    if (segs.length === 0) continue;
    const text = segs.map((s) => String(s?.utf8 || '')).join('').replace(/\n+/g, ' ').trim();
    if (!text) continue;
    cues.push({ start: (ev.tStartMs || 0) / 1000, dur: (ev.dDurationMs || 0) / 1000, text });
  }
  return cues;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: CORS_HEADERS });
  }

  try {
    const { videoId: rawInput, preferLang } = await req.json();
    if (!rawInput) {
      return new Response(JSON.stringify({ error: 'Thiếu videoId hoặc url' }), {
        status: 400,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      });
    }

    const videoId = extractVideoId(rawInput);
    const attempts: string[] = [];

    for (const client of CLIENTS) {
      try {
        const result = await tryClient(client, videoId);
        const tracks = result.captionTracks.map((t) => ({ languageCode: t.languageCode, name: t.name, isAuto: t.isAuto }));
        const chosen = pickCaptionTrack(result.captionTracks, preferLang || undefined);
        let cues: Cue[] = [];
        let cuesError: string | null = null;
        if (chosen) {
          try {
            cues = await fetchCues(chosen.baseUrl);
          } catch (err) {
            cuesError = (err as Error).message;
          }
        }
        return new Response(JSON.stringify({
          ok: true,
          client: result.client,
          title: result.title,
          isLive: result.isLive,
          tracks,
          chosen: chosen ? { languageCode: chosen.languageCode, name: chosen.name, isAuto: chosen.isAuto } : null,
          cues,
          cuesError,
        }), {
          headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
        });
      } catch (err) {
        attempts.push(`${client.name}: ${(err as Error).message}`);
      }
    }

    return new Response(
      JSON.stringify({ ok: false, error: 'Tất cả client đều fail', attempts }),
      { status: 502, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
    );
  } catch (err) {
    return new Response(JSON.stringify({ ok: false, error: (err as Error).message }), {
      status: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
    });
  }
});
