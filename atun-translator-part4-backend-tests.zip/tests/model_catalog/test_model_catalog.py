"""Validate CATALOG trong native/ModelManagerPlugin.kt.

Chạy: cd tests/model_catalog && pip install pytest && pytest -v
Chạy CẢ kiểm tra URL thật (cần internet, nên chạy trong CI): pytest -v -m network
Chỉ chạy kiểm tra tĩnh, bỏ qua kiểm tra mạng (chạy máy cá nhân không có mạng):
    pytest -v -m "not network"

Mục tiêu: bắt lớp bug "entry catalog có URL placeholder/sai/không tồn tại"
NGAY khi push code (CI), thay vì chỉ tình cờ phát hiện lúc bấm tải model trên
máy thật và thấy lỗi 404. Đây chính là bug F đã từng gặp trước đó.

catalog_parser.py đọc THẲNG file .kt thật (không hand-port) - xem docstring
ở đó để biết lý do.
"""

import sys
import urllib.error
import urllib.request
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent))

from catalog_parser import CatalogEntry, parse_catalog  # noqa: E402


# Các chuỗi placeholder/giả hay gặp khi code chưa hoàn thiện (bug F thuộc dạng này) -
# nếu URL chứa bất kỳ chuỗi nào dưới đây (không phân biệt hoa/thường) thì coi là lỗi.
_PLACEHOLDER_MARKERS = [
    "todo",
    "placeholder",
    "changeme",
    "example.com",
    "your-",
    "xxx",
    "fixme",
    "localhost",
    "127.0.0.1",
]

# Danh sách host được tin cậy để host model Vosk - mở rộng danh sách này nếu sau
# này catalog dùng thêm nguồn khác (vd tự host trên GitHub Releases của repo).
# "huggingface.co": thêm vào sau khi phát hiện lỗ hổng kiểm tra - đây là host thật của
# mirrorUrl cho vi/ja/ko trong CATALOG (xem ModelInfo.mirrorUrl), nhưng trước đây các test
# _url_ ở dưới chỉ đọc field `url`, KHÔNG BAO GIỜ đụng tới `mirror_url` -> nếu ai gõ nhầm/hỏng
# 1 mirrorUrl thật (chính là loại bug F mà bộ test này sinh ra để chặn) thì không test nào bắt
# được. Đã thêm _iter_url_fields() + các test_mirror_* bên dưới để vá lỗ hổng này.
_TRUSTED_HOSTS = [
    "alphacephei.com",
    "github.com",
    "githubusercontent.com",
    "objects.githubusercontent.com",
    "huggingface.co",
]


@pytest.fixture(scope="module")
def catalog() -> list[CatalogEntry]:
    return parse_catalog()


def _iter_mirror_urls(catalog: list[CatalogEntry]):
    """Yield (lang, mirror_url) cho các entry CÓ mirrorUrl - dùng chung cho mọi
    test_mirror_* bên dưới, bỏ qua entry mirror_url=None thay vì fail/assert rỗng
    (mirrorUrl là optional, không phải mọi ngôn ngữ đều cần có)."""
    for e in catalog:
        if e.mirror_url:
            yield e.lang, e.mirror_url


# ===== Kiểm tra tĩnh - luôn chạy, không cần mạng ===== #

def test_catalog_is_not_empty(catalog):
    assert len(catalog) > 0


def test_no_duplicate_lang_keys(catalog):
    langs = [e.lang for e in catalog]
    assert len(langs) == len(set(langs)), f"Có lang trùng lặp trong CATALOG: {langs}"


def test_english_small_model_in_catalog(catalog):
    # "en" (small) trước đây bundle sẵn trong APK, giờ tải on-demand như mọi ngôn ngữ khác -
    # đảm bảo không bị xoá nhầm khỏi CATALOG (nếu thiếu, app sẽ không có cách nào tải tiếng
    # Anh về nữa vì không còn asset bundle dự phòng).
    langs = [e.lang for e in catalog]
    assert "en" in langs, "CATALOG thiếu entry 'en' - tiếng Anh không còn bundle sẵn trong APK nên PHẢI có trong CATALOG để tải on-demand."


@pytest.mark.parametrize("field", ["lang", "name", "url"])
def test_no_blank_fields(catalog, field):
    for e in catalog:
        value = getattr(e, field)
        assert value and value.strip(), f"Entry lang={e.lang!r} có field {field!r} rỗng."


def test_urls_use_https(catalog):
    for e in catalog:
        assert e.url.startswith("https://"), (
            f"Entry lang={e.lang!r} có URL không dùng https://: {e.url}"
        )


def test_urls_end_with_zip(catalog):
    for e in catalog:
        assert e.url.endswith(".zip"), (
            f"Entry lang={e.lang!r} có URL không kết thúc bằng .zip (model Vosk luôn là "
            f"file zip): {e.url}"
        )


def test_urls_have_no_placeholder_markers(catalog):
    for e in catalog:
        lowered = e.url.lower()
        for marker in _PLACEHOLDER_MARKERS:
            assert marker not in lowered, (
                f"Entry lang={e.lang!r} có URL chứa chuỗi placeholder {marker!r} - đây "
                f"chính là lớp bug F đã gặp trước đó: {e.url}"
            )


def test_urls_use_trusted_host(catalog):
    for e in catalog:
        host_ok = any(trusted in e.url for trusted in _TRUSTED_HOSTS)
        assert host_ok, (
            f"Entry lang={e.lang!r} dùng host không nằm trong danh sách tin cậy "
            f"({_TRUSTED_HOSTS}): {e.url}\n"
            "Nếu đây là host mới hợp lệ, thêm vào _TRUSTED_HOSTS trong test này."
        )


def test_mirror_urls_use_https(catalog):
    for lang, mirror in _iter_mirror_urls(catalog):
        assert mirror.startswith("https://"), (
            f"Entry lang={lang!r} có mirrorUrl không dùng https://: {mirror}"
        )


def test_mirror_urls_end_with_zip(catalog):
    for lang, mirror in _iter_mirror_urls(catalog):
        assert mirror.endswith(".zip"), (
            f"Entry lang={lang!r} có mirrorUrl không kết thúc bằng .zip: {mirror}"
        )


def test_mirror_urls_have_no_placeholder_markers(catalog):
    for lang, mirror in _iter_mirror_urls(catalog):
        lowered = mirror.lower()
        for marker in _PLACEHOLDER_MARKERS:
            assert marker not in lowered, (
                f"Entry lang={lang!r} có mirrorUrl chứa chuỗi placeholder {marker!r} - đây "
                f"chính là lớp bug F đã gặp trước đó (lần này ở mirror, không phải url gốc): "
                f"{mirror}"
            )


def test_mirror_urls_use_trusted_host(catalog):
    for lang, mirror in _iter_mirror_urls(catalog):
        host_ok = any(trusted in mirror for trusted in _TRUSTED_HOSTS)
        assert host_ok, (
            f"Entry lang={lang!r} dùng mirrorUrl với host không nằm trong danh sách tin cậy "
            f"({_TRUSTED_HOSTS}): {mirror}\n"
            "Nếu đây là host mirror mới hợp lệ, thêm vào _TRUSTED_HOSTS trong test này."
        )


def test_mirror_url_differs_from_primary_url(catalog):
    # Bug thực tế có thể gõ nhầm: copy-paste url gốc vào luôn mirrorUrl (mirror trùng hệt
    # url chính) - vô nghĩa vì không còn là nguồn KHÁC HOST để fallback khi url gốc lỗi.
    for e in catalog:
        if e.mirror_url:
            assert e.mirror_url != e.url, (
                f"Entry lang={e.lang!r} có mirrorUrl giống hệt url gốc - không phải nguồn dự "
                f"phòng thật (mirrorUrl nên trỏ host KHÁC url gốc): {e.url}"
            )


def test_size_mb_is_sane(catalog):
    for e in catalog:
        assert 0 < e.size_mb <= 5000, (
            f"Entry lang={e.lang!r} có sizeMB={e.size_mb} bất thường (0 hoặc >5000MB, "
            "có thể gõ nhầm số 0 hoặc thiếu chữ số)."
        )


def test_lang_keys_look_like_lang_codes(catalog):
    for e in catalog:
        # vd "vi", "ja", "ko", "en-in" - 2-3 chữ thường, có thể kèm "-<hậu tố>"
        assert e.lang[:2].isalpha() and e.lang[:2].islower(), (
            f"lang={e.lang!r} không giống mã ngôn ngữ hợp lệ (phải bắt đầu bằng 2 chữ "
            "thường, vd 'vi', 'ja', 'en-in')."
        )


# ===== Kiểm tra mạng thật - chỉ chạy khi có -m network (khuyến khích chạy trong CI) ===== #


def _check_urls_reachable(pairs: list[tuple[str, str]]) -> list[str]:
    """HEAD request thật tới từng (lang, url) - bắt được URL 404/sai domain mà kiểm tra tĩnh
    ở trên không thể phát hiện (vd domain đúng format nhưng model đã bị gỡ/đổi tên).

    Dùng HEAD (không GET) để không phải tải cả model - GET thật sự cho toàn bộ ~29 entry sẽ
    chậm/tốn băng thông CI hơn hẳn HEAD dù model lớn nhất trong catalog hiện tại cũng chỉ
    ~128MB ("en"). Dùng chung cho cả url gốc lẫn mirror_url (2 test bên dưới).
    """
    failures: list[str] = []
    for lang, url in pairs:
        req = urllib.request.Request(url, method="HEAD")
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                status = resp.status
                if not (200 <= status < 400):
                    failures.append(f"{lang} ({url}): HTTP {status}")
        except urllib.error.HTTPError as err:
            # Server trả lời thật nhưng bằng mã lỗi (vd 404) - đây LÀ bug thật, không skip.
            failures.append(f"{lang} ({url}): HTTP {err.code}")
        except urllib.error.URLError as err:
            # Không kết nối được (DNS/timeout/không có mạng trong môi trường chạy test) -
            # không đủ căn cứ kết luận URL sai, skip thay vì fail để tránh CI flaky vì lý
            # do ngoài tầm kiểm soát (vd sandbox không có internet).
            pytest.skip(f"Không kết nối được để kiểm tra mạng thật ({err}) - bỏ qua test này.")
    return failures


@pytest.mark.network
def test_urls_are_actually_reachable(catalog):
    failures = _check_urls_reachable([(e.lang, e.url) for e in catalog])
    assert not failures, "Các URL sau không truy cập được:\n" + "\n".join(failures)


@pytest.mark.network
def test_mirror_urls_are_actually_reachable(catalog):
    # Trước đây KHÔNG có test này - mirrorUrl (huggingface.co, dùng làm nguồn tải dự phòng
    # thật khi alphacephei.com lỗi, xem ModelManagerPlugin.downloadModel()) chưa từng được
    # xác minh còn tồn tại/đúng đường dẫn, dù đây chính xác là loại lỗi (URL sai/đã gỡ) mà
    # bộ test này được viết ra để chặn.
    pairs = list(_iter_mirror_urls(catalog))
    if not pairs:
        pytest.skip("Không có entry nào trong CATALOG có mirrorUrl.")
    failures = _check_urls_reachable(pairs)
    assert not failures, "Các mirrorUrl sau không truy cập được:\n" + "\n".join(failures)
