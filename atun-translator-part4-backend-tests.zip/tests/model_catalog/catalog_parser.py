"""Trích xuất CATALOG từ native/ModelManagerPlugin.kt bằng regex.

KHÁC với cách tiếp cận "port tay" ở tests/vad/ và tests/translate/: ở đây
KHÔNG hand-copy danh sách URL sang Python, vì mục đích của test này chính là
phát hiện dữ liệu sai/placeholder trong file .kt THẬT - nếu hand-copy thì test
sẽ luôn pass trên bản copy đúng của chính nó, không bắt được lỗi trong file
gốc (đây chính xác là kiểu bug F đã lọt qua trước đó: chỉ phát hiện khi build
thật rồi bấm tải model, không có gì tự động kiểm tra được).

Vì vậy file này ĐỌC THẲNG native/ModelManagerPlugin.kt mỗi lần chạy test -
không cần giữ đồng bộ thủ công, không có rủi ro lệch pha.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

# tests/model_catalog/catalog_parser.py -> parents[2] = thư mục gốc repo
REPO_ROOT = Path(__file__).resolve().parents[2]
MODEL_MANAGER_KT_PATH = REPO_ROOT / "native" / "ModelManagerPlugin.kt"

# Khớp từng entry dạng:
#   "vi" to ModelInfo(
#       "Tiếng Việt",
#       "https://alphacephei.com/vosk/models/vosk-model-small-vn-0.4.zip",
#       32,
#       mirrorUrl = "https://huggingface.co/.../vosk-model-small-vn-0.4.zip"
#   ),
# mirrorUrl là tham số optional (mọi entry thật hiện tại đều có, sau bug F) - trước đây
# regex bắt "size rồi ) ngay" nên KHÔNG khớp được entry nào có mirrorUrl chen giữa, làm
# parse_catalog() luôn báo "không parse được entry nào". Giờ cho dấu phẩy sau size + cả
# khối mirrorUrl=... là optional.
_ENTRY_RE = re.compile(
    r'"(?P<lang>[A-Za-z0-9_-]+)"\s+to\s+ModelInfo\(\s*'
    r'"(?P<name>[^"]+)"\s*,\s*'
    r'"(?P<url>[^"]+)"\s*,\s*'
    r'(?P<size>\d+)\s*,?\s*'
    r'(?:mirrorUrl\s*=\s*"(?P<mirror>[^"]*)"\s*,?\s*)?'
    r'\)',
    re.DOTALL,
)


@dataclass(frozen=True)
class CatalogEntry:
    lang: str
    name: str
    url: str
    size_mb: int
    mirror_url: str | None = None


def read_source() -> str:
    if not MODEL_MANAGER_KT_PATH.exists():
        raise FileNotFoundError(
            f"Không tìm thấy {MODEL_MANAGER_KT_PATH} - test này phải chạy từ repo có "
            "đủ native/ModelManagerPlugin.kt (chạy trong CI sau khi checkout đầy đủ)."
        )
    return MODEL_MANAGER_KT_PATH.read_text(encoding="utf-8")


def _find_catalog_block(text: str) -> str:
    """Trả về nội dung bên trong `mapOf( ... )` của CATALOG, dùng scanner đếm độ sâu
    ngoặc (có nhận biết chuỗi ký tự) thay vì regex đơn giản - vì 1 số display name
    trong catalog (vd "English (chính xác cao)") chứa dấu ngoặc NGAY BÊN TRONG chuỗi,
    khiến cách khớp "dòng chỉ có 1 dấu )" bị nhầm điểm đóng khối."""
    marker = "val CATALOG:"
    if marker not in text:
        raise ValueError("Không tìm thấy 'val CATALOG:' trong ModelManagerPlugin.kt.")
    start_idx = text.index(marker)

    map_of = "mapOf("
    if map_of not in text[start_idx:]:
        raise ValueError("Không tìm thấy 'mapOf(' ngay sau khai báo CATALOG.")
    open_paren_idx = text.index(map_of, start_idx) + len(map_of) - 1

    depth = 0
    in_string = False
    i = open_paren_idx
    n = len(text)
    while i < n:
        ch = text[i]
        if in_string:
            if ch == "\\":
                i += 2
                continue
            if ch == '"':
                in_string = False
        else:
            if ch == '"':
                in_string = True
            elif ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth == 0:
                    return text[open_paren_idx + 1 : i]
        i += 1
    raise ValueError(
        "Không tìm thấy dấu ')' khớp với 'mapOf(' của CATALOG - file .kt có thể bị lỗi "
        "cú pháp hoặc cấu trúc đã đổi khác cách viết hiện tại."
    )


def parse_catalog(source: str | None = None) -> list[CatalogEntry]:
    text = source if source is not None else read_source()
    block = _find_catalog_block(text)

    entries = [
        CatalogEntry(
            lang=m.group("lang"),
            name=m.group("name"),
            url=m.group("url"),
            size_mb=int(m.group("size")),
            mirror_url=m.group("mirror"),
        )
        for m in _ENTRY_RE.finditer(block)
    ]
    if not entries:
        raise ValueError(
            "Tìm thấy khối CATALOG nhưng không parse được entry nào - regex _ENTRY_RE có "
            "thể không còn khớp cấu trúc ModelInfo(...) thật trong file .kt."
        )
    return entries
