# Test harness cho `ModelCatalog.CATALOG` (Hạng mục H)

Validate danh sách model tải-thêm trong `native/ModelCatalog.kt`, để bắt
lỗi kiểu **URL placeholder/sai/không tồn tại** ngay khi push code (CI), thay vì
chỉ tình cờ phát hiện lúc bấm tải model trên máy thật và thấy lỗi 404. Đây
chính là bug F đã từng gặp trước đó.

## Chạy test

```bash
cd tests/model_catalog
pip install pytest
pytest -v                 # chỉ kiểm tra tĩnh (không cần mạng)
pytest -v -m network      # thêm cả kiểm tra URL thật (cần internet - chạy trong CI)
pytest -v -m "not network"  # rõ ràng bỏ qua kiểm tra mạng
```

## Cấu trúc

- `catalog_parser.py` — đọc **thẳng** `native/ModelCatalog.kt` (không
  hand-copy dữ liệu), dùng scanner đếm độ sâu ngoặc có nhận biết chuỗi ký tự
  để tách đúng khối `mapOf(...)` (regex đơn giản bị nhầm vì 1 số tên hiển thị,
  vd `"English (chính xác cao)"`, có dấu ngoặc ngay trong chuỗi).
- `test_model_catalog.py` — kiểm tra tĩnh (không trùng lang, URL dùng https +
  đuôi `.zip`, không chứa chuỗi placeholder như `TODO`/`example.com`/`xxx`,
  host nằm trong danh sách tin cậy, sizeMB hợp lý...) + 2 test mạng thật
  (`@pytest.mark.network`, dùng HEAD request, không tải cả file để tránh tốn
  băng thông với model nặng ~1.8GB).

  **`mirrorUrl` được kiểm y hệt `url` gốc** (https, đuôi `.zip`, không
  placeholder, host tin cậy, HEAD request thật + 1 test riêng đảm bảo mirror
  không trùng hệt url gốc) - trước đây các test chỉ đọc field `url`, bỏ sót
  hoàn toàn `mirror_url` dù đây là nguồn tải dự phòng THẬT (dùng khi
  alphacephei.com lỗi, xem `ModelManagerPlugin.downloadModel()`) - đúng loại
  lỗ hổng mà bộ test này được viết ra để chặn (bug F) nhưng lại chưa che phủ
  hết. `huggingface.co` đã thêm vào `_TRUSTED_HOSTS` vì đây là host mirror
  thật đang dùng cho `vi`/`ja`/`ko`.

## ⚠️ KHÁC với `tests/vad/` và `tests/translate/`

2 bộ test kia là **bản dịch tay** (hand-port) từ Kotlin/JS sang Python - phải
tự cập nhật thủ công mỗi khi sửa file gốc.

Bộ test này thì **đọc trực tiếp** file `.kt` thật, không hand-copy gì cả -
mục đích chính là phát hiện dữ liệu sai NGAY TRONG file gốc, nên hand-copy sẽ
vô nghĩa (test sẽ luôn pass trên bản copy đúng của chính nó, không bắt được
lỗi thật). Vì vậy không cần giữ đồng bộ thủ công, không có rủi ro lệch pha -
chỉ cần `catalog_parser.py` parse đúng cấu trúc `ModelInfo(...)` hiện tại; nếu
sau này đổi cấu trúc CATALOG (thêm field, đổi tên class...) thì mới cần sửa
lại `_ENTRY_RE`/`_find_catalog_block` trong `catalog_parser.py`.

## Thêm model mới vào catalog

Chỉ cần thêm entry vào `CATALOG` trong `ModelCatalog.kt` như bình
thường, rồi chạy `pytest -v -m network` (cần mạng) để tự động xác nhận URL
mới thật sự tải được trước khi commit - không cần tự tay mở URL kiểm tra.
