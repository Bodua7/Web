"""Bản dịch tay của phần LOGIC NGẮT CÂU THÔNG MINH (smart pause) trong
`startVoskAndReadLoop()` (`native/SttReadLoop.kt`) - quyết định KHI NÀO gọi
`sttEngine.forcePauseFinal()` để ép Vosk chốt câu ngay khi phát hiện người nói
tạm nghỉ, tách biệt hoàn toàn khỏi nhánh Cloud STT (`startCloudSttReadLoop()`,
đã có port riêng ở `tests/cloud_stt_segment/` - 2 nhánh dùng 2 ngưỡng thời
gian khác hẳn nhau: SMART_PAUSE_MS ~30ms cho Vosk vs CLOUD_SEGMENT_PAUSE_MS
600ms cho Cloud STT, không dùng chung state machine).

CỐ Ý KHÔNG port: AudioRecord.read() thật, VadDetector.process() thật (đã có
port riêng ở `tests/vad/`, dùng chung is_voice: bool làm input y hệt cách
`tests/cloud_stt_segment/segment_cutter.py` đã làm), việc feed buffer vào
SttEngine, bắn sự kiện audioLevel (thống kê UI, không ảnh hưởng hành vi chốt
câu) - chỉ port đúng state machine `lastVoiceAt`/`pauseHandled` + điều kiện
gọi forcePauseFinal().

Không import trực tiếp từ .kt - mỗi khi sửa khối `if (smartPause) { ... }`
trong `startVoskAndReadLoop()` (đổi SMART_PAUSE_MS, đổi điều kiện reset
pauseHandled, đổi thứ tự set lastVoiceAt...) thì phải sửa lại file này cho
khớp.
"""

from __future__ import annotations

from dataclasses import dataclass

# ===== Hằng số - PHẢI khớp AudioCaptureService.SMART_PAUSE_MS ===== #
SMART_PAUSE_MS = 30


@dataclass(frozen=True)
class ReadResult:
    """Kết quả 1 lần xử lý read() - khớp đúng thân vòng lặp `while (isCapturing)`
    khi `read > 0` và `smartPause == true` trong Kotlin."""

    force_pause_final_called: bool
    pause_handled: bool
    last_voice_at: int


class VoskSmartPause:
    """Port của các biến closure trong startVoskAndReadLoop(): lastVoiceAt,
    pauseHandled + đúng nhánh `if (smartPause) { ... }`. Thời gian truyền vào
    bằng mili-giây tuyệt đối do caller tự quản lý (test dùng số nguyên đơn
    giản thay System.currentTimeMillis() thật) - giống hệt quy ước đã dùng ở
    tests/cloud_stt_segment/segment_cutter.py.

    force_pause_final: callable không tham số - gọi lại đúng lúc Kotlin gọi
    sttEngine?.forcePauseFinal(); mặc định đếm số lần gọi để test kiểm tra.
    """

    def __init__(self, now_ms: int, force_pause_final=None):
        self._last_voice_at = now_ms
        self._pause_handled = False
        self._force_pause_final_calls = 0
        self._on_force_pause_final = force_pause_final

    @property
    def pause_handled(self) -> bool:
        return self._pause_handled

    @property
    def last_voice_at(self) -> int:
        return self._last_voice_at

    @property
    def force_pause_final_calls(self) -> int:
        return self._force_pause_final_calls

    def process_read(self, is_silent_read: bool, now_ms: int) -> ReadResult:
        """Port 1-1 của khối:
            if (isSilentRead) {
                if (!pauseHandled && (now - lastVoiceAt) >= SMART_PAUSE_MS) {
                    sttEngine?.forcePauseFinal()
                    pauseHandled = true
                }
            } else {
                lastVoiceAt = now
                pauseHandled = false
            }
        """
        called = False
        if is_silent_read:
            if not self._pause_handled and (now_ms - self._last_voice_at) >= SMART_PAUSE_MS:
                if self._on_force_pause_final:
                    self._on_force_pause_final()
                self._force_pause_final_calls += 1
                self._pause_handled = True
                called = True
        else:
            self._last_voice_at = now_ms
            self._pause_handled = False

        return ReadResult(
            force_pause_final_called=called,
            pause_handled=self._pause_handled,
            last_voice_at=self._last_voice_at,
        )
