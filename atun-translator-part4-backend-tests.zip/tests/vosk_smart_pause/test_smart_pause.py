"""Test cho smart_pause.py (bản port Python của phần "Ngắt câu thông minh"
nhánh Vosk trong native/SttReadLoop.kt, startVoskAndReadLoop()).

Chạy: cd tests/vosk_smart_pause && pip install pytest && pytest -v
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from smart_pause import SMART_PAUSE_MS, VoskSmartPause  # noqa: E402


# ===== Chưa im lặng đủ lâu: không gọi forcePauseFinal ===== #

def test_no_call_while_still_speaking():
    sp = VoskSmartPause(now_ms=0)
    result = sp.process_read(is_silent_read=False, now_ms=10)
    assert result.force_pause_final_called is False
    assert sp.force_pause_final_calls == 0


def test_no_call_when_silence_shorter_than_threshold():
    sp = VoskSmartPause(now_ms=0)
    result = sp.process_read(is_silent_read=True, now_ms=SMART_PAUSE_MS - 1)
    assert result.force_pause_final_called is False


def test_call_exactly_at_threshold():
    # Kotlin dùng >= nên đúng bằng ngưỡng vẫn phải gọi.
    sp = VoskSmartPause(now_ms=0)
    result = sp.process_read(is_silent_read=True, now_ms=SMART_PAUSE_MS)
    assert result.force_pause_final_called is True
    assert result.pause_handled is True


def test_call_after_threshold():
    sp = VoskSmartPause(now_ms=0)
    result = sp.process_read(is_silent_read=True, now_ms=SMART_PAUSE_MS + 50)
    assert result.force_pause_final_called is True


# ===== pauseHandled chặn gọi lặp lại cho cùng 1 khoảng im lặng ===== #

def test_does_not_call_again_while_still_silent_after_first_call():
    sp = VoskSmartPause(now_ms=0)
    first = sp.process_read(is_silent_read=True, now_ms=SMART_PAUSE_MS)
    assert first.force_pause_final_called is True

    # Vẫn im lặng tiếp, nhiều lần read() sau đó - KHÔNG được gọi lại.
    second = sp.process_read(is_silent_read=True, now_ms=SMART_PAUSE_MS + 10)
    third = sp.process_read(is_silent_read=True, now_ms=SMART_PAUSE_MS + 1000)
    assert second.force_pause_final_called is False
    assert third.force_pause_final_called is False
    assert sp.force_pause_final_calls == 1


def test_call_count_via_callback():
    calls = []
    sp = VoskSmartPause(now_ms=0, force_pause_final=lambda: calls.append(1))
    sp.process_read(is_silent_read=True, now_ms=SMART_PAUSE_MS)
    sp.process_read(is_silent_read=True, now_ms=SMART_PAUSE_MS + 5)
    assert len(calls) == 1


# ===== Có giọng nói trở lại: reset lastVoiceAt + pauseHandled ===== #

def test_voice_resets_last_voice_at():
    sp = VoskSmartPause(now_ms=0)
    sp.process_read(is_silent_read=False, now_ms=100)
    assert sp.last_voice_at == 100


def test_voice_after_pause_handled_allows_new_pause_cycle():
    sp = VoskSmartPause(now_ms=0)
    # Chu kỳ 1: im lặng đủ lâu -> chốt câu.
    sp.process_read(is_silent_read=True, now_ms=SMART_PAUSE_MS)
    assert sp.pause_handled is True

    # Người nói lại - reset pauseHandled + lastVoiceAt.
    sp.process_read(is_silent_read=False, now_ms=SMART_PAUSE_MS + 5)
    assert sp.pause_handled is False
    assert sp.last_voice_at == SMART_PAUSE_MS + 5

    # Chu kỳ 2: im lặng đủ lâu tính từ mốc lastVoiceAt MỚI -> chốt câu lần nữa.
    result = sp.process_read(is_silent_read=True, now_ms=SMART_PAUSE_MS + 5 + SMART_PAUSE_MS)
    assert result.force_pause_final_called is True
    assert sp.force_pause_final_calls == 2


def test_brief_voice_blip_during_silence_resets_pause_window():
    # Người nói phát ra 1 âm ngắn giữa khoảng nghỉ (vd hắng giọng) - lastVoiceAt dời lại,
    # khoảng im lặng phải tính lại từ đầu, không được chốt câu sớm hơn dự kiến.
    sp = VoskSmartPause(now_ms=0)
    sp.process_read(is_silent_read=True, now_ms=SMART_PAUSE_MS - 1)  # gần tới ngưỡng nhưng chưa đủ
    sp.process_read(is_silent_read=False, now_ms=SMART_PAUSE_MS - 1)  # có tiếng -> dời mốc

    # Nếu KHÔNG dời mốc, now=SMART_PAUSE_MS đã đủ ngưỡng tính từ lastVoiceAt=0 cũ.
    result = sp.process_read(is_silent_read=True, now_ms=SMART_PAUSE_MS)
    assert result.force_pause_final_called is False

    # Đủ ngưỡng tính từ mốc MỚI (SMART_PAUSE_MS - 1) mới được chốt.
    result2 = sp.process_read(is_silent_read=True, now_ms=(SMART_PAUSE_MS - 1) + SMART_PAUSE_MS)
    assert result2.force_pause_final_called is True


# ===== Kịch bản nhiều câu liên tiếp (mô phỏng người nói cả đoạn dài) ===== #

def test_multiple_sentences_in_sequence():
    sp = VoskSmartPause(now_ms=0)
    calls_at = []
    t = 0
    # Nói 1 câu (voice liên tục 200ms), nghỉ đủ lâu, lặp lại 3 lần.
    for _ in range(3):
        for offset in range(0, 200, 10):
            sp.process_read(is_silent_read=False, now_ms=t + offset)
        t += 200
        result = sp.process_read(is_silent_read=True, now_ms=t + SMART_PAUSE_MS)
        if result.force_pause_final_called:
            calls_at.append(t + SMART_PAUSE_MS)
        t += SMART_PAUSE_MS + 500  # nghỉ giữa các câu trước khi nói câu tiếp

    assert len(calls_at) == 3
    assert sp.force_pause_final_calls == 3
