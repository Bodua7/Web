# Test harness cho "Ngắt câu thông minh" nhánh Vosk (Hạng mục cuối AudioCaptureService)

Port thuần Python của phần LOGIC THUẦN còn thiếu trong `startVoskAndReadLoop()`
(`native/SttReadLoop.kt`) - state machine quyết định KHI NÀO gọi
`sttEngine.forcePauseFinal()` để ép Vosk chốt câu ngay khi phát hiện người nói
tạm nghỉ (`SMART_PAUSE_MS`). Đây là phần được chính README của
`tests/cloud_stt_segment/` liệt là "CHƯA che phủ" (nhánh Cloud STT dùng
`CLOUD_SEGMENT_PAUSE_MS`/state machine khác hẳn, đã có test riêng).

## Chạy test

```bash
cd tests/vosk_smart_pause
pip install pytest
pytest -v
```

## Cấu trúc

- `smart_pause.py` — port của biến `lastVoiceAt`/`pauseHandled` + đúng nhánh
  `if (smartPause) { ... }` trong `startVoskAndReadLoop()`, nhận trực tiếp
  `is_silent_read: bool` làm input (tách khỏi `VadDetector` thật - đã có port
  riêng ở `tests/vad/`, không port lại ở đây).
- `test_smart_pause.py` — 10 test case bao phủ: chưa im lặng đủ `SMART_PAUSE_MS`
  thì không gọi, gọi đúng lúc chạm/ vượt ngưỡng (biên `>=`), `pauseHandled`
  chặn gọi lặp lại nhiều lần cho cùng 1 khoảng im lặng, có giọng nói trở lại
  thì reset `lastVoiceAt`/`pauseHandled` cho phép chu kỳ chốt câu tiếp theo,
  1 tiếng nói ngắn xen giữa khoảng nghỉ (vd hắng giọng) dời lại đúng mốc tính
  ngưỡng thay vì chốt câu sớm hơn dự kiến, và 1 kịch bản nói nhiều câu liên
  tiếp trong 1 phiên dài.

## ⚠️ Bắt buộc giữ đồng bộ

`smart_pause.py` là bản dịch **tay**. Mỗi khi sửa `SMART_PAUSE_MS`, đổi thứ
tự set `lastVoiceAt`/`pauseHandled`, hay đổi điều kiện gọi `forcePauseFinal()`
trong `startVoskAndReadLoop()` (`native/SttReadLoop.kt`) thì phải sửa lại file
này cho khớp, rồi chạy lại `pytest`.

## Phạm vi CHƯA che phủ (cần build thật hoặc máy Android thật)

- Toàn bộ phần dựng `SttEngine`/`MultiLangVoskEngine`, `AudioRecord.startRecording()`
  thật, việc `feed()` audio thật vào Vosk, và luồng resume qua `onStartCommand`
  khi service bị OS kill giữa chừng (`AudioCaptureService.kt`).
- `VadDetector.process()` thật (đã có port riêng, xem `tests/vad/`) - bộ test
  này chỉ nhận `is_silent_read: bool` làm input giả lập.
- Luồng chọn Vosk vs Cloud STT ở tầng JS (`app.module.js`: `cloudSttQueue`,
  `pushFinalToBatch`) - phụ thuộc nhiều DOM/state UI, chưa port; đáng cân
  nhắc port riêng phần chọn `effectiveSourceLang` trong `flushFinalBatch()`
  nếu cần thêm test hồi quy sau này.
