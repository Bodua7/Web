"""Test cho normalizeUrl() (bản port Python của native/BrowserTabManager.kt).

Chạy: cd tests/browser_url && pip install pytest && pytest -v

Mục tiêu: bắt đúng loại bug đã ghi trong comment gốc - các ký tự "vô hình"
dính theo khi copy link từ app khác khiến startsWith("https://") trượt oan,
và các trường hợp biên giữa "đây là URL" vs "đây là từ khoá tìm kiếm".
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from normalize_url import normalize_url  # noqa: E402


# ===== Chuỗi rỗng ===== #

def test_empty_string_defaults_to_google_home():
    assert normalize_url("") == "https://www.google.com"


def test_whitespace_only_defaults_to_google_home():
    assert normalize_url("   \t  ") == "https://www.google.com"


# ===== Đã có scheme sẵn ===== #

def test_https_url_passed_through_unchanged():
    assert normalize_url("https://example.com") == "https://example.com"


def test_http_url_passed_through_unchanged():
    assert normalize_url("http://example.com") == "http://example.com"


def test_scheme_match_is_case_insensitive():
    """lower.startsWith(...) dùng bản chữ thường để so khớp scheme, nhưng
    TRẢ VỀ đúng chuỗi gốc (trimmed), không phải bản đã lowercase."""
    assert normalize_url("HTTPS://Example.com") == "HTTPS://Example.com"


# ===== www. không kèm scheme ===== #

def test_www_prefix_gets_https_scheme_added():
    assert normalize_url("www.example.com") == "https://www.example.com"


def test_www_prefix_case_insensitive_still_gets_https():
    assert normalize_url("WWW.example.com") == "https://WWW.example.com"


# ===== Trông giống URL (có dấu chấm, không khoảng trắng) ===== #

def test_bare_domain_looks_like_url_gets_https():
    assert normalize_url("example.com") == "https://example.com"


def test_subdomain_looks_like_url_gets_https():
    assert normalize_url("news.example.co.uk") == "https://news.example.co.uk"


# ===== Không giống URL -> rơi xuống tìm kiếm Google ===== #

def test_plain_keyword_without_dot_goes_to_search():
    assert normalize_url("tin tuc hom nay") == (
        "https://www.google.com/search?q=tin+tuc+hom+nay"
    )


def test_text_with_dot_but_containing_whitespace_goes_to_search():
    """Có dấu "." nhưng có khoảng trắng -> KHÔNG tính là URL (vd câu tìm
    kiếm dạng "giá 19.99 đô la đổi ra vnd bao nhiêu")."""
    result = normalize_url("gia 19.99 do la doi ra vnd")
    assert result.startswith("https://www.google.com/search?q=")
    assert "example.com" not in result


def test_search_query_is_url_encoded():
    result = normalize_url("hello world & more?")
    assert result == "https://www.google.com/search?q=hello+world+%26+more%3F"


# ===== Ký tự vô hình dính theo khi copy link (bug đã sửa) ===== #

def test_zero_width_space_around_url_is_stripped():
    dirty = "\u200B" + "https://example.com" + "\u200B"
    assert normalize_url(dirty) == "https://example.com"


def test_bom_around_url_is_stripped():
    dirty = "\uFEFF" + "https://example.com"
    assert normalize_url(dirty) == "https://example.com"


def test_left_to_right_mark_around_url_is_stripped():
    dirty = "\u200E" + "https://example.com" + "\u200E"
    assert normalize_url(dirty) == "https://example.com"


def test_invisible_chars_touching_url_after_outer_whitespace():
    """Trường hợp thực tế nhất khi copy link (share sheet dán thêm khoảng
    trắng thật NGOÀI CÙNG, rồi ký tự vô hình áp sát ngay link) - .strip()
    thường bỏ khoảng trắng ngoài trước, sau đó .strip(invisible) bỏ tiếp ký
    tự vô hình áp sát link, ra đúng URL sạch."""
    dirty = "  \u200Bhttps://example.com\u200B  "
    assert normalize_url(dirty) == "https://example.com"


def test_known_limitation_whitespace_between_invisible_char_and_url():
    """GHI NHẬN hành vi biên hiện tại (không phải bug mới cần sửa ở đây, chỉ
    port đúng 1-1 những gì Kotlin thật làm): nếu có khoảng trắng THẬT nằm
    GIỮA ký tự vô hình và URL (vd "\u200B https://..."), trim() thường chỉ
    bỏ được lớp khoảng trắng NGOÀI CÙNG trước, để lộ ký tự vô hình ra ngoài
    cùng; sau khi trim(invisible) bỏ tiếp ký tự vô hình đó thì vẫn còn sót
    lại đúng 1 khoảng trắng sát URL (không được trim() lại lần 2) - khiến
    chuỗi cuối cùng KHÔNG bắt đầu bằng "https://" nữa và rơi nhầm xuống
    nhánh tìm kiếm Google. Kịch bản này hiếm gặp trong thực tế (space chen
    giữa 2 lớp trim) hơn nhiều so với ký tự vô hình áp sát thẳng URL (test ở
    trên) - nhưng nếu sau này sửa lại thuật toán trim (vd lặp trim đến khi
    ổn định thay vì chỉ 2 bước cố định), test này sẽ NHẮC phải cập nhật kỳ
    vọng bên dưới theo hành vi mới."""
    dirty = "  \u200B https://example.com \u200B  "
    result = normalize_url(dirty)
    assert not result.startswith("https://example.com")
    assert result.startswith("https://www.google.com/search?q=")


def test_only_invisible_chars_defaults_to_google_home():
    assert normalize_url("\u200B\u200C\uFEFF") == "https://www.google.com"
