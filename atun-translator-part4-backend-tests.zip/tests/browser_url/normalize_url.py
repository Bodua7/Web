"""Bản dịch tay (hand-port) của `normalizeUrl()` trong
`native/BrowserTabManager.kt` - quyết định chuỗi người dùng gõ vào ô địa chỉ
của "Web mini" (BrowserActivity) sẽ được mở thẳng như 1 URL hay đưa vào tìm
kiếm Google.

CỐ Ý KHÔNG port: mọi thứ đụng Android/Activity thật (hàm gốc là extension
function `BrowserActivity.normalizeUrl`, nhưng KHÔNG dùng field nào của
Activity - chỉ là chỗ đặt code, không phải phụ thuộc thật). Toàn bộ logic bên
trong là xử lý chuỗi thuần + `java.net.URLEncoder` -> port 1-1 được sang
`urllib.parse.quote_plus` (tương đương `URLEncoder.encode(..., "UTF-8")`).

Không import trực tiếp từ .kt - mỗi khi sửa normalizeUrl() trong
BrowserTabManager.kt thì phải tự sửa lại file này cho khớp (xem README.md).
"""

from __future__ import annotations

from urllib.parse import quote_plus

# Các ký tự "vô hình" thường dính theo khi copy link từ app khác (share sheet
# YouTube, bàn phím Samsung...) - PHẢI khớp đúng danh sách trong Kotlin:
# zero-width space/joiner (U+200B/U+200C/U+200D), BOM (U+FEFF), dấu định
# hướng trái/phải LRM/RLM (U+200E/U+200F).
_INVISIBLE_CHARS = "\u200B\u200C\u200D\uFEFF\u200E\u200F"


def normalize_url(input_str: str) -> str:
    """Port 1-1 của `BrowserActivity.normalizeUrl(input: String): String`."""
    # val trimmed = input.trim().trim(<invisible chars>)
    # Kotlin trim() (whitespace thường) rồi trim(vararg chars) (các ký tự vô
    # hình) - Python .strip() cũng chỉ bỏ whitespace ASCII/Unicode thường,
    # không tự bỏ các ký tự vô hình trên, nên phải strip() riêng từng bước
    # đúng thứ tự để hành vi giống hệt (vd chuỗi "  \u200B" trước hết bị
    # .trim() cắt whitespace đuôi thành "  " rồi mới trim ký tự vô hình).
    trimmed = input_str.strip()
    trimmed = trimmed.strip(_INVISIBLE_CHARS)

    # if (trimmed.isEmpty()) return "https://www.google.com"
    if trimmed == "":
        return "https://www.google.com"

    # val lower = trimmed.lowercase()
    lower = trimmed.lower()
    # val looksLikeUrl = trimmed.contains(".") && !trimmed.any { it.isWhitespace() }
    looks_like_url = "." in trimmed and not any(ch.isspace() for ch in trimmed)

    if lower.startswith("http://") or lower.startswith("https://"):
        return trimmed
    if lower.startswith("www."):
        return "https://" + trimmed
    if looks_like_url:
        return "https://" + trimmed
    return "https://www.google.com/search?q=" + quote_plus(trimmed)
