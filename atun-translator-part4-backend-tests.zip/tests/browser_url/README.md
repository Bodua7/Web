# Test harness cho `normalizeUrl()` (ô địa chỉ "Web mini")

Port phần LOGIC THUẦN của `normalizeUrl()` trong `native/BrowserTabManager.kt`
- quyết định chuỗi gõ vào ô địa chỉ của "Web mini" (`BrowserActivity`) được mở
thẳng như URL hay đưa vào tìm kiếm Google. Hàm này tuy là extension function
của `BrowserActivity` (`internal fun BrowserActivity.normalizeUrl(...)`) nhưng
không dùng field nào của Activity - chỉ xử lý chuỗi thuần + `URLEncoder`, nên
port 1-1 sang Python được.

## Chạy test

```bash
cd tests/browser_url
pip install pytest
pytest -v
```

## Cấu trúc

- `normalize_url.py` — hand-port `normalizeUrl()`, dùng
  `urllib.parse.quote_plus` tương đương `URLEncoder.encode(..., "UTF-8")` của
  Kotlin (cả 2 đều encode dấu cách thành `+`). Không import trực tiếp từ
  `.kt` - sửa `normalizeUrl()` trong `BrowserTabManager.kt` thì phải tự sửa
  lại file này theo (xem docstring).
- `test_normalize_url.py` — trọng tâm là đúng theo comment gốc trong Kotlin:
  ký tự "vô hình" dính theo khi copy link từ app khác (zero-width
  space/joiner, BOM, LRM/RLM) khiến `startsWith("https://")` trượt oan nếu
  không được lọc đúng; ranh giới giữa "trông giống URL" (có dấu chấm, không
  khoảng trắng) và "từ khoá tìm kiếm"; mã hoá URL cho câu tìm kiếm.

  Có 1 test ghi nhận **hành vi biên đã biết** (không phải bug mới, chỉ port
  đúng 1-1 Kotlin thật): nếu có khoảng trắng THẬT nằm giữa ký tự vô hình và
  URL (hiếm gặp trong thực tế hơn nhiều so với ký tự vô hình áp sát thẳng
  URL), 2 bước `trim()` liên tiếp không dọn hết được, khiến chuỗi rơi nhầm
  xuống nhánh tìm kiếm Google - xem
  `test_known_limitation_whitespace_between_invisible_char_and_url()`.
