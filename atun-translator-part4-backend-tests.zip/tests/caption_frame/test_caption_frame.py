"""Test cho applyCaptionFrame() (bản port Python của native/BrowserActivity.kt).

Chạy: cd tests/caption_frame && pip install pytest && pytest -v

Mục tiêu: bắt hồi quy đúng loại bug đã từng gặp thật ("khung phụ đề hẹp bất
thường" ở Web mini) — sai sót trong quy đổi % rộng/cao sang px theo kích
thước webViewContainer thật, quên coerceIn, hoặc quên fallback lúc stage
chưa layout xong (stage_width/height == 0).
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from caption_frame import (  # noqa: E402
    CaptionFrame,
    OverlayState,
    apply_caption_frame,
    FONT_SIZE_SMALL_SP,
    FONT_SIZE_MEDIUM_SP,
    FONT_SIZE_LARGE_SP,
)


# ===== Ẩn/hiện theo text rỗng ===== #

def test_blank_text_hides_overlay():
    overlay = OverlayState(visible=True, text="xin chào", width_px=500)
    result = apply_caption_frame(CaptionFrame(text=""), overlay, stage_width=1000, stage_height=2000)
    assert result.visible is False


def test_whitespace_only_text_counts_as_blank():
    overlay = OverlayState(visible=True)
    result = apply_caption_frame(CaptionFrame(text="   "), overlay, stage_width=1000, stage_height=2000)
    assert result.visible is False


def test_blank_text_does_not_wipe_previous_style():
    """Kotlin return NGAY khi blank — không đụng width_px/max_height_px/alpha
    cũ. Nếu code lỡ reset các field này về default lúc ẩn, câu dịch TIẾP
    THEO sẽ hiện sai khung trong giây lát trước khi resize kịp — đúng kiểu
    'khung hẹp bất thường' thoáng qua đã từng gặp."""
    overlay = OverlayState(visible=True, width_px=777, max_height_px=444, alpha=200)
    result = apply_caption_frame(CaptionFrame(text=""), overlay, stage_width=1000, stage_height=2000)
    assert result.width_px == 777
    assert result.max_height_px == 444
    assert result.alpha == 200


def test_nonblank_text_shows_overlay_with_text():
    overlay = OverlayState()
    result = apply_caption_frame(CaptionFrame(text="hello"), overlay, stage_width=1000, stage_height=2000)
    assert result.visible is True
    assert result.text == "hello"


# ===== Quy đổi opacity -> alpha ===== #

def test_opacity_default_converts_to_expected_alpha():
    result = apply_caption_frame(CaptionFrame(text="a", opacity=0.75), OverlayState(), 1000, 2000)
    assert result.alpha == 191  # int(0.75 * 255) = 191 (truncate, không làm tròn)


def test_opacity_clamped_above_one():
    result = apply_caption_frame(CaptionFrame(text="a", opacity=1.5), OverlayState(), 1000, 2000)
    assert result.alpha == 255


def test_opacity_clamped_below_zero():
    result = apply_caption_frame(CaptionFrame(text="a", opacity=-0.5), OverlayState(), 1000, 2000)
    assert result.alpha == 0


# ===== Quy đổi fontSize ===== #

def test_font_size_small():
    result = apply_caption_frame(CaptionFrame(text="a", font_size="small"), OverlayState(), 1000, 2000)
    assert result.text_size_sp == FONT_SIZE_SMALL_SP


def test_font_size_large():
    result = apply_caption_frame(CaptionFrame(text="a", font_size="large"), OverlayState(), 1000, 2000)
    assert result.text_size_sp == FONT_SIZE_LARGE_SP


def test_font_size_medium():
    result = apply_caption_frame(CaptionFrame(text="a", font_size="medium"), OverlayState(), 1000, 2000)
    assert result.text_size_sp == FONT_SIZE_MEDIUM_SP


def test_font_size_unknown_value_falls_back_to_medium():
    """when() Kotlin có nhánh else -> bất kỳ giá trị lạ nào (vd data cũ/hỏng
    từ localStorage bên www/index.html) đều phải rơi về medium, không crash."""
    result = apply_caption_frame(CaptionFrame(text="a", font_size="huge"), OverlayState(), 1000, 2000)
    assert result.text_size_sp == FONT_SIZE_MEDIUM_SP


# ===== Quy đổi widthPercent/heightPercent -> px (trọng tâm bug đã gặp) ===== #

def test_width_percent_converts_to_px_using_stage_width():
    result = apply_caption_frame(
        CaptionFrame(text="a", width_percent=50), OverlayState(), stage_width=1000, stage_height=2000
    )
    assert result.width_px == 500


def test_height_percent_converts_to_px_using_stage_height():
    result = apply_caption_frame(
        CaptionFrame(text="a", height_percent=30), OverlayState(), stage_width=1000, stage_height=2000
    )
    assert result.max_height_px == 600


def test_width_percent_uses_web_mini_stage_not_main_screen_stage():
    """Điểm mấu chốt của CaptionRelay: widthPercent/heightPercent tính theo %
    webViewContainer của CHÍNH Web mini, không phải % #videoStage màn hình
    chính (2 kích thước khác nhau). Test bằng cách feed 1 stage_width khác
    hẳn 'màn hình chính' để đảm bảo hàm dùng đúng tham số truyền vào, không
    lỡ hardcode/nhầm nguồn nào khác."""
    result = apply_caption_frame(
        CaptionFrame(text="a", width_percent=100), OverlayState(), stage_width=333, stage_height=2000
    )
    assert result.width_px == 333


def test_width_percent_below_min_is_clamped_to_10():
    """coerceIn(10, 100) — thiếu dòng này chính là kiểu lỗi khiến khung có
    thể co về gần 0px nếu 1 nơi nào đó lỡ truyền widthPercent rất nhỏ/âm."""
    result = apply_caption_frame(
        CaptionFrame(text="a", width_percent=1), OverlayState(), stage_width=1000, stage_height=2000
    )
    assert result.width_px == 100  # 1000 * 10 / 100, không phải 1000 * 1 / 100


def test_width_percent_above_max_is_clamped_to_100():
    result = apply_caption_frame(
        CaptionFrame(text="a", width_percent=250), OverlayState(), stage_width=1000, stage_height=2000
    )
    assert result.width_px == 1000


def test_height_percent_below_min_is_clamped_to_5():
    result = apply_caption_frame(
        CaptionFrame(text="a", height_percent=0), OverlayState(), stage_width=1000, stage_height=2000
    )
    assert result.max_height_px == 100  # 2000 * 5 / 100


def test_height_percent_above_max_is_clamped_to_100():
    result = apply_caption_frame(
        CaptionFrame(text="a", height_percent=999), OverlayState(), stage_width=1000, stage_height=2000
    )
    assert result.max_height_px == 2000


def test_zero_stage_width_skips_resize_and_keeps_previous_width():
    """Đúng bug gốc: lúc Activity vừa mở, webViewContainer.width có thể vẫn
    là 0 (chưa kịp layout) — applyCaptionFrame() PHẢI bỏ qua bước resize lần
    này (giữ width_px cũ) thay vì tính ra 0px (khung biến mất/hẹp về 0)."""
    overlay = OverlayState(width_px=600)
    result = apply_caption_frame(
        CaptionFrame(text="a", width_percent=50), overlay, stage_width=0, stage_height=2000
    )
    assert result.width_px == 600


def test_zero_stage_height_skips_resize_and_keeps_previous_height():
    overlay = OverlayState(max_height_px=400)
    result = apply_caption_frame(
        CaptionFrame(text="a", height_percent=30), overlay, stage_width=1000, stage_height=0
    )
    assert result.max_height_px == 400


def test_first_frame_ever_with_zero_stage_leaves_width_none():
    """Lần đầu tiên (chưa từng có width_px cũ, stage cũng chưa layout xong)
    -> width_px vẫn None, không crash, không suy ra 1 con số sai."""
    result = apply_caption_frame(
        CaptionFrame(text="a", width_percent=50), OverlayState(), stage_width=0, stage_height=0
    )
    assert result.width_px is None
    assert result.max_height_px is None


def test_integer_division_truncates_like_kotlin_int_division():
    """stageWidth * percent / 100 dùng phép chia Int của Kotlin (cắt phần dư,
    không làm tròn) — 999 * 33 / 100 = 329.67 -> phải ra 329, không phải 330."""
    result = apply_caption_frame(
        CaptionFrame(text="a", width_percent=33), OverlayState(), stage_width=999, stage_height=2000
    )
    assert result.width_px == 329


# ===== Kịch bản end-to-end: đổi nhiều frame liên tiếp (mô phỏng thực tế) ===== #

def test_sequence_resize_then_blank_then_new_text_reuses_last_size():
    stage_w, stage_h = 1080, 600
    overlay = OverlayState()

    overlay = apply_caption_frame(
        CaptionFrame(text="câu đầu", width_percent=80, height_percent=40), overlay, stage_w, stage_h
    )
    assert overlay.visible is True
    assert overlay.width_px == 864

    overlay = apply_caption_frame(CaptionFrame(text=""), overlay, stage_w, stage_h)
    assert overlay.visible is False
    assert overlay.width_px == 864  # vẫn giữ, không reset

    overlay = apply_caption_frame(
        CaptionFrame(text="câu kế tiếp", width_percent=80, height_percent=40), overlay, stage_w, stage_h
    )
    assert overlay.visible is True
    assert overlay.text == "câu kế tiếp"
    assert overlay.width_px == 864
