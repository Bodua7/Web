"""Bản dịch tay (hand-port) phần LOGIC THUẦN (không phải Android API) của
`applyCaptionFrame()` trong `native/BrowserActivity.kt` — quy đổi CaptionFrame
(đến từ CaptionRelay, xem `native/CaptionRelay.kt`) sang các thuộc tính hiển
thị thật của `captionOverlay` (TextView đè lên WebView của "Web mini").

CỐ Ý KHÔNG port: mọi thứ đụng Android View thật (View.GONE/VISIBLE,
FrameLayout.LayoutParams, runOnUiThread, webViewContainer.width/height đọc từ
layout thật...). Chỉ port phần TÍNH TOÁN THUẦN - đúng chỗ từng có bug (khung
phụ đề hẹp bất thường) vì đây là phần dễ lệch nhất khi sửa code (đổi thứ tự
phép tính, quên coerceIn, quên fallback lúc stage chưa layout xong).

Không import trực tiếp từ .kt — mỗi khi sửa applyCaptionFrame() trong
BrowserActivity.kt thì phải tự sửa lại file này cho khớp (xem README.md).
"""

from __future__ import annotations

from dataclasses import dataclass, replace


# ===== Hằng số — PHẢI khớp applyCaptionFrame() / CaptionFrame trong Kotlin ===== #

FONT_SIZE_SMALL_SP = 13.0
FONT_SIZE_MEDIUM_SP = 16.0  # mặc định (else -> "medium" hoặc giá trị lạ)
FONT_SIZE_LARGE_SP = 20.0

WIDTH_PERCENT_MIN = 10
WIDTH_PERCENT_MAX = 100
HEIGHT_PERCENT_MIN = 5
HEIGHT_PERCENT_MAX = 100


def _coerce_in(value: int, lo: int, hi: int) -> int:
    """Tương đương Int.coerceIn(lo, hi) của Kotlin."""
    return max(lo, min(hi, value))


@dataclass(frozen=True)
class CaptionFrame:
    """Tương đương CaptionRelay.CaptionFrame (native/CaptionRelay.kt) — giữ
    đúng tên field + giá trị mặc định."""

    text: str = ""
    opacity: float = 0.75
    font_size: str = "medium"
    width_percent: int = 96
    height_percent: int = 30


@dataclass(frozen=True)
class OverlayState:
    """Tương đương trạng thái thật của `captionOverlay` (TextView) mà
    applyCaptionFrame() đọc/ghi. `width_px`/`max_height_px` là None khi
    chưa từng được set (Activity vừa mở, webViewContainer chưa layout) —
    khớp hành vi Kotlin: nếu stageWidth/stageHeight == 0, KHÔNG đụng tới
    layoutParams/maxHeight, giữ nguyên giá trị trước đó."""

    visible: bool = False
    text: str = ""
    alpha: int = 191  # (0.75 * 255) mặc định, chỉ đúng nếu opacity mặc định
    text_size_sp: float = FONT_SIZE_MEDIUM_SP
    width_px: int | None = None
    max_height_px: int | None = None


def _font_size_sp(font_size: str) -> float:
    if font_size == "small":
        return FONT_SIZE_SMALL_SP
    if font_size == "large":
        return FONT_SIZE_LARGE_SP
    return FONT_SIZE_MEDIUM_SP  # nhánh "else" của when() Kotlin


def apply_caption_frame(
    frame: CaptionFrame,
    overlay: OverlayState,
    stage_width: int,
    stage_height: int,
) -> OverlayState:
    """Port 1-1 của applyCaptionFrame(frame: CaptionRelay.CaptionFrame).

    stage_width/stage_height = webViewContainer.width/height THẬT tại thời
    điểm gọi (0 nếu Activity chưa kịp layout lần nào — xem comment gốc
    trong Kotlin dòng 144-147).
    """
    # if (frame.text.isBlank()) { captionOverlay.visibility = View.GONE; return }
    # QUAN TRỌNG: return NGAY, không đụng text/alpha/textSize/width/height —
    # ẩn đi nhưng giữ nguyên style/kích thước cũ cho lần hiện tiếp theo.
    if frame.text.strip() == "":
        return replace(overlay, visible=False)

    alpha = int(max(0.0, min(1.0, frame.opacity)) * 255)  # .toInt() truncates toward 0
    text_size = _font_size_sp(frame.font_size)

    width_px = overlay.width_px
    if stage_width > 0:
        clamped_w = _coerce_in(frame.width_percent, WIDTH_PERCENT_MIN, WIDTH_PERCENT_MAX)
        width_px = stage_width * clamped_w // 100  # (Int * Int) / 100 — thứ tự phép tính giữ nguyên

    max_height_px = overlay.max_height_px
    if stage_height > 0:
        clamped_h = _coerce_in(frame.height_percent, HEIGHT_PERCENT_MIN, HEIGHT_PERCENT_MAX)
        max_height_px = stage_height * clamped_h // 100

    return OverlayState(
        visible=True,
        text=frame.text,
        alpha=alpha,
        text_size_sp=text_size,
        width_px=width_px,
        max_height_px=max_height_px,
    )
