# Test harness cho `applyCaptionFrame()` (Web mini — đồng bộ khung phụ đề)

Port thuần Python của phần LOGIC THUẦN trong `native/BrowserActivity.kt` —
quy đổi `CaptionRelay.CaptionFrame` (opacity/cỡ chữ/tỉ lệ rộng-cao) sang
thuộc tính hiển thị thật của `captionOverlay`, để test hồi quy chỗ **từng có
bug thật** (khung phụ đề hẹp bất thường ở "Web mini") mà không cần build APK
+ cài máy thật.

`BrowserActivity.kt` (40KB) và `CaptionRelay.kt` không có test tự động nào
trước bộ này — khác với `VadDetector`/`google_free_translate`/
`ModelManagerPlugin.CATALOG` đã có port.

## Chạy test

```bash
cd tests/caption_frame
pip install pytest
pytest -v
```

## Cấu trúc

- `caption_frame.py` — bản dịch tay 1-1 phần TÍNH TOÁN THUẦN của
  `applyCaptionFrame()`: quy đổi `opacity` (Float 0..1) → `alpha` (Int
  0..255), `fontSize` (String) → cỡ chữ sp, và `widthPercent`/`heightPercent`
  (Int, `coerceIn`) → px theo `stageWidth`/`stageHeight` thật. KHÔNG port
  phần đụng Android View thật (`View.GONE/VISIBLE`,
  `FrameLayout.LayoutParams`, `runOnUiThread`, đọc `webViewContainer.width`
  thật) — những phần đó không phải logic, cần build thật để test có ý nghĩa.
- `test_caption_frame.py` — 23 test case bao phủ: ẩn/hiện theo text rỗng
  (và giữ nguyên style cũ lúc ẩn, không reset), quy đổi opacity→alpha (kể cả
  clamp 2 đầu), quy đổi fontSize (small/medium/large/giá trị lạ→medium),
  quy đổi widthPercent/heightPercent→px (đúng tham số stage của Web mini,
  KHÔNG phải của màn hình chính), clamp `coerceIn(10,100)`/`coerceIn(5,100)`,
  bỏ qua resize khi `stageWidth`/`stageHeight` == 0 (Activity chưa layout
  xong — giữ nguyên kích thước cũ thay vì co về 0px, đúng nguyên nhân bug
  gốc), phép chia nguyên kiểu Kotlin (cắt phần dư, không làm tròn), và 1
  kịch bản end-to-end nhiều frame liên tiếp.

## ⚠️ Bắt buộc giữ đồng bộ

File `caption_frame.py` là bản dịch **tay**, không phải import trực tiếp từ
Kotlin. Mỗi khi sửa `applyCaptionFrame()` hoặc `CaptionRelay.CaptionFrame`
trong `native/BrowserActivity.kt` / `native/CaptionRelay.kt` (đổi hằng số cỡ
chữ, đổi khoảng `coerceIn`, đổi công thức quy đổi %, thêm field mới vào
`CaptionFrame`...) thì phải sửa lại `caption_frame.py` cho khớp, rồi chạy lại
`pytest` để biết thay đổi đó ảnh hưởng gì đến hành vi.

## Phạm vi CHƯA che phủ (cần build thật)

- `BrowserActivity` phần còn lại (quản lý tab, AdBlockList áp cho WebView,
  dark mode, fullscreen video trong Web mini...) — vẫn 0 test, ngoài phạm vi
  lần này vì gắn chặt với Android View/WebView thật, khó port thuần logic.
- Việc `captionOverlay` có thực sự được add đúng chỗ (con của
  `webViewContainer`, sau `tabsContainer`) hay không — đây là bug đã sửa
  trước đó (xem lịch sử `applyCaptionFrame()`/`tabsContainer` trong
  `BrowserActivity.kt`), thuộc về cấu trúc View thật, không phải logic quy
  đổi số nên không port được vào đây.
