# Test harness cho `AdBlockList.isBlocked()`

Trước đây `native/BrowserActivity.kt`/`AdBlockList.kt` (dùng cho "Web mini")
không có test tự động nào - phần chặn quảng cáo/tracker theo domain là logic
dễ có bug tinh vi (khớp nhầm domain lạ) nhưng lại khó tự nhận ra bằng mắt lúc
đọc code, nên được port sang đây.

## Chạy test

```bash
cd tests/adblock
pip install pytest
pytest -v
```

## Cấu trúc

- `adblock_list.py` — **KHÁC** cách hand-copy ở `tests/vad/`/`tests/translate/`:
  danh sách `BLOCKED_DOMAINS` được **đọc thẳng** từ `native/AdBlockList.kt`
  (giống cách `tests/model_catalog/` đọc `CATALOG`), dùng scanner đếm độ sâu
  ngoặc để tách đúng khối `setOf(...)`. Chỉ riêng hàm so khớp `is_blocked()`
  (thuật toán `h == it || h.endsWith(".$it")`, gần như không đổi) là hand-port
  thật.
- `test_adblock_list.py` — trọng tâm là các trường hợp so khớp domain: khớp
  chính xác, khớp subdomain lồng nhiều cấp, KHÔNG khớp nhầm domain chỉ tình cờ
  chứa chuỗi con giống domain bị chặn (vd `notdoubleclick.net` không phải
  subdomain của `doubleclick.net`), không chặn nhầm domain đa năng
  (facebook.com/amazon.com...), và xử lý input rỗng/`None`.

## Vì sao đọc thẳng file `.kt` thay vì hand-copy danh sách domain

Nếu hand-copy `BLOCKED_DOMAINS` sang Python, test sẽ luôn pass trên bản copy
đúng của chính nó dù ai đó thêm/bớt domain sai trong `.kt` gốc - không bắt
được lỗi thật. Đọc trực tiếp từ nguồn thì không có rủi ro lệch pha, đổi lại
`test_parsed_domain_count_matches_real_file()` khoá cứng số lượng domain hiện
tại (47) để nhắc người sửa code cân nhắc lại nếu số này đổi bất ngờ (đặc biệt
là bị XOÁ nhầm domain).
