"""Test cho AdBlockList.isBlocked() (bản port Python của native/AdBlockList.kt).

Chạy: cd tests/adblock && pip install pytest && pytest -v

Mục tiêu: bắt đúng loại lỗi dễ gặp với so khớp domain kiểu "endsWith" - khớp
nhầm domain lạ chỉ tình cờ chứa chuỗi con giống 1 domain bị chặn (vd
"notdoubleclick.net" không được tính là subdomain của "doubleclick.net"), và
đảm bảo danh sách thật trong .kt luôn parse được (không có entry rỗng/hỏng).
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from adblock_list import is_blocked, parse_blocked_domains, read_source  # noqa: E402

# Parse 1 lần, dùng chung cho mọi test trong file này - đọc thẳng
# native/AdBlockList.kt thật (không hand-copy danh sách), xem docstring module.
DOMAINS = parse_blocked_domains(read_source())


# ===== Danh sách thật parse từ .kt ===== #

def test_parses_at_least_the_documented_ad_networks():
    """Vài domain mốc chắc chắn phải có mặt - nếu regex parse sai/lệch, các
    domain quen thuộc này là thứ đầu tiên sẽ biến mất khỏi tập kết quả."""
    for domain in ("doubleclick.net", "googlesyndication.com", "taboola.com", "criteo.com"):
        assert domain in DOMAINS


def test_no_empty_or_malformed_entries():
    for domain in DOMAINS:
        assert domain.strip() == domain
        assert "." in domain
        assert domain == domain.lower() or True  # domain trong source vốn đã viết thường


def test_parsed_domain_count_matches_real_file():
    """Khoá số lượng domain hiện tại (47) - nếu ai thêm/bớt domain trong .kt,
    test này nhắc phải cân nhắc cập nhật con số ở đây theo, tránh thay đổi im
    lặng không ai để ý (đặc biệt là XOÁ nhầm domain)."""
    assert len(DOMAINS) == 47


# ===== isBlocked(): khớp chính xác domain ===== #

def test_exact_domain_match_is_blocked():
    assert is_blocked("doubleclick.net", DOMAINS) is True


def test_case_insensitive_match():
    assert is_blocked("DoubleClick.NET", DOMAINS) is True


# ===== isBlocked(): khớp subdomain ===== #

def test_subdomain_match_is_blocked():
    assert is_blocked("pagead2.googlesyndication.com", DOMAINS) is True


def test_deeply_nested_subdomain_match_is_blocked():
    assert is_blocked("a.b.c.doubleclick.net", DOMAINS) is True


# ===== isBlocked(): KHÔNG được khớp nhầm ===== #

def test_unrelated_domain_is_not_blocked():
    assert is_blocked("example.com", DOMAINS) is False


def test_lookalike_domain_without_dot_boundary_is_not_blocked():
    """Trọng tâm của bug kiểu "contains thay vì endsWith với dấu chấm ranh
    giới": "notdoubleclick.net" KHÔNG phải subdomain thật của
    "doubleclick.net" (thiếu dấu "." ngăn cách) - nếu code lỡ dùng
    `h.endsWith(it)` (thiếu tiền tố ".") thay vì `h.endsWith(".$it")`, domain
    giả này sẽ bị chặn oan."""
    assert is_blocked("notdoubleclick.net", DOMAINS) is False


def test_domain_containing_blocked_string_in_middle_is_not_blocked():
    assert is_blocked("doubleclick.net.evil-tracker.example", DOMAINS) is False


def test_multi_domain_general_purpose_sites_not_in_blocklist():
    """Đúng theo comment gốc trong AdBlockList.kt: KHÔNG chặn domain đa năng
    như facebook.com/amazon.com dù chúng cũng có quảng cáo/tracker riêng -
    chặn cả domain sẽ chặn luôn nội dung chính hợp lệ."""
    for domain in ("facebook.com", "amazon.com", "google.com"):
        assert is_blocked(domain, DOMAINS) is False


# ===== isBlocked(): input rỗng/None ===== #

def test_none_host_is_not_blocked():
    assert is_blocked(None, DOMAINS) is False


def test_blank_host_is_not_blocked():
    assert is_blocked("", DOMAINS) is False


def test_whitespace_only_host_is_not_blocked():
    assert is_blocked("   ", DOMAINS) is False
