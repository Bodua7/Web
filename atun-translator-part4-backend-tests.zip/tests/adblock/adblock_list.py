"""Bản port Python của `native/AdBlockList.kt`.

KHÁC với `tests/caption_frame/` (hand-port toàn bộ, phải tự sửa theo khi đổi
Kotlin): danh sách `BLOCKED_DOMAINS` ở đây được ĐỌC THẲNG từ
native/AdBlockList.kt mỗi lần chạy test (giống cách tests/model_catalog/ đọc
CATALOG) - vì đây là 1 tập dữ liệu (không phải logic), dễ có người thêm/bớt
domain trực tiếp trong .kt mà quên cập nhật bản port tay, khiến test luôn
pass trên bản copy cũ dù file gốc đã đổi khác.

Chỉ có hàm so khớp `is_blocked()` (thuật toán, gần như không đổi) là hand-port
thật - xem docstring của hàm.
"""

from __future__ import annotations

import re
from pathlib import Path

# tests/adblock/adblock_list.py -> parents[2] = thư mục gốc repo
REPO_ROOT = Path(__file__).resolve().parents[2]
ADBLOCK_KT_PATH = REPO_ROOT / "native" / "AdBlockList.kt"

_DOMAIN_LINE_RE = re.compile(r'"((?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,})"\s*,?')


def read_source() -> str:
    if not ADBLOCK_KT_PATH.exists():
        raise FileNotFoundError(
            f"Không tìm thấy {ADBLOCK_KT_PATH} - test này phải chạy từ repo có "
            "đủ native/AdBlockList.kt (chạy trong CI sau khi checkout đầy đủ)."
        )
    return ADBLOCK_KT_PATH.read_text(encoding="utf-8")


def parse_blocked_domains(source: str | None = None) -> frozenset[str]:
    """Trích các chuỗi domain trong khối `BLOCKED_DOMAINS = setOf(...)`.

    Dùng scanner đếm độ sâu ngoặc (giống catalog_parser._find_catalog_block)
    để chỉ lấy đúng nội dung bên trong setOf(...), tránh vô tình khớp phải
    chuỗi domain xuất hiện ở comment/nơi khác trong file.
    """
    text = source if source is not None else read_source()
    marker = "BLOCKED_DOMAINS"
    if marker not in text:
        raise ValueError("Không tìm thấy 'BLOCKED_DOMAINS' trong AdBlockList.kt.")
    start_idx = text.index(marker)

    set_of = "setOf("
    if set_of not in text[start_idx:]:
        raise ValueError("Không tìm thấy 'setOf(' ngay sau khai báo BLOCKED_DOMAINS.")
    open_paren_idx = text.index(set_of, start_idx) + len(set_of) - 1

    depth = 0
    in_string = False
    i = open_paren_idx
    n = len(text)
    block = None
    while i < n:
        ch = text[i]
        if in_string:
            if ch == "\\":
                i += 2
                continue
            if ch == '"':
                in_string = False
        else:
            if ch == '"':
                in_string = True
            elif ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth == 0:
                    block = text[open_paren_idx + 1 : i]
                    break
        i += 1
    if block is None:
        raise ValueError(
            "Không tìm thấy dấu ')' khớp với 'setOf(' của BLOCKED_DOMAINS - file .kt "
            "có thể bị lỗi cú pháp hoặc cấu trúc đã đổi khác cách viết hiện tại."
        )

    domains = frozenset(m.group(1) for m in _DOMAIN_LINE_RE.finditer(block))
    if not domains:
        raise ValueError(
            "Tìm thấy khối BLOCKED_DOMAINS nhưng không parse được domain nào - regex "
            "_DOMAIN_LINE_RE có thể không còn khớp cấu trúc thật trong file .kt."
        )
    return domains


def is_blocked(host: str | None, domains: frozenset[str]) -> bool:
    """Port 1-1 của `AdBlockList.isBlocked(host: String?)`.

    fun isBlocked(host: String?): Boolean {
        if (host.isNullOrBlank()) return false
        val h = host.lowercase()
        return BLOCKED_DOMAINS.any { h == it || h.endsWith(".$it") }
    }
    """
    if host is None or host.strip() == "":
        return False
    h = host.lower()
    return any(h == d or h.endswith("." + d) for d in domains)
