"""Bản dịch tay của `shortsToBytesLE()` và `buildWavFile()` trong
`native/AudioCaptureService.kt` (phần Whisper Cloud STT / groq-relay) —
2 hàm byte-manipulation THUẦN, không đụng Android API nào, dùng để đóng gói
PCM16 mono thô thu được từ AudioRecord thành file .wav hoàn chỉnh trước khi
upload lên groq-relay?op=transcribe (Whisper cần file có header, không nhận
PCM thô).
"""

from __future__ import annotations

import struct


def shorts_to_bytes_le(samples: list[int]) -> bytes:
    """Port của shortsToBytesLE(samples: ShortArray, len: Int) — PCM16 mono,
    little-endian. Mỗi phần tử phải nằm trong khoảng Short của Kotlin
    (-32768..32767), giống dữ liệu thật đọc từ AudioRecord."""
    return b"".join(struct.pack("<h", s) for s in samples)


def build_wav_file(pcm: bytes, sample_rate: int) -> bytes:
    """Port 1-1 của buildWavFile(pcm: ByteArray, sampleRate: Int) — header 44
    byte chuẩn WAV cho PCM16 mono, theo ĐÚNG thứ tự field/giá trị hardcode
    của bản Kotlin gốc (NumChannels=1, BitsPerSample=16, BlockAlign=2)."""
    byte_rate = sample_rate * 2  # 16-bit mono: 2 byte/mẫu
    header = struct.pack(
        "<4sI4s4sIHHIIHH4sI",
        b"RIFF",
        36 + len(pcm),
        b"WAVE",
        b"fmt ",
        16,  # Subchunk1Size cho PCM
        1,  # AudioFormat = 1 (PCM)
        1,  # NumChannels = 1 (mono)
        sample_rate,
        byte_rate,
        2,  # BlockAlign = NumChannels * BitsPerSample/8
        16,  # BitsPerSample
        b"data",
        len(pcm),
    )
    assert len(header) == 44
    return header + pcm
