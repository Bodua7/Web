"""Test cho wav_builder.py + segment_cutter.py (bản port Python của phần
"Whisper Cloud (Groq)" trong native/AudioCaptureService.kt).

Chạy: cd tests/cloud_stt_segment && pip install pytest && pytest -v
"""

import struct
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from wav_builder import build_wav_file, shorts_to_bytes_le  # noqa: E402
from segment_cutter import (  # noqa: E402
    CloudSttSegmenter,
    CLOUD_SEGMENT_PAUSE_MS,
    CLOUD_SEGMENT_MAX_MS,
    CLOUD_SEGMENT_MIN_BYTES,
)


# ===== shorts_to_bytes_le ===== #

def test_shorts_to_bytes_le_length_is_double_sample_count():
    result = shorts_to_bytes_le([1, 2, 3, 4])
    assert len(result) == 8


def test_shorts_to_bytes_le_is_little_endian():
    result = shorts_to_bytes_le([256])  # 0x0100
    assert result == b"\x00\x01"


def test_shorts_to_bytes_le_handles_negative_and_extremes():
    result = shorts_to_bytes_le([-1, 32767, -32768, 0])
    assert struct.unpack("<4h", result) == (-1, 32767, -32768, 0)


# ===== build_wav_file ===== #

def test_wav_header_is_44_bytes():
    wav = build_wav_file(b"", 16000)
    assert len(wav) == 44


def test_wav_total_length_is_header_plus_pcm():
    pcm = b"\x01\x02" * 100
    wav = build_wav_file(pcm, 16000)
    assert len(wav) == 44 + len(pcm)


def test_wav_riff_wave_fmt_data_markers():
    wav = build_wav_file(b"\x00\x00", 16000)
    assert wav[0:4] == b"RIFF"
    assert wav[8:12] == b"WAVE"
    assert wav[12:16] == b"fmt "
    assert wav[36:40] == b"data"


def test_wav_chunk_size_is_36_plus_pcm_size():
    pcm = b"\x01\x02\x03\x04\x05\x06"
    wav = build_wav_file(pcm, 16000)
    chunk_size = struct.unpack("<I", wav[4:8])[0]
    assert chunk_size == 36 + len(pcm)


def test_wav_data_subchunk_size_equals_pcm_size():
    pcm = b"\x01\x02\x03\x04\x05\x06"
    wav = build_wav_file(pcm, 16000)
    data_size = struct.unpack("<I", wav[40:44])[0]
    assert data_size == len(pcm)


def test_wav_format_fields_hardcoded_mono_pcm16():
    """Đúng giá trị hardcode trong Kotlin: AudioFormat=1 (PCM), NumChannels=1
    (mono), BlockAlign=2, BitsPerSample=16 — không đọc từ tham số nào khác."""
    wav = build_wav_file(b"", 16000)
    subchunk1_size, audio_format, num_channels = struct.unpack("<IHH", wav[16:24])
    assert subchunk1_size == 16
    assert audio_format == 1
    assert num_channels == 1
    block_align, bits_per_sample = struct.unpack("<HH", wav[32:36])
    assert block_align == 2
    assert bits_per_sample == 16


def test_wav_sample_rate_and_byte_rate():
    wav = build_wav_file(b"", 22050)
    sample_rate, byte_rate = struct.unpack("<II", wav[24:32])
    assert sample_rate == 22050
    assert byte_rate == 22050 * 2  # 16-bit mono: 2 byte/mẫu


def test_wav_pcm_bytes_appended_verbatim_after_header():
    pcm = bytes(range(20))
    wav = build_wav_file(pcm, 16000)
    assert wav[44:] == pcm


# ===== CloudSttSegmenter — trọng tâm: khi nào cắt đoạn / khi nào bỏ qua ===== #

def test_no_flush_while_within_pause_and_max_duration():
    seg = CloudSttSegmenter(now_ms=0)
    result = seg.process_read(read_bytes=320, is_voice=True, now_ms=100)
    assert result is None
    assert seg.pcm_bytes == 320


def test_flushes_on_pause_after_voice_detected():
    seg = CloudSttSegmenter(now_ms=0)
    seg.process_read(read_bytes=CLOUD_SEGMENT_MIN_BYTES, is_voice=True, now_ms=0)
    result = seg.process_read(read_bytes=10, is_voice=False, now_ms=CLOUD_SEGMENT_PAUSE_MS)
    assert result is not None
    assert result.reason == "pause"


def test_no_flush_on_pause_without_prior_voice():
    """hasVoiceInSegment vẫn False (chưa từng có is_voice=True) — dù im lặng
    lâu bao nhiêu cũng KHÔNG cắt đoạn theo lý do 'pause' (chỉ max_duration
    mới có thể cắt lúc này), tránh gửi request Whisper cho khoảng im lặng
    thuần không có gì để dịch."""
    seg = CloudSttSegmenter(now_ms=0)
    result = seg.process_read(read_bytes=10, is_voice=False, now_ms=CLOUD_SEGMENT_PAUSE_MS * 5)
    assert result is None


def test_flush_on_pause_discards_short_segment_without_emitting():
    """Đoạn có voice nhưng CHƯA đạt CLOUD_SEGMENT_MIN_BYTES (vd tiếng click
    ngắn) - flush vẫn xảy ra (dọn buffer) nhưng emitted=False, KHÔNG tốn
    request Whisper - đúng dòng
    `if (hasVoiceInSegment && pcmBuffer.size() >= CLOUD_SEGMENT_MIN_BYTES)`."""
    seg = CloudSttSegmenter(now_ms=0)
    seg.process_read(read_bytes=CLOUD_SEGMENT_MIN_BYTES - 100, is_voice=True, now_ms=0)
    result = seg.process_read(read_bytes=0, is_voice=False, now_ms=CLOUD_SEGMENT_PAUSE_MS)
    assert result is not None
    assert result.emitted is False


def test_flush_on_pause_emits_when_long_enough():
    seg = CloudSttSegmenter(now_ms=0)
    seg.process_read(read_bytes=CLOUD_SEGMENT_MIN_BYTES, is_voice=True, now_ms=0)
    result = seg.process_read(read_bytes=0, is_voice=False, now_ms=CLOUD_SEGMENT_PAUSE_MS)
    assert result.emitted is True


def test_flush_resets_state_for_next_segment():
    seg = CloudSttSegmenter(now_ms=0)
    seg.process_read(read_bytes=CLOUD_SEGMENT_MIN_BYTES, is_voice=True, now_ms=0)
    seg.process_read(read_bytes=0, is_voice=False, now_ms=CLOUD_SEGMENT_PAUSE_MS)
    assert seg.pcm_bytes == 0
    assert seg.has_voice_in_segment is False


def test_flushes_on_max_duration_even_without_pause():
    """Người nói liên tục không ngừng (VAD báo voice=True suốt) — vẫn phải
    cắt đoạn sau CLOUD_SEGMENT_MAX_MS để tránh đệm audio vô hạn trong RAM,
    dù chưa có khoảng lặng nào."""
    seg = CloudSttSegmenter(now_ms=0)
    now = 0
    while now < CLOUD_SEGMENT_MAX_MS:
        seg.process_read(read_bytes=1000, is_voice=True, now_ms=now)
        now += 50
    result = seg.process_read(read_bytes=1000, is_voice=True, now_ms=CLOUD_SEGMENT_MAX_MS)
    assert result is not None
    assert result.reason == "max_duration"


def test_pause_condition_checked_before_max_duration_when_both_true():
    """if/else if trong Kotlin: nếu CẢ HAI điều kiện đều đúng cùng lúc, nhánh
    pause được ưu tiên (đứng trước). Dựng kịch bản người nói dừng đúng lúc
    tổng thời lượng đoạn cũng đã chạm ngưỡng max để xác nhận thứ tự."""
    seg = CloudSttSegmenter(now_ms=0)
    seg.process_read(read_bytes=CLOUD_SEGMENT_MIN_BYTES, is_voice=True, now_ms=0)
    # lastVoiceAt vẫn = 0; now_ms đồng thời thoả cả pause (>=600ms kể từ
    # lastVoiceAt) LẪN max_duration (>=12000ms kể từ segmentStartAt=0) vì
    # CLOUD_SEGMENT_MAX_MS >= CLOUD_SEGMENT_PAUSE_MS.
    now_ms = CLOUD_SEGMENT_MAX_MS
    result = seg.process_read(read_bytes=0, is_voice=False, now_ms=now_ms)
    assert result.reason == "pause"


def test_voice_resets_pause_clock_but_not_max_duration_clock():
    """Nói lại giữa chừng (voice=True) phải reset lastVoiceAt (dời mốc tính
    pause) nhưng KHÔNG dời segmentStartAt (mốc tính max_duration vẫn tính từ
    lúc đoạn bắt đầu, không phải từ lần nói cuối)."""
    seg = CloudSttSegmenter(now_ms=0)
    seg.process_read(read_bytes=100, is_voice=True, now_ms=0)
    # Gần chạm pause threshold thì lại nói tiếp -> không được flush vì pause
    result_mid = seg.process_read(read_bytes=100, is_voice=True, now_ms=CLOUD_SEGMENT_PAUSE_MS - 1)
    assert result_mid is None
    # Ngay sau đó im lặng thêm đúng PAUSE_MS kể từ lần nói cuối (không phải
    # kể từ lúc segment bắt đầu) mới flush.
    result_after = seg.process_read(read_bytes=0, is_voice=False, now_ms=(CLOUD_SEGMENT_PAUSE_MS - 1) + CLOUD_SEGMENT_PAUSE_MS)
    assert result_after is not None
    assert result_after.reason == "pause"


def test_flush_final_emits_pending_partial_segment():
    """User bấm 'Dừng nghe' giữa câu -> flush_final() phải đẩy nốt đoạn dang
    dở (nếu đủ điều kiện), tránh mất trắng câu cuối cùng đang nói dở."""
    seg = CloudSttSegmenter(now_ms=0)
    seg.process_read(read_bytes=CLOUD_SEGMENT_MIN_BYTES, is_voice=True, now_ms=0)
    result = seg.flush_final(now_ms=200)  # dừng giữa chừng, chưa kịp pause/max
    assert result.emitted is True
    assert result.reason == "final"


def test_flush_final_on_empty_buffer_does_not_emit():
    seg = CloudSttSegmenter(now_ms=0)
    result = seg.flush_final(now_ms=0)
    assert result.emitted is False


# ===== Kịch bản end-to-end: nhiều câu liên tiếp ===== #

def test_multiple_sentences_each_produce_one_emitted_segment():
    seg = CloudSttSegmenter(now_ms=0)
    emitted_count = 0
    now = 0
    for _sentence in range(3):
        # nói 1 câu ~500ms
        for _ in range(10):
            r = seg.process_read(read_bytes=CLOUD_SEGMENT_MIN_BYTES // 10 + 10, is_voice=True, now_ms=now)
            if r is not None and r.emitted:
                emitted_count += 1
            now += 50
        # im lặng đủ lâu để cắt câu
        r = seg.process_read(read_bytes=0, is_voice=False, now_ms=now + CLOUD_SEGMENT_PAUSE_MS)
        if r is not None and r.emitted:
            emitted_count += 1
        now += CLOUD_SEGMENT_PAUSE_MS + 200  # khoảng nghỉ giữa 2 câu
    assert emitted_count == 3
