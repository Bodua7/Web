import os
import re

path = "android/app/src/main/AndroidManifest.xml"
with open(path, "r", encoding="utf-8") as f:
    content = f.read()

permissions = [
    '<uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />',
    '<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />',
    '<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION" />',
    '<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE" />',
    '<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
    '<uses-permission android:name="android.permission.RECORD_AUDIO" />',
    '<uses-permission android:name="android.permission.WAKE_LOCK" />',
    '<uses-permission android:name="android.permission.INTERNET" />',
    # Nâng cấp "ổn định chạy nền dài": cho phép xin miễn trừ tối ưu pin, tránh OEM
    # (Xiaomi/Oppo/Samsung...) tự kill AudioCaptureService giữa phiên nghe dài.
    '<uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />',
]

# Insert permissions right after <manifest ...> opening tag
if 'SYSTEM_ALERT_WINDOW' not in content:
    manifest_tag_end = content.index(">", content.index("<manifest")) + 1
    perm_block = "\n    " + "\n    ".join(permissions)
    content = content[:manifest_tag_end] + perm_block + content[manifest_tag_end:]

# Insert service declaration inside <application>...</application>, before closing tag.
# Chỉ còn AudioCaptureService - ForegroundService.kt đã bị xoá (dead code, không nơi
# nào start nó; AudioCaptureService đã tự làm foreground notification riêng, đúng
# foregroundServiceType=mediaProjection theo yêu cầu Android 14+).
service_block = '''
    <service
        android:name=".AudioCaptureService"
        android:foregroundServiceType="mediaProjection|microphone"
        android:exported="false" />
'''
if 'AudioCaptureService' not in content:
    app_close_idx = content.rindex("</application>")
    content = content[:app_close_idx] + service_block + content[app_close_idx:]

# FileProvider cho ExportPlugin (xuất/chia sẻ nhật ký dịch .srt/.txt qua Share Sheet) -
# bắt buộc phải khai báo <provider> vì Android 7+ chặn Uri file:// trần trong ACTION_SEND
# (FileUriExposedException), phải đi qua content:// do FileProvider cấp.
provider_block = '''
    <provider
        android:name="androidx.core.content.FileProvider"
        android:authorities="${applicationId}.fileprovider"
        android:exported="false"
        android:grantUriPermissions="true">
        <meta-data
            android:name="android.support.FILE_PROVIDER_PATHS"
            android:resource="@xml/file_paths" />
    </provider>
'''
if 'FileProvider' not in content:
    app_close_idx = content.rindex("</application>")
    content = content[:app_close_idx] + provider_block + content[app_close_idx:]

with open(path, "w", encoding="utf-8") as f:
    f.write(content)

# res/xml/file_paths.xml khai báo thư mục cache/exports/ mà ExportPlugin.shareFile() ghi
# file vào, để FileProvider được phép cấp Uri cho đúng thư mục đó (không cấp toàn bộ app).
xml_dir = "android/app/src/main/res/xml"
os.makedirs(xml_dir, exist_ok=True)
file_paths_content = '''<?xml version="1.0" encoding="utf-8"?>
<paths>
    <cache-path name="exports" path="exports/" />
</paths>
'''
with open(f"{xml_dir}/file_paths.xml", "w", encoding="utf-8") as f:
    f.write(file_paths_content)

print("Manifest patched OK (+ FileProvider + file_paths.xml)")
