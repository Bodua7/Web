import re

path = "android/app/src/main/AndroidManifest.xml"
with open(path, "r", encoding="utf-8") as f:
    content = f.read()

permissions = [
    '<uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />',
    '<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />',
    '<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION" />',
    '<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE" />',
    '<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
    '<uses-permission android:name="android.permission.RECORD_AUDIO" />',
    '<uses-permission android:name="android.permission.WAKE_LOCK" />',
    '<uses-permission android:name="android.permission.INTERNET" />',
    # Nâng cấp "ổn định chạy nền dài": cho phép xin miễn trừ tối ưu pin, tránh OEM
    # (Xiaomi/Oppo/Samsung...) tự kill AudioCaptureService giữa phiên nghe dài.
    '<uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />',
]

# Insert permissions right after <manifest ...> opening tag
if 'SYSTEM_ALERT_WINDOW' not in content:
    manifest_tag_end = content.index(">", content.index("<manifest")) + 1
    perm_block = "\n    " + "\n    ".join(permissions)
    content = content[:manifest_tag_end] + perm_block + content[manifest_tag_end:]

# Insert service declaration inside <application>...</application>, before closing tag.
# Chỉ còn AudioCaptureService - ForegroundService.kt đã bị xoá (dead code, không nơi
# nào start nó; AudioCaptureService đã tự làm foreground notification riêng, đúng
# foregroundServiceType=mediaProjection theo yêu cầu Android 14+).
service_block = '''
    <service
        android:name=".AudioCaptureService"
        android:foregroundServiceType="mediaProjection|microphone"
        android:exported="false" />
'''
if 'AudioCaptureService' not in content:
    app_close_idx = content.rindex("</application>")
    content = content[:app_close_idx] + service_block + content[app_close_idx:]

with open(path, "w", encoding="utf-8") as f:
    f.write(content)

print("Manifest patched OK")
