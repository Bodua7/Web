// Fix (audit Detekt - InvalidPackageDeclaration false-positive): file này nằm phẳng trong
// native/ ở gốc repo, không theo cấu trúc thư mục com/atun/translator/ - CÓ CHỦ ĐÍCH, vì bước
// build-debug (android-build.yml) tự copy file này vào đúng
// android/app/src/main/java/com/atun/translator/ trước khi biên dịch thật (xem step "Copy
// native Kotlin sources"). Detekt ở job validation chạy TRƯỚC bước copy đó (trên native/ phẳng)
// nên luôn báo package không khớp đường dẫn vật lý lúc đó - không phải lỗi thật, khai báo
// package vẫn đúng với vị trí SAU KHI copy (nơi thật sự biên dịch).
@file:Suppress("InvalidPackageDeclaration")

package com.atun.translator

import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.widget.FrameLayout
import com.getcapacitor.BridgeActivity
import com.getcapacitor.BridgeWebChromeClient
import java.io.PrintWriter
import java.io.StringWriter

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installCrashLogger()
        // OverlayWindowPlugin/OverlayView đã gỡ (dọn code chết) - hệ thống "chữ nổi" overlay
        // đè app khác (SYSTEM_ALERT_WINDOW) đã bị thay hoàn toàn bằng phụ đề trong app
        // (#inVideoCaption ở www/index.html) từ lâu, JS không còn gọi Plugins.OverlayPlugin
        // nữa - giữ lại chỉ tốn dung lượng APK + xin thừa 1 quyền nhạy cảm khi build/nộp Play
        // Store. Nếu sau này cần lại chữ nổi ngoài app, khôi phục 2 file từ lịch sử git.
        // ModelManagerPlugin/MlkitTranslatePlugin/ExportPlugin/TtsPlugin/BrowserLauncherPlugin
        // đã gỡ cùng đợt bỏ STT/dịch offline, TTS, Web mini, xuất phụ đề - chỉ còn Cloud STT +
        // chuỗi dịch API (Groq/Gemini/DeepL/Azure/Google free).
        // TtsBoostPlugin (MỚI, theo yêu cầu "tăng âm lượng dịch") KHÔNG phải khôi phục TtsPlugin
        // cũ đã gỡ ở trên - mục đích khác hẳn: khuếch đại được vượt 100% (TtsPlugin cũ không có
        // khả năng này), xem comment đầu TtsBoostPlugin.kt.
        registerPlugin(AudioCapturePlugin::class.java)
        registerPlugin(ScreenOrientationPlugin::class.java)
        registerPlugin(TtsBoostPlugin::class.java)
        super.onCreate(savedInstanceState)
        installFullscreenVideoSupport()
    }

    // ===== Hỗ trợ fullscreen HTML5 thật cho WebView Android (nút "Phóng to" trong
    // www/index.html gọi videoStageEl.requestFullscreen()) - MẶC ĐỊNH Capacitor KHÔNG cài đặt
    // WebChromeClient.onShowCustomView()/onHideCustomView(), nên dù JS gọi requestFullscreen()
    // hợp lệ, WebView Android vẫn không có nơi ("custom view container") để hiển thị nội dung
    // fullscreen - Promise trả về bị reject âm thầm (hoặc không làm gì cả), nút bấm trông như
    // "không phản hồi". Đây chính là nguyên nhân khiến nút "Phóng to" không hoạt động, KHÔNG
    // liên quan gì đến logic JS (enterVideoFullscreen()/fullscreenchange) vốn đã đúng.
    //
    // Cách này thêm 1 FrameLayout phủ toàn màn hình (con của root decorView) để chèn view
    // fullscreen WebView cấp cho onShowCustomView() vào - đây là cách chuẩn để hỗ trợ
    // <video>/Element.requestFullscreen() trong Android WebView (áp dụng luôn cho toàn bộ nội
    // dung DOM lồng trong iframe YouTube lẫn videoStage của chính app, không riêng gì thẻ
    // <video>).
    private var fullscreenCustomView: View? = null
    private var fullscreenCallback: WebChromeClient.CustomViewCallback? = null
    private var fullscreenContainer: FrameLayout? = null

    private fun installFullscreenVideoSupport() {
        val webView = bridge.webView
        // Kế thừa BridgeWebChromeClient(bridge) - CHÍNH class WebChromeClient mặc định mà
        // Capacitor tự gán cho WebView (xử lý sẵn onShowFileChooser cho <input type="file">,
        // onPermissionRequest cho camera/mic, onConsoleMessage...) - override THÊM
        // onShowCustomView/onHideCustomView ở đây, KHÔNG viết đè hẳn bằng WebChromeClient()
        // trơn, để không mất các hành vi mặc định đó (nếu thay hẳn, tính năng "Dịch file"
        // (input type=file) sẽ hỏng vì không còn ai xử lý onShowFileChooser nữa).
        webView.webChromeClient = object : BridgeWebChromeClient(bridge) {
            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (fullscreenCustomView != null) {
                    // Đã đang fullscreen 1 view khác (hiếm khi xảy ra) - dọn view cũ trước khi
                    // nhận view mới, tránh chồng 2 lớp fullscreen lên nhau.
                    callback?.onCustomViewHidden()
                    return
                }
                fullscreenCustomView = view
                fullscreenCallback = callback

                val decor = window.decorView as FrameLayout
                val container = FrameLayout(this@MainActivity)
                container.layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                container.addView(
                    view,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
                decor.addView(container)
                fullscreenContainer = container

                // Ẩn hẳn WebView gốc trong lúc fullscreen (đè lên bởi container ở trên rồi,
                // ẩn thêm cho chắc - tránh input/scroll lọt xuống WebView bên dưới trên vài
                // dòng máy Android render layer không đúng thứ tự).
                webView.visibility = View.GONE
            }

            override fun onHideCustomView() {
                val decor = window.decorView as FrameLayout
                fullscreenContainer?.let { decor.removeView(it) }
                fullscreenContainer = null
                fullscreenCustomView = null
                fullscreenCallback?.onCustomViewHidden()
                fullscreenCallback = null
                webView.visibility = View.VISIBLE
            }
        }
    }

    private fun installCrashLogger() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                val content = "===== CRASH " + java.util.Date().toString() + " =====\n" +
                    "Thread: " + thread.name + "\n" +
                    sw.toString() + "\n"

                // CHỈ ghi qua AppLog (filesDir, có append thật + trim) - đã bỏ nhánh ghi thẳng
                // vào Download công khai trước đây vì gọi resolver.insert() không điều kiện mỗi
                // lần crash tạo ra file MỚI "atun_translator_crash_log (1).txt", (2).txt... trên
                // Android 10+ thay vì nối vào 1 file (MediaStore không hỗ trợ ghi đè theo
                // DISPLAY_NAME qua insert()).
                AppLog.append(applicationContext, content)
            } catch (e: Exception) {
                // Nếu chính việc ghi log bị lỗi thì bỏ qua, không được crash thêm lần nữa ở đây
            }
            // Vẫn gọi handler mặc định để hệ thống xử lý crash (đóng app) như bình thường
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }
}
