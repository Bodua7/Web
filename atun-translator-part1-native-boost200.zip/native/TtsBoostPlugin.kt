// Fix (audit Detekt - InvalidPackageDeclaration false-positive): file này nằm phẳng trong
// native/ ở gốc repo, không theo cấu trúc thư mục com/atun/translator/ - CÓ CHỦ ĐÍCH, vì bước
// build-debug (android-build.yml) tự copy file này vào đúng
// android/app/src/main/java/com/atun/translator/ trước khi biên dịch thật (xem step "Copy
// native Kotlin sources"). Detekt ở job validation chạy TRƯỚC bước copy đó (trên native/ phẳng)
// nên luôn báo package không khớp đường dẫn vật lý lúc đó - không phải lỗi thật, khai báo
// package vẫn đúng với vị trí SAU KHI copy (nơi thật sự biên dịch).
@file:Suppress("InvalidPackageDeclaration")

package com.atun.translator

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.UUID

// Theo yêu cầu "tăng âm lượng dịch": www/app.js TRƯỚC ĐÂY dùng Web Speech API
// (window.speechSynthesis) để đọc to bản dịch - API đó CHỈ nhận volume 0.0-1.0, trình duyệt/
// WebView tự kẹp về 1.0 (100%) nếu đặt cao hơn, và KHÔNG có cách nào lấy audio thật ra để tự
// khuếch đại (không có speechSynthesis.captureStream()). Plugin này thay bằng
// android.speech.tts.TextToSpeech của chính hệ thống: khi cần <=100% vẫn phát thẳng như bình
// thường (speak() gần như tức thời, không cần mạng/quota), khi cần >100% thì tổng hợp ra file
// PCM (synthesizeToFile()), tự nhân biên độ mẫu lên (xem TtsGainUtils.kt) rồi tự phát qua
// AudioTrack - né hẳn giới hạn volume=1.0f của framework Android (tts.speak() + KEY_PARAM_VOLUME
// cũng bị kẹp y hệt, không phải chỉ web mới bị).
//
// Lưu ý lịch sử: 1 plugin tên "TtsPlugin" đã từng có rồi bị GỠ (xem comment trong
// MainActivity.kt, đợt bỏ STT/dịch offline). Plugin NÀY khác hẳn về mục đích (khuếch đại được
// >100%, không có ở bản cũ) nên viết lại từ đầu, không phải khôi phục bản cũ.
@CapacitorPlugin(name = "TtsBoost")
class TtsBoostPlugin : com.getcapacitor.Plugin() {

    companion object {
        // Trần khuếch đại 200% (theo yêu cầu "Boost 200%") - chặn nhập giá trị vô lý (vd 1000%). Vỡ
        // tiếng ở mức này được giảm bằng bộ giới hạn mềm boostPcm16() (TtsGainUtils.kt) thay vì clip
        // cứng, nhưng khuếch đại vượt biên độ gốc vẫn luôn để lại ít nhiều méo tiếng ở các đỉnh.
        const val MAX_VOLUME = 2.0f
        const val MIN_RATE = 0.5f
        const val MAX_RATE = 2.0f
        const val MIN_PITCH = 0.5f
        const val MAX_PITCH = 2.0f
    }

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    // Fix: phân biệt "init chưa xong" với "init XONG NHƯNG THẤT BẠI". Trước đây thất bại (status !=
    // SUCCESS) vẫn chạy hết hàng đợi rồi mọi lệnh sau đó xếp hàng chờ VÔ HẠN (ttsReady mãi false)
    // - JS không nhận được resolve lẫn reject, không có log nào -> trông như "không có tiếng".
    private var ttsInitDone = false
    private var ttsInitStatus = Int.MIN_VALUE
    // Hàng đợi cho lệnh speak()/getVoices() gọi TRƯỚC khi TextToSpeech init xong (chỉ có thể xảy
    // ra trong khoảng rất ngắn ngay lúc mới mở app). Tham số Boolean = init có thành công không.
    private val pendingReadyCallbacks = mutableListOf<(Boolean) -> Unit>()
    private var audioTrack: AudioTrack? = null

    override fun load() {
        super.load()
        tts = TextToSpeech(context) { status ->
            ttsInitStatus = status
            ttsReady = status == TextToSpeech.SUCCESS
            ttsInitDone = true
            val callbacks = pendingReadyCallbacks.toList()
            pendingReadyCallbacks.clear()
            callbacks.forEach { it(ttsReady) }
        }
    }

    override fun handleOnDestroy() {
        tts?.stop()
        tts?.shutdown()
        audioTrack?.release()
        super.handleOnDestroy()
    }

    private fun whenReady(call: PluginCall, block: () -> Unit) {
        val run: (Boolean) -> Unit = { ok ->
            if (ok) {
                block()
            } else {
                // Thông báo rõ lý do thay vì treo im lặng - JS log ra panel debug (xem app.js).
                call.reject(
                    "TTS không khởi tạo được (status=$ttsInitStatus). Máy chưa cài engine TTS, " +
                        "hoặc app thiếu <queries> TTS_SERVICE trong AndroidManifest (Android 11+)."
                )
            }
        }
        if (ttsInitDone) run(ttsReady) else pendingReadyCallbacks.add(run)
    }

    // Chẩn đoán cho JS log lúc mở app: init xong chưa, thành công không, engine mặc định là gì,
    // có bao nhiêu giọng.
    @PluginMethod
    fun getStatus(call: PluginCall) {
        val ret = JSObject()
        ret.put("initDone", ttsInitDone)
        ret.put("ready", ttsReady)
        ret.put("initStatus", ttsInitStatus)
        ret.put("engine", if (ttsReady) (tts?.defaultEngine ?: "") else "")
        ret.put("voiceCount", if (ttsReady) (tts?.voices?.size ?: 0) else 0)
        call.resolve(ret)
    }

    @PluginMethod
    fun getVoices(call: PluginCall) {
        whenReady(call) {
            val engine = tts
            if (engine == null) {
                call.reject("TTS chưa khởi tạo được")
                return@whenReady
            }
            val arr = JSArray()
            engine.voices?.forEach { v ->
                val o = JSObject()
                o.put("name", v.name)
                o.put("locale", v.locale.toLanguageTag())
                arr.put(o)
            }
            val ret = JSObject()
            ret.put("voices", arr)
            call.resolve(ret)
        }
    }

    @PluginMethod
    fun stop(call: PluginCall) {
        tts?.stop()
        audioTrack?.let {
            // pause()/stop() ném IllegalStateException nếu track chưa từng play() - bỏ qua, vô
            // hại (nghĩa là không có gì đang phát để dừng).
            try {
                it.pause()
                it.flush()
                it.stop()
            } catch (e: IllegalStateException) {
                // Không có gì đang phát - không cần làm gì thêm.
            }
        }
        call.resolve()
    }

    // params: text (bắt buộc), lang (vd "vi", mặc định "vi"), voiceName (khớp field "name" trả
    // về từ getVoices(), optional), volume (0.0-3.0, mặc định 1.0 - áp dụng ĐÚNG NHƯ nhập, KHÔNG
    // kẹp về 1.0 như speechSynthesis.volume của Web Speech API khi >1.0 - xem comment đầu file).
    @PluginMethod
    fun speak(call: PluginCall) {
        val text = call.getString("text")
        if (text.isNullOrBlank()) {
            call.reject("Thiếu text")
            return
        }
        val lang = call.getString("lang", "vi") ?: "vi"
        val voiceName = call.getString("voiceName")
        val volume = (call.getDouble("volume", 1.0)?.toFloat() ?: 1.0f).coerceIn(0f, MAX_VOLUME)
        // Tốc độ nói (1.0 = bình thường) và tông giọng (1.0 = mặc định, <1 trầm hơn, >1 cao hơn) -
        // TextToSpeech.setSpeechRate()/setPitch(); áp dụng cho cả đường speak() thẳng lẫn
        // synthesizeToFile() (đường khuếch đại >100%).
        val rate = (call.getDouble("rate", 1.0)?.toFloat() ?: 1.0f).coerceIn(MIN_RATE, MAX_RATE)
        val pitch = (call.getDouble("pitch", 1.0)?.toFloat() ?: 1.0f).coerceIn(MIN_PITCH, MAX_PITCH)

        whenReady(call) {
            val engine = tts
            if (engine == null) {
                call.reject("TTS chưa khởi tạo được")
                return@whenReady
            }

            val matchedVoice = voiceName?.let { name -> engine.voices?.find { v -> v.name == name } }
            if (matchedVoice != null) {
                engine.voice = matchedVoice
            } else {
                engine.setLanguage(Locale.forLanguageTag(lang))
            }

            engine.setSpeechRate(rate)
            engine.setPitch(pitch)

            // Huỷ câu đang đọc dở - giống hệt lý do window.speechSynthesis.cancel() bên bản Web
            // Speech API cũ (không xếp hàng đợi, luôn đọc ĐÚNG câu phụ đề mới nhất).
            engine.stop()

            if (volume <= 1.0f) {
                // Vùng bình thường (<=100%) - dùng thẳng tts.speak(), không cần vòng qua file +
                // AudioTrack (nhanh hơn, tốn ít CPU/pin hơn, gần như tức thời).
                val params = Bundle()
                params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume)
                engine.speak(text, TextToSpeech.QUEUE_FLUSH, params, UUID.randomUUID().toString())
                call.resolve()
            } else {
                // Vùng khuếch đại (>100%) - PHẢI tổng hợp ra file rồi tự nhân biên độ mẫu PCM lên,
                // vì tts.speak() + KEY_PARAM_VOLUME cũng bị kẹp về tối đa 1.0f y hệt
                // speechSynthesis.volume (giới hạn của chính framework Android, không phải do
                // web) - không có cách nào xin âm lượng >100% qua đường phát trực tiếp.
                synthesizeAndBoost(engine, text, volume, call)
            }
        }
    }

    private fun synthesizeAndBoost(engine: TextToSpeech, text: String, gain: Float, call: PluginCall) {
        val outFile = File(context.cacheDir, "tts_boost_${UUID.randomUUID()}.wav")
        val utteranceId = UUID.randomUUID().toString()
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {
                // Không cần làm gì - chỉ quan tâm lúc xong (onDone) để đọc file ra khuếch đại.
            }

            override fun onDone(id: String?) {
                if (id != utteranceId) return
                try {
                    playBoostedWavFile(outFile, gain)
                    call.resolve()
                } catch (e: Exception) {
                    call.reject("Lỗi khuếch đại/phát âm thanh: " + e.message)
                } finally {
                    outFile.delete()
                }
            }

            @Deprecated("Deprecated in Java - vẫn phải override vì UtteranceProgressListener là abstract class Java cũ")
            override fun onError(id: String?) {
                call.reject("Lỗi tổng hợp giọng đọc")
                outFile.delete()
            }

            override fun onError(id: String?, errorCode: Int) {
                call.reject("Lỗi tổng hợp giọng đọc (mã $errorCode)")
                outFile.delete()
            }
        })
        val result = engine.synthesizeToFile(text, Bundle(), outFile, utteranceId)
        if (result != TextToSpeech.SUCCESS) {
            call.reject("Không gọi được synthesizeToFile")
            outFile.delete()
        }
    }

    private class WavInfo(val channels: Int, val sampleRate: Int, val dataOffset: Int, val dataLen: Int)

    // Fix: trước đây GIẢ ĐỊNH header đúng 44 byte và đọc cứng sampleRate/kênh ở offset 22/24. Một số
    // engine TTS (Samsung, vài bản Google TTS...) ghi thêm chunk (LIST/fact...) hoặc header khác
    // 44 byte -> đọc sai sampleRate/nhầm dữ liệu header thành mẫu PCM -> phát ra rè/câm/sai tốc độ.
    // Giờ duyệt các chunk RIFF thật để tìm "fmt " và "data".
    private fun parseWav(bytes: ByteArray): WavInfo? {
        if (bytes.size < 12) return null
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        var pos = 12
        var channels = 0
        var sampleRate = 0
        var bits = 16
        while (pos + 8 <= bytes.size) {
            val id = String(bytes, pos, 4, Charsets.US_ASCII)
            val size = bb.getInt(pos + 4)
            val body = pos + 8
            if (id == "fmt " && body + 16 <= bytes.size) {
                channels = bb.getShort(body + 2).toInt()
                sampleRate = bb.getInt(body + 4)
                bits = bb.getShort(body + 14).toInt()
            } else if (id == "data") {
                val avail = bytes.size - body
                // size âm/quá lớn (engine ghi 0xFFFFFFFF khi chưa biết độ dài) -> lấy hết phần còn lại.
                val len = (if (size < 0 || size > avail) avail else size) and 1.inv()
                if (channels <= 0 || sampleRate <= 0 || bits != 16 || len <= 0) return null
                return WavInfo(channels, sampleRate, body, len)
            }
            if (size < 0) return null
            pos = body + size + (size and 1)
        }
        return null
    }

    private fun playBoostedWavFile(file: File, gain: Float) {
        val bytes = file.readBytes()
        val wav = parseWav(bytes)
            ?: throw IllegalStateException("WAV không hợp lệ/không phải PCM16 (${bytes.size} byte)")
        val numChannels = wav.channels
        val sampleRate = wav.sampleRate

        val pcmShorts = ByteBuffer.wrap(bytes, wav.dataOffset, wav.dataLen)
            .order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val original = ShortArray(pcmShorts.remaining())
        pcmShorts.get(original)
        val boosted = boostPcm16(original, gain)

        val channelConfig = if (numChannels >= 2) AudioFormat.CHANNEL_OUT_STEREO else AudioFormat.CHANNEL_OUT_MONO
        val minBufSize = AudioTrack.getMinBufferSize(sampleRate, channelConfig, AudioFormat.ENCODING_PCM_16BIT)
        val bufSize = maxOf(minBufSize, boosted.size * 2)

        audioTrack?.release()
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(channelConfig)
                    .build()
            )
            .setBufferSizeInBytes(bufSize)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track.write(boosted, 0, boosted.size)
        track.play()
        audioTrack = track
    }
}
