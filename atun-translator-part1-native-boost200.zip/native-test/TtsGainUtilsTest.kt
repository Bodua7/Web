package com.atun.translator

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test

class TtsGainUtilsTest {

    @Test
    fun `gain 1_0 giu nguyen mau khong doi`() {
        val input = shortArrayOf(100, -100, 0, 32000, -32000)
        assertArrayEquals(input, applyGainToPcm16(input, 1.0f))
    }

    @Test
    fun `gain 2_0 nhan doi bien do dung`() {
        val input = shortArrayOf(100, -100, 5000, -5000, 0)
        val expected = shortArrayOf(200, -200, 10000, -10000, 0)
        assertArrayEquals(expected, applyGainToPcm16(input, 2.0f))
    }

    @Test
    fun `gain le lam tron ve so nguyen gan nhat`() {
        // 100 * 1.234 = 123.4 -> làm tròn xuống 123; 100 * 1.236 = 123.6 -> làm tròn lên 124.
        // Cố tình tránh test đúng mốc .5 (vd 101 * 1.5 = 151.5) - quy ước làm tròn .5 khác nhau
        // giữa các hàm round (nửa lên vs nửa chẵn) nên tránh test đúng biên đó để không phụ
        // thuộc quy ước cụ thể nào.
        assertArrayEquals(shortArrayOf(123), applyGainToPcm16(shortArrayOf(100), 1.234f))
        assertArrayEquals(shortArrayOf(124), applyGainToPcm16(shortArrayOf(100), 1.236f))
    }

    @Test
    fun `vuot tran duong thi clip ve Short_MAX_VALUE khong wrap-around`() {
        val input = shortArrayOf(20000, 32767)
        val result = applyGainToPcm16(input, 3.0f)
        assertEquals(Short.MAX_VALUE, result[0])
        assertEquals(Short.MAX_VALUE, result[1])
    }

    @Test
    fun `vuot tran am thi clip ve Short_MIN_VALUE khong wrap-around`() {
        val input = shortArrayOf(-20000, -32768)
        val result = applyGainToPcm16(input, 3.0f)
        assertEquals(Short.MIN_VALUE, result[0])
        assertEquals(Short.MIN_VALUE, result[1])
    }

    @Test
    fun `gain 0 thi tat ca mau ve 0 (cau lang)`() {
        val input = shortArrayOf(12345, -12345, 32767, -32768)
        val result = applyGainToPcm16(input, 0f)
        assertArrayEquals(shortArrayOf(0, 0, 0, 0), result)
    }

    @Test
    fun `mang rong tra ve mang rong khong loi`() {
        val result = applyGainToPcm16(ShortArray(0), 2.0f)
        assertEquals(0, result.size)
    }

    // ===== boostPcm16 (bộ giới hạn mềm cho Boost > 100%) =====

    @Test
    fun `boost gain 1_0 hoac thap hon giong het applyGainToPcm16`() {
        val input = shortArrayOf(100, -100, 0, 32000, -32000)
        assertArrayEquals(applyGainToPcm16(input, 1.0f), boostPcm16(input, 1.0f))
        assertArrayEquals(applyGainToPcm16(input, 0.5f), boostPcm16(input, 0.5f))
    }

    @Test
    fun `boost mau nho duoi nguong van nhan dung gain tuyen tinh`() {
        // 1000 * 2 = 2000 (0.061 << knee 0.6) - phải đúng tuyến tính, không bị nén.
        assertArrayEquals(shortArrayOf(2000, -2000, 0), boostPcm16(shortArrayOf(1000, -1000, 0), 2.0f))
    }

    @Test
    fun `boost dinh cao khong bao gio clip cung hay wrap-around`() {
        val result = boostPcm16(shortArrayOf(20000, 32767, -20000, -32768), 3.0f)
        // Nén mềm: luôn nằm trong biên và KHÔNG chạm đúng biên như clip cứng ở mẫu 20000.
        assertEquals(true, result[0] > 0 && result[0] < Short.MAX_VALUE)
        assertEquals(true, result[2] < 0 && result[2] > Short.MIN_VALUE)
        assertEquals(true, result[1] > 0)
        assertEquals(true, result[3] < 0)
    }

    @Test
    fun `boost doi xung am duong va don dieu tang`() {
        val a = boostPcm16(shortArrayOf(10000, 20000, 30000), 2.0f)
        val b = boostPcm16(shortArrayOf(-10000, -20000, -30000), 2.0f)
        for (i in a.indices) assertEquals(a[i].toInt(), -b[i].toInt())
        assertEquals(true, a[0] < a[1] && a[1] < a[2])
    }

    @Test
    fun `boost to hon ban goc o moi mau duoi nguong bao hoa`() {
        val input = shortArrayOf(5000, 10000, 15000)
        val out = boostPcm16(input, 2.0f)
        for (i in input.indices) assertEquals(true, out[i] > input[i])
    }
}
