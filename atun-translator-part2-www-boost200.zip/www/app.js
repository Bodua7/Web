// www/app.js - JS "thường" (không phải module) tách ra từ khối <script> đầu tiên trong
// index.html. Nạp qua <script src="app.js"></script> - đúng ngay vị trí cũ trong <body> nên
// thứ tự chạy/scope top-level (let/const/function) không đổi so với lúc còn inline. File
// app.module.js (khối <script type="module"> thứ 2) và file này KHÔNG chung scope - mọi cầu
// nối 2 chiều vẫn đi qua window.__xxx như trước, không đổi gì thêm ở đây.

    const logEl = document.getElementById('log');
    // Log phình vô hạn sau phiên chạy dài (đặc biệt log audio-level bắn mỗi giây) làm
    // WebView tốn RAM dần rồi crash app - giới hạn chỉ giữ tối đa 300 dòng gần nhất.
    // Gắn vào window để script type="module" bên dưới dùng chung, tránh 2 log rời rạc
    // cùng ghi đè lên nhau trên cùng 1 phần tử #log.
    const MAX_LOG_LINES = 300;
    let logLines = [];
    function log(msg) {
      const time = new Date().toLocaleTimeString();
      logLines.unshift(`[${time}] ${msg}`);
      if (logLines.length > MAX_LOG_LINES) logLines.length = MAX_LOG_LINES;
      // Chỉ ghi lại DOM (textContent) khi panel debug đang HIỆN - lúc ẩn (mặc định, và suốt
      // hầu hết thời gian chạy nền) build lại chuỗi 300 dòng + reflow mỗi lần log() (đặc biệt
      // audioLevel bắn đều đặn mỗi giây) chỉ tốn CPU/pin vô ích vì không ai nhìn thấy. Mảng
      // logLines vẫn được cập nhật đầy đủ nên bật debug lên bất kỳ lúc nào vẫn thấy đủ log.
      if (debugToggleEl?.checked) {
        logEl.textContent = logLines.join('\n');
      }
    }
    window.__appLog = log;

    window.addEventListener('error', (e) => {
      log('JS ERROR: ' + e.message);
    });

    // QUAN TRỌNG: window.addEventListener('error') ở trên CHỈ bắt lỗi throw đồng bộ,
    // KHÔNG bắt được Promise bị reject mà không có .catch() riêng - phần lớn code trong
    // app (gọi native plugin, dịch, STT...) đều là async/await, nên trước đây rất nhiều
    // lỗi thật xảy ra âm thầm, không bao giờ tới được log()/persistIfError() -> đây là
    // nguyên nhân chính khiến log lỗi (cả bảng debug lẫn file lỗi cục bộ qua AppLog) bị
    // "thiếu" lỗi dù lỗi có xảy ra. Thêm listener này để không bỏ sót nữa.
    window.addEventListener('unhandledrejection', (e) => {
      const reason = e.reason;
      const msg = reason instanceof Error
        ? (reason.message || String(reason))
        : String(reason);
      log('JS ERROR (unhandled promise): ' + msg);
    });

    // ===== Debug log: ẩn theo mặc định (Phase 2) - chỉ hiện khi user tự bật, và nhớ lựa
    // chọn đó cho lần mở app sau bằng localStorage. Người dùng thường không cần thấy log kỹ
    // thuật; log vẫn được ghi ngầm ở #log để bật lên xem khi cần báo lỗi. =====
    const DEBUG_KEY = 'atun_debug_enabled';
    const debugToggleEl = document.getElementById('debugToggle');
    function applyDebugVisibility() {
      logEl.style.display = debugToggleEl.checked ? 'block' : 'none';
      // Vì log() giờ chỉ ghi DOM khi đang hiện (xem log() ở trên), lúc BẬT debug lên phải tự
      // render lại 1 lần cho đủ nội dung tích luỹ trong lúc ẩn, không đợi tới dòng log() kế tiếp.
      if (debugToggleEl.checked) {
        logEl.textContent = logLines.join('\n');
      }
    }

    // ===== Nút thu nhỏ/mở rộng cho khung "Cài đặt nghe/dịch" - nhớ trạng thái đóng/mở qua
    // localStorage (giống DEBUG_KEY ở trên) để lần sau mở app giữ nguyên. =====
    // containerEl: tuỳ chọn - phần tử SẼ được toggle class "collapsed" lên. Bỏ trống thì tự dùng
    // headerEl.closest('.card') như trước (khối "Model ngôn ngữ"/"Cài đặt nghe/dịch" - mỗi khối
    // đúng là 1 .card riêng ở cấp ngoài cùng). Truyền containerEl RÕ RÀNG khi khối cần thu/mở
    // KHÔNG phải chính .card ngoài cùng mà là 1 khối con lồng bên trong .card khác (vd
    // #captionSettingsWrap lồng trong .card của mainSettingsHeader) - nếu để tự closest('.card')
    // sẽ lấy nhầm .card cha, thu nhỏ nhầm cả khối cha.
    function setupCollapsibleCard(headerId, toggleBtnId, storageKey, defaultCollapsed, containerEl) {
      const headerEl = document.getElementById(headerId);
      const toggleBtnEl = document.getElementById(toggleBtnId);
      if (!headerEl || !toggleBtnEl) return;
      const cardEl = containerEl || headerEl.closest('.card');
      if (!cardEl) return;

      function applyCollapsed(collapsed) {
        cardEl.classList.toggle('collapsed', collapsed);
        toggleBtnEl.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
        toggleBtnEl.title = collapsed ? 'Mở rộng' : 'Thu nhỏ';
      }

      const saved = localStorage.getItem(storageKey);
      const collapsed = saved === null ? !!defaultCollapsed : saved === '1';
      applyCollapsed(collapsed);

      function toggle() {
        const nowCollapsed = !cardEl.classList.contains('collapsed');
        applyCollapsed(nowCollapsed);
        localStorage.setItem(storageKey, nowCollapsed ? '1' : '0');
      }

      toggleBtnEl.addEventListener('click', (e) => {
        e.stopPropagation();
        toggle();
      });
      // Bấm vào cả phần tiêu đề (không chỉ riêng nút nhỏ) cũng thu/mở được cho dễ bấm trên máy.
      headerEl.addEventListener('click', toggle);
    }
    setupCollapsibleCard('mainSettingsHeader', 'mainSettingsToggleBtn', 'atun_main_settings_collapsed', false);
    // Fix (theo yêu cầu - "xoá nút ẩn ngôn ngữ"): TRƯỚC ĐÂY có thêm 1 lệnh
    // setupCollapsibleCard('sourceLangHeader', 'sourceLangToggleBtn', ...) ở đây cho khối "Ngôn
    // ngữ đang nói" - đã bỏ hẳn (header + nút ▾ tương ứng cũng đã xoá khỏi index.html), khối đó
    // giờ luôn hiện, không thu/mở được nữa. Key localStorage cũ 'atun_source_lang_collapsed' (nếu
    // máy nào đã từng lưu) giờ không còn đọc/ghi tới nữa - vô hại, không cần dọn.
    // Mặc định ĐÓNG (defaultCollapsed=true) - khác các khối trên (mặc định mở) - vì đây là
    // khối tuỳ chỉnh chi tiết ít khi cần đụng tới thường xuyên, đóng gọn từ đầu cho đỡ chiếm
    // chỗ màn hình chính; người dùng tự mở khi cần, trạng thái mở/đóng vẫn nhớ lại như thường.
    setupCollapsibleCard('captionSettingsHeader', 'captionSettingsToggleBtn', 'atun_caption_settings_collapsed', true, document.getElementById('captionSettingsWrap'));
    debugToggleEl.checked = localStorage.getItem(DEBUG_KEY) === '1';
    applyDebugVisibility();
    debugToggleEl.onchange = () => {
      localStorage.setItem(DEBUG_KEY, debugToggleEl.checked ? '1' : '0');
      applyDebugVisibility();
    };

    // ===== Lưu lựa chọn (ngôn ngữ đích, ngôn ngữ nguồn, nguồn audio, cỡ chữ overlay) qua
    // localStorage - persist trong bộ nhớ WebView riêng của app, không mất khi tắt/mở lại app,
    // không cần chọn lại mỗi lần (Phase 2). Dùng localStorage thay vì Capacitor Preferences vì
    // pipeline build hiện tại không chạy `cap sync` để autolink plugin native mới. =====
    const SETTINGS_KEY = 'atun_settings_v1';
    function loadSettings() {
      try {
        return JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}');
      } catch (e) {
        return {};
      }
    }
    function saveSettings(patch) {
      const current = loadSettings();
      localStorage.setItem(SETTINGS_KEY, JSON.stringify({ ...current, ...patch }));
    }
    // app.module.js cũng cần lưu patch (vd. captureMode='mic' lúc fallback) - bắc cầu qua
    // window.__ thay vì tự đọc/ghi localStorage riêng, tránh 2 nơi cùng biết SETTINGS_KEY/schema
    // rồi lệch nhau khi 1 bên đổi mà bên kia quên theo (xem window.__translateText ở trên).
    window.__saveSettings = saveSettings;

    const targetLangEl = document.getElementById('targetLang');
    const sourceLangEl = document.getElementById('sourceLang');
    const captureModeEl = document.getElementById('captureMode');
    const preferExternalMicEl = document.getElementById('preferExternalMic');
    const externalMicRowEl = document.getElementById('externalMicRow');
    const externalMicStatusEl = document.getElementById('externalMicStatus');
    // Chỉ hiện khi captureMode='mixed' - xem updateExternalMicUi()/startCaptureFlow() trong
    // app.module.js.
    const mixedModeHintEl = document.getElementById('mixedModeHint');

    // #sourceLang chỉ có 1 <option> placeholder ("en") lúc trang vừa load - danh sách thật
    // (WHISPER_LANGS, xem bên dưới) chỉ được xây khi buildSourceLangOptions() chạy. Nếu user đã
    // lưu sourceLang khác "en" từ trước, gán thẳng vào sourceLangEl.value ở đây sẽ KHÔNG có tác
    // dụng (option đó chưa tồn tại, DOM âm thầm bỏ qua) - lưu tạm giá trị đã lưu vào biến này,
    // buildSourceLangOptions() sẽ ưu tiên dùng nó.
    let pendingSourceLangFromSettings = null;
    (function restoreSettings() {
      const s = loadSettings();
      if (s.targetLang) targetLangEl.value = s.targetLang;
      if (s.sourceLang) pendingSourceLangFromSettings = s.sourceLang;
      if (s.captureMode) captureModeEl.value = s.captureMode;
      if (typeof s.preferExternalMic === 'boolean') preferExternalMicEl.checked = s.preferExternalMic;
    })();
    targetLangEl.onchange = () => saveSettings({ targetLang: targetLangEl.value });
    sourceLangEl.onchange = () => saveSettings({ sourceLang: sourceLangEl.value });
    captureModeEl.onchange = () => {
      saveSettings({ captureMode: captureModeEl.value });
      window.__updateExternalMicUi?.();
    };
    preferExternalMicEl.onchange = () => {
      saveSettings({ preferExternalMic: preferExternalMicEl.checked });
      window.__refreshExternalMicStatus?.();
    };
    // Fix (dọn code thừa - audit): dòng gọi window.__updateExternalMicUi?.() từng nằm ở đây đã bị
    // xoá - nó LUÔN no-op (im lặng nhờ ?.) vì app.js chạy đồng bộ ngay khi parse, còn
    // app.module.js là <script type="module"> nên bị hoãn chạy tới SAU đó - hàm window.__
    // updateExternalMicUi chưa hề tồn tại lúc dòng đó thực thi. Việc hiện/ẩn khối "Ưu tiên micro
    // ngoài" đúng ngay từ lần load đầu vẫn hoạt động đúng - do app.module.js TỰ gọi lại
    // updateExternalMicUi() ngay sau khi định nghĩa xong (xem chỗ khai báo `capture` trong
    // app.module.js), không phải nhờ dòng đã xoá này.

    // ===== Đọc to bản dịch bằng giọng nói (TTS) =====
    // Fix (theo yêu cầu "tăng âm lượng dịch"): TRƯỚC ĐÂY dùng thẳng Web Speech API
    // (window.speechSynthesis) - API đó CHỈ nhận volume 0.0-1.0, trình duyệt/WebView tự kẹp về
    // 1.0 (100%) nếu đặt cao hơn, KHÔNG có cách nào lấy audio thật ra để tự khuếch đại (không có
    // speechSynthesis.captureStream()). Giờ khi chạy TRONG app native, dùng plugin TtsBoost
    // (native/TtsBoostPlugin.kt) - tự tổng hợp ra PCM rồi tự khuếch đại/phát qua AudioTrack khi
    // cần >100%, né hẳn giới hạn đó. Khi chạy NGOÀI app (dev/test trên trình duyệt máy tính) vẫn
    // dùng lại Web Speech API làm fallback - hoạt động bình thường ở đó, chỉ bị kẹp ở 100% (không
    // sao, dev/test không cần khuếch đại).
    const ttsEnabledEl = document.getElementById('ttsEnabled');
    const ttsControlsBodyEl = document.getElementById('ttsControlsBody');
    const ttsMuteBtnEl = document.getElementById('ttsMuteBtn');
    const ttsVolumeEl = document.getElementById('ttsVolume');
    const ttsVolumeLabelEl = document.getElementById('ttsVolumeLabel');
    const ttsVoiceEl = document.getElementById('ttsVoice');
    const ttsRateEl = document.getElementById('ttsRate');
    const ttsRateLabelEl = document.getElementById('ttsRateLabel');
    const ttsPitchEl = document.getElementById('ttsPitch');
    const ttsPitchLabelEl = document.getElementById('ttsPitchLabel');
    const ttsPreviewBtnEl = document.getElementById('ttsPreviewBtn');
    const ttsBoostPlugin = window.Capacitor?.isNativePlatform?.() ? (window.Capacitor?.Plugins?.TtsBoost || null) : null;

    function applyTtsControlsVisibility() {
      ttsControlsBodyEl.style.display = ttsEnabledEl.checked ? 'block' : 'none';
    }
    function applyTtsMuteButtonIcon() {
      // ttsMuted CHỈ ảnh hưởng icon/volume hiệu lực khi đọc - KHÔNG ghi đè giá trị thanh trượt
      // ttsVolumeEl (bật lại mute phải về đúng % đã set trước đó, không phải luôn về 100%).
      ttsMuteBtnEl.textContent = loadSettings().ttsMuted ? '🔇' : '🔊';
    }
    // Danh sách giọng tải KHÔNG đồng bộ trên cả 2 đường (plugin native: Promise; Web Speech API:
    // rỗng ngay sau load trang, chỉ có thật sau sự kiện 'voiceschanged') - populateTtsVoiceList()
    // dùng chung cho cả 2, chỉ khác nguồn lấy "voices" (mảng {name, locale} chuẩn hoá như nhau).
    // Theo yêu cầu "chỉ giữ giọng đọc tiếng Việt": chỉ liệt kê giọng có locale vi / vi-VN / vi_VN
    // (native trả toLanguageTag() = "vi-VN"; Web Speech API có thể trả "vi_VN" trên vài máy).
    function isVietnameseVoice(v) {
      return /^vi([-_]|$)/i.test(String(v.locale || ''));
    }
    function renderTtsVoiceOptions(allVoices) {
      if (allVoices.length === 0) return; // danh sách chưa tải xong - đợi lần gọi sau
      const voices = allVoices.filter(isVietnameseVoice);
      const savedVoiceURI = loadSettings().ttsVoiceURI || '';
      // Giọng đã lưu từ trước mà không phải tiếng Việt (vd giọng Anh chọn ở bản cũ) -> xoá, nếu
      // không speakTranslated() vẫn đọc bằng giọng đó dù danh sách đã không còn hiện nó.
      if (savedVoiceURI && !voices.some((v) => v.id === savedVoiceURI)) {
        saveSettings({ ttsVoiceURI: '' });
        ttsVoiceEl.value = '';
      }
      const currentValue = ttsVoiceEl.value || (savedVoiceURI && voices.some((v) => v.id === savedVoiceURI) ? savedVoiceURI : '');
      ttsVoiceEl.innerHTML = '<option value="">(Mặc định của máy - tiếng Việt)</option>';
      voices.forEach((v, idx) => {
        const opt = document.createElement('option');
        opt.value = v.id;
        opt.textContent = `Giọng ${idx + 1} - ${v.name} (${v.locale})`;
        ttsVoiceEl.appendChild(opt);
      });
      // Khôi phục lựa chọn cũ NẾU giọng đó vẫn còn trong danh sách mới tải (danh sách giọng có
      // thể khác nhau giữa các lần load - ứng dụng TTS bên thứ 3 cài thêm/gỡ trên máy).
      if (currentValue && voices.some((v) => v.id === currentValue)) {
        ttsVoiceEl.value = currentValue;
      }
    }
    function populateTtsVoiceList() {
      if (ttsBoostPlugin) {
        // Chẩn đoán TTS: hiện trong log kỹ thuật để biết engine có khởi tạo được không (thiếu
        // <queries> TTS_SERVICE ở manifest -> initStatus=-1, ready=false, không có giọng nào).
        setTimeout(() => {
          ttsBoostPlugin.getStatus?.()
            .then((st) => log('[TTS] status: ready=' + st.ready + ', initStatus=' + st.initStatus
              + ', engine=' + (st.engine || '(không có)') + ', voiceCount=' + st.voiceCount))
            .catch((err) => log('[TTS] getStatus lỗi: ' + err.message));
        }, 3000);
        ttsBoostPlugin.getVoices()
          .then((res) => {
            const list = res.voices || [];
            log('[TTS] getVoices: ' + list.length + ' giọng, '
              + list.filter((v) => isVietnameseVoice({ locale: v.locale })).length + ' giọng tiếng Việt');
            renderTtsVoiceOptions(list.map((v) => ({ id: v.name, name: v.name, locale: v.locale })));
          })
          .catch((err) => log('[TTS] Không lấy được danh sách giọng đọc: ' + err.message));
      } else {
        const voices = window.speechSynthesis?.getVoices() || [];
        renderTtsVoiceOptions(voices.map((v) => ({ id: v.voiceURI, name: v.name, locale: v.lang })));
      }
    }
    populateTtsVoiceList();
    if (!ttsBoostPlugin && window.speechSynthesis) {
      window.speechSynthesis.onvoiceschanged = populateTtsVoiceList;
    }
    (function restoreTtsSettings() {
      const s = loadSettings();
      ttsEnabledEl.checked = !!s.ttsEnabled;
      // Trần thanh trượt: 200% khi có plugin native (khuếch đại thật được, khớp
      // TtsBoostPlugin.MAX_VOLUME), 100% khi fallback Web Speech API (khuếch đại thêm cũng
      // không có tác dụng, kẹp cứng ở 100% - xem comment đầu khối TTS).
      ttsVolumeEl.max = ttsBoostPlugin ? 200 : 100;
      ttsVolumeEl.value = Math.min(typeof s.ttsVolume === 'number' ? s.ttsVolume : 100, Number(ttsVolumeEl.max));
      ttsVolumeLabelEl.textContent = ttsVolumeEl.value + '%';
      ttsRateEl.value = typeof s.ttsRate === 'number' ? s.ttsRate : 100;
      ttsRateLabelEl.textContent = (Number(ttsRateEl.value) / 100).toFixed(2).replace(/0$/, '') + 'x';
      ttsPitchEl.value = typeof s.ttsPitch === 'number' ? s.ttsPitch : 100;
      ttsPitchLabelEl.textContent = (Number(ttsPitchEl.value) / 100).toFixed(2).replace(/0$/, '');
      if (s.ttsVoiceURI) ttsVoiceEl.value = s.ttsVoiceURI; // không ăn thua nếu voice chưa tải kịp - populateTtsVoiceList() ở trên sẽ tự khôi phục lại khi tải xong
      applyTtsControlsVisibility();
      applyTtsMuteButtonIcon();
    })();
    ttsEnabledEl.onchange = () => {
      saveSettings({ ttsEnabled: ttsEnabledEl.checked });
      applyTtsControlsVisibility();
      if (!ttsEnabledEl.checked) {
        // Tắt hẳn thì ngưng luôn câu đang đọc dở, ở CẢ 2 đường (chỉ 1 trong 2 đang thực sự dùng,
        // gọi cả 2 cho gọn code, đường không dùng gọi vào cũng vô hại).
        ttsBoostPlugin?.stop();
        window.speechSynthesis?.cancel();
      }
    };
    ttsVolumeEl.oninput = () => {
      ttsVolumeLabelEl.textContent = ttsVolumeEl.value + '%';
      saveSettings({ ttsVolume: Number(ttsVolumeEl.value) });
      // Tự kéo về 0 coi như bật mute luôn (đỡ phải bấm thêm nút 🔇), tự kéo lên > 0 thì tự bỏ
      // mute - khớp hành vi quen thuộc của hầu hết app nghe nhạc/gọi video.
      const shouldMute = Number(ttsVolumeEl.value) === 0;
      if (shouldMute !== !!loadSettings().ttsMuted) {
        saveSettings({ ttsMuted: shouldMute });
        applyTtsMuteButtonIcon();
      }
    };
    ttsMuteBtnEl.onclick = () => {
      const nowMuted = !loadSettings().ttsMuted;
      saveSettings({ ttsMuted: nowMuted });
      applyTtsMuteButtonIcon();
      // Bấm bỏ mute lúc thanh trượt đang ở 0% (từ trước đó tự kéo về 0 ở oninput bên trên) thì
      // trả lại 1 mức nghe được (50%) thay vì bỏ mute nhưng vẫn câm vì volume=0 - tránh cảm giác
      // "bấm bỏ mute mà vẫn không nghe thấy gì".
      if (!nowMuted && Number(ttsVolumeEl.value) === 0) {
        ttsVolumeEl.value = 50;
        ttsVolumeLabelEl.textContent = '50%';
        saveSettings({ ttsVolume: 50 });
      }
    };
    ttsVoiceEl.onchange = () => saveSettings({ ttsVoiceURI: ttsVoiceEl.value });
    ttsRateEl.oninput = () => {
      ttsRateLabelEl.textContent = (Number(ttsRateEl.value) / 100).toFixed(2).replace(/0$/, '') + 'x';
      saveSettings({ ttsRate: Number(ttsRateEl.value) });
    };
    ttsPitchEl.oninput = () => {
      ttsPitchLabelEl.textContent = (Number(ttsPitchEl.value) / 100).toFixed(2).replace(/0$/, '');
      saveSettings({ ttsPitch: Number(ttsPitchEl.value) });
    };
    // Nghe thử: đọc 1 câu mẫu bằng đúng giọng/tốc độ/tông/âm lượng đang chọn - bỏ qua công tắc
    // "Đọc to bản dịch" và nút tắt tiếng để luôn nghe được (dùng để CHỌN giọng, vì Android không
    // cho biết giọng nam/nữ).
    ttsPreviewBtnEl.onclick = () => {
      speakTranslated('Xin chào, đây là giọng đọc bản dịch tiếng Việt.', 'vi', true);
    };

    // app.module.js gọi hàm này mỗi khi có câu dịch MỚI trong luồng nghe trực tiếp - bắc cầu qua
    // window.__ giống translateText/queueTranslate/saveSettings/transcribeCloudSegment ở trên,
    // vì app.js/app.module.js không chung scope.
    function speakTranslated(text, lang, isPreview) {
      if ((!ttsEnabledEl.checked && !isPreview) || !text) return;
      const s = loadSettings();
      const effectiveVolume = (s.ttsMuted && !isPreview) ? 0 : (typeof s.ttsVolume === 'number' && s.ttsVolume > 0 ? s.ttsVolume : 100);
      const rate = (typeof s.ttsRate === 'number' ? s.ttsRate : 100) / 100;
      const pitch = (typeof s.ttsPitch === 'number' ? s.ttsPitch : 100) / 100;

      if (ttsBoostPlugin) {
        // volume truyền dạng tỉ lệ (1.0 = 100%) cho plugin native - KHÔNG chia thêm 1 lần nữa,
        // plugin tự nhân biên độ PCM lên khi >1.0 (xem TtsBoostPlugin.kt).
        ttsBoostPlugin.speak({
          text,
          lang: lang || 'vi',
          voiceName: s.ttsVoiceURI || undefined,
          volume: effectiveVolume / 100,
          rate,
          pitch,
        }).catch((err) => log('Lỗi đọc to bản dịch: ' + err.message));
        return;
      }

      if (!window.speechSynthesis) return;
      // Huỷ câu đang đọc dở (nếu có) trước khi đọc câu mới - KHÔNG xếp hàng đợi: nếu để mặc định
      // speechSynthesis tự xếp hàng, lúc STT/dịch ra câu nhanh hơn tốc độ đọc (rất hay gặp khi
      // người nói nhanh) hàng đợi giọng đọc sẽ dồn ứ, đọc trễ so với phụ đề đang hiện ngày càng
      // xa - thà bỏ qua câu đọc dở, luôn đọc ĐÚNG câu phụ đề mới nhất đang hiện trên màn hình.
      window.speechSynthesis.cancel();
      const utter = new SpeechSynthesisUtterance(text);
      utter.lang = lang || 'vi';
      utter.rate = rate;
      utter.pitch = pitch;
      utter.volume = Math.min(effectiveVolume, 100) / 100; // fallback web: kẹp cứng ở 100%, xem comment đầu khối TTS
      if (s.ttsVoiceURI) {
        const voice = window.speechSynthesis.getVoices().find((v) => v.voiceURI === s.ttsVoiceURI);
        if (voice) utter.voice = voice;
      }
      // Lỗi biết trước của Chrome/WebView: gọi speak() NGAY trong cùng tick sau cancel() đôi khi
      // bị nuốt im lặng (không đọc gì, không lỗi) - trễ 1 chút (setTimeout 0) để tránh.
      setTimeout(() => window.speechSynthesis.speak(utter), 0);
    }
    window.__speakTranslated = speakTranslated;

    function getAudioCapturePlugin() {
      return window.Capacitor?.Plugins?.AudioCapture || null;
    }

    // ===== Danh sách ngôn ngữ cho Whisper Cloud (groq-relay?op=transcribe, model
    // whisper-large-v3-turbo) - đường DUY NHẤT còn lại để nhận diện giọng nói (đã bỏ Vosk
    // offline), nên đây cũng là toàn bộ danh sách #sourceLang. Không cần tải gì trước - mọi
    // ngôn ngữ dưới đây dùng NGAY. Danh sách lấy đúng theo mã ISO-639-1 mà Whisper/Groq hỗ trợ
    // (https://whisper-api.com/docs/languages/ - dựa theo LANGUAGES dict gốc của openai/whisper,
    // ~99 ngôn ngữ + "yue" Quảng Đông thêm ở whisper-large-v3).
    const WHISPER_LANGS = [
      { lang: 'af', name: 'Afrikaans' },
      { lang: 'am', name: 'አማርኛ (Amharic - Ethiopia)' },
      { lang: 'ar', name: 'العربية (Ả Rập)' },
      { lang: 'as', name: 'অসমীয়া (Assam)' },
      { lang: 'az', name: 'Azərbaycan (Azerbaijan)' },
      { lang: 'ba', name: 'Башҡорт (Bashkir)' },
      { lang: 'be', name: 'Беларуская (Belarus)' },
      { lang: 'bg', name: 'Български (Bulgaria)' },
      { lang: 'bn', name: 'বাংলা (Bengal)' },
      { lang: 'bo', name: 'བོད་སྐད (Tây Tạng)' },
      { lang: 'br', name: 'Brezhoneg (Breton)' },
      { lang: 'bs', name: 'Bosanski (Bosnia)' },
      { lang: 'ca', name: 'Català (Catalan)' },
      { lang: 'cs', name: 'Čeština (Séc)' },
      { lang: 'cy', name: 'Cymraeg (Wales)' },
      { lang: 'da', name: 'Dansk (Đan Mạch)' },
      { lang: 'de', name: 'Deutsch (Đức)' },
      { lang: 'el', name: 'Ελληνικά (Hy Lạp)' },
      { lang: 'en', name: 'English' },
      { lang: 'es', name: 'Español (Tây Ban Nha)' },
      { lang: 'et', name: 'Eesti (Estonia)' },
      { lang: 'eu', name: 'Euskara (Basque)' },
      { lang: 'fa', name: 'فارسی (Ba Tư/Iran)' },
      { lang: 'fi', name: 'Suomi (Phần Lan)' },
      { lang: 'fo', name: 'Føroyskt (Faroe)' },
      { lang: 'fr', name: 'Français (Pháp)' },
      { lang: 'gl', name: 'Galego (Galicia)' },
      { lang: 'gu', name: 'ગુજરાતી (Gujarat)' },
      { lang: 'ha', name: 'Hausa' },
      { lang: 'haw', name: 'ʻŌlelo Hawaiʻi (Hawaii)' },
      { lang: 'he', name: 'עברית (Do Thái)' },
      { lang: 'hi', name: 'हिन्दी (Ấn Độ - Hindi)' },
      { lang: 'hr', name: 'Hrvatski (Croatia)' },
      { lang: 'ht', name: 'Kreyòl Ayisyen (Haiti)' },
      { lang: 'hu', name: 'Magyar (Hungary)' },
      { lang: 'hy', name: 'Հայերեն (Armenia)' },
      { lang: 'id', name: 'Bahasa Indonesia' },
      { lang: 'is', name: 'Íslenska (Iceland)' },
      { lang: 'it', name: 'Italiano (Ý)' },
      { lang: 'ja', name: '日本語' },
      { lang: 'jw', name: 'Basa Jawa (Java)' },
      { lang: 'ka', name: 'ქართული (Georgia)' },
      { lang: 'kk', name: 'Қазақша (Kazakhstan)' },
      { lang: 'km', name: 'ខ្មែរ (Khmer/Campuchia)' },
      { lang: 'kn', name: 'ಕನ್ನಡ (Kannada)' },
      { lang: 'ko', name: '한국어' },
      { lang: 'la', name: 'Latina' },
      { lang: 'lb', name: 'Lëtzebuergesch (Luxembourg)' },
      { lang: 'ln', name: 'Lingála' },
      { lang: 'lo', name: 'ລາວ (Lào)' },
      { lang: 'lt', name: 'Lietuvių (Litva)' },
      { lang: 'lv', name: 'Latviešu (Latvia)' },
      { lang: 'mg', name: 'Malagasy (Madagascar)' },
      { lang: 'mi', name: 'Māori' },
      { lang: 'mk', name: 'Македонски (Macedonia)' },
      { lang: 'ml', name: 'മലയാളം (Malayalam)' },
      { lang: 'mn', name: 'Монгол (Mông Cổ)' },
      { lang: 'mr', name: 'मराठी (Marathi)' },
      { lang: 'ms', name: 'Bahasa Melayu' },
      { lang: 'mt', name: 'Malti (Malta)' },
      { lang: 'my', name: 'မြန်မာ (Myanmar)' },
      { lang: 'ne', name: 'नेपाली (Nepal)' },
      { lang: 'nl', name: 'Nederlands (Hà Lan)' },
      { lang: 'nn', name: 'Norsk Nynorsk' },
      { lang: 'no', name: 'Norsk (Na Uy)' },
      { lang: 'oc', name: 'Occitan' },
      { lang: 'pa', name: 'ਪੰਜਾਬੀ (Punjab)' },
      { lang: 'pl', name: 'Polski (Ba Lan)' },
      { lang: 'ps', name: 'پښتو (Pashto)' },
      { lang: 'pt', name: 'Português (Bồ Đào Nha)' },
      { lang: 'ro', name: 'Română (Romania)' },
      { lang: 'ru', name: 'Русский (Nga)' },
      { lang: 'sa', name: 'संस्कृत (Sanskrit)' },
      { lang: 'sd', name: 'سنڌي (Sindhi)' },
      { lang: 'si', name: 'සිංහල (Sri Lanka)' },
      { lang: 'sk', name: 'Slovenčina (Slovakia)' },
      { lang: 'sl', name: 'Slovenščina (Slovenia)' },
      { lang: 'sn', name: 'ChiShona (Zimbabwe)' },
      { lang: 'so', name: 'Soomaali (Somalia)' },
      { lang: 'sq', name: 'Shqip (Albania)' },
      { lang: 'sr', name: 'Српски (Serbia)' },
      { lang: 'su', name: 'Basa Sunda' },
      { lang: 'sv', name: 'Svenska (Thuỵ Điển)' },
      { lang: 'sw', name: 'Kiswahili (Swahili)' },
      { lang: 'ta', name: 'தமிழ் (Tamil)' },
      { lang: 'te', name: 'తెలుగు (Telugu)' },
      { lang: 'tg', name: 'Тоҷикӣ (Tajikistan)' },
      { lang: 'th', name: 'ไทย (Thái Lan)' },
      { lang: 'tk', name: 'Türkmençe (Turkmenistan)' },
      { lang: 'tl', name: 'Tagalog (Philippines)' },
      { lang: 'tr', name: 'Türkçe (Thổ Nhĩ Kỳ)' },
      { lang: 'tt', name: 'Татар (Tatar)' },
      { lang: 'uk', name: 'Українська (Ukraine)' },
      { lang: 'ur', name: 'اردو (Urdu)' },
      { lang: 'uz', name: "O'zbekcha (Uzbekistan)" },
      { lang: 'vi', name: 'Tiếng Việt' },
      { lang: 'yi', name: 'ייִדיש (Yiddish)' },
      { lang: 'yo', name: 'Yorùbá' },
      { lang: 'zh', name: '中文' },
      { lang: 'yue', name: '廣東話 (Quảng Đông)' },
    ];

    // Xây <option> cho #sourceLang trực tiếp từ WHISPER_LANGS (Cloud STT không cần tải gì
    // trước, nên không còn trạng thái "cần tải"/"đã tải" như trước đây với Vosk). Luôn có thêm
    // 1 <option value="auto"> cố định ở cuối (Whisper tự nhận diện ngôn ngữ khi không gửi
    // 'language' - xem transcribeCloudSegment()). Giữ lại lựa chọn đã lưu của user
    // (pendingSourceLangFromSettings) nếu mã đó có trong danh sách.
    function buildSourceLangOptions() {
      const previousValue = pendingSourceLangFromSettings ?? sourceLangEl.value;
      pendingSourceLangFromSettings = null;
      sourceLangEl.innerHTML = '';
      for (const w of WHISPER_LANGS) {
        const opt = document.createElement('option');
        opt.value = w.lang;
        opt.textContent = w.name;
        sourceLangEl.appendChild(opt);
      }
      const autoOpt = document.createElement('option');
      autoOpt.value = 'auto';
      autoOpt.textContent = '🌐 Tự động nhận diện (Whisper tự nhận diện ngôn ngữ)';
      sourceLangEl.appendChild(autoOpt);

      if ([...sourceLangEl.options].some((o) => o.value === previousValue)) {
        sourceLangEl.value = previousValue;
      }
    }
    buildSourceLangOptions();


    // ===== Onboarding: notification permission -> battery optimization -> mainControlSection.
    // Đã bỏ bước overlay permission vì không còn dùng chữ nổi đè app khác. =====
    const stepNotificationEl = document.getElementById('stepNotification');
    const stepBatteryEl = document.getElementById('stepBattery');
    const mainControlSectionEl = document.getElementById('mainControlSection');

    // Bước pin có thể bị user bấm "Bỏ qua" - lưu lại để không ép hỏi lại mỗi lần mở app
    // (khác bước notification, vốn bắt buộc nên luôn kiểm tra lại thật từ hệ thống).
    const BATTERY_SKIPPED_KEY = 'batteryOptimizationSkipped';

    async function refreshOnboarding() {
      const audioPlugin = getAudioCapturePlugin();
      const notifRes = audioPlugin
        ? await audioPlugin.checkNotificationPermission().catch(() => ({ granted: true }))
        : { granted: true };
      if (!notifRes.granted) {
        stepNotificationEl.style.display = 'block';
        stepBatteryEl.style.display = 'none';
        mainControlSectionEl.style.display = 'none';
        return;
      }
      stepNotificationEl.style.display = 'none';

      const batterySkipped = localStorage.getItem(BATTERY_SKIPPED_KEY) === '1';
      const batteryRes = audioPlugin
        ? await audioPlugin.checkBatteryOptimization().catch(() => ({ ignoringOptimizations: true }))
        : { ignoringOptimizations: true };
      if (!batteryRes.ignoringOptimizations && !batterySkipped) {
        stepBatteryEl.style.display = 'block';
        mainControlSectionEl.style.display = 'none';
        return;
      }
      stepBatteryEl.style.display = 'none';
      mainControlSectionEl.style.display = 'block';
    }

    document.getElementById('grantNotificationBtn').onclick = async () => {
      const plugin = getAudioCapturePlugin();
      if (!plugin) return;
      try {
        const res = await plugin.requestNotificationPermission();
        log('Kết quả xin quyền thông báo: granted=' + res.granted);
        await refreshOnboarding();
      } catch (err) {
        log('LỖI khi xin quyền thông báo: ' + err.message);
      }
    };

    document.getElementById('grantBatteryBtn').onclick = async () => {
      const plugin = getAudioCapturePlugin();
      if (!plugin) return;
      try {
        const res = await plugin.requestIgnoreBatteryOptimizations();
        log('Kết quả xin miễn trừ tối ưu pin: ignoringOptimizations=' + res.ignoringOptimizations);
        await refreshOnboarding();
      } catch (err) {
        log('LỖI khi xin miễn trừ tối ưu pin: ' + err.message);
      }
    };

    document.getElementById('skipBatteryBtn').onclick = async () => {
      localStorage.setItem(BATTERY_SKIPPED_KEY, '1');
      await refreshOnboarding();
    };

    // App quay lại foreground -> kiểm tra lại onboarding để tự chuyển bước.
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) refreshOnboarding();
    });

    // ===== Dịch: groq-relay (openai/gpt-oss-120b, LLM chính, phủ hết ~99 ngôn ngữ Whisper) ->
    // Gemini (gemini-3.5-flash-lite, LLM dự phòng thứ 2, cũng phủ ~29 ngôn ngữ) -> DeepL (chất
    // lượng dịch rất cao cho các ngôn ngữ nó hỗ trợ, đặc biệt các cặp Âu-Âu, nhưng KHÔNG bao
    // phủ hết ~29 ngôn ngữ app đang hỗ trợ) -> Azure (chỉ 3 mã DeepL thiếu: kz/uz/ky) -> cuối
    // cùng mới rơi xuống Google Translate free (endpoint miễn phí, không cần API key, chất
    // lượng thấp nhất, hay bị 429) =====
    let lastTranslated = '';

    // ===== Xác thực THEO NGƯỜI DÙNG thật (Supabase Auth ẩn danh) - THAY THẾ cho chuỗi
    // X-App-Secret ghi cứng cũ (chuỗi đó ai unzip APK cũng đọc được, không phải xác thực thật -
    // xem comment cũ trong migration_rate_limit.sql: "giải pháp triệt để là chuyển sang xác thực
    // THEO NGƯỜI DÙNG thật"). Mỗi lần mở app, nếu chưa có phiên đăng nhập còn hạn,
    // signInAnonymously() để Supabase Auth server cấp 1 access_token (JWT) gắn với 1 user_id ổn
    // định + claim is_anonymous=true. supabase-js TỰ LƯU token này vào localStorage
    // (persistSession bên dưới) nên các lần mở app sau dùng lại đúng user_id cũ (không tạo user
    // mới mỗi lần) và TỰ ĐỘNG refresh khi gần hết hạn (autoRefreshToken). Edge Function
    // (groq-relay) xác minh chữ ký + hạn dùng JWT này qua
    // supabaseAdmin.auth.getUser(token) trước khi xử lý (xem verifyUser() trong
    // index.ts).
    const SUPABASE_URL = 'https://clbddroyrueafygedycy.supabase.co';
    // TODO: điền đúng khoá "anon public" của project (Supabase Dashboard -> Project Settings ->
    // API -> Project API keys -> anon public). Đây là khoá CÔNG KHAI, thiết kế để đặt trong
    // client (app di động/web) - khác hẳn service_role key (tuyệt đối KHÔNG đặt ở client).
    const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNsYmRkcm95cnVlYWZ5Z2VkeWN5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODQzNzM4ODQsImV4cCI6MjA5OTk0OTg4NH0.PmkyB3ZHsKD2dHJBBtMFKGrcmq6mNrBg7ePJLUe8Of8';

    const supabaseAuthClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      auth: {
        persistSession: true,
        storage: window.localStorage,
        autoRefreshToken: true,
        detectSessionInUrl: false,
      },
    });

    // ensureAuthSession(): trả về session hiện có nếu còn hạn, tự đăng nhập ẩn danh nếu chưa có
    // (lần đầu mở app) hoặc phiên cũ đã mất (vd người dùng xoá dữ liệu app). Gộp các lần gọi
    // đồng thời (translateGroq/translateGemini/translateDeepl/translateAzure/
    // transcribeCloudSegment đều gọi hàm này) vào ĐÚNG 1 lần
    // signInAnonymously() thật sự qua biến pendingSignIn - tránh tạo nhiều user ẩn danh khác
    // nhau nếu vài request đầu tiên của phiên app cùng lúc phát hiện "chưa có session".
    //
    // Fix: trước đây nếu signInAnonymously() fail (vd quên bật "Allow anonymous sign-ins" trên
    // Supabase Dashboard, hoặc SUPABASE_ANON_KEY vẫn còn là placeholder chưa điền) thì MỌI câu
    // dịch sau đó đều thử gọi lại signInAnonymously() từ đầu (tốn thêm 1 round-trip mạng + độ
    // trễ cho từng câu, và lỗi bị nuốt êm bởi chuỗi fallback Groq->Gemini->DeepL->Azure->Google
    // free nên không ai để ý app đã tụt xuống tầng dịch thấp nhất). Giờ thêm cooldown: sau 1 lần
    // fail, ghi log LỖI (xem log() ở đầu file) đúng 1 lần và tạm nghỉ
    // AUTH_FAIL_COOLDOWN_MS trước khi thử lại signInAnonymously() lần nữa, thay vì thử lại ngay
    // lập tức mỗi lần gọi.
    const AUTH_FAIL_COOLDOWN_MS = 60_000;
    let pendingSignIn = null;
    let lastAuthFailAt = 0;
    let authFailLogged = false;
    // captchaToken: chỗ cắm sẵn cho Cloudflare Turnstile/hCaptcha nếu sau này bật captcha cho
    // anonymous sign-in trên Supabase Dashboard (khuyến nghị chính thức của Supabase để chống
    // lạm dụng signInAnonymously() - xem README mục "Xác thực"). Mặc định null = không gửi gì,
    // không ảnh hưởng nếu chưa bật captcha phía Supabase.
    let captchaToken = null;
    async function ensureAuthSession() {
      const { data } = await supabaseAuthClient.auth.getSession();
      if (data && data.session && data.session.access_token) return data.session;
      const now = Date.now();
      if (now - lastAuthFailAt < AUTH_FAIL_COOLDOWN_MS) {
        throw new Error('AUTH_ANONYMOUS_COOLDOWN');
      }
      if (!pendingSignIn) {
        const opts = captchaToken ? { options: { captchaToken } } : undefined;
        pendingSignIn = supabaseAuthClient.auth.signInAnonymously(opts).finally(() => {
          pendingSignIn = null;
        });
      }
      const { data: signInData, error } = await pendingSignIn;
      if (error || !signInData || !signInData.session) {
        lastAuthFailAt = now;
        if (!authFailLogged) {
          authFailLogged = true;
          log('LỖI đăng nhập ẩn danh Supabase Auth (kiểm tra: đã bật "Allow anonymous '
            + 'sign-ins" trên Dashboard? đã điền đúng SUPABASE_ANON_KEY thật chưa?): '
            + (error ? error.message : 'không rõ nguyên nhân'));
        }
        throw new Error('AUTH_ANONYMOUS_FAILED' + (error ? ': ' + error.message : ''));
      }
      authFailLogged = false;
      return signInData.session;
    }

    // authHeader(): giá trị sẵn sàng gán thẳng vào headers.Authorization của fetch().
    async function authHeader() {
      const session = await ensureAuthSession();
      return 'Bearer ' + session.access_token;
    }

    // authHeaders(): bản đầy đủ hơn authHeader() - kèm thêm header "apikey". Trước đây khi còn
    // dùng X-App-Secret, request không hề gửi Authorization/apikey mà vẫn chạy được, nên nhiều
    // khả năng verify_jwt đang tắt ở cấp Supabase Function - NHƯNG chưa ai xác nhận thực tế
    // tầng gateway (Kong) của Supabase có tự đòi header "apikey" ở tầng hạ tầng hay không, TRƯỚC
    // KHI request tới được code hàm. Gửi kèm cả 2 header là vô hại (Supabase bỏ qua apikey nếu
    // không cần) và phòng đúng rủi ro đó mà không cần chờ test thực tế trên production.
    async function authHeaders() {
      return { 'Authorization': await authHeader(), 'apikey': SUPABASE_ANON_KEY };
    }

    const GROQ_RELAY_TRANSLATE_URL =
      'https://clbddroyrueafygedycy.supabase.co/functions/v1/groq-relay?op=translate';
    const GROQ_TIMEOUT_MS = 8000;

    // groq-relay giờ có LANG_NAMES đủ ~29 ngôn ngữ (khớp ModelCatalog.CATALOG, xem index.ts) -
    // không còn giới hạn chỉ vi/en/zh nữa. Chỉ còn cắt hậu tố vùng/miền (vd 'zh-CN' -> 'zh')
    // để khớp đúng key trong LANG_NAMES, server cũng tự làm fallback này nhưng cắt sẵn ở đây
    // cho chắc + đỡ phải sửa cả 2 nơi mỗi khi thêm mã mới.
    function normalizeGroqLangCode(targetLang) {
      if (!targetLang) return null;
      return targetLang.split('-')[0];
    }

    // Ngữ cảnh (Hạng mục "dịch tốt hơn"): lưu vài câu NGUỒN gần nhất theo từng cặp
    // (sourceLang, targetLang) để gửi kèm cho CẢ groq-relay lẫn DeepL - giúp model/engine giải
    // quyết đại từ bị lược, thành ngữ nối câu, giữ xưng hô/thuật ngữ nhất quán giữa các câu
    // liên tiếp trong 1 đoạn hội thoại/video, thay vì mỗi câu bị dịch hoàn toàn độc lập như
    // trước. Không dùng chung 1 mảng toàn cục vì nhiều luồng gọi translateText song song với
    // các cặp ngôn ngữ khác nhau (live listen, dịch thủ công) - trộn ngữ cảnh giữa các
    // luồng sẽ gây nhiễu. Đặt tên chung "translationContext" (không còn gắn riêng "groq") vì
    // DeepL cũng đọc/ghi cùng lịch sử này.
    const TRANSLATION_CONTEXT_MAX = 3;
    const translationContextHistory = {};

    function translationContextKey(sourceLang, targetLang) {
      return (sourceLang || '?') + '|' + targetLang;
    }

    function getTranslationContext(sourceLang, targetLang) {
      return translationContextHistory[translationContextKey(sourceLang, targetLang)] || [];
    }

    function pushTranslationContext(sourceLang, targetLang, text) {
      const key = translationContextKey(sourceLang, targetLang);
      const arr = translationContextHistory[key] || (translationContextHistory[key] = []);
      arr.push(text);
      if (arr.length > TRANSLATION_CONTEXT_MAX) arr.shift();
    }

    async function translateGroq(text, targetLang, sourceLang) {
      const langCode = normalizeGroqLangCode(targetLang);
      if (!langCode) throw new Error('groq-relay: thiếu targetLang');

      const context = getTranslationContext(sourceLang, targetLang);

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), GROQ_TIMEOUT_MS);
      let res;
      try {
        res = await fetch(GROQ_RELAY_TRANSLATE_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...(await authHeaders()) },
          body: JSON.stringify({ text, targetLangCode: langCode, context }),
          signal: controller.signal,
        });
      } finally {
        clearTimeout(timeoutId);
      }

      if (!res.ok) {
        const body = await res.text().catch(() => '');
        throw new Error('groq-relay HTTP ' + res.status + (body ? ': ' + body.slice(0, 200) : ''));
      }
      const data = await res.json();
      if (!data.translated) throw new Error('groq-relay: response rỗng');

      // Chỉ lưu vào ngữ cảnh SAU KHI dịch thành công - câu lỗi/rỗng không nên làm nhiễu
      // ngữ cảnh cho các câu dịch sau.
      pushTranslationContext(sourceLang, targetLang, text);

      // Chinese: groq-relay tự thêm Pinyin, gộp vào 1 dòng cho tiện hiển thị overlay
      return data.pinyin ? data.translated + '\n' + data.pinyin : data.translated;
    }

    // ===== Circuit breaker (Hạng mục "chống lỗi"): tránh việc MỖI câu dịch đều phải chờ hết
    // GROQ_TIMEOUT_MS (8s) rồi mới rơi xuống Gemini, trong lúc Groq đang hết quota/sập tạm thời
    // (401/429 hoặc timeout kéo dài liên tục) - rất hay xảy ra khi dùng free-tier. Sau
    // CIRCUIT_FAIL_THRESHOLD lần lỗi LIÊN TIẾP, "mở" breaker: bỏ qua thẳng lệnh gọi Groq trong
    // CIRCUIT_OPEN_MS tiếp theo (không tốn thời gian chờ timeout nữa), rồi tự "đóng" lại (thử
    // gọi Groq bình thường) sau khi hết thời gian đó - không cần khởi động lại app. Bất kỳ lần
    // gọi Groq nào thành công cũng reset breaker về trạng thái đóng (0 lỗi) ngay lập tức, vì
    // thành công nghĩa là Groq đã hoạt động bình thường trở lại.
    const CIRCUIT_FAIL_THRESHOLD = 3;
    const CIRCUIT_OPEN_MS = 60000; // 60s - đủ ngắn để không bỏ lỡ lâu khi Groq hồi phục nhanh
    const groqCircuit = { failCount: 0, openUntil: 0 };
    // ===== Circuit breaker RIÊNG cho Google Translate free (tầng CUỐI CÙNG của chuỗi fallback,
    // xem translateText()) - endpoint KHÔNG chính thức (translate.googleapis.com/translate_a),
    // rate-limit (429) theo IP và có thể mất VÀI PHÚT mới hồi phục (khác hẳn Groq/Gemini/DeepL/
    // Azure là API chính thức, thường chỉ nghẽn tạm vài chục giây). Mở circuit SỚM HƠN (chỉ 2
    // lần lỗi liên tiếp, so với 3 của Groq) và ĐÓNG BĂNG LÂU HƠN NHIỀU (5 phút, so với 60s của
    // Groq) - vì đây là tầng CUỐI, không còn fallback nào sau nó để "đỡ" nếu cứ bắn tiếp vào lúc
    // đang bị chặn (chỉ càng làm IP bị Google giữ chặn lâu hơn), thà chấp nhận vài câu không có
    // bản dịch trong 5 phút còn hơn tự làm nặng thêm rate-limit của chính mình.
    const GOOGLE_FREE_CIRCUIT_FAIL_THRESHOLD = 2;
    const GOOGLE_FREE_CIRCUIT_OPEN_MS = 5 * 60 * 1000;
    const googleFreeCircuit = { failCount: 0, openUntil: 0 };

    function isGoogleFreeCircuitOpen() {
      return Date.now() < googleFreeCircuit.openUntil;
    }

    function recordGoogleFreeSuccess() {
      googleFreeCircuit.failCount = 0;
      googleFreeCircuit.openUntil = 0;
    }

    function recordGoogleFreeFailure() {
      googleFreeCircuit.failCount += 1;
      if (googleFreeCircuit.failCount >= GOOGLE_FREE_CIRCUIT_FAIL_THRESHOLD) {
        googleFreeCircuit.openUntil = Date.now() + GOOGLE_FREE_CIRCUIT_OPEN_MS;
        log('Google Translate free bị rate-limit ' + googleFreeCircuit.failCount + ' lần liên tiếp - ' +
          'tạm ngắt ' + (GOOGLE_FREE_CIRCUIT_OPEN_MS / 60000) + ' phút (đây là tầng dịch cuối cùng, ' +
          'không còn fallback nào khác - các câu trong lúc này sẽ không có bản dịch).');
      }
    }

    function isGroqCircuitOpen() {
      return Date.now() < groqCircuit.openUntil;
    }

    function recordGroqSuccess() {
      groqCircuit.failCount = 0;
      groqCircuit.openUntil = 0;
    }

    function recordGroqFailure() {
      groqCircuit.failCount += 1;
      if (groqCircuit.failCount >= CIRCUIT_FAIL_THRESHOLD) {
        groqCircuit.openUntil = Date.now() + CIRCUIT_OPEN_MS;
        log('Groq lỗi ' + groqCircuit.failCount + ' lần liên tiếp - tạm ngắt Groq ' +
          (CIRCUIT_OPEN_MS / 1000) + 's, chuyển thẳng sang Gemini...');
      }
    }

    // ===== Gemini - tầng dịch LLM dự phòng thứ 2, chen NGAY SAU Groq (trước DeepL). Gemini
    // cũng là LLM như Groq nên phủ được cả ~29 ngôn ngữ app hỗ trợ (dùng chung LANG_NAMES phía
    // server), trong khi DeepL chỉ có ~16/29 mã - đặt Gemini trước DeepL/Azure giữ được chất
    // lượng dịch LLM cho nhiều ngôn ngữ hơn trước khi phải rơi xuống Google Translate free.
    // Cần secret GEMINI_API_KEY set trong Supabase (xem README) - nếu chưa set, server tự trả
    // lỗi SERVER_MISSING_GEMINI_KEY, rơi tiếp xuống DeepL như bình thường, không chặn app.
    const GEMINI_RELAY_TRANSLATE_URL =
      'https://clbddroyrueafygedycy.supabase.co/functions/v1/groq-relay?op=translateGemini';
    const GEMINI_TIMEOUT_MS = 8000;

    async function translateGemini(text, targetLang, sourceLang) {
      const langCode = normalizeGroqLangCode(targetLang); // tái dùng cắt hậu tố vùng/miền
      if (!langCode) throw new Error('Gemini relay: thiếu targetLang');

      const context = getTranslationContext(sourceLang, targetLang);

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), GEMINI_TIMEOUT_MS);
      let res;
      try {
        res = await fetch(GEMINI_RELAY_TRANSLATE_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...(await authHeaders()) },
          body: JSON.stringify({ text, targetLangCode: langCode, context }),
          signal: controller.signal,
        });
      } finally {
        clearTimeout(timeoutId);
      }

      if (!res.ok) {
        const body = await res.text().catch(() => '');
        throw new Error('Gemini relay HTTP ' + res.status + (body ? ': ' + body.slice(0, 200) : ''));
      }
      const data = await res.json();
      if (!data.translated) throw new Error('Gemini relay: response rỗng');

      pushTranslationContext(sourceLang, targetLang, text);

      // Chinese: server tự thêm Pinyin giống op=translate (Groq), gộp vào 1 dòng cho tiện overlay
      return data.pinyin ? data.translated + '\n' + data.pinyin : data.translated;
    }

    // ===== DeepL - tầng dịch chen giữa Groq và Google Translate free. Chất lượng dịch DeepL
    // (đặc biệt các cặp ngôn ngữ Âu-Âu: en/de/fr/es/it/nl/pt/pl...) thường được đánh giá cao
    // hơn cả dịch máy NMT thông thường lẫn nhiều model LLM nhỏ, và free tier 500.000 ký
    // tự/tháng đủ dùng cho lượng dịch phụ đề bình thường. CHỈ dùng làm dự phòng khi Groq lỗi
    // (hết quota Groq/model lỗi) - không thay Groq làm ưu tiên số 1 vì DeepL không phủ hết
    // ~29 ngôn ngữ app hỗ trợ (xem DEEPL_TARGET_LANG_MAP - chỉ ~16/29 mã có mặt, phần còn lại
    // như fa/hi/ka/gu/te/ky/uz/kz/tg/eo/br/ca vẫn phải rơi tiếp xuống Google Translate free).
    const DEEPL_RELAY_TRANSLATE_URL =
      'https://clbddroyrueafygedycy.supabase.co/functions/v1/groq-relay?op=translateDeepl';
    const DEEPL_TIMEOUT_MS = 8000;

    // Mã đích DeepL (viết hoa, có biến thể vùng cho EN/PT theo đúng API DeepL) - chỉ liệt kê
    // các ngôn ngữ DeepL THỰC SỰ hỗ trợ tính đến 2026 (đã xác nhận Việt được thêm giữa 2025).
    // Không đoán mò thêm các ngôn ngữ hiếm (Gujarati, Telugu, Kyrgyz...) vì chưa xác minh được.
    const DEEPL_TARGET_LANG_MAP = {
      vi: 'VI', en: 'EN-US', 'en-in': 'EN-US', zh: 'ZH', ja: 'JA', ko: 'KO',
      ru: 'RU', fr: 'FR', de: 'DE', es: 'ES', pt: 'PT-PT', tr: 'TR',
      it: 'IT', nl: 'NL', uk: 'UK', cs: 'CS', pl: 'PL',
    };
    // Mã nguồn DeepL không có biến thể vùng (khác targetLang) - dùng để gợi ý source_lang,
    // KHÔNG bắt buộc: nếu sourceLang không có trong map này, bỏ qua source_lang, để DeepL tự
    // nhận diện ngôn ngữ nguồn (vẫn hoạt động bình thường, chỉ có thể chậm/kém chính xác hơn
    // 1 chút so với chỉ định thẳng).
    const DEEPL_SOURCE_LANG_MAP = {
      vi: 'VI', en: 'EN', 'en-in': 'EN', zh: 'ZH', ja: 'JA', ko: 'KO',
      ru: 'RU', fr: 'FR', de: 'DE', es: 'ES', pt: 'PT', tr: 'TR',
      it: 'IT', nl: 'NL', uk: 'UK', cs: 'CS', pl: 'PL',
    };

    async function translateDeepl(text, targetLang, sourceLang) {
      const deeplTarget = DEEPL_TARGET_LANG_MAP[targetLang];
      if (!deeplTarget) throw new Error('DeepL không hỗ trợ targetLang=' + targetLang);
      const deeplSource = DEEPL_SOURCE_LANG_MAP[sourceLang]; // có thể undefined -> DeepL tự nhận diện

      // Tái dùng đúng lịch sử ngữ cảnh với Groq (gộp thành 1 đoạn text, đúng định dạng
      // "context" dạng chuỗi của DeepL - khác context dạng mảng câu của groq-relay?op=translate).
      const context = getTranslationContext(sourceLang, targetLang).join(' ');

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), DEEPL_TIMEOUT_MS);
      let res;
      try {
        res = await fetch(DEEPL_RELAY_TRANSLATE_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...(await authHeaders()) },
          body: JSON.stringify({
            text,
            targetLangCode: deeplTarget,
            sourceLangCode: deeplSource,
            context,
          }),
          signal: controller.signal,
        });
      } finally {
        clearTimeout(timeoutId);
      }

      if (!res.ok) {
        const body = await res.text().catch(() => '');
        throw new Error('DeepL relay HTTP ' + res.status + (body ? ': ' + body.slice(0, 200) : ''));
      }
      const data = await res.json();
      if (!data.translated) throw new Error('DeepL relay: response rỗng');

      pushTranslationContext(sourceLang, targetLang, text);

      return data.translated;
    }

    // ===== Azure Translator - tầng chen giữa Groq và Google Translate free, CHỈ dùng riêng
    // cho 3 mã DeepL KHÔNG hỗ trợ: kz (Kazakh), uz (Uzbek), ky (Kyrgyz) - xem
    // AZURE_TARGET_LANG_MAP bên dưới. KHÔNG thay DeepL cho các mã DeepL đã dịch tốt (không cần
    // thêm 1 dependency mới cho thứ đã có sẵn). Free tier F0 của Azure Translator: 2 triệu ký
    // tự/tháng - lớn hơn nhiều DeepL free (500k/tháng), giảm áp lực quota riêng cho 3 mã này
    // khi Groq hết quota. Cần secret AZURE_TRANSLATOR_KEY + AZURE_TRANSLATOR_REGION set trong
    // Supabase (xem README) - nếu chưa set, server tự trả lỗi SERVER_MISSING_AZURE_KEY/REGION,
    // rơi tiếp xuống Google Translate free như bình thường, không chặn app.
    const AZURE_RELAY_TRANSLATE_URL =
      'https://clbddroyrueafygedycy.supabase.co/functions/v1/groq-relay?op=translateAzure';
    const AZURE_TIMEOUT_MS = 8000;

    // Chỉ 3 mã app đang thiếu ở DeepL - KHÔNG mở rộng thêm ra các mã DeepL đã hỗ trợ, tránh 2
    // tầng dịch chồng chéo cho cùng 1 ngôn ngữ mà không giải quyết gap thực tế nào thêm.
    const AZURE_TARGET_LANG_MAP = { kz: 'kk', uz: 'uz', ky: 'ky' };
    const AZURE_SOURCE_LANG_MAP = { kz: 'kk', uz: 'uz', ky: 'ky' };

    async function translateAzure(text, targetLang, sourceLang) {
      const azureTarget = AZURE_TARGET_LANG_MAP[targetLang];
      if (!azureTarget) throw new Error('Azure Translator không hỗ trợ targetLang=' + targetLang + ' (chỉ dùng cho kz/uz/ky)');
      const azureSource = AZURE_SOURCE_LANG_MAP[sourceLang]; // có thể undefined -> Azure tự nhận diện

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), AZURE_TIMEOUT_MS);
      let res;
      try {
        res = await fetch(AZURE_RELAY_TRANSLATE_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...(await authHeaders()) },
          body: JSON.stringify({ text, targetLangCode: azureTarget, sourceLangCode: azureSource }),
          signal: controller.signal,
        });
      } finally {
        clearTimeout(timeoutId);
      }

      if (!res.ok) {
        const body = await res.text().catch(() => '');
        throw new Error('Azure relay HTTP ' + res.status + (body ? ': ' + body.slice(0, 200) : ''));
      }
      const data = await res.json();
      if (!data.translated) throw new Error('Azure relay: response rỗng');

      return data.translated;
    }

    // ===== Whisper Cloud (Groq) - đường DUY NHẤT còn lại để nhận diện giọng nói (đã bỏ Vosk
    // offline). Native (AudioCaptureService.startCloudSttReadLoop) chỉ lo capture + VAD cắt câu,
    // tự đóng gói WAV + base64 rồi bắn sự kiện 'cloudSttSegment' - JS ở đây lo phần mạng (upload
    // lên groq-relay?op=transcribe) và tự đẩy text nhận được vào pipeline dịch/hiển thị/log
    // (pushFinalToBatch). =====
    const GROQ_RELAY_TRANSCRIBE_URL =
      'https://clbddroyrueafygedycy.supabase.co/functions/v1/groq-relay?op=transcribe';
    // Audio dài hơn 1 câu text nhiều - cho thời gian chờ rộng hơn GROQ_TIMEOUT_MS (dịch text).
    const GROQ_STT_TIMEOUT_MS = 20000;

    function base64ToBlob(base64, mimeType) {
      const binary = atob(base64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      return new Blob([bytes], { type: mimeType });
    }

    // sourceLang: bỏ qua (không set 'language') khi 'auto' - Whisper tự nhận diện ngôn ngữ theo
    // nội dung audio khi không được chỉ định trước, giống cách groq-relay?op=translate đã dùng
    // cho targetLang.
    async function transcribeCloudSegment(wavBase64, sourceLang) {
      const blob = base64ToBlob(wavBase64, 'audio/wav');
      const form = new FormData();
      form.append('file', blob, 'segment.wav');
      if (sourceLang && sourceLang !== 'auto') form.append('language', sourceLang);

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), GROQ_STT_TIMEOUT_MS);
      let res;
      try {
        res = await fetch(GROQ_RELAY_TRANSCRIBE_URL, {
          method: 'POST',
          // Không set 'Content-Type' thủ công (FormData tự set kèm boundary đúng) - chỉ thêm
          // header xác thực.
          headers: { ...(await authHeaders()) },
          body: form,
          signal: controller.signal,
        });
      } finally {
        clearTimeout(timeoutId);
      }

      if (!res.ok) {
        const body = await res.text().catch(() => '');
        throw new Error('groq-relay(transcribe) HTTP ' + res.status + (body ? ': ' + body.slice(0, 200) : ''));
      }
      const data = await res.json();
      // language: mã app (vd "vi") do groq-relay tự tra ngược từ tên Whisper trả về (xem
      // WHISPER_NAME_TO_CODE trong index.ts), null nếu Whisper trả tên ngôn ngữ không khớp
      // bảng 29 ngôn ngữ app hỗ trợ HOẶC nếu request đã ép sẵn 1 ngôn ngữ cụ thể (không auto).
      // Trả nguyên object thay vì chỉ text - caller (onCloudSttSegment trong app.module.js)
      // cần field này để gắn detectedLang cho câu ở chế độ auto (sourceLang='auto') - trước đây
      // field này bị bỏ hẳn, luôn coi như "không rõ".
      return { text: (data.text || '').trim(), language: data.language || null };
    }
    // app.module.js (luồng mic) cũng cần gọi Whisper Cloud qua đúng endpoint/timeout/auth này -
    // bắc cầu qua window.__ như translateText/queueTranslate/saveSettings ở trên, tránh viết lại
    // 1 bản riêng (GROQ_RELAY_TRANSCRIBE_URL, GROQ_STT_TIMEOUT_MS, authHeaders, base64ToBlob) dễ
    // lệch nhau.
    window.__transcribeCloudSegment = transcribeCloudSegment;

    // Endpoint free của Google rate-limit (HTTP 429) nếu bắn nhiều request dồn dập -
    // hay gặp khi Whisper Cloud chốt nhiều câu "final" liên tiếp lúc nói nhanh/liên tục.
    // Fix: (1) tự retry có chờ khi gặp 429 (backoff tăng dần 2s/4s/8s - đã kéo dài từ 1s/2s/3s
    // theo góp ý audit, vì endpoint không chính thức này cần nghỉ lâu hơn API chính thức mới hết
    // rate-limit), (2) xếp hàng tuần tự (không gọi song song) riêng cho luồng tự động từ onFinal,
    // để không bao giờ có 2 request cùng lúc, (3) circuit breaker RIÊNG (googleFreeCircuit, xem
    // khai báo phía trên) mở lâu hơn Groq nhiều vì đây là tầng CUỐI, không có gì "đỡ" sau nó.
    async function translateGoogleFree(text, targetLang, retriesLeft = 3) {
      const url = 'https://translate.googleapis.com/translate_a/single'
        + '?client=gtx&sl=auto&tl=' + encodeURIComponent(targetLang)
        + '&dt=t&q=' + encodeURIComponent(text);
      const res = await fetch(url);
      if (res.status === 429 && retriesLeft > 0) {
        const waitMs = Math.pow(2, 4 - retriesLeft) * 1000; // 2s, 4s, 8s
        log('Dịch bị rate-limit (429), thử lại sau ' + waitMs + 'ms...');
        await new Promise((resolve) => setTimeout(resolve, waitMs));
        return translateGoogleFree(text, targetLang, retriesLeft - 1);
      }
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();
      // data[0] là mảng các đoạn [dịch, gốc, ...]
      return data[0].map(seg => seg[0]).join('');
    }

    // ===== Cache câu đã dịch (Hạng mục J) - video dài hay lặp lại câu/cụm từ (lời chào,
    // filler, quảng cáo lặp...) -> cache theo (sourceLang, targetLang, text đã chuẩn hoá) để
    // tránh gọi mạng lại cho câu ĐÃ dịch y hệt trước đó, giảm tải Groq/Google free (đỡ 429
    // hơn) và trả kết quả tức thì cho câu lặp. Lưu vào localStorage để cache sống qua các
    // phiên nghe khác nhau, giới hạn TRANSLATION_CACHE_MAX_ENTRIES để không phình vô hạn -
    // khi đầy, xoá entry cũ nhất theo thứ tự chèn (giống LRU đơn giản, không cần cấu trúc
    // dữ liệu phức tạp vì tần suất truy cập cache thấp, không cần tối ưu tốc độ cao).
    const TRANSLATION_CACHE_KEY = 'atun_translation_cache_v1';
    const TRANSLATION_CACHE_MAX_ENTRIES = 500;
    let translationCache = {};
    try {
      translationCache = JSON.parse(localStorage.getItem(TRANSLATION_CACHE_KEY) || '{}');
    } catch (e) {
      translationCache = {};
    }

    function translationCacheKey(text, sourceLang, targetLang) {
      // Chuẩn hoá nhẹ: trim + gộp khoảng trắng thừa - "Hello  world" và "Hello world" nên
      // dùng chung 1 entry cache. KHÔNG lowercase vì có thể đổi nghĩa/độ trang trọng ở một số
      // ngôn ngữ (vd tên riêng viết hoa) - chấp nhận cache-miss nếu chỉ khác hoa/thường.
      const normalized = text.trim().replace(/\s+/g, ' ');
      return (sourceLang || '?') + '|' + targetLang + '|' + normalized;
    }

    function getCachedTranslation(text, sourceLang, targetLang) {
      const key = translationCacheKey(text, sourceLang, targetLang);
      return Object.prototype.hasOwnProperty.call(translationCache, key)
        ? translationCache[key]
        : null;
    }

    function setCachedTranslation(text, sourceLang, targetLang, translated) {
      const key = translationCacheKey(text, sourceLang, targetLang);
      const isNewKey = !Object.prototype.hasOwnProperty.call(translationCache, key);
      translationCache[key] = translated;

      if (isNewKey) {
        const keys = Object.keys(translationCache);
        if (keys.length > TRANSLATION_CACHE_MAX_ENTRIES) {
          // Object.keys() trả về theo thứ tự chèn (đúng chuẩn ES2015+ cho string key thường) -
          // xoá bớt các entry cũ nhất, giữ lại đúng TRANSLATION_CACHE_MAX_ENTRIES gần nhất.
          const toRemove = keys.length - TRANSLATION_CACHE_MAX_ENTRIES;
          for (let i = 0; i < toRemove; i++) delete translationCache[keys[i]];
        }
      }

      try {
        localStorage.setItem(TRANSLATION_CACHE_KEY, JSON.stringify(translationCache));
      } catch (e) {
        // localStorage đầy (hiếm, vì đã giới hạn 500 entry) - bỏ qua, cache chỉ là tối ưu,
        // không phải chức năng bắt buộc, mất cache không ảnh hưởng tính đúng của app.
      }
    }

    // sourceLang: optional - CHỈ có khi bên gọi biết chắc ngôn ngữ nguồn (vd luồng live từ
    // Whisper Cloud, nơi sourceLangEl.value/detectedLang chính là ngôn ngữ đang nghe) - dùng để
    // groq-relay/Gemini/DeepL/Azure dịch chính xác hơn thay vì phải tự đoán ngôn ngữ nguồn từ
    // nội dung văn bản. Khi không có sourceLang (dịch thủ công/dịch file), các dịch vụ trên vẫn
    // tự nhận diện được (trừ Google Translate free cần 'auto' rõ ràng, đã xử lý riêng bên dưới).
    async function translateText(text, targetLang, sourceLang) {
      const cached = getCachedTranslation(text, sourceLang, targetLang);
      if (cached !== null) return cached;

      let translated;
      try {
        if (isGroqCircuitOpen()) {
          throw new Error('groq-relay: đang tạm ngắt (circuit breaker mở)');
        }
        try {
          translated = await translateGroq(text, targetLang, sourceLang);
          recordGroqSuccess();
        } catch (errGroqAttempt) {
          recordGroqFailure(); // chỉ đếm lỗi khi THẬT SỰ có gọi Groq (không tính lần bị breaker chặn)
          throw errGroqAttempt;
        }
      } catch (errGroq) {
        log('Groq dịch lỗi (' + errGroq.message + '), thử Gemini...');
        try {
          translated = await translateGemini(text, targetLang, sourceLang);
        } catch (errGemini) {
          log('Gemini dịch lỗi (' + errGemini.message + '), thử DeepL...');
          try {
            translated = await translateDeepl(text, targetLang, sourceLang);
          } catch (errDeepl) {
            log('DeepL dịch lỗi (' + errDeepl.message + '), thử Azure Translator...');
            try {
              translated = await translateAzure(text, targetLang, sourceLang);
            } catch (errAzure) {
              log('Azure dịch lỗi (' + errAzure.message + '), fallback Google Translate free...');
              if (isGoogleFreeCircuitOpen()) {
                throw new Error('Google Translate free: đang tạm ngắt (circuit breaker mở) - ' + errAzure.message);
              }
              try {
                translated = await translateGoogleFree(text, targetLang);
                recordGoogleFreeSuccess();
              } catch (errGoogleFree) {
                recordGoogleFreeFailure();
                throw errGoogleFree;
              }
            }
          }
        }
      }
      setCachedTranslation(text, sourceLang, targetLang, translated);
      return translated;
    }
    // app.module.js (ES module, KHÔNG chung scope với file này - xem eslint.config.js) cần gọi
    // lại đúng logic dịch (Groq -> Gemini -> DeepL -> Azure -> Google Translate free + cache) cho
    // luồng "system"/"mic" của nó - bắc cầu qua window.__ thay vì viết lại 1 bản riêng dễ lệch
    // hành vi (thứ tự fallback, cache key...) mỗi khi 1 bên sửa mà bên kia quên theo.
    window.__translateText = translateText;

    // Hàng đợi tuần tự: mỗi lần chỉ chạy 1 tác vụ dịch, tác vụ sau đợi tác vụ trước
    // xong (kể cả khi lỗi) rồi mới chạy - tránh nhiều request cùng lúc gây 429.
    let translateQueue = Promise.resolve();
    function queueTranslate(fn) {
      const run = () => fn();
      translateQueue = translateQueue.then(run, run);
      return translateQueue;
    }
    // Cùng lý do như window.__translateText ở trên - app.module.js xếp batch dịch của NÓ vào
    // CHUNG 1 hàng đợi tuần tự với app.js (tránh 2 hàng đợi riêng bắn request dịch cùng lúc gây
    // 429 y như lý do queueTranslate() tồn tại).
    window.__queueTranslate = queueTranslate;

    // ===== Nhật ký dịch: thay cho chữ nổi overlay. Lưu vào localStorage để không mất khi
    // tắt/mở lại app, giới hạn 200 dòng gần nhất để tránh phình bộ nhớ vô hạn. =====
    const TRANSLATION_LOG_KEY = 'atun_translation_log_v1';
    const MAX_TRANSLATION_LOG_ENTRIES = 200;
    const translationLogEl = document.getElementById('translationLog');
    let translationLog = [];

    function loadTranslationLog() {
      try {
        translationLog = JSON.parse(localStorage.getItem(TRANSLATION_LOG_KEY) || '[]');
      } catch (e) {
        translationLog = [];
      }
      // Nhật ký lưu từ bản cũ hơn có thể chưa có trường ts (epoch ms) - gán tạm ts tăng dần
      // theo thứ tự đã lưu để giữ đúng thứ tự thời gian khi hiển thị.
      let needsResave = false;
      let fallbackTs = Date.now() - translationLog.length * 1000;
      translationLog = translationLog.map((e) => {
        if (typeof e.ts !== 'number') {
          needsResave = true;
          fallbackTs += 1000;
          return { ...e, ts: fallbackTs };
        }
        return e;
      });
      if (needsResave) {
        localStorage.setItem(TRANSLATION_LOG_KEY, JSON.stringify(translationLog));
      }
      renderTranslationLog();
    }

    function renderTranslationLog() {
      if (translationLog.length === 0) {
        translationLogEl.innerHTML = '<div style="color:#999; font-size:13px;">Chưa có câu nào được dịch.</div>';
        return;
      }
      // Mới nhất lên trên cho dễ theo dõi khi đang nghe liên tục.
      translationLogEl.innerHTML = translationLog.slice().reverse().map((entry) => `
        <div style="padding:6px 0; border-bottom:1px solid #e0e0e0;">
          <div style="font-size:11px; color:#999;">${entry.time}</div>
          <div style="font-size:13px; color:#666;">${escapeHtml(entry.original)}</div>
          <div style="font-weight:500;">${escapeHtml(entry.translated)}</div>
        </div>
      `).join('');
    }

    function escapeHtml(text) {
      const div = document.createElement('div');
      div.textContent = text;
      return div.innerHTML;
    }

    function addTranslationLogEntry(original, translated) {
      // ts: epoch ms - dùng để tính timestamp .srt (thời điểm câu này xuất hiện, tính từ
      // câu đầu tiên trong log). time: chuỗi giờ hiển thị trong UI, giữ như cũ.
      translationLog.push({ time: new Date().toLocaleTimeString(), ts: Date.now(), original, translated });
      if (translationLog.length > MAX_TRANSLATION_LOG_ENTRIES) {
        translationLog = translationLog.slice(-MAX_TRANSLATION_LOG_ENTRIES);
      }
      localStorage.setItem(TRANSLATION_LOG_KEY, JSON.stringify(translationLog));
      renderTranslationLog();
    }

    document.getElementById('clearLogBtn').onclick = () => {
      translationLog = [];
      localStorage.removeItem(TRANSLATION_LOG_KEY);
      renderTranslationLog();
      log('Đã xoá nhật ký dịch.');
    };

    // ===== Xuất nhật ký dịch ra file (.txt / .srt) =====
    // HTML đã ghi chú tính năng này từ trước ("xuất ra file .txt để lưu/chia sẻ") nhưng chưa ai
    // thật sự viết - chỉ có nút "Xoá". Thêm ở đây, dùng lại đúng "translationLog" + trường "ts"
    // (epoch ms) đã lưu sẵn cho từng dòng.
    function downloadTextFile(fileName, content, mimeType = 'text/plain;charset=utf-8') {
      // Fix (báo lỗi thật trên máy: log ghi "Đã xuất..." nhưng KHÔNG có file nào xuất hiện) -
      // trước đây tưởng Capacitor WebView (android.webkit.WebView) hỗ trợ tải qua Blob + <a
      // download> giống trình duyệt thường - THỰC TẾ KHÔNG: blob: URL không tạo ra request mạng
      // nào cả (mọi thứ xử lý ngay trong trang), nên WebView không có gì để DownloadListener bắt
      // được - a.click() chạy nhưng không có chuyện gì xảy ra, và code không có cách nào tự biết
      // để báo lỗi (đó là lý do log vẫn ghi "đã xuất" dù thực tế thất bại). Giờ khi chạy TRONG
      // app native, dùng đúng cách Capacitor khuyến nghị: Filesystem.writeFile() ghi file thật
      // vào bộ nhớ cache của app rồi Share.share() mở màn hình chia sẻ/lưu chuẩn của Android (Lưu
      // vào Files, gửi qua Zalo/Messenger/Gmail...) - người dùng tự chọn nơi lưu ở đó. Khi chạy
      // NGOÀI app (vd mở thẳng index.html bằng trình duyệt máy tính lúc dev/test) thì
      // Capacitor.isNativePlatform() = false, vẫn dùng lại đúng cách Blob + <a download> cũ (hoạt
      // động bình thường trên trình duyệt thật, chỉ hỏng riêng trong WebView của app).
      //
      // CHƯA test được trên máy Android thật (cần thêm @capacitor/filesystem + @capacitor/share
      // vào package.json rồi build lại mới có plugin - xem README mục "Việc còn phải tự làm").
      if (window.Capacitor?.isNativePlatform?.()) {
        const Filesystem = window.Capacitor?.Plugins?.Filesystem;
        const Share = window.Capacitor?.Plugins?.Share;
        if (Filesystem && Share) {
          Filesystem.writeFile({ path: fileName, data: content, directory: 'CACHE', encoding: 'utf8' })
            .then((result) => Share.share({ title: fileName, url: result.uri, dialogTitle: `Lưu/chia sẻ ${fileName}` }))
            .then(() => log(`Đã xuất "${fileName}" - chọn nơi lưu hoặc ứng dụng để chia sẻ ở màn hình vừa mở.`))
            .catch((err) => log(`LỖI khi xuất file "${fileName}": ${err.message}`));
          return;
        }
        // Thiếu plugin Filesystem/Share (build cũ chưa cài lại, chưa chạy `npm install` +
        // `npx cap sync`) - rơi xuống cách Blob+<a> bên dưới còn hơn không làm gì, dù biết trước
        // là sẽ không ăn thua trong WebView thật.
        log(`Thiếu plugin Filesystem/Share - thử cách tải cũ (có thể không hoạt động trong app).`);
      }
      const blob = new Blob([content], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      log(`Đã xuất "${fileName}" (trình duyệt tự lưu vào thư mục Downloads).`);
    }

    function timestampedFileName(ext) {
      // Tên file có ngày giờ để không tự ghi đè lần xuất trước nếu user xuất nhiều lần trong
      // ngày - dùng giờ local (không phải UTC) để khớp với "time" hiển thị trong log.
      const d = new Date();
      const pad = (n) => String(n).padStart(2, '0');
      return `nhat-ky-dich-${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}.${ext}`;
    }

    document.getElementById('exportLogTxtBtn').onclick = () => {
      if (translationLog.length === 0) {
        log('Nhật ký dịch đang trống, không có gì để xuất.');
        return;
      }
      // Theo đúng thứ tự thời gian (cũ -> mới) cho dễ đọc lại như 1 bản ghi hội thoại, KHÔNG
      // đảo ngược như khi hiển thị trong app (renderTranslationLog() đảo ngược chỉ để mới nhất
      // lên đầu màn hình cho dễ theo dõi lúc đang nghe, không nên áp dụng cho file xuất ra).
      const lines = translationLog.map((e) => `[${e.time}]\n${e.original}\n${e.translated}\n`);
      downloadTextFile(timestampedFileName('txt'), lines.join('\n'));
    };

    // Định dạng thời gian SRT chuẩn: HH:MM:SS,mmm - "ms" là số mili-giây TƯƠNG ĐỐI tính từ mốc
    // 0 (không phải giờ thật trong ngày - .srt luôn tính từ lúc bắt đầu media/phiên).
    function formatSrtTimestamp(ms) {
      const clamped = Math.max(0, Math.round(ms));
      const totalSeconds = Math.floor(clamped / 1000);
      const millis = clamped % 1000;
      const hours = Math.floor(totalSeconds / 3600);
      const minutes = Math.floor((totalSeconds % 3600) / 60);
      const seconds = totalSeconds % 60;
      const pad2 = (n) => String(n).padStart(2, '0');
      const pad3 = (n) => String(n).padStart(3, '0');
      return `${pad2(hours)}:${pad2(minutes)}:${pad2(seconds)},${pad3(millis)}`;
    }

    const SRT_DEFAULT_DURATION_MS = 4000; // độ dài hiện mặc định cho 1 dòng phụ đề nếu không có dòng kế tiếp để tính

    document.getElementById('exportLogSrtBtn').onclick = () => {
      if (translationLog.length === 0) {
        log('Nhật ký dịch đang trống, không có gì để xuất.');
        return;
      }
      // .srt tính mốc thời gian TƯƠNG ĐỐI so với câu ĐẦU TIÊN trong log (coi như "thời điểm bắt
      // đầu phiên nghe = 0:00") - đúng như comment đã ghi từ trước lúc thêm trường "ts"
      // (addTranslationLogEntry() phía trên). Thời gian hiện mỗi dòng = tới khi câu kế tiếp xuất
      // hiện, cap tối đa SRT_DEFAULT_DURATION_MS để tránh 1 dòng bị "treo" quá lâu nếu 2 câu cách
      // nhau rất xa (vd người dùng tạm dừng nói lâu giữa chừng).
      const firstTs = translationLog[0].ts;
      const blocks = translationLog.map((entry, i) => {
        const startMs = entry.ts - firstTs;
        const nextTs = i + 1 < translationLog.length ? translationLog[i + 1].ts - firstTs : null;
        const endMs = nextTs !== null
          ? Math.min(nextTs, startMs + SRT_DEFAULT_DURATION_MS)
          : startMs + SRT_DEFAULT_DURATION_MS;
        // Dịch hiện song ngữ trong 1 khối phụ đề (gốc + dịch) - dễ đối chiếu lại hơn là chỉ có
        // 1 trong 2, và không cần tạo 2 file .srt riêng.
        return `${i + 1}\n${formatSrtTimestamp(startMs)} --> ${formatSrtTimestamp(endMs)}\n${entry.original}\n${entry.translated}\n`;
      });
      downloadTextFile(timestampedFileName('srt'), blocks.join('\n'), 'application/x-subrip;charset=utf-8');
    };

    loadTranslationLog();
    window.__addTranslationLogEntry = addTranslationLogEntry;

    // ===== Hàng đợi thử lại khi STT/dịch lỗi giữa chừng (mất mạng, timeout, lỗi tạm thời từ
    // groq-relay...) =====
    // TRƯỚC ĐÂY: 1 đoạn lỗi (dù chỉ do rớt mạng thoáng qua) là MẤT TRẮNG câu đó vĩnh viễn - chỉ
    // log lỗi ra console debug (moduleLog), người dùng không có cách nào lấy lại câu đã nói. Hàng
    // đợi này lưu lại các đoạn lỗi (cả bước nhận dạng giọng nói LẪN bước dịch - 2 điểm lỗi tách
    // biệt, xem onCloudSttSegment/flushFinalBatch trong app.module.js), tự thử lại định kỳ + khi
    // mạng có lại, và cho phép bấm thử lại thủ công. Lưu vào localStorage để còn sống sót qua cả
    // việc tắt/mở lại app giữa lúc mất mạng dài, không chỉ transient trong phiên hiện tại.
    const PENDING_QUEUE_KEY = 'atun_pending_retry_v1';
    // Cap kích thước hàng đợi - mục loại 'stt' mang theo cả audio base64 (vài chục KB/đoạn), mất
    // mạng càng lâu càng dễ phình to; localStorage có giới hạn dung lượng theo origin (thường vài
    // MB tuỳ WebView) - không để 1 đợt mất mạng dài làm hỏng luôn cả tính năng lưu nhật ký dịch
    // (localStorage dùng CHUNG budget cho cả 2 key).
    const MAX_PENDING_ITEMS = 20;
    const MAX_RETRY_ATTEMPTS = 6; // quá số này coi như lỗi vĩnh viễn (vd audio hỏng thật) - bỏ hẳn, không thử vô hạn
    const RETRY_INTERVAL_MS = 15000;
    // Cap nhat 2026-09-12: RATE_LIMIT_EXCEEDED (đã chạm trần NGÀY phía groq-relay, xem
    // RATE_LIMIT_PER_DAY/RATE_LIMIT_PER_DAY_PER_USER trong index.ts) là lỗi KHÁC HẲN mất mạng/
    // lỗi tạm thời - nó sẽ tái diễn ĐỀU ĐẶN mỗi lần thử cho tới khi qua ngày mới, không phải
    // "thoáng qua rồi hết". Trước đây lỗi này bị gộp chung xử lý với lỗi mạng: dội lại mỗi 15s,
    // hết MAX_RETRY_ATTEMPTS (90s) là ÂM THẦM bỏ hẳn đoạn đó - người dùng chỉ thấy phụ đề tự
    // nhiên biến mất, không có thông báo nào. Giờ phát hiện riêng lỗi này để (1) không tính vào
    // MAX_RETRY_ATTEMPTS (không bỏ đoạn oan chỉ vì đợi qua ngày mới), (2) giãn cách thử lại xa
    // hơn hẳn (khỏi dội request vô ích lúc chắc chắn vẫn còn bị chặn), (3) hiện rõ banner cho
    // người dùng biết thay vì im lặng.
    const DAILY_LIMIT_RETRY_MS = 30 * 60 * 1000; // 30 phút - đỡ dội request vô ích khi chắc chắn còn bị chặn
    // Dài hơn DAILY_LIMIT_RETRY_MS 1 chút để cờ không tắt ngay trước lần thử lại kế tiếp (tránh
    // banner nhấp nháy qua lại giữa 2 trạng thái ngay trước mỗi lần chạy runRetryQueue()).
    const DAILY_LIMIT_COOLDOWN_MS = DAILY_LIMIT_RETRY_MS + 5 * 60 * 1000;

    // Cap nhat 2026-09-12 (audit đợt 3, #2+#4): bản vá RATE_LIMIT_EXCEEDED ở trên chỉ nhận diện
    // ĐÚNG 1 chuỗi lỗi, bỏ sót GROQ_CIRCUIT_OPEN (breaker phía SERVER cho Groq, xem
    // GROQ_CIRCUIT_OPEN_MS=60s trong pure.ts) - lỗi này CŨNG chắc chắn tái diễn đều đặn (mọi lần
    // thử lại trong lúc breaker còn mở đều dính y hệt), nhưng trước đây rơi vào nhánh else, bị
    // tính vào MAX_RETRY_ATTEMPTS và sau ~90s bị bỏ hẳn trong im lặng - đúng con đường bug gốc,
    // chỉ khác tên lỗi kích hoạt. Khác với RATE_LIMIT_EXCEEDED (chỉ transcribeCloudSegment('stt')
    // mới có thể dính, vì đây là op DUY NHẤT gọi thẳng Groq relay không qua chuỗi fallback - xem
    // translateText(): các item 'translate' đã tự kiểm tra isGroqCircuitOpen() phía CLIENT rồi
    // rớt xuống Gemini/DeepL/Azure/Google free trước khi lỗi này có cơ hội lọt tới hàng đợi này),
    // cooldown NGẮN hơn nhiều - khớp thời gian breaker server tự đóng (60s), không phải 30 phút.
    const GROQ_CIRCUIT_RETRY_MS = 70 * 1000; // hơi dài hơn GROQ_CIRCUIT_OPEN_MS=60s (pure.ts) 1 chút để chắc breaker đã đóng lại trước khi thử
    const GROQ_CIRCUIT_COOLDOWN_MS = GROQ_CIRCUIT_RETRY_MS + 10 * 1000;

    // Nhận diện lỗi "chắc chắn còn tái diễn" (khác lỗi mạng/timeout thoáng qua) - trả về mã lý do
    // hoặc null nếu là lỗi tạm thời bình thường (vẫn xử lý theo MAX_RETRY_ATTEMPTS như cũ).
    function classifyBlockingError(err) {
      const msg = typeof err?.message === 'string' ? err.message : '';
      if (msg.includes('RATE_LIMIT_EXCEEDED')) return 'dailyLimit';
      if (msg.includes('GROQ_CIRCUIT_OPEN')) return 'groqCircuit';
      return null;
    }

    function retryDelayForReason(reason) {
      return reason === 'dailyLimit' ? DAILY_LIMIT_RETRY_MS : GROQ_CIRCUIT_RETRY_MS;
    }
    function cooldownForReason(reason) {
      return reason === 'dailyLimit' ? DAILY_LIMIT_COOLDOWN_MS : GROQ_CIRCUIT_COOLDOWN_MS;
    }

    // Fix audit #4: TRƯỚC ĐÂY dùng 1 cờ dailyLimitHitAt TOÀN CỤC dùng chung cho mọi item trong
    // hàng đợi - nhưng RATE_LIMIT_PER_DAY_PER_USER khác nhau rất xa giữa các op (transcribe 150
    // vs translate 1000/ngày/user, xem index.ts). Chỉ cần 1 đoạn 'stt' chạm trần riêng của nó là
    // TOÀN BỘ hàng đợi, kể cả các mục 'translate' còn cách trần rất xa, bị áp cooldown 30 phút
    // một cách oan uổng. Giờ tách trạng thái chặn theo TỪNG loại item ('stt'/'translate' - đây là
    // 2 loại DUY NHẤT tồn tại trong hàng đợi, xem __enqueueFailedSttSegment/__enqueueFailedTranslateBatch)
    // - mỗi loại tự chờ đúng cooldown của lý do khiến NÓ bị chặn, không ảnh hưởng loại kia.
    const blockState = {
      stt: { reason: null, hitAt: 0 },
      translate: { reason: null, hitAt: 0 },
    };

    function isTypeBlockedNow(type) {
      const b = blockState[type];
      return !!(b && b.reason && (Date.now() - b.hitAt) < cooldownForReason(b.reason));
    }

    const pendingRetryBarEl = document.getElementById('pendingRetryBar');
    const pendingRetryTextEl = document.getElementById('pendingRetryText');

    let pendingQueue = [];
    let retryTimer = null;
    let retryInFlight = false;

    function loadPendingQueue() {
      try {
        pendingQueue = JSON.parse(localStorage.getItem(PENDING_QUEUE_KEY) || '[]');
      } catch (e) {
        pendingQueue = [];
      }
    }

    function savePendingQueue() {
      try {
        localStorage.setItem(PENDING_QUEUE_KEY, JSON.stringify(pendingQueue));
      } catch (e) {
        // QuotaExceededError hiếm khi xảy ra (đã cap MAX_PENDING_ITEMS) nhưng không để việc ghi
        // hàng đợi thất bại làm crash cả luồng xử lý audio đang chạy.
        log('Không lưu được hàng đợi thử lại vào localStorage: ' + e.message);
      }
    }

    function renderPendingBadge() {
      if (pendingQueue.length === 0) {
        pendingRetryBarEl.style.display = 'none';
        // Hết hàng đợi thì cũng không còn gì để chờ - reset cả 2 loại (fix #4: mỗi loại 1 trạng
        // thái riêng, không còn 1 cờ toàn cục chung).
        blockState.stt.reason = null;
        blockState.translate.reason = null;
        return;
      }
      pendingRetryBarEl.style.display = 'flex';
      const typesPresent = [...new Set(pendingQueue.map((p) => p.type))];
      // Dọn trạng thái chặn của loại KHÔNG còn mục nào trong hàng đợi (vd tất cả mục 'stt' đã
      // xong/bị bỏ, chỉ còn 'translate') - tránh giữ cờ chặn "ma" không còn ý nghĩa.
      Object.keys(blockState).forEach((t) => {
        if (!typesPresent.includes(t)) blockState[t].reason = null;
      });
      const blockedTypes = typesPresent.filter((t) => isTypeBlockedNow(t));
      if (blockedTypes.length === 0) {
        pendingRetryTextEl.textContent = `🔄 ${pendingQueue.length} đoạn đang chờ thử lại`;
        return;
      }
      // Chỉ hiện banner "chặn" khi TẤT CẢ loại còn lại trong hàng đợi đều đang bị chặn - nếu 1
      // loại vẫn đang thử lại bình thường (vd 'translate' trong khi 'stt' đang chờ cooldown),
      // ưu tiên hiện trạng thái "đang thử lại" chung để không gây hiểu lầm là mọi thứ đều đứng im.
      if (blockedTypes.length < typesPresent.length) {
        pendingRetryTextEl.textContent = `🔄 ${pendingQueue.length} đoạn đang chờ thử lại`;
        return;
      }
      const anyDailyLimit = blockedTypes.some((t) => blockState[t].reason === 'dailyLimit');
      pendingRetryTextEl.textContent = anyDailyLimit
        ? `⛔ Đã đạt giới hạn dịch/nhận dạng hôm nay - ${pendingQueue.length} đoạn đang chờ, tự thử lại sau`
        : `⏳ Groq đang tạm ngắt (quá tải) - ${pendingQueue.length} đoạn đang chờ, tự thử lại sau`;
    }

    function enqueuePending(item) {
      pendingQueue.push({
        id: Date.now() + '-' + Math.random().toString(36).slice(2),
        attempts: 0,
        createdAt: Date.now(),
        ...item,
      });
      if (pendingQueue.length > MAX_PENDING_ITEMS) {
        // Bỏ mục CŨ NHẤT (không phải mới nhất vừa thêm) - càng cũ càng có khả năng đã lệch xa
        // ngữ cảnh cuộc hội thoại đang diễn ra so với mục mới hơn.
        const dropped = pendingQueue.length - MAX_PENDING_ITEMS;
        pendingQueue.splice(0, dropped);
        log(`Hàng đợi thử lại đã đầy (tối đa ${MAX_PENDING_ITEMS}) - bỏ ${dropped} đoạn cũ nhất, không thử lại nữa.`);
      }
      savePendingQueue();
      renderPendingBadge();
      scheduleRetry();
    }

    function scheduleRetry() {
      if (retryTimer || pendingQueue.length === 0) return;
      // Fix #4: chỉ giãn cách thử lại xa nếu MỌI loại còn trong hàng đợi đều đang bị chặn - nếu
      // còn ít nhất 1 loại không bị chặn (vd 'translate' rảnh trong khi 'stt' đang chờ cooldown),
      // vẫn chạy đúng nhịp RETRY_INTERVAL_MS bình thường (runRetryQueue() tự bỏ qua mục đang bị
      // chặn của loại kia, xem bên dưới - không dội request vô ích cho loại đó).
      const typesPresent = [...new Set(pendingQueue.map((p) => p.type))];
      const allBlocked = typesPresent.length > 0 && typesPresent.every((t) => isTypeBlockedNow(t));
      let delay = RETRY_INTERVAL_MS;
      if (allBlocked) {
        // Đợi đúng bằng cooldown NGẮN NHẤT còn lại trong số các loại đang chặn (không phải loại
        // dài nhất) - để không trễ hơn cần thiết khi loại đó đã sẵn sàng thử lại trước.
        delay = Math.min(
          ...typesPresent.map((t) => {
            const b = blockState[t];
            const remain = cooldownForReason(b.reason) - (Date.now() - b.hitAt);
            return Math.max(remain, 1000);
          })
        );
      }
      retryTimer = setTimeout(() => {
        retryTimer = null;
        runRetryQueue();
      }, delay);
    }

    async function retryOneItem(item) {
      const isMic = item.channel === 'mic';
      if (item.type === 'stt') {
        const { text, language: whisperDetectedLang } = await transcribeCloudSegment(item.wavBase64, item.sourceLang);
        if (!text) return; // Whisper trả rỗng (im lặng/nhiễu thật) - coi như xử lý xong, không phải lỗi
        // Lưu ý: nếu lúc thử lại thành công mà người dùng ĐÃ bấm "Dừng nghe" từ lâu, câu này vẫn
        // được đẩy vào nhật ký dịch + có thể thoáng hiện lại caption cũ - chấp nhận đánh đổi này
        // (ưu tiên "không mất câu" hơn "caption luôn khớp đúng trạng thái đang nghe/không nghe"
        // - trường hợp thực tế cũng hiếm vì hàng đợi tự chạy ngay khi có mạng, không đợi user mở
        // lại app).
        if (isMic) {
          // Luồng mic (chế độ hội thoại 2 chiều) - đi vào batch RIÊNG (pushMicFinalToBatch), dịch
          // ngược hướng vi -> ngôn ngữ đối phương, KHÔNG phải window.__pushFinalToBatch ở dưới
          // (đó là batch của luồng system/đối phương).
          window.__pushMicFinalToBatch?.(text);
        } else {
          const detectedLang = item.sourceLang === 'auto' ? whisperDetectedLang : item.sourceLang;
          window.__pushFinalToBatch?.(text, detectedLang);
        }
      } else if (item.type === 'translate') {
        if (isMic) {
          await window.__retryMicTranslateBatch?.(item.texts);
        } else {
          await window.__retryTranslateBatch?.(item.texts, item.effectiveSourceLang);
        }
      }
    }

    async function runRetryQueue() {
      if (retryInFlight || pendingQueue.length === 0) return;
      retryInFlight = true;
      // Chạy TUẦN TỰ (không song song) để giữ đúng thứ tự hội thoại khi phục hồi hàng loạt đoạn
      // sau 1 đợt mất mạng dài - nhiều đoạn trả về không đúng thứ tự sẽ làm log/phụ đề rối.
      const queueSnapshot = pendingQueue.slice();
      for (const item of queueSnapshot) {
        // Item có thể đã bị xoá khỏi pendingQueue thật (vd đã đạt MAX_RETRY_ATTEMPTS ở 1 vòng
        // lặp trước đó trong CÙNG lần chạy này) - kiểm tra lại còn tồn tại không.
        if (!pendingQueue.find((p) => p.id === item.id)) continue;
        // Fix #4: loại của item này đang bị chặn (chưa hết cooldown riêng của nó) - bỏ qua HẲN,
        // không thử/không tính attempt, để dành lượt cho các item loại KHÁC không bị chặn.
        if (isTypeBlockedNow(item.type)) continue;
        try {
          await retryOneItem(item);
          pendingQueue = pendingQueue.filter((p) => p.id !== item.id);
        } catch (err) {
          const real = pendingQueue.find((p) => p.id === item.id);
          if (real) {
            const reason = classifyBlockingError(err);
            if (reason) {
              // Lỗi "chắc chắn còn tái diễn" (đã chạm trần NGÀY hoặc Groq circuit breaker phía
              // server đang mở) - không tính vào MAX_RETRY_ATTEMPTS, khác bản chất với lỗi mạng
              // tạm thời. Chỉ đánh dấu chặn cho ĐÚNG loại item này (fix #4 - không còn ảnh hưởng
              // loại kia như cờ toàn cục cũ).
              blockState[item.type] = { reason, hitAt: Date.now() };
              log(
                reason === 'dailyLimit'
                  ? `Đã đạt giới hạn dịch/nhận dạng hôm nay (${item.type}) - tạm dừng thử dồn dập, sẽ tự thử lại sau.`
                  : `Groq đang tạm ngắt (circuit breaker phía server, ${item.type}) - đợi ~${Math.round(retryDelayForReason(reason) / 1000)}s rồi thử lại.`
              );
            } else {
              real.attempts += 1;
              if (real.attempts >= MAX_RETRY_ATTEMPTS) {
                log(`Đoạn thử lại đã lỗi ${MAX_RETRY_ATTEMPTS} lần liên tiếp (${item.type}) - bỏ hẳn, không thử nữa: ${err.message}`);
                pendingQueue = pendingQueue.filter((p) => p.id !== item.id);
              }
            }
          }
        }
        savePendingQueue();
        renderPendingBadge();
      }
      retryInFlight = false;
      if (pendingQueue.length > 0) scheduleRetry(); // vẫn còn lỗi (mới hoặc cũ) - hẹn đợt sau
    }

    // Chạy lại ngay khi có mạng trở lại (nhanh hơn chờ hết RETRY_INTERVAL_MS) - sự kiện 'online'
    // của window phản ánh đúng trạng thái mạng thật trong Capacitor WebView, không chỉ mô phỏng
    // network của trình duyệt desktop.
    window.addEventListener('online', () => {
      if (pendingQueue.length > 0) {
        log('Mạng đã có lại - thử lại ngay các đoạn đang chờ.');
        runRetryQueue();
      }
    });

    document.getElementById('retryNowBtn').onclick = () => runRetryQueue();

    loadPendingQueue();
    renderPendingBadge();
    if (pendingQueue.length > 0) scheduleRetry(); // còn tồn đọng từ phiên trước (vừa mở lại app)

    // API cho app.module.js gọi vào khi STT/dịch lỗi (theo đúng convention window.__ đã dùng
    // cho addTranslationLogEntry ở trên) - xem onCloudSttSegment/flushFinalBatch/flushMicFinalBatch.
    // channel: 'mic'|'system'|undefined - xem retryOneItem() ở trên để biết cách dùng.
    window.__enqueueFailedSttSegment = (wavBase64, sourceLang, channel) => enqueuePending({ type: 'stt', wavBase64, sourceLang, channel });
    window.__enqueueFailedTranslateBatch = (texts, effectiveSourceLang, channel) => enqueuePending({ type: 'translate', texts, effectiveSourceLang, channel });

    // ===== Phát video từ link dán vào, ngay trong app (iframe embed chính chủ YouTube,
    // KHÔNG phải scraping InnerTube). Hỗ trợ các dạng link phổ biến: watch?v=, youtu.be/,
    // shorts/, embed/, và link live (/live/VIDEOID). =====
    function extractYoutubeVideoId(input) {
      const trimmed = input.trim();
      // Link dạng watch?v=, youtu.be/, embed/, shorts/, live/, hoặc chỉ dán thẳng video ID (11 ký tự).
      const patterns = [
        /(?:youtube\.com\/watch\?v=|youtube\.com\/live\/|youtube\.com\/shorts\/|youtube\.com\/embed\/|youtu\.be\/)([A-Za-z0-9_-]{11})/,
        /^([A-Za-z0-9_-]{11})$/,
      ];
      for (const re of patterns) {
        const match = trimmed.match(re);
        if (match) return match[1];
      }
      return null;
    }

    const videoUrlInputEl = document.getElementById('videoUrlInput');
    const videoPlayerContainerEl = document.getElementById('videoPlayerContainer');
    const videoStageEl = document.getElementById('videoStage');
    const videoVolumeEl = document.getElementById('videoVolume');
    const videoVolumeLabelEl = document.getElementById('videoVolumeLabel');

    (function restoreVideoVolume() {
      const s = loadSettings();
      videoVolumeEl.value = typeof s.videoVolume === 'number' ? s.videoVolume : 100;
      videoVolumeLabelEl.textContent = videoVolumeEl.value + '%';
    })();

    let ytPlayer = null;
    let ytApiReady = false;

    // Fix (lỗi thật: bấm "Phát" khung video hiện nhưng trắng tinh, không log): index.html nạp
    // iframe_api (đồng bộ) -> supabase.js (đồng bộ, tải mạng) -> app.js. iframe_api tự tải
    // tiếp www-widgetapi.js bất đồng bộ và gọi window.onYouTubeIframeAPIReady() NGAY khi
    // xong - nếu xong TRƯỚC khi app.js chạy tới đây (dễ xảy ra vì supabase.js chen giữa) thì
    // callback gọi vào hàm CHƯA tồn tại và bị bỏ lỡ vĩnh viễn -> ytApiReady mãi false -> bấm
    // "Phát" chỉ xếp pendingVideoId rồi không làm gì (iframe gốc chưa có src nên trắng).
    // Cách sửa: không phụ thuộc riêng cờ callback, luôn hỏi thẳng window.YT.Player.
    function isYtApiLoaded() {
      return !!(window.YT && typeof window.YT.Player === 'function');
    }
    if (isYtApiLoaded()) ytApiReady = true;

    // Log panel mặc định ẩn nên lỗi phát video trước đây vô hình - hiện thông báo ngay dưới ô
    // dán link (tự tạo bằng JS, không đổi index.html).
    let videoStatusEl = null;
    function showVideoStatus(msg, isError) {
      if (!videoStatusEl) {
        videoStatusEl = document.createElement('div');
        videoStatusEl.style.cssText = 'font-size:13px; margin-top:6px;';
        videoUrlInputEl.parentElement.insertAdjacentElement('afterend', videoStatusEl);
      }
      videoStatusEl.style.color = isError ? '#c62828' : '#666';
      videoStatusEl.textContent = msg || '';
    }

    let ytApiPollTimer = null;
    let ytApiScriptRetried = false;
    // Chờ API sẵn sàng tối đa ~12s (kiểm tra mỗi 300ms); giữa chừng nạp lại iframe_api 1 lần
    // (idempotent - script tự bỏ qua nếu đã tải) phòng lần nạp đầu bị lỗi mạng.
    function waitForYtApi() {
      if (ytApiPollTimer) return;
      const startedAt = Date.now();
      ytApiPollTimer = setInterval(() => {
        if (isYtApiLoaded()) {
          clearInterval(ytApiPollTimer); ytApiPollTimer = null;
          ytApiReady = true;
          if (pendingVideoId) {
            const v = pendingVideoId; pendingVideoId = null;
            showVideoStatus('');
            startYoutubePlayer(v);
          }
          return;
        }
        const waited = Date.now() - startedAt;
        if (waited > 4000 && !ytApiScriptRetried) {
          ytApiScriptRetried = true;
          const sc = document.createElement('script');
          sc.src = 'https://www.youtube.com/iframe_api';
          sc.onerror = () => log('Nạp lại iframe_api YouTube thất bại (lỗi mạng/bị chặn).');
          document.head.appendChild(sc);
        }
        if (waited > 12000) {
          clearInterval(ytApiPollTimer); ytApiPollTimer = null;
          pendingVideoId = null;
          showVideoStatus('Không tải được trình phát YouTube (kiểm tra mạng, hoặc thiết bị đang chặn youtube.com). Thử bấm Phát lại.', true);
          log('Hết thời gian chờ YouTube IFrame API (12s).');
        }
      }, 300);
    }
    // Fix (lỗi thật trên máy: "ytPlayer.loadVideoById is not a function") - new YT.Player(...)
    // trả về object NGAY LẬP TỨC nhưng các hàm loadVideoById()/setVolume()/stopVideo() CHƯA TỒN
    // TẠI trên object đó cho tới khi sự kiện onReady bắn ra (bắt tay postMessage với iframe con
    // xong - có thể mất 0.5-2s tuỳ mạng/máy). ytPlayer khác null KHÔNG có nghĩa là dùng được
    // ngay - phải chờ đúng cờ này.
    let ytPlayerReady = false;
    // videoId bấm "Phát" TRƯỚC KHI script API tải xong - hiếm, chỉ có thể xảy ra trong khoảng
    // rất ngắn ngay lúc mới mở trang.
    let pendingVideoId = null;
    // videoId bấm "Phát" (đổi video) TRONG LÚC player đã được tạo (ytPlayer khác null) NHƯNG
    // CHƯA kịp bắn onReady - khác hẳn pendingVideoId ở trên (đó là chờ TẢI SCRIPT API, cái này là
    // chờ PLAYER SẴN SÀNG, có thể xảy ra thường xuyên hơn nếu bấm "Phát" lại nhanh).
    let pendingVideoIdForPlayer = null;

    window.onYouTubeIframeAPIReady = () => {
      ytApiReady = true;
      if (pendingVideoId) {
        const videoId = pendingVideoId;
        pendingVideoId = null;
        showVideoStatus('');
        startYoutubePlayer(videoId);
      }
    };

    // Nghi vấn (chưa chắc, cần log [YT] để xác nhận): khung iframe YouTube trắng tinh cho tới khi
    // có sự kiện làm WebView vẽ lại toàn bộ (vd: hộp thoại xin quyền ghi màn hình/micro lúc bấm
    // "Bắt đầu nghe" làm Activity pause/resume) -> video vốn đã tải nhưng lớp vẽ của iframe không
    // được cập nhật (lỗi compositing hay gặp của WebView trên 1 số máy Android). Cách chữa an
    // toàn: ép vẽ lại iframe vài lần sau khi tạo player + mỗi khi app quay lại foreground.
    function forceVideoRepaint() {
      const f = videoStageEl.querySelector('iframe');
      if (!f) return;
      f.style.opacity = '0.99';
      f.style.transform = 'translateZ(0)';
      requestAnimationFrame(() => { f.style.opacity = ''; });
    }
    function scheduleVideoRepaints() {
      [300, 1000, 2500, 5000].forEach((ms) => setTimeout(forceVideoRepaint, ms));
    }
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) { forceVideoRepaint(); setTimeout(forceVideoRepaint, 500); }
    });

    // Watchdog: onReady không bắn sau 6s (iframe trắng/không tải được) -> ghi log chẩn đoán
    // (src iframe thật) và thử 1 lần lại bằng youtube-nocookie.com. Thất bại nữa -> báo lỗi
    // rõ ràng ra màn hình thay vì im lặng.
    let ytEmbedHost = null;
    let ytWatchdog = null;
    let ytFallbackTried = false;
    function armYtWatchdog(videoId) {
      clearTimeout(ytWatchdog);
      ytWatchdog = setTimeout(() => {
        if (ytPlayerReady) return;
        const f = videoStageEl.querySelector('iframe');
        log('[YT] 6s chưa onReady. iframe src=' + (f ? f.src : '(không có iframe)'));
        if (!ytFallbackTried) {
          ytFallbackTried = true;
          ytEmbedHost = 'https://www.youtube-nocookie.com';
          log('[YT] Thử lại bằng youtube-nocookie.com');
          rebuildYtPlayer(videoId);
        } else {
          showVideoStatus('Không tải được khung video YouTube trong app (xem log [YT]). Có thể thiết bị/WebView chặn nhúng.', true);
        }
      }, 6000);
    }
    function rebuildYtPlayer(videoId) {
      try { if (ytPlayer && ytPlayer.destroy) ytPlayer.destroy(); } catch (e) { log('[YT] destroy lỗi: ' + e); }
      ytPlayer = null;
      ytPlayerReady = false;
      if (!document.getElementById('videoPlayerFrame')) {
        const d = document.createElement('div');
        d.id = 'videoPlayerFrame';
        videoStageEl.insertBefore(d, videoStageEl.firstChild);
      }
      startYoutubePlayer(videoId);
    }

    function startYoutubePlayer(videoId) {
      if (ytPlayer && ytPlayerReady) {
        // Player đã tồn tại VÀ đã sẵn sàng (từ lần phát trước, kể cả sau khi đã "Dừng video") -
        // chỉ đổi video thay vì tạo lại player mới (tạo lại sẽ nháy/tải lại toàn bộ iframe, chậm
        // hơn hẳn).
        ytPlayer.loadVideoById(videoId);
        ytPlayer.setVolume(Number(videoVolumeEl.value));
        scheduleVideoRepaints();
        return;
      }
      if (ytPlayer && !ytPlayerReady) {
        // Player đã được tạo (từ 1 lần bấm "Phát" trước đó) nhưng CHƯA kịp bắn onReady - xếp
        // video này vào hàng đợi, onReady bên dưới sẽ tự load nó khi xong. KHÔNG gọi thẳng
        // loadVideoById() ở đây - đúng nguyên nhân gây lỗi "is not a function".
        pendingVideoIdForPlayer = videoId;
        return;
      }
      // new YT.Player(...) THAY HẲN phần tử <iframe id="videoPlayerFrame"> gốc trong index.html
      // bằng iframe riêng của nó (hành vi chuẩn của API này, áp dụng cho cả phần tử là iframe
      // hay div) - xem fix ở listener 'fullscreenchange' bên dưới (không còn dùng
      // videoPlayerFrameEl nữa vì lý do này).
      //
      // cc_load_policy=0: xin YouTube KHÔNG tự bật mặc định phụ đề CC gốc (tránh đè/rối với
      // phụ đề dịch của app - 2 lớp chữ chồng lên nhau nếu để CC gốc bật). Đây LÀ tham số đúng
      // theo tài liệu chính thức của YouTube (0 = không tự bật, không có tham số "buộc tắt
      // hẳn"), NHƯNG có 2 giới hạn KHÔNG thể fix bằng code phía app:
      // 1) YouTube nhiều lần bị báo là không tôn trọng tuyệt đối cc_load_policy=0 trên embed
      //    (đặc biệt bản mobile/app WebView) - có lúc vẫn tự bật lại tuỳ phiên bản player phía
      //    YouTube, ngoài tầm kiểm soát của app.
      // 2) Nếu video gốc có phụ đề "cứng" (burned-in / hard-sub - chữ được ghi thẳng vào từng
      //    khung hình lúc dựng video) thì đó là PIXEL của chính video, không phải track CC thật
      //    - không có tham số URL hay API nào của YouTube tắt được.
      log('[YT] Tạo player (host=' + (ytEmbedHost || 'youtube.com') + ', origin=' + location.origin + ')');
      const ytOpts = {
        width: '100%',
        height: 200, // ghi đè lại lúc fullscreen bằng CSS #videoStage:fullscreen iframe - xem style.css
        videoId,
        playerVars: { autoplay: 1, playsinline: 1, cc_load_policy: 0, origin: location.origin },
        events: {
          onStateChange: (e) => log('[YT] state=' + e.data),
          onReady: (e) => {
            clearTimeout(ytWatchdog);
            log('[YT] onReady OK');
            scheduleVideoRepaints();
            ytPlayerReady = true;
            e.target.setVolume(Number(videoVolumeEl.value));
            if (pendingVideoIdForPlayer) {
              const v = pendingVideoIdForPlayer;
              pendingVideoIdForPlayer = null;
              e.target.loadVideoById(v);
            }
          },
          // Video lỗi (ID sai/riêng tư/chặn nhúng...) thì onReady KHÔNG BAO GIỜ bắn cho video đó
          // - nếu không báo gì, người dùng chỉ thấy khung video đen im lìm, không hiểu vì sao.
          // Mã lỗi theo tài liệu YouTube: 2=tham số videoId sai định dạng, 5=lỗi HTML5 player,
          // 100=video không tồn tại/đã xoá, 101/150=chủ video chặn nhúng ở nơi khác.
          onError: (e) => {
            const messages = {
              2: 'ID video không hợp lệ.',
              5: 'Lỗi trình phát HTML5 của YouTube.',
              100: 'Video không tồn tại hoặc đã bị xoá.',
              101: 'Chủ video chặn không cho nhúng vào nơi khác.',
              150: 'Chủ video chặn không cho nhúng vào nơi khác.',
              153: 'Lỗi cấu hình trình phát (YouTube không nhận được nguồn nhúng hợp lệ).',
            };
            const errMsg = messages[e.data] || ('mã ' + e.data);
            log('Lỗi phát video YouTube: ' + errMsg);
            showVideoStatus('Lỗi phát video: ' + errMsg + (e.data === 153 ? ' (YouTube từ chối nhúng vì thiếu thông tin nguồn - xem hướng dẫn)' : ''), true);
          },
        },
      };
      if (ytEmbedHost) ytOpts.host = ytEmbedHost;
      // Phòng thủ: nếu vì lý do nào đó phần tử đích vẫn là <iframe> (index.html cũ) thì đổi thành
      // <div> trước - YT.Player chỉ nạp video khi đích là div (xem chú thích ở index.html).
      const ytTarget = document.getElementById('videoPlayerFrame');
      if (ytTarget && ytTarget.tagName === 'IFRAME') {
        const d = document.createElement('div');
        d.id = 'videoPlayerFrame';
        ytTarget.replaceWith(d);
      }
      ytPlayer = new YT.Player('videoPlayerFrame', ytOpts);
      const ytFrame = videoStageEl.querySelector('iframe');
      if (ytFrame) { ytFrame.style.border = 'none'; ytFrame.style.borderRadius = '8px'; ytFrame.style.display = 'block'; }
      armYtWatchdog(videoId);
      scheduleVideoRepaints();
    }

    document.getElementById('playVideoBtn').onclick = () => {
      const videoId = extractYoutubeVideoId(videoUrlInputEl.value);
      if (!videoId) {
        log('Không nhận ra link/ID video YouTube hợp lệ.');
        return;
      }
      videoPlayerContainerEl.style.display = 'block';
      showVideoStatus('');
      if (ytApiReady || isYtApiLoaded()) {
        ytApiReady = true;
        startYoutubePlayer(videoId);
      } else {
        // Script YouTube IFrame API chưa sẵn sàng - chờ qua onYouTubeIframeAPIReady() HOẶC
        // vòng kiểm tra waitForYtApi() (cái sau mới cứu được trường hợp callback đã bị bỏ lỡ).
        pendingVideoId = videoId;
        showVideoStatus('Đang tải trình phát YouTube...', false);
        log('Đang tải trình phát YouTube, sẽ phát ngay khi xong...');
        waitForYtApi();
      }
      log('Đang phát video "' + videoId + '" trong app. Nếu dùng "Bắt audio hệ thống", '
        + 'nhiều khả năng sẽ bắt được audio này (khác app YouTube ngoài, có thể bị chặn capture).');
    };

    document.getElementById('stopVideoBtn').onclick = () => {
      // stopVideo() thay vì destroy() - GIỮ LẠI player để lần "Phát" sau chỉ cần loadVideoById()
      // (nhanh hơn, không tải lại toàn bộ iframe YouTube từ đầu). Chỉ gọi khi đã ready - xem
      // comment ở khai báo ytPlayerReady phía trên.
      if (ytPlayer && ytPlayerReady) {
        ytPlayer.stopVideo();
      }
      videoPlayerContainerEl.style.display = 'none';
      document.getElementById('inVideoCaption').style.display = 'none';
      log('Đã dừng video trong app.');
    };

    videoVolumeEl.oninput = () => {
      videoVolumeLabelEl.textContent = videoVolumeEl.value + '%';
      if (ytPlayer && ytPlayerReady) {
        ytPlayer.setVolume(Number(videoVolumeEl.value));
      }
      saveSettings({ videoVolume: Number(videoVolumeEl.value) });
    };

    // ===== Phóng to toàn màn hình - fullscreen videoStageEl (gồm iframe + phụ đề dịch,
    // KHÔNG gồm nút "Dừng video" - xem cấu trúc HTML), KHÔNG fullscreen mỗi iframe. Nút
    // fullscreen riêng của chính YouTube (trong iframe) chỉ fullscreen được mỗi iframe - phụ
    // đề (nằm NGOÀI iframe, không thể chèn vào trong vì iframe cross-origin) sẽ biến mất lúc
    // đó. fullscreenchange bên dưới BẮT mọi trường hợp fullscreen (kể cả tự YouTube gọi) rồi
    // tự chuyển hướng sang fullscreen videoStageEl thay vào - nhờ vậy dù bấm nút của YouTube
    // hay nút "Phóng to" của app, phụ đề vẫn luôn hiện.
    //
    // Đồng thời khoá xoay màn hình sang ngang khi vào fullscreen: nếu không, điện thoại vẫn ở
    // chiều dọc trong lúc video 16:9 fullscreen theo khung dọc đó -> video chỉ lấp được 1 dải
    // ngang mỏng ở giữa màn hình, 2 mảng đen lớn phía trên/dưới.
    //
    // BUG đã sửa: trước đây chỉ gọi screen.orientation.lock('landscape') (Web Screen
    // Orientation API) - API này KHÔNG hoạt động trong Android WebView (nơi Capacitor chạy
    // JS, khác Chrome/trình duyệt thật), luôn ném lỗi (thường "NotSupportedError" hoặc
    // "SecurityError") ngay khi gọi -> catch() nuốt lỗi âm thầm, video fullscreen không bao
    // giờ tự xoay ngang, chỉ lấp đầy khung dọc hẹp như mô tả ở trên. Giờ ưu tiên gọi plugin
    // native ScreenOrientationPlugin (khoá thật ở tầng Activity Android qua
    // requestedOrientation - luôn hoạt động, không phụ thuộc WebView có hỗ trợ Web API hay
    // không); vẫn giữ screen.orientation.lock() làm fallback khi KHÔNG chạy trong app native
    // (vd mở thẳng index.html bằng trình duyệt máy tính để test) - lúc đó không có plugin,
    // nhiều khả năng trình duyệt desktop vẫn không hỗ trợ nhưng không sao, không hỏng gì. =====
    function nativeOrientationPlugin() {
      return window.Capacitor?.Plugins?.ScreenOrientation || null;
    }

    function lockLandscape() {
      const p = nativeOrientationPlugin();
      if (p) {
        return p.lock({ orientation: 'landscape' }).catch(() => {
          // Không nên xảy ra (native luôn hỗ trợ) - nhưng vẫn bọc catch cho chắc, không để
          // lỗi ở đây làm hỏng luôn cả fullscreen.
        });
      }
      return Promise.resolve(screen.orientation?.lock?.('landscape').catch(() => {
        // Không chạy trong app native VÀ trình duyệt không hỗ trợ khoá xoay - vẫn fullscreen
        // bình thường, chỉ là người dùng phải tự xoay ngang điện thoại thủ công.
      }));
    }

    function unlockOrientation() {
      const p = nativeOrientationPlugin();
      if (p) {
        p.unlock().catch(() => {});
        return;
      }
      screen.orientation?.unlock?.();
    }

    function enterVideoFullscreen() {
      return videoStageEl.requestFullscreen?.().then(() => lockLandscape());
    }

    document.getElementById('videoFullscreenBtn').onclick = () => {
      enterVideoFullscreen()?.catch((err) => {
        log('Không phóng to được: ' + err.message);
      });
    };

    // Nút "Thu nhỏ" - chỉ hiện lúc fullscreen (xem CSS #videoStage:fullscreen ở trên). Thoát
    // fullscreen tường minh thay vì bắt user tự tìm nút fullscreen gốc của trình duyệt/cử chỉ
    // back - fullscreenchange bên dưới tự lo mở khoá xoay màn hình lại.
    document.getElementById('videoExitFullscreenBtn').onclick = () => {
      document.exitFullscreen?.().catch(() => {});
    };

    document.addEventListener('fullscreenchange', () => {
      // Fix (thêm YT.Player để chỉnh âm lượng video - xem startYoutubePlayer()): YT.Player THAY
      // HẲN phần tử <iframe id="videoPlayerFrame"> gốc bằng iframe mới của nó, nên so sánh trực
      // tiếp với biến videoPlayerFrameEl (tham chiếu node CŨ, không còn gắn vào trang sau khi bị
      // thay) sẽ luôn sai. Kiểm tra bằng quan hệ cha-con với videoStageEl thay vào đó - đúng bất
      // kể iframe con hiện tại là node nào.
      if (document.fullscreenElement && videoStageEl.contains(document.fullscreenElement)
          && document.fullscreenElement !== videoStageEl) {
        // YouTube tự gọi fullscreen trên CHÍNH iframe (bấm nút fullscreen của YouTube, không
        // phải nút "Phóng to" của app) - thoát ra rồi tự fullscreen lại đúng videoStageEl để
        // phụ đề không bị mất. Gọi requestFullscreen() NGAY trong handler này (cùng chuỗi sự
        // kiện do người dùng bấm) nên trình duyệt vẫn cho phép, không cần thêm cử chỉ chạm nào.
        document.exitFullscreen().then(() => {
          enterVideoFullscreen()?.catch(() => {});
        }).catch(() => {});
      } else if (!document.fullscreenElement) {
        // Thoát fullscreen (bấm nút thu nhỏ, bấm back, v.v.) - mở khoá xoay màn hình lại, trả
        // quyền xoay tự do về cho toàn app (không riêng gì lúc xem video).
        unlockOrientation();
      }
      // Vào/thoát fullscreen đổi hẳn kích thước #videoStage -> áp lại width/max-height khung
      // phụ đề theo đúng bộ cài đặt (thường/toàn màn hình) tương ứng. applyCaptionSettings()
      // sống ở <script type="module"> khác (dưới xa), không cùng scope với listener này (script
      // thường) - gọi qua window.__applyCaptionSettings đã expose (giống các window.__xxx khác
      // trong file, vd window.__addTranslationLogEntry).
      window.__applyCaptionSettings?.();
    });

    document.getElementById('translateBtn').onclick = async () => {
      const text = document.getElementById('srcText').value.trim();
      const targetLang = targetLangEl.value;
      const resultEl = document.getElementById('result');
      if (!text) {
        log('Chưa nhập văn bản.');
        return;
      }
      resultEl.textContent = 'Đang dịch...';
      try {
        const translated = await translateText(text, targetLang);
        lastTranslated = translated;
        resultEl.textContent = translated;
        addTranslationLogEntry(text, translated);
        log('Dịch xong (' + targetLang + ').');
      } catch (err) {
        resultEl.textContent = '';
        log('LỖI khi dịch: ' + err.message);
      }
    };

    // ===== Dịch file văn bản: cắt theo đoạn (dòng trống) để mỗi lần gọi API không quá dài
    // (endpoint Google Translate free giới hạn độ dài query), cắt cứng nếu 1 đoạn tự nó
    // đã dài hơn giới hạn. Dịch TUẦN TỰ qua queueTranslate - dùng chung hàng đợi với luồng
    // nghe live để không bắn 2 request Google Translate cùng lúc gây 429. =====
    const MAX_TRANSLATE_CHUNK_CHARS = 1800;

    function chunkTextForTranslate(text, maxLen) {
      const paragraphs = text.split(/\n\s*\n/);
      const chunks = [];
      let current = '';
      for (const p of paragraphs) {
        const candidate = current ? current + '\n\n' + p : p;
        if (candidate.length > maxLen && current) {
          chunks.push(current);
          current = p;
        } else {
          current = candidate;
        }
        while (current.length > maxLen) {
          chunks.push(current.slice(0, maxLen));
          current = current.slice(maxLen);
        }
      }
      if (current) chunks.push(current);
      return chunks;
    }

    let lastTranslatedFile = null; // { name, content } - giữ để nút "Tải file đã dịch" dùng

    document.getElementById('translateFileBtn').onclick = async () => {
      const fileInput = document.getElementById('srcFile');
      const statusEl = document.getElementById('fileTranslateStatus');
      const downloadBtn = document.getElementById('downloadTranslatedFileBtn');
      const resultEl = document.getElementById('result');
      const file = fileInput.files[0];
      if (!file) {
        log('Chưa chọn file để dịch.');
        return;
      }
      const targetLang = targetLangEl.value;
      downloadBtn.style.display = 'none';
      statusEl.textContent = 'Đang đọc file...';
      try {
        const content = await file.text();
        if (!content.trim()) {
          statusEl.textContent = 'File rỗng, không có gì để dịch.';
          return;
        }
        const chunks = chunkTextForTranslate(content, MAX_TRANSLATE_CHUNK_CHARS);
        const translatedChunks = [];
        for (let i = 0; i < chunks.length; i++) {
          statusEl.textContent = `Đang dịch phần ${i + 1}/${chunks.length}...`;
          const translated = await queueTranslate(() => translateText(chunks[i], targetLang));
          translatedChunks.push(translated);
        }
        const fullTranslated = translatedChunks.join('\n\n');
        lastTranslatedFile = { name: file.name, content: fullTranslated };

        resultEl.textContent = fullTranslated.length > 800
          ? fullTranslated.slice(0, 800) + '\n… (xem đầy đủ trong file tải về)'
          : fullTranslated;
        statusEl.textContent = `Đã dịch xong "${file.name}" (${chunks.length} phần).`;
        downloadBtn.style.display = 'inline-block';
        addTranslationLogEntry(
          '[File: ' + file.name + ']',
          'Đã dịch xong (' + chunks.length + ' phần) - bấm "Tải file đã dịch" để lưu.'
        );
        log('Dịch file "' + file.name + '" xong (' + chunks.length + ' phần).');
      } catch (err) {
        statusEl.textContent = '';
        log('LỖI khi dịch file: ' + err.message);
      }
    };

    document.getElementById('downloadTranslatedFileBtn').onclick = () => {
      if (!lastTranslatedFile) return;
      const dotIndex = lastTranslatedFile.name.lastIndexOf('.');
      const base = dotIndex > 0 ? lastTranslatedFile.name.slice(0, dotIndex) : lastTranslatedFile.name;
      const ext = dotIndex > 0 ? lastTranslatedFile.name.slice(dotIndex) : '.txt';
      const fileName = base + '-dich' + ext;
      // Fix (cùng lỗi y hệt nút xuất nhật ký ở trên - xem comment trong downloadTextFile()):
      // trước đây tự lặp lại code Blob+<a download> riêng ở đây, giờ dùng chung 1 hàm để chỉ cần
      // sửa 1 chỗ khi cách "tải file" đổi (đã đổi sang Filesystem+Share cho app native).
      downloadTextFile(fileName, lastTranslatedFile.content);
    };

    // Log ngay khi trang load để biết Capacitor có sẵn sàng từ đầu không
    window.addEventListener('load', () => {
      log('Trang đã load xong.');
      if (typeof Capacitor !== 'undefined') {
        log('Capacitor object OK. Plugins: ' + Object.keys(Capacitor.Plugins || {}).join(', '));
      } else {
        log('Capacitor CHƯA có ở thời điểm load - có thể app không chạy qua Capacitor WebView.');
      }
      refreshOnboarding();
    });
