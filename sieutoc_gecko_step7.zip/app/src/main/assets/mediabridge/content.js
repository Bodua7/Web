// Ban Gecko cua mediaHookScript trong BrowserActivity.kt - GIU NGUYEN logic gan listener, chi
// doi cach bao ve app: thay AndroidMediaBridge.onPlay()/onPause()/onError() (addJavascriptInterface,
// khong co o GeckoView) bang browser.runtime.sendNativeMessage() (API chuan cua WebExtension,
// duoc GeckoView nhan qua WebExtension.MessageDelegate ben phia Kotlin - xem
// GeckoEngine.attachMediaBridge()).
(function () {
  if (window.__sieutocMediaHooked) return;
  window.__sieutocMediaHooked = true;

  // Phai khop CHINH XAC voi hang so MEDIA_BRIDGE_NATIVE_APP trong GeckoEngine.kt - day la "dia
  // chi" de app nhan dung message, doi 1 ben ma khong doi ben kia se lam mat ket noi hoan toan.
  var NATIVE_APP = "sieutoc";

  function send(message) {
    try {
      browser.runtime.sendNativeMessage(NATIVE_APP, message);
    } catch (e) {
      // Bo qua neu app chua dang ky message delegate (vd extension moi cai, chua kip attach) -
      // khong lam vo trang web vi 1 loi o day.
    }
  }

  function hook(el) {
    if (!el || el.__sieutocHooked) return;
    el.__sieutocHooked = true;
    el.addEventListener("play", function () {
      send({ type: "play" });
    });
    el.addEventListener("pause", function () {
      send({ type: "pause" });
    });
    el.addEventListener("ended", function () {
      send({ type: "pause" });
    });
    el.addEventListener("error", function () {
      var err = el.error;
      // Ma loi chuan cua the <video>/<audio>: 1=ABORTED, 2=NETWORK, 3=DECODE, 4=SRC_NOT_SUPPORTED
      // - y het comment trong mediaHookScript ban WebView, xem onWebMediaError() de biet cach
      // dien giai tung ma.
      var code = err ? err.code : -1;
      var msg = err && err.message ? err.message : "";
      var src = el.currentSrc || el.src || "";
      send({
        type: "error",
        detail: JSON.stringify({ code: code, message: msg, src: src, tag: el.tagName }),
      });
    });
  }

  document.querySelectorAll("video,audio").forEach(hook);
  var mo = new MutationObserver(function (mutations) {
    mutations.forEach(function (m) {
      m.addedNodes.forEach(function (node) {
        if (!(node instanceof Element)) return;
        if (node.tagName === "VIDEO" || node.tagName === "AUDIO") hook(node);
        if (node.querySelectorAll) node.querySelectorAll("video,audio").forEach(hook);
      });
    });
  });
  mo.observe(document.documentElement, { childList: true, subtree: true });
})();
