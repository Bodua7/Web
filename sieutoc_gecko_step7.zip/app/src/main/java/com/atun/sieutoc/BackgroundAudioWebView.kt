package com.atun.sieutoc

import android.content.Context
import android.view.View
import android.webkit.WebView

/**
 * WebView tuỳ biến để tiếp tục giải mã audio khi màn hình bị TẮT (khoá máy) trong lúc đang phát
 * video/audio.
 *
 * VÌ SAO CẦN LỚP NÀY (xem log lỗi thực tế build 1.7.8 - "trang báo pause" đúng ngay lúc khoá
 * máy): khi cửa sổ (Window) chứa WebView bị hệ thống báo là không còn hiển thị (tắt màn hình),
 * Android gọi View.onWindowVisibilityChanged() xuống WebView - và tầng Chromium bên trong coi
 * đây là tín hiệu "ngừng render", kéo theo dừng luôn giải mã audio của thẻ <video>/<audio> ở tầng
 * NATIVE (không phải do JS trang tự pause - script chặn 'visibilitychange'/'pagehide' ở
 * BrowserActivity không đụng tới được tầng này vì nó xảy ra dưới cả JS).
 *
 * Samsung Internet ("Background play"), Herond, Firefox Android (add-on "Video Background Play
 * Fix")... đều cùng dùng chung 1 nhân Chromium như WebView và giải quyết bằng đúng cách này: khi
 * đang thật sự có media phát, báo ngược lại cho Chromium rằng cửa sổ vẫn VISIBLE, để nó không
 * dừng giải mã.
 *
 * CHỈ bật cờ [keepAliveWhenHidden] đúng lúc tab này có media đang phát thật (do
 * BrowserActivity#refreshMediaFocusState bật/tắt theo trạng thái thực tế) - nếu bật tràn lan cả
 * lúc không phát gì thì Chromium vẫn tưởng đang hiển thị nên tiếp tục render/tốn pin vô ích khi
 * màn hình tắt.
 *
 * KHÔNG áp dụng khi visibility == View.GONE: đó là lúc BrowserActivity#switchTab tự ẩn tab không
 * active (View.GONE ở cấp View, không phải cấp Window) - trường hợp này khác hẳn "màn hình tắt",
 * để nguyên hành vi mặc định, tránh giữ giải mã cho 1 tab người dùng đã chủ động rời khỏi.
 */
class BackgroundAudioWebView(context: Context) : WebView(context) {

    var keepAliveWhenHidden: Boolean = false

    override fun onWindowVisibilityChanged(visibility: Int) {
        if (keepAliveWhenHidden && visibility != View.GONE) {
            super.onWindowVisibilityChanged(View.VISIBLE)
        } else {
            super.onWindowVisibilityChanged(visibility)
        }
    }
}
