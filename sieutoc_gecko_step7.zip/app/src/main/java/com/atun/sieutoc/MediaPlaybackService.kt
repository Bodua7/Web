package com.atun.sieutoc

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.IBinder

/**
 * Foreground service báo cho Android biết app đang phát media THẬT (qua MediaSession chuẩn),
 * để hệ thống không tạm dừng WebView khi màn hình tắt hoặc chuyển app khác.
 *
 * Trước đây chỉ gọi startForeground() suông không kèm MediaSession - nhiều bản Android (đặc
 * biệt 12+) không coi đó là "đang phát media hợp lệ" và vẫn có thể đóng băng process sau vài
 * giây. MediaSession + PlaybackState.STATE_PLAYING là tín hiệu chuẩn mà hệ thống nhận diện đúng
 * loại foreground service "mediaPlayback" khai báo trong Manifest.
 *
 * BrowserActivity tự start/stop service này theo đúng trạng thái phát thực tế (xem
 * refreshMediaFocusState) - không tồn tại dư thừa lúc không cần.
 */
class MediaPlaybackService : Service() {

    companion object {
        private const val CHANNEL_ID = "sieutoc_media_playback"
        private const val NOTIFICATION_ID = 1001
    }

    private var mediaSession: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        try {
            createChannelIfNeeded()
            mediaSession = MediaSession(this, "SieuTocPlayback").apply {
                setPlaybackState(
                    PlaybackState.Builder()
                        .setState(PlaybackState.STATE_PLAYING, PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1f)
                        .setActions(PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY)
                        .build()
                )
                isActive = true
            }
            AppLog.log("[media-service] onCreate OK, MediaSession active")
        } catch (e: Exception) {
            AppLog.log("[media-service] LỖI onCreate: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            startForeground(NOTIFICATION_ID, buildNotification())
            AppLog.log("[media-service] startForeground OK")
        } catch (e: Exception) {
            // Ghi lại lý do thật thay vì để service chết âm thầm không dấu vết - đây chính là
            // đầu mối để biết vì sao thông báo "đang phát" không bao giờ hiện lên
            AppLog.log("[media-service] LỖI startForeground: ${e.javaClass.simpleName}: ${e.message}")
        }
        return START_STICKY
    }

    override fun onDestroy() {
        mediaSession?.release()
        mediaSession = null
        AppLog.log("[media-service] onDestroy")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannelIfNeeded() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) != null) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Đang phát trong nền",
            NotificationManager.IMPORTANCE_LOW // im lặng, không rung/kêu - chỉ hiện thông báo
        ).apply {
            description = "Hiện khi Siêu Tốc đang phát video/audio để không bị hệ thống tạm dừng"
        }
        nm.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val openAppIntent = packageManager.getLaunchIntentForPackage(packageName)
        val contentIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder.apply {
            setContentTitle("Siêu Tốc đang phát")
            setContentText("Chạm để quay lại")
            setSmallIcon(android.R.drawable.ic_media_play)
            setContentIntent(contentIntent)
            setOngoing(true)
            setOnlyAlertOnce(true)
        }.build()
    }
}
