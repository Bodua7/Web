package com.atun.sieutoc

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.util.Patterns
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView
import org.mozilla.geckoview.WebExtension

// ============================================================================================
// BƯỚC 7/7 CỦA LỘ TRÌNH MIGRATE SANG GECKOVIEW - ĐÃ NỐI THẬT, KHÔNG CÒN SONG SONG NỮA
// ============================================================================================
// File này giờ dùng GeckoTab/GeckoSession (GeckoEngine.kt) THAY HẲN Tab/WebView cũ - bản gốc
// dùng WebView được backup nguyên vẹn ở BrowserActivity.kt.bak (không đóng gói vào zip build)
// để đối chiếu/khôi phục nếu cần.
//
// ĐÂY LÀ LẦN NỐI ĐẦU TIÊN, CHƯA CHẠY THỬ TRÊN THIẾT BỊ THẬT - vài chỗ được đánh dấu FIXME vì
// API GeckoView ở đó có rủi ro cao (tên hàm/chữ ký có thể lệch giữa các version, hoặc GeckoView
// không có API tương đương trực tiếp với WebView nên phải suy luận/giản lược hành vi cũ). Xem
// README mục "Đang làm" để biết danh sách đầy đủ những chỗ cần test kỹ + có thể phải sửa lại.
//
// Những WebView-only setting/hack KHÔNG còn trong bản này (không có API tương đương ở GeckoView,
// hoặc Gecko đã tự xử lý đúng mặc định nên không cần):
//   - getDefaultVideoPoster() hack (URL poster giả của WebView không tồn tại ở Gecko)
//   - user agent thay "wv" (chuỗi UA của Gecko không có marker này)
//   - mixedContentMode, builtInZoomControls/displayZoomControls, offscreenPreRaster,
//     saveFormData (không có cờ tương đương trực tiếp trong GeckoSessionSettings đã biết)
//   - pauseAllWebMedia()/resumeAllWebMedia() (dựa vào evaluateJavascript() tùy ý - GeckoView
//     không có API tương đương trong phần đã dựng; 2 hàm này VỐN ĐÃ không được gọi ở đâu trong
//     bản WebView cũ, xoá theo an toàn)
//   - "Bật JavaScript" ở Cài đặt: UI vẫn còn nhưng CHƯA có API bật/tắt JS theo từng session đã
//     xác nhận trên GeckoView - xem showSettingsDialog()/applySettings() để biết chi tiết
// ============================================================================================
abstract class BrowserActivity : AppCompatActivity() {

    protected abstract val isIncognitoActivity: Boolean

    protected lateinit var webViewContainer: FrameLayout
    protected lateinit var rootUiLayout: View
    private lateinit var tabsLayout: LinearLayout
    protected lateinit var addressBar: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var btnBookmark: ImageButton
    private lateinit var btnIncognito: ImageButton
    protected lateinit var prefs: SharedPreferences

    // GeckoTab giờ LÀ "1 tab" luôn (đã gộp sẵn geckoView + session + title/url/isPopup/
    // hasPlayingMedia/canGoBack/canGoForward) - không cần lớp Tab bọc ngoài như bản WebView cũ.
    protected val tabs = mutableListOf<GeckoTab>()
    private val tabViews = mutableListOf<View>()
    private var currentTabIndex = -1
    // Mốc thời gian popup gần nhất được mở, để chặn popup ăn theo bắn liên tiếp - xem
    // onNewPopupSession() bên dưới. LƯU Ý: onNewSession() của GeckoView không báo isUserGesture
    // như onCreateWindow cũ, nên giờ chặn popup HOÀN TOÀN theo mốc thời gian (không phân biệt
    // được popup do người dùng bấm hay JS tự bắn) - có thể chặn nhầm 1 số popup hợp lệ mở liên
    // tiếp nhanh, cần thử thực tế để tinh chỉnh lại mốc 1200ms nếu thấy phiền.
    private var lastPopupOpenedAt = 0L

    protected val homeUrl = "https://www.google.com/"
    protected val currentTab: GeckoTab? get() = tabs.getOrNull(currentTabIndex)

    // WebExtension cầu nối media (bước 6/7) - nạp 1 lần cho toàn app, gắn cho từng tab ngay khi
    // có (xem installMediaBridgeOnce() và registerNewTab()).
    private var mediaBridgeExtension: WebExtension? = null

    // ---- Nhật ký console (để tự chẩn đoán lỗi trên điện thoại, không cần máy tính) ----
    private val consoleLogLines = ArrayDeque<String>()
    private val consoleLogCap = 400
    private val appLogListener: (String) -> Unit = { line -> runOnUiThread { appendConsoleLog(line) } }

    private fun appendConsoleLog(line: String) {
        consoleLogLines.addLast(line)
        while (consoleLogLines.size > consoleLogCap) consoleLogLines.removeFirst()
    }

    // FIXME: WebChromeClient.onConsoleMessage (bắt console.log/warn/error của trang) không có ở
    // đây nữa - GeckoView bắt console qua ContentDelegate.onConsoleMessage với chữ ký khác hẳn
    // (nhận trực tiếp message/nguồn) NHƯNG chưa được đối chiếu javadoc đúng version trong lần
    // nối này. Nhật ký console giờ chỉ còn ghi log của chính app (AppLog), không còn log JS của
    // trang web - cần bổ sung lại nếu vẫn muốn tính năng debug JS trên điện thoại.
    private fun showConsoleLogDialog() {
        val text = if (consoleLogLines.isEmpty()) {
            "(Chưa có log nào)"
        } else {
            consoleLogLines.joinToString("\n\n")
        }
        val scrollView = android.widget.ScrollView(this)
        val textView = TextView(this).apply {
            setText(text)
            setTextIsSelectable(true)
            setPadding(32, 24, 32, 24)
            textSize = 12f
        }
        scrollView.addView(textView)

        AlertDialog.Builder(this)
            .setTitle("Nhật ký console (${consoleLogLines.size} dòng)")
            .setView(scrollView)
            .setPositiveButton("Sao chép toàn bộ") { _, _ ->
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("SieuToc console log", text))
                Toast.makeText(this, "Đã sao chép log - dán vào đâu cũng được", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Xoá log") { _, _ -> consoleLogLines.clear() }
            .setNegativeButton("Đóng", null)
            .show()
    }

    // ---- Wake lock để không tắt màn hình khi đang phát video/audio ----
    private var mediaWakeLock: PowerManager.WakeLock? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        AppLog.addListener(appLogListener)

        prefs = getSharedPreferences("sieutoc_prefs", MODE_PRIVATE)

        appendConsoleLog("[app] Khởi động SieuToc (Gecko) - build ${BuildConfig.VERSION_NAME}.${BuildConfig.VERSION_CODE}")

        webViewContainer = findViewById(R.id.webViewContainer)
        rootUiLayout = findViewById(R.id.rootUiLayout)
        tabsLayout = findViewById(R.id.tabsLayout)
        addressBar = findViewById(R.id.addressBar)
        progressBar = findViewById(R.id.progressBar)
        btnBookmark = findViewById(R.id.btnBookmark)
        btnIncognito = findViewById(R.id.btnIncognito)

        // Nạp trước blocklist.txt + cài WebExtension media bridge càng sớm càng tốt, trước khi
        // restoreSession() bắt đầu tạo tab - GeckoEngine tự lười nạp nếu quên gọi, gọi ở đây chỉ
        // để tránh lần đọc/cài đầu tiên rơi đúng lúc mở tab đầu tiên.
        GeckoEngine.preloadBlocklist(this)
        GeckoEngine.installMediaBridge(
            this,
            onReady = { extension ->
                mediaBridgeExtension = extension
                // Gắn bù cho các tab đã tạo trước khi extension kịp sẵn sàng (restoreSession()
                // thường chạy trước khi GeckoResult của installMediaBridge() trả về).
                tabs.forEach { attachMediaBridgeTo(it, extension) }
            },
            onError = { e ->
                appendConsoleLog("[media-bridge] Lỗi cài WebExtension: ${e.message}")
            }
        )

        setupToolbar()
        restoreSession()
    }

    protected abstract fun restoreSession()
    protected open fun persistSession() { }

    protected fun isJsEnabled(): Boolean = prefs.getBoolean("pref_js_enabled", true)
    protected fun isTrackerBlockEnabled(): Boolean = prefs.getBoolean("pref_block_tracker", true)

    // ---------------- Quản lý tab ----------------

    private fun attachMediaBridgeTo(tab: GeckoTab, extension: WebExtension) {
        tab.attachMediaBridge(
            extension,
            onPlay = { onWebMediaPlayStateChanged(true, tab) },
            onPause = { onWebMediaPlayStateChanged(false, tab) },
            onMediaError = { detail -> onWebMediaError(detail) }
        )
    }

    // Tương đương createWebView() cũ: tạo 1 GeckoSession + GeckoView mới, gắn toàn bộ delegate,
    // trả về GeckoTab đã sẵn sàng (nhưng CHƯA thêm vào danh sách tabs/thanh tab - việc đó do
    // registerNewTab() làm, giống tách bạch createWebView()/registerNewTab() cũ).
    private fun createGeckoTab(isPopup: Boolean = false): GeckoTab {
        val session = GeckoEngine.createSession(this, isPrivate = isIncognitoActivity)
        return wrapSession(session, isPopup)
    }

    // Dùng khi session đã được GeckoView tự tạo sẵn (trường hợp popup, xem onNewPopupSession) -
    // chỉ còn việc bọc GeckoTab + gắn delegate, không tự createSession() nữa.
    private fun wrapSession(session: GeckoSession, isPopup: Boolean): GeckoTab {
        val geckoView = GeckoView(this)
        geckoView.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        GeckoEngine.attach(geckoView, session)
        val tab = GeckoTab(this, geckoView, session, isPopup = isPopup)
        attachDelegatesTo(tab)
        mediaBridgeExtension?.let { attachMediaBridgeTo(tab, it) }
        return tab
    }

    private fun attachDelegatesTo(tab: GeckoTab) {
        tab.attachBasicDelegates(
            onTitleChanged = { refreshTabStrip() },
            onLocationChanged = { url ->
                if (tab === currentTab) {
                    addressBar.setText(url)
                    updateBookmarkIcon(url)
                }
                persistSession()
            },
            onLoadingStateChanged = { loading ->
                if (tab === currentTab) {
                    // FIXME: GeckoView chỉ báo bắt đầu/kết thúc tải, KHÔNG báo % tiến độ như
                    // WebChromeClient.onProgressChanged cũ - progressBar (thanh %) đổi tạm sang
                    // kiểu ẩn/hiện, muốn có hiệu ứng "quay vòng" (indeterminate) thì đổi thuộc
                    // tính android:indeterminate="true" của progressBar trong layout XML.
                    progressBar.visibility = if (loading) View.VISIBLE else View.GONE
                }
            },
            onCanGoBackChanged = { canGoBack ->
                if (tab === currentTab) findViewById<ImageButton>(R.id.btnBack).isEnabled = canGoBack
            },
            onCanGoForwardChanged = { canGoForward ->
                if (tab === currentTab) findViewById<ImageButton>(R.id.btnForward).isEnabled = canGoForward
            },
            onFullScreen = { fullScreen, _ ->
                GeckoEngine.applyFullScreenChrome(this, rootUiLayout, fullScreen)
            },
            onPopupBlockedOnFirstLoad = {
                val idx = tabs.indexOf(tab)
                if (idx >= 0) {
                    runOnUiThread {
                        closeTab(idx)
                        Toast.makeText(this, "Đã chặn 1 popup quảng cáo", Toast.LENGTH_SHORT).show()
                    }
                }
            },
            onNewPopupSession = { _ -> onNewPopupRequested() }
        )
        tab.attachPromptAndPermissionDelegates(allowDialog = { allowJsDialog(tab) })
    }

    // Tương đương allowJsDialog() cũ - cho phép tối đa 3 hộp thoại JS/tab khi đang bật chặn
    // quảng cáo, sau đó tự chặn êm các hộp thoại tiếp theo.
    private fun allowJsDialog(tab: GeckoTab): Boolean {
        if (!isTrackerBlockEnabled()) return true
        return tab.jsDialogCount <= 3
    }

    // Tương đương phần "tạo transport + WebView mới" trong onCreateWindow cũ, nhưng đơn giản
    // hơn: GeckoView đã tự tạo sẵn GeckoSession rỗng cho popup (xem GeckoTab.onNewSession) -
    // việc của hàm này chỉ là bọc GeckoTab quanh session đó, đăng ký vào danh sách tab/thanh tab,
    // rồi TRẢ VỀ đúng session đó cho GeckoView gắn nội dung popup vào.
    //
    // Giữ nguyên tinh thần giới hạn "mỗi lần chạm chỉ 1 popup" bằng mốc thời gian lastPopupOpenedAt
    // (xem ghi chú ở khai báo field phía trên về việc mất khả năng phân biệt user-gesture).
    private fun onNewPopupRequested(): GeckoSession? {
        if (isTrackerBlockEnabled()) {
            val now = android.os.SystemClock.elapsedRealtime()
            if (now - lastPopupOpenedAt < 1200L) {
                runOnUiThread { Toast.makeText(this, "Đã chặn popup quảng cáo", Toast.LENGTH_SHORT).show() }
                return null
            }
            lastPopupOpenedAt = now
        }
        val session = GeckoEngine.createSession(this, isPrivate = isIncognitoActivity)
        runOnUiThread {
            val tab = wrapSession(session, isPopup = true)
            addTabToUi(tab)
            switchTab(tabs.size - 1)
        }
        return session
    }

    protected fun addTab(url: String?) {
        val tab = createGeckoTab()
        addTabToUi(tab)
        tab.loadUrl(url ?: homeUrl)
        switchTab(tabs.size - 1)
    }

    // Tương đương registerNewTab() cũ - thêm 1 GeckoTab đã dựng sẵn vào danh sách + dựng UI
    // thanh tab. KHÔNG tự loadUrl/switchTab, y hệt quy ước cũ.
    private fun addTabToUi(tab: GeckoTab) {
        tabs.add(tab)
        webViewContainer.addView(tab.geckoView)

        val tabView = LayoutInflater.from(this).inflate(R.layout.item_tab, tabsLayout, false)
        tabsLayout.addView(tabView)
        tabViews.add(tabView)
        val index = tabs.size - 1

        tabView.findViewById<TextView>(R.id.tabTitle).apply {
            text = if (isIncognitoActivity) "🕶 Ẩn danh" else "Tab mới"
            if (isIncognitoActivity) setTextColor(0xFFFFFFFF.toInt())
        }
        if (isIncognitoActivity) tabView.setBackgroundColor(0xFF333333.toInt())

        tabView.setOnClickListener { switchTab(index) }
        tabView.findViewById<ImageButton>(R.id.tabClose).setOnClickListener { closeTab(index) }
    }

    protected fun switchTab(index: Int) {
        if (index !in tabs.indices) return
        currentTabIndex = index
        tabs.forEachIndexed { i, tab -> tab.geckoView.visibility = if (i == index) View.VISIBLE else View.GONE }
        tabViews.forEachIndexed { i, v -> v.isSelected = (i == index) }
        val tab = tabs[index]
        addressBar.setText(tab.url)
        progressBar.visibility = View.GONE
        findViewById<ImageButton>(R.id.btnBack).isEnabled = tab.canGoBack
        findViewById<ImageButton>(R.id.btnForward).isEnabled = tab.canGoForward
        updateBookmarkIcon(tab.url)
    }

    private fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        val tab = tabs[index]
        val activeTabBeforeClose = currentTab

        tab.close()
        webViewContainer.removeView(tab.geckoView)
        tabsLayout.removeView(tabViews[index])
        tabs.removeAt(index)
        tabViews.removeAt(index)
        refreshMediaFocusState()

        if (tabs.isEmpty()) {
            addTab(homeUrl)
            return
        }

        rebindTabListeners()

        val newIndex = if (tab === activeTabBeforeClose) {
            (index - 1).coerceAtLeast(0)
        } else {
            val shiftedIndex = tabs.indexOf(activeTabBeforeClose)
            if (shiftedIndex >= 0) shiftedIndex else (index - 1).coerceAtLeast(0)
        }
        switchTab(newIndex.coerceAtMost(tabs.size - 1))
        persistSession()
    }

    private fun rebindTabListeners() {
        tabViews.forEachIndexed { i, v ->
            v.setOnClickListener { switchTab(i) }
            v.findViewById<ImageButton>(R.id.tabClose).setOnClickListener { closeTab(i) }
        }
    }

    private fun refreshTabStrip() {
        tabs.forEachIndexed { i, tab ->
            val view = tabViews.getOrNull(i) ?: return@forEachIndexed
            val label = if (isIncognitoActivity) "🕶 " + shortTitle(tab.title) else shortTitle(tab.title)
            view.findViewById<TextView>(R.id.tabTitle).text = label
        }
    }

    private fun shortTitle(title: String): String =
        if (title.length > 14) title.take(14) + "…" else title

    // ---------------- Media: wake lock + foreground service ----------------
    // Logic refreshMediaFocusState()/onWebMediaPlayStateChanged() GIỮ NGUYÊN so với bản WebView -
    // chỉ đổi nguồn báo play/pause (từ AndroidMediaBridge sang WebExtension bước 6) và bỏ hẳn
    // BackgroundAudioWebView (lớp đó là hack riêng cho Chromium/WebView, KHÔNG áp dụng được cho
    // GeckoView - hành vi thật của Gecko lúc tắt màn hình trong khi phát media CHƯA được kiểm
    // chứng trên máy thật, đây là rủi ro lớn nhất cần test ở bước sau).

    private var lastMediaErrorToastAt = 0L

    private fun onWebMediaError(detail: String) {
        val hint = try {
            val json = org.json.JSONObject(detail)
            val code = json.optInt("code", -1)
            val codeMeaning = when (code) {
                1 -> "ABORTED (bị hủy giữa chừng)"
                2 -> "NETWORK (lỗi mạng/tải nguồn)"
                3 -> "DECODE (dữ liệu hỏng hoặc máy không giải mã được)"
                4 -> "SRC_NOT_SUPPORTED (định dạng/URL không phát được)"
                else -> "không rõ (code=$code)"
            }
            "[media error] code=$codeMeaning, src=${json.optString("src")}"
        } catch (e: Exception) {
            "[media error] $detail"
        }
        appendConsoleLog(hint)

        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastMediaErrorToastAt < 4000L) return
        lastMediaErrorToastAt = now
        Toast.makeText(
            this,
            "Video/âm thanh gặp lỗi khi phát. Xem chi tiết ở \"Xem nhật ký console\"",
            Toast.LENGTH_LONG
        ).show()
    }

    private var lastLoadErrorToastAt = 0L

    private fun showLoadErrorToast(message: String) {
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastLoadErrorToastAt < 3000L) return
        lastLoadErrorToastAt = now
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    // FIXME: onReceivedError/onReceivedHttpError/onReceivedSslError (báo lỗi tải trang/HTTP/SSL)
    // của WebViewClient cũ CHƯA được nối lại - GeckoView báo qua NavigationDelegate.onLoadError()
    // với kiểu WebRequestError khác hẳn WebResourceError, cần đối chiếu javadoc đúng version rồi
    // thêm vào GeckoTab.attachBasicDelegates() ở GeckoEngine.kt. showLoadErrorToast() ở trên tạm
    // thời không được gọi từ đâu cả cho tới khi làm việc này.

    private fun onWebMediaPlayStateChanged(isPlaying: Boolean, tab: GeckoTab) {
        appendConsoleLog("[media] trang báo ${if (isPlaying) "play" else "pause"}")
        tab.hasPlayingMedia = isPlaying
        refreshMediaFocusState()
    }

    private fun refreshMediaFocusState() {
        val anyTabPlaying = tabs.any { it.hasPlayingMedia }
        if (anyTabPlaying) {
            acquireMediaWakeLock()
            startMediaPlaybackService()
        } else {
            releaseMediaWakeLock()
            stopMediaPlaybackService()
        }
        // KHÔNG còn bước "bật/tắt keepAliveWhenHidden trên BackgroundAudioWebView" như bản
        // WebView cũ - xem ghi chú đầu khối media ở trên.
    }

    private fun startMediaPlaybackService() {
        val intent = Intent(this, MediaPlaybackService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun stopMediaPlaybackService() {
        stopService(Intent(this, MediaPlaybackService::class.java))
    }

    private fun acquireMediaWakeLock() {
        if (mediaWakeLock == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            mediaWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SieuToc:MediaPlayback").apply {
                setReferenceCounted(false)
            }
        }
        mediaWakeLock?.let { if (!it.isHeld) it.acquire(6 * 60 * 60 * 1000L) }
    }

    private fun releaseMediaWakeLock() {
        mediaWakeLock?.let { if (it.isHeld) it.release() }
    }

    // ---------------- Điều hướng & thanh công cụ ----------------

    private fun navigateTo(input: String) {
        val query = input.trim()
        if (query.isEmpty()) return

        val url = when {
            Patterns.WEB_URL.matcher(query).matches() && !query.contains(" ") -> {
                if (query.startsWith("http://") || query.startsWith("https://")) query
                else "https://$query"
            }
            query.contains(".") && !query.contains(" ") -> "https://$query"
            else -> "https://www.google.com/search?q=" + Uri.encode(query)
        }
        currentTab?.loadUrl(url)
        currentFocus?.let {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
            imm.hideSoftInputFromWindow(it.windowToken, 0)
        }
    }

    private fun setupToolbar() {
        addressBar.setOnEditorActionListener { _, actionId, event ->
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_GO ||
                (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            ) {
                navigateTo(addressBar.text.toString())
                true
            } else {
                false
            }
        }

        findViewById<ImageButton>(R.id.btnBack).setOnClickListener {
            currentTab?.let { if (it.canGoBack) it.goBack() }
        }
        findViewById<ImageButton>(R.id.btnForward).setOnClickListener {
            currentTab?.let { if (it.canGoForward) it.goForward() }
        }
        btnBookmark.setOnClickListener { toggleBookmark() }
        findViewById<ImageButton>(R.id.btnMenu).setOnClickListener { view -> showMenu(view) }

        findViewById<ImageButton>(R.id.btnNewTab).setOnClickListener { onNewTabButtonClicked() }
        btnIncognito.setOnClickListener { onIncognitoButtonClicked() }
    }

    protected abstract fun onNewTabButtonClicked()
    protected abstract fun onIncognitoButtonClicked()

    private fun toggleBookmark() {
        if (isIncognitoActivity) {
            Toast.makeText(this, "Không thể đánh dấu ở chế độ ẩn danh", Toast.LENGTH_SHORT).show()
            return
        }
        val tab = currentTab ?: return
        val url = tab.url
        if (url.isBlank()) return
        val bookmarks = prefs.getStringSet("bookmarks", mutableSetOf())!!.toMutableSet()
        if (bookmarks.contains(url)) {
            bookmarks.remove(url)
            Toast.makeText(this, "Đã bỏ đánh dấu", Toast.LENGTH_SHORT).show()
        } else {
            bookmarks.add(url)
            Toast.makeText(this, "Đã đánh dấu trang", Toast.LENGTH_SHORT).show()
        }
        prefs.edit().putStringSet("bookmarks", bookmarks).apply()
        updateBookmarkIcon(url)
    }

    private fun updateBookmarkIcon(url: String?) {
        if (isIncognitoActivity) {
            btnBookmark.setImageResource(android.R.drawable.star_off)
            btnBookmark.alpha = 0.4f
            return
        }
        btnBookmark.alpha = 1.0f
        val bookmarks = prefs.getStringSet("bookmarks", mutableSetOf())!!
        val isBookmarked = url != null && bookmarks.contains(url)
        btnBookmark.setImageResource(
            if (isBookmarked) android.R.drawable.star_on else android.R.drawable.star_off
        )
    }

    private fun showMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add(0, 1, 0, "Trang chủ")
        if (!isIncognitoActivity) popup.menu.add(0, 2, 1, "Danh sách đánh dấu")
        popup.menu.add(0, 5, 2, if (isCurrentPageTranslated()) "Xem bản gốc" else "Dịch trang")
        popup.menu.add(0, 6, 3, "Ngôn ngữ dịch (${translateLangLabel()})")
        popup.menu.add(0, 3, 4, "Xóa dữ liệu duyệt web")
        popup.menu.add(0, 4, 5, "Cài đặt")
        popup.menu.add(0, 8, 6, "Xem nhật ký console (debug)")
        if (isIncognitoActivity) popup.menu.add(0, 7, 7, "Đóng phiên ẩn danh")
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> { currentTab?.loadUrl(homeUrl); true }
                2 -> { showBookmarks(); true }
                3 -> { clearBrowsingData(); true }
                4 -> { showSettingsDialog(); true }
                5 -> { translateCurrentPage(); true }
                6 -> { showTranslateLanguageDialog(); true }
                7 -> { onCloseIncognitoSessionRequested(); true }
                8 -> { showConsoleLogDialog(); true }
                else -> false
            }
        }
        popup.show()
    }

    protected open fun onCloseIncognitoSessionRequested() { }

    // ---------------- Dịch trang ----------------
    // Toàn bộ logic buildTranslateUrl/originalUrlFromTranslated GIỮ NGUYÊN 100% so với bản
    // WebView - chỉ là thao tác chuỗi URL, không đụng gì tới engine, nên tự nhiên vẫn đúng.

    private val translateLanguages = listOf(
        "vi" to "Tiếng Việt",
        "en" to "English",
        "zh-CN" to "中文 (Giản thể)",
        "ja" to "日本語",
        "ko" to "한국어",
        "fr" to "Français",
        "es" to "Español",
        "de" to "Deutsch",
        "th" to "ภาษาไทย"
    )

    private fun targetLang(): String = prefs.getString("pref_translate_lang", "vi") ?: "vi"

    private fun translateLangLabel(): String =
        translateLanguages.firstOrNull { it.first == targetLang() }?.second ?: targetLang()

    private fun showTranslateLanguageDialog() {
        val labels = translateLanguages.map { it.second }.toTypedArray()
        val currentIndex = translateLanguages.indexOfFirst { it.first == targetLang() }.coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Ngôn ngữ dịch")
            .setSingleChoiceItems(labels, currentIndex) { dialog, which ->
                val lang = translateLanguages[which].first
                prefs.edit().putString("pref_translate_lang", lang).apply()
                Toast.makeText(this, "Đã đặt ngôn ngữ dịch: ${translateLanguages[which].second}", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
                reapplyTranslationIfActive(lang)
            }
            .setNegativeButton("Đóng", null)
            .show()
    }

    private fun reapplyTranslationIfActive(newLang: String) {
        val tab = currentTab ?: return
        val url = tab.url
        if (!isTranslatedUrl(url)) return
        val original = originalUrlFromTranslated(url) ?: return
        val target = buildTranslateUrl(original, newLang) ?: return
        tab.loadUrl(target)
    }

    private fun isTranslatedUrl(url: String): Boolean =
        Uri.parse(url).host?.endsWith(".translate.goog") == true

    private fun isCurrentPageTranslated(): Boolean {
        val url = currentTab?.url ?: return false
        return isTranslatedUrl(url)
    }

    private fun buildTranslateUrl(url: String, targetLang: String): String? {
        val uri = Uri.parse(url)
        val host = uri.host?.lowercase() ?: return null
        if (host == "localhost" || Patterns.IP_ADDRESS.matcher(host).matches()) return null
        val encodedHost = host.replace("-", "--").replace(".", "-") + ".translate.goog"
        val builder = Uri.Builder()
            .scheme(uri.scheme ?: "https")
            .encodedAuthority(encodedHost)
            .encodedPath(uri.encodedPath ?: "/")
        uri.encodedQuery?.let { builder.encodedQuery(it) }
        builder.appendQueryParameter("_x_tr_sl", "auto")
        builder.appendQueryParameter("_x_tr_tl", targetLang)
        builder.appendQueryParameter("_x_tr_hl", targetLang)
        builder.appendQueryParameter("_x_tr_pto", "wapp")
        return builder.build().toString()
    }

    private fun originalUrlFromTranslated(url: String): String? {
        val uri = Uri.parse(url)
        val host = uri.host ?: return null
        if (!host.endsWith(".translate.goog")) return null
        val encodedHost = host.removeSuffix(".translate.goog")
        val originalHost = encodedHost
            .replace("--", "\u0000")
            .replace("-", ".")
            .replace("\u0000", "-")
        if (originalHost.isBlank()) return null

        val builder = Uri.Builder()
            .scheme(uri.scheme ?: "https")
            .encodedAuthority(originalHost)
            .encodedPath(uri.encodedPath ?: "/")
        uri.queryParameterNames
            .filterNot { it.startsWith("_x_tr_") }
            .forEach { name -> uri.getQueryParameter(name)?.let { builder.appendQueryParameter(name, it) } }
        return builder.build().toString()
    }

    private fun translateCurrentPage() {
        val tab = currentTab ?: return
        val url = tab.url
        if (url.isBlank()) {
            Toast.makeText(this, "Chưa có trang để dịch", Toast.LENGTH_SHORT).show()
            return
        }
        val target = if (isTranslatedUrl(url)) {
            originalUrlFromTranslated(url)
        } else {
            buildTranslateUrl(url, targetLang())
        }
        if (target == null) {
            Toast.makeText(this, "Không dịch được trang này", Toast.LENGTH_SHORT).show()
            return
        }
        tab.loadUrl(target)
    }

    private fun showBookmarks() {
        val bookmarks = prefs.getStringSet("bookmarks", mutableSetOf())!!.toList()
        if (bookmarks.isEmpty()) {
            Toast.makeText(this, "Chưa có trang nào được đánh dấu", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Đánh dấu")
            .setItems(bookmarks.toTypedArray()) { _, which ->
                currentTab?.loadUrl(bookmarks[which])
            }
            .setNegativeButton("Đóng", null)
            .create()
            .show()
    }

    private fun showSettingsDialog() {
        val options = arrayOf("Bật JavaScript (*)", "Chặn quảng cáo / theo dõi / popup")
        val checked = booleanArrayOf(isJsEnabled(), isTrackerBlockEnabled())

        AlertDialog.Builder(this)
            .setTitle("Cài đặt")
            .setMultiChoiceItems(options, checked) { _, which, isChecked ->
                checked[which] = isChecked
            }
            .setMessage("(*) Lưu ý: bản Gecko hiện chưa xác nhận được API tắt JavaScript theo từng tab - tuỳ chọn này tạm thời chỉ lưu lại lựa chọn, CHƯA thật sự tắt JS. Xem applySettings() trong code.")
            .setPositiveButton("Áp dụng") { _, _ ->
                applySettings(jsEnabled = checked[0], trackerBlockEnabled = checked[1])
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun applySettings(jsEnabled: Boolean, trackerBlockEnabled: Boolean) {
        prefs.edit()
            .putBoolean("pref_js_enabled", jsEnabled)
            .putBoolean("pref_block_tracker", trackerBlockEnabled)
            .apply()

        // FIXME: bản WebView cũ áp ngay "javaScriptEnabled" cho mọi tab đang mở
        // (tab.webView.settings.javaScriptEnabled = jsEnabled). GeckoView KHÔNG có API bật/tắt
        // JS theo từng session đã được xác nhận trong lần nối này - cần tra
        // GeckoRuntimeSettings/GeckoSessionSettings đúng version xem có cờ nào tương đương
        // không trước khi tin cài đặt "Bật JavaScript" thật sự có tác dụng.

        Toast.makeText(this, "Đã lưu cài đặt, đang tải lại trang hiện tại", Toast.LENGTH_SHORT).show()
        currentTab?.loadUrl(currentTab?.url ?: return)
    }

    // FIXME (rủi ro cao): CookieManager/WebStorage của android.webkit không còn tác dụng gì với
    // dữ liệu của GeckoView (2 engine dùng kho lưu trữ khác nhau hoàn toàn). Xoá dữ liệu duyệt
    // web thật sự của GeckoRuntime cần gọi qua StorageController (vd
    // GeckoEngine.getRuntime(this).storageController.clearData(...)) - CHƯA đối chiếu chính xác
    // tên hằng số cờ xoá (ClearFlags) đúng version GeckoView trong lần nối này, nên TẠM THỜI chỉ
    // xoá được lịch sử/bookmark phía app (SharedPreferences) + đóng lại các tab đang mở (khiến
    // GeckoSession riêng của mỗi tab bị huỷ, nhưng cookie/cache của GeckoRuntime dùng CHUNG cho
    // các session mới KHÔNG chắc đã bị xoá). Đây là 1 trong những điểm BẮT BUỘC phải kiểm tra kỹ
    // trên máy thật trước khi coi lộ trình 7 bước là hoàn tất.
    protected fun clearBrowsingData() {
        val count = tabs.size
        for (i in 0 until count) {
            tabs[0].close()
            webViewContainer.removeView(tabs[0].geckoView)
            tabsLayout.removeView(tabViews[0])
            tabs.removeAt(0)
            tabViews.removeAt(0)
        }
        if (!isIncognitoActivity) prefs.edit().remove("tab_urls").apply()
        addTab(homeUrl)
        Toast.makeText(
            this,
            "Đã đóng lại các tab. LƯU Ý: xoá cookie/cache thật sự của GeckoView chưa được xác nhận hoạt động đúng ở bản này - xem comment clearBrowsingData() trong code",
            Toast.LENGTH_LONG
        ).show()
    }

    override fun onBackPressed() {
        val tab = currentTab
        when {
            tab != null && tab.canGoBack -> tab.goBack()
            tabs.size > 1 -> closeTab(currentTabIndex)
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() {
        releaseMediaWakeLock()
        stopMediaPlaybackService()
        AppLog.removeListener(appLogListener)
        super.onDestroy()
    }
}
