package com.atun.sieutoc

/**
 * Log tĩnh dùng chung giữa các component (Activity, Service) trong CÙNG process, để lỗi xảy ra
 * trong Service (không có sẵn UI để hiện log riêng) vẫn gộp chung vào đúng 1 nơi xem được:
 * dialog "Xem nhật ký console" của BrowserActivity.
 *
 * Không dùng cho IncognitoActivity (chạy process riêng ":incognito") - log của process đó tách
 * biệt hoàn toàn, đúng ý đồ cô lập dữ liệu ẩn danh.
 */
object AppLog {
    private val lines = ArrayDeque<String>()
    private const val CAP = 200
    private val listeners = mutableListOf<(String) -> Unit>()

    @Synchronized
    fun log(line: String) {
        lines.addLast(line)
        while (lines.size > CAP) lines.removeFirst()
        listeners.forEach { it(line) }
    }

    @Synchronized
    fun addListener(listener: (String) -> Unit) {
        listeners.add(listener)
    }

    @Synchronized
    fun removeListener(listener: (String) -> Unit) {
        listeners.remove(listener)
    }
}
