# Siêu Tốc — Trình duyệt Android không theo dõi

## Tính năng
- WebView tốc độ cao (loadWithOverviewMode, cacheMode mặc định của hệ thống)
- Chặn ~60 domain quảng cáo/tracker phổ biến ngay ở tầng shouldInterceptRequest
  (Google Ads, Facebook Pixel, AppsFlyer, Crashlytics, TikTok Ads, v.v.) —
  danh sách ở app/src/main/assets/blocklist.txt, tự thêm domain nếu muốn
- **Chặn popup quảng cáo**: popup do JS tự mở (không phải người dùng bấm) bị chặn khi
  "Chặn quảng cáo / theo dõi" đang bật ở Cài đặt; popup do người dùng chủ động bấm
  (link mở tab mới, nút "mở tab mới" của trình phát video...) vẫn mở bình thường
- Chặn cookie bên thứ 3 (giữ cookie bên thứ nhất để vẫn đăng nhập được)
- Không tích hợp bất kỳ SDK phân tích/quảng cáo nào — chỉ 1 quyền INTERNET
- Đánh dấu trang, lịch sử phiên gần nhất, xóa toàn bộ dữ liệu duyệt web 1 chạm
- Tìm kiếm mặc định qua DuckDuckGo (không theo dõi)
- **Đa tab**: nút "+" mở tab mới, bấm tab trên thanh để chuyển, "×" để đóng
- **Chế độ ẩn danh**: bấm icon kính râm để bật/tắt trước khi mở tab mới —
  tab ẩn danh không lưu localStorage, không lưu vào phiên khôi phục lúc mở lại app,
  không cho bookmark, và tự xóa cache/cookie/localStorage khi đóng tab hoặc thoát app
  (lưu ý: CookieManager của Android WebView dùng chung 1 kho cookie toàn app,
  nên lúc đóng tab ẩn danh sẽ xóa luôn cookie — chấp nhận được cho bản hobby,
  nếu cần cách ly cookie tuyệt đối giữa các tab thì phải tách process riêng, phức tạp hơn nhiều)

## Build qua GitHub Actions
1. Tạo repo mới, upload toàn bộ zip này — **có thể để nguyên file `.zip` ở gốc repo,
   không cần tự giải nén**: workflow sẽ tự phát hiện và giải nén nếu chưa thấy
   `settings.gradle` ở gốc repo (nếu bạn quen giải nén sẵn rồi upload từng file thì cũng
   chạy bình thường, workflow tự bỏ qua bước giải nén khi đã thấy `settings.gradle`)
2. Push lên nhánh `main` hoặc chạy tay bằng "Run workflow" (workflow_dispatch)
3. Tải APK debug ở tab Actions > Artifacts > SieuToc-debug-apk

## Đã có
- Đa tab, chế độ ẩn danh
- Menu > Cài đặt: bật/tắt JavaScript, bật/tắt chặn quảng cáo/theo dõi — áp dụng ngay
  cho mọi tab đang mở, không cần khởi động lại app; lưu vào SharedPreferences nên
  giữ nguyên qua các lần mở app sau
- **Xem video mượt**: video HTML5 fullscreen (YouTube, Facebook, TikTok web...) chuyển
  sang toàn màn hình thật (ẩn cả thanh tab, thanh địa chỉ, thanh điều hướng hệ thống),
  tự động chống tắt màn hình trong lúc xem, hardware acceleration bật rõ ràng, xoay màn
  hình không load lại video (configChanges đã xử lý). Bấm Back để thoát fullscreen mà
  không mất trang
- **Dịch trang**: Menu > "Dịch trang" — dịch toàn trang qua proxy translate.goog của
  Google (không cần thêm quyền hay SDK nào), bấm lại thành "Xem bản gốc" để quay về
  trang chưa dịch. Chọn ngôn ngữ đích ở Menu > "Ngôn ngữ dịch" (mặc định Tiếng Việt),
  áp dụng ngay cho lần dịch tiếp theo, lưu qua SharedPreferences nên giữ nguyên qua
  các lần mở app sau
- **Mở link từ app khác**: khai báo intent-filter VIEW cho http/https nên có thể chọn
  "Mở bằng Siêu Tốc" từ app khác (Zalo, Messenger, Gmail...), link sẽ mở ở tab mới

## Ký release build (khuyến nghị — bản debug không tối ưu, và mỗi lần build lại đổi chữ ký làm mất dữ liệu app khi cập nhật)
1. Vào repo trên GitHub > Settings > Secrets and variables > Actions > New repository secret, thêm đúng 3 secret sau (giá trị lấy trong file keystore_secrets.txt mình gửi kèm và file release.keystore.base64):
   - `KEYSTORE_BASE64` → dán toàn bộ nội dung file `release.keystore.base64`
   - `KEYSTORE_PASSWORD` → dán giá trị STOREPASS trong `keystore_secrets.txt`
   - `KEY_ALIAS` → `sieutoc`
   - `KEY_PASSWORD` → dán giá trị KEYPASS trong `keystore_secrets.txt` (thực chất bằng STOREPASS, vì keystore dạng PKCS12 dùng chung 1 mật khẩu)
2. Chạy lại workflow (push hoặc "Run workflow"), sẽ có thêm artifact `SieuToc-release-apk` đã ký sẵn, cài trực tiếp lên máy được, minify bật nên nhẹ hơn bản debug
3. **Giữ kỹ file `release.keystore` và mật khẩu** — mất là không thể phát hành bản cập nhật cùng chữ ký được nữa (Android sẽ bắt gỡ cài đặt cũ trước khi cài bản mới)
4. Không commit `release.keystore` hay `keystore_secrets.txt` vào repo — chỉ dùng để lấy giá trị nhập vào Secrets rồi lưu riêng ở chỗ an toàn (Google Drive riêng tư, password manager...)

## Đã vá (1.7.9)
- **Phát audio khi khoá máy**: trước đây video/audio tự dừng NGAY lúc tắt màn hình (kể cả với
  trang phát file trực tiếp, không riêng gì YouTube) - do tầng Chromium trong WebView tự dừng giải
  mã khi cửa sổ không còn hiển thị. Đã vá bằng `BackgroundAudioWebView` (đè `onWindowVisibilityChanged`
  để báo Chromium là vẫn hiển thị, ĐÚNG lúc tab đó có media đang phát thật) - cùng cơ chế Herond/
  Samsung Internet/Firefox Android dùng, vì tất cả cùng chung 1 nhân Chromium với WebView.
  Xem chi tiết lý do kỹ thuật ở comment trong `BackgroundAudioWebView.kt`.
  LƯU Ý: chỉ đảm bảo cho trang phát file media trực tiếp (mp3/mp4 nhúng thẳng). Với YouTube/
  Facebook/TikTok (dùng MSE, không có URL phát trực tiếp), cần kiểm tra thực tế trên máy - nhân
  Chromium có thể vẫn giữ được audio track dù video là MSE, nhưng đây là hành vi tầng dưới ngoài
  tầm kiểm soát trực tiếp của code, không cam kết chắc 100%.

## Đang làm: Migrate sang GeckoView (bước 1-7/7 — ĐÃ NỐI THẬT, CHƯA TEST TRÊN MÁY)
- Đã thêm repo `maven.mozilla.org` (`build.gradle`) + dependency GeckoView (`app/build.gradle`,
  version đọc từ `gradle.properties` - **phải tự điền version thật trước khi build, xem hướng
  dẫn ngay trong `gradle.properties`**, vì Mozilla rút các bản cũ khỏi maven theo thời gian nên
  không ghi cứng được 1 số hiệu chắc chắn còn tồn tại)
- Đã tạo `GeckoEngine.kt`: `GeckoRuntime` singleton + `GeckoTab` (song song `Tab` trong
  `BrowserActivity.kt`, CHƯA nối vào nhau) với delegate cơ bản (title, location, loading,
  fullscreen) - đọc comment trong file để biết khác biệt so với WebViewClient/WebChromeClient
- **Bước 3 (mới xong)**: `createSession(context, isPrivate)` bật `usePrivateMode(isPrivate)`,
  thêm `closeSession()`/`GeckoTab.close()` để giải phóng dữ liệu phiên riêng tư ngay lúc đóng tab.
  Khác cơ chế `IncognitoActivity` hiện tại (tách hẳn `android:process=":incognito"` + tự tay
  `CookieManager.removeAllCookies()`/`WebStorage.deleteAllData()` lúc `onDestroy()`), phiên
  private-mode của Gecko không bao giờ ghi dữ liệu xuống đĩa ngay từ đầu nên không cần tách
  process lẫn không cần tự dọn cookie/storage - đọc comment đầu `GeckoEngine.kt` để biết chi tiết.
  **Lưu ý**: đây vẫn CHƯA thay được `IncognitoActivity` thật - vẫn code song song, an toàn, không
  đụng app hiện tại. Việc thật sự bỏ tách process phải đợi xong bước 5-6 (fullscreen, JS bridge)
  để tab ẩn danh không bị mất tính năng khi chuyển hẳn sang Gecko.
- **Bước 4 (mới xong)**: `GeckoTab` giờ chặn theo `blocklist.txt` thật (đọc từ `assets`, cùng
  logic khớp domain/subdomain + entry có path như `isBlocked()` cũ) qua
  `NavigationDelegate.onLoadRequest` → trả `AllowOrDeny.DENY`, đọc chung khoá SharedPreferences
  `pref_block_tracker` nên công tắc ở Menu > Cài đặt áp dụng đồng thời cho cả WebView lẫn
  GeckoSession. **Giới hạn cần biết**: GeckoView chỉ cho chặn ở cấp *navigation* (link/redirect/
  iframe top-level) chứ không chặn được subresource nhúng sâu trong 1 trang đã cho phép load
  (vd script `facebook.com/tr` nhúng trong 1 trang báo) như `shouldInterceptRequest` cũ làm được -
  phần đó phải đợi WebExtension ở bước 6. ETP (STRICT + cryptomining + fingerprinting, đã bật từ
  bước 1) vẫn chạy song song, bổ sung chứ không thay thế blocklist.txt.
- **Bước 5 (mới xong)**: `GeckoTab.onFullScreen` giờ có sẵn 3 hàm dùng chung trong
  `GeckoEngine` — `enterImmersiveMode(activity)` / `exitImmersiveMode(activity)` (y hệt flag
  `systemUiVisibility` đang dùng cho WebView) và `applyFullScreenChrome(activity, rootUiLayout,
  fullScreen)` gộp cả immersive mode + ẩn/hiện `rootUiLayout` + `FLAG_KEEP_SCREEN_ON` trong 1 lần
  gọi. **Khác biệt với `onShowCustomView` cũ**: GeckoView không đưa 1 `View` riêng để add vào
  `fullscreenContainer` — chính `geckoView` đang hiển thị tự vẽ nội dung fullscreen, nên nhánh
  Gecko không cần `fullscreenContainer`/`customView`/`customViewCallback` nữa, chỉ còn ẩn/hiện
  UI chrome + immersive mode. Lúc ghép vào `BrowserActivity` (bước sau), chỗ tạo `GeckoTab` chỉ
  cần truyền lambda gọi `GeckoEngine.applyFullScreenChrome(this, rootUiLayout, fullScreen)`.
- Việc build thử qua GitHub Actions sau bước này: xác nhận dependency tải được + đo APK tăng
  bao nhiêu MB, CHƯA có UI nào dùng GeckoView cả (an toàn, không ảnh hưởng app hiện tại)
- **Bước 6 (mới xong, khó nhất)**: JS bridge thay `addJavascriptInterface` — GeckoView không có
  API tương đương trực tiếp, phải dựng hẳn 1 **WebExtension thật**:
  - `app/src/main/assets/mediabridge/manifest.json` + `content.js` — bản Gecko của
    `mediaHookScript` hiện có, GIỮ NGUYÊN logic gắn listener play/pause/ended/error lên mọi thẻ
    video/audio (kể cả thẻ được trang tạo thêm sau qua `MutationObserver`), chỉ đổi cách gửi
    tin: gọi `browser.runtime.sendNativeMessage("sieutoc", {...})` thay vì gọi thẳng
    `AndroidMediaBridge.onPlay()`.
  - `GeckoEngine.installMediaBridge()` nạp extension 1 lần cho toàn app (như cài 1 addon vào
    Firefox), `GeckoEngine.attachMediaBridgeDelegate()`/`GeckoTab.attachMediaBridge()` gắn
    `MessageDelegate` riêng cho từng tab để biết chính xác message đến từ tab nào — tương đương
    tham số `ownerWebView` trong `MediaPlaybackBridge(webView)` cũ.
  - **Lưu ý version**: tên hàm (`webExtensionController`, `ensureBuiltIn`,
    `WebExtension.SessionController.setMessageDelegate`) đúng với dòng GeckoView hiện hành, nhưng
    đây là API còn tương đối mới, có thể lệch nhẹ giữa các bản build-id — nếu build lỗi
    "unresolved reference" đúng những dòng này, tra javadoc GeckoView đúng version đang khai
    trong `gradle.properties` (tìm class `WebExtensionController`/`WebExtension.SessionController`)
    để đối chiếu tên gọi chính xác. Các bước 1-5 dùng API đã ổn định lâu, không bị ảnh hưởng.
- Còn lại (bước 7): test lại toàn bộ trên máy thật (đặc biệt phát audio nền khi khoá máy — hành
  vi tầng dưới của Gecko lúc app background có thể khác Chromium), rồi mới thật sự nối
  `GeckoTab` vào `BrowserActivity` thay `Tab`/`createWebView()`

---

## BƯỚC 7/7 (MỚI XONG): ĐÃ NỐI THẬT — `BrowserActivity.kt` giờ dùng GeckoView, không còn WebView

`BrowserActivity.kt` đã được viết lại hoàn toàn để dùng `GeckoTab`/`GeckoSession` thay
`Tab`/`WebView`. Bản gốc dùng WebView được giữ nguyên ở `BrowserActivity.kt.bak` (KHÔNG đóng gói
vào file zip build) để đối chiếu hoặc khôi phục nếu cần quay lại.

**QUAN TRỌNG: đây là lần nối đầu tiên, CHƯA build/chạy thử trên máy thật hay CI nào cả.** Vì
GeckoView không compile/chạy được ở môi trường viết code này (không có mạng để tải Gradle/Maven),
toàn bộ phần dưới đây chỉ được viết dựa trên tra cứu javadoc GeckoView, CHƯA được xác nhận bằng
build thật. Việc đầu tiên cần làm: build qua GitHub Actions, sửa mọi lỗi compile phát sinh (nhiều
khả năng có, xem danh sách rủi ro bên dưới), rồi mới test tính năng trên điện thoại.

### Những gì đã hoạt động đúng theo thiết kế (rủi ro thấp — đã dựng kỹ ở bước 1-6)
- Đa tab, chuyển tab, đóng tab, mở tab mới, khôi phục phiên (`MainActivity`)/tab trắng
  (`IncognitoActivity`)
- Chặn quảng cáo theo `blocklist.txt` (cấp navigation) + ETP built-in
- Fullscreen video (ẩn thanh tab/địa chỉ + immersive mode)
- JS bridge báo play/pause/error qua WebExtension (`mediaBridgeExtension`)
- Dịch trang qua `translate.goog` (thuần thao tác URL, không đụng engine)
- Đánh dấu trang, lịch sử URL đã lưu, cài đặt ẩn danh cơ bản (process riêng + `usePrivateMode`)

### FIXME / rủi ro cao — CẦN kiểm tra lại đúng javadoc GeckoView version trong `gradle.properties`
Tìm từ khoá `FIXME` trong `GeckoEngine.kt` và `BrowserActivity.kt` để thấy đúng vị trí — tóm tắt:
1. **`onCloseRequest`** (GeckoTab.ContentDelegate) — tên hàm chính xác cho sự kiện JS gọi
   `window.close()` chưa đối chiếu trực tiếp, đã đổi tên qua vài version GeckoView.
2. **`onContentPermissionRequest`** (quyền DRM/Widevine) — chữ ký hàm + tên hằng số
   `PERMISSION_MEDIA_KEY_SYSTEM_ACCESS`/`VALUE_ALLOW`/`VALUE_DENY` chưa xác nhận đúng version.
3. **`onBeforeUnloadPrompt` confirm()/dismiss()** — ngữ nghĩa "cho rời trang hay không" suy luận
   từ hành vi `JsResult` cũ, có thể bị đảo ngược.
4. **Bật/tắt JavaScript** — chưa xác nhận GeckoView có API tắt JS theo từng session hay không;
   tuỳ chọn trong Cài đặt hiện chỉ lưu giá trị, CHƯA thật sự có tác dụng (xem `applySettings()`).
5. **Xoá dữ liệu duyệt web** (`clearBrowsingData()`) — chỉ đóng lại các tab đang mở, CHƯA gọi
   đúng API `StorageController` của `GeckoRuntime` để xoá cookie/cache thật sự (tên hằng số
   `ClearFlags` chưa được đối chiếu).
6. **Báo lỗi tải trang/SSL** (`onReceivedError`/`onReceivedHttpError`/`onReceivedSslError` cũ) —
   CHƯA nối lại, `showLoadErrorToast()` hiện không được gọi từ đâu cả.
7. **Log console JS** (`onConsoleMessage` cũ) — CHƯA nối lại, nhật ký console giờ chỉ còn log của
   app, không còn log JS của trang.
8. **Hành vi phát audio nền khi khoá máy** — `BackgroundAudioWebView` (hack riêng cho Chromium)
   đã bỏ hẳn vì không áp dụng được cho GeckoView; hành vi thật của Gecko lúc tắt màn hình trong
   khi phát media **hoàn toàn chưa được kiểm chứng** — đây là rủi ro lớn nhất, đúng như lo ngại đã
   nêu từ bước 1.
9. **Popup "ăn theo"**: `onNewSession` của GeckoView không báo `isUserGesture` như
   `onCreateWindow` cũ — giờ chặn popup hoàn toàn theo mốc thời gian 1200ms, có thể chặn nhầm
   popup hợp lệ mở nhanh liên tiếp.

### Cố tình bỏ (không có API tương đương ở GeckoView, hoặc không cần thiết)
`getDefaultVideoPoster()` hack, thay `"wv"` trong user agent, `mixedContentMode`,
`builtInZoomControls`/`displayZoomControls`, `offscreenPreRaster`, `saveFormData`,
`pauseAllWebMedia()`/`resumeAllWebMedia()` (vốn đã không được gọi ở đâu trong bản cũ).

### Việc cần làm tiếp theo
1. Build qua GitHub Actions, sửa lỗi compile (ưu tiên đúng 9 điểm FIXME ở trên)
2. Chạy checklist kiểm thử đã nêu ở lượt trao đổi trước (fullscreen, chặn quảng cáo, tab ẩn danh,
   phát audio nền khi khoá máy, log console)
3. Sau khi ổn định, có thể xoá hẳn `BrowserActivity.kt.bak`, `BackgroundAudioWebView.kt` và các
   dòng `CookieManager`/`WebStorage` vô hại còn sót trong `IncognitoActivity.kt`

## Nâng cấp gợi ý sau này (nói "Vá" hoặc "Tiếp" nếu muốn làm)
- Chặn tracker theo từng site riêng (hiện là cài đặt toàn cục)
- Nút Play/Pause thật trên thông báo (nối MediaSession callback vào JS play()/pause())
- Xin miễn trừ tối ưu hoá pin 1 lần khi bắt đầu phát media (để ổn định hơn trên Xiaomi/Oppo/Vivo/Samsung)
