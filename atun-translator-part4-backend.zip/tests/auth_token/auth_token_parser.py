"""Đọc thẳng logic parse header "Authorization: Bearer <token>" từ chính file index.ts thật
(groq-relay) - giống cách tiếp cận của tests/model_catalog/catalog_parser.py trước đây (đọc
file .kt thật thay vì hand-port).

Phần thực thi logic (extract_bearer_token) vẫn phải hand-port sang Python vì Deno không chạy
được trong môi trường test này - nhưng được RÀNG BUỘC phải khớp đúng chuỗi literal "Bearer "
trích ra từ chính source thật ở dưới, nên nếu source thay đổi cách viết mà test không cập nhật
theo, get_bearer_prefix() sẽ đổi giá trị và các test case bên dưới lộ ra ngay (không im lặng pass
trên 1 bản copy đã lỗi thời).
"""

from __future__ import annotations

import re
from pathlib import Path

# tests/auth_token/auth_token_parser.py -> parents[2] = thư mục gốc repo
REPO_ROOT = Path(__file__).resolve().parents[2]
GROQ_RELAY_PATH = REPO_ROOT / "supabase-functions" / "groq-relay" / "index.ts"

# Khớp:  const token = authz.startsWith("Bearer ") ? authz.slice(7).trim() : "";
_TOKEN_LINE_RE = re.compile(
    r"""authz\.startsWith\((['"])(?P<prefix>[^'"]*)\1\)\s*
        \?\s*authz\.slice\((?P<slice_len>\d+)\)\.trim\(\)\s*
        :\s*(['"])\4""",
    re.VERBOSE,
)


def extract_bearer_prefix_and_slice(path: Path) -> tuple[str, int]:
    """Đọc file .ts thật, trả về (prefix, slice_len) từ dòng parse token.

    Raise nếu KHÔNG tìm thấy dòng đúng dạng - test phải FAIL rõ ràng nếu ai đó đổi cách viết
    trong index.ts mà không cập nhật test này, thay vì im lặng bỏ qua.
    """
    text = path.read_text(encoding="utf-8")
    m = _TOKEN_LINE_RE.search(text)
    if not m:
        raise ValueError(f"Không tìm thấy dòng parse Bearer token trong {path}")
    return m.group("prefix"), int(m.group("slice_len"))


def extract_bearer_token(authz: str, prefix: str, slice_len: int) -> str:
    """Hand-port đúng biểu thức JS: authz.startsWith(prefix) ? authz.slice(slice_len).trim() : ""

    Lưu ý JS .slice(N) cắt theo UTF-16 code unit, Python [N:] cắt theo code point - khác nhau
    nếu prefix có ký tự ngoài BMP (không xảy ra ở đây vì prefix chỉ gồm ASCII "Bearer ").
    """
    if not authz.startswith(prefix):
        return ""
    return authz[slice_len:].strip()
