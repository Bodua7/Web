"""Test cho luồng parse header Authorization: Bearer <token> dùng trong verifyUser() (xem
groq-relay/index.ts) - phần LOGIC PHỤ THUỘC MẠNG (gọi thật lên supabaseAdmin.auth.getUser())
không test được ở đây, nhưng phần TÁCH TOKEN KHỎI HEADER thì có, và đây chính là chỗ dễ viết sai
nhất (thiếu dấu cách sau "Bearer", quên .trim(), sai độ dài slice).
"""

from __future__ import annotations

from auth_token_parser import (
    GROQ_RELAY_PATH,
    extract_bearer_prefix_and_slice,
    extract_bearer_token,
)

import pytest


def test_source_uses_bearer_prefix_with_trailing_space():
    """Phải dùng đúng "Bearer " (có dấu cách) - thiếu dấu cách sẽ khiến slice(7) cắt nhầm 1 ký
    tự đầu của token thật."""
    prefix, slice_len = extract_bearer_prefix_and_slice(GROQ_RELAY_PATH)
    assert prefix == "Bearer "
    assert slice_len == len(prefix)


@pytest.fixture
def parse():
    prefix, slice_len = extract_bearer_prefix_and_slice(GROQ_RELAY_PATH)

    def _parse(authz: str) -> str:
        return extract_bearer_token(authz, prefix, slice_len)

    return _parse


def test_valid_bearer_header(parse):
    assert parse("Bearer abc.def.ghi") == "abc.def.ghi"


def test_missing_header(parse):
    assert parse("") == ""


def test_wrong_scheme(parse):
    assert parse("Basic dXNlcjpwYXNz") == ""


def test_lowercase_bearer_is_rejected(parse):
    # HTTP header value case-sensitive theo RFC 7235 cho scheme - "bearer" thường (không phải
    # "Bearer") KHÔNG được chấp nhận. Nếu client nào đó gửi sai case, request phải bị coi là
    # thiếu token (401), không được âm thầm chấp nhận.
    assert parse("bearer abc.def.ghi") == ""


def test_bearer_without_trailing_space_is_rejected(parse):
    assert parse("Bearertoken") == ""


def test_bearer_with_only_whitespace_token(parse):
    # "Bearer    " (token rỗng sau khi trim) phải trả về "" (rỗng), để verifyUser() coi như
    # KHÔNG có token thay vì gọi supabaseAdmin.auth.getUser("") lãng phí 1 lần gọi mạng.
    assert parse("Bearer    ") == ""


def test_bearer_token_with_surrounding_whitespace_is_trimmed(parse):
    assert parse("Bearer  abc.def.ghi  ") == "abc.def.ghi"


def test_empty_bearer_prefix_alone(parse):
    assert parse("Bearer ") == ""
