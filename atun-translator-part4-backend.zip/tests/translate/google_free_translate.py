"""Port thuần Python của translateGoogleFree() trong www/index.html.

MỤC ĐÍCH: test logic retry/backoff khi endpoint free translate.googleapis.com
trả về HTTP 429 (rate-limit), KHÔNG cần build app + chờ bị rate-limit thật để
biết retry có đúng số lần/đúng thời gian chờ hay không. Cùng cách tiếp cận đã
dùng cho VadDetector (xem tests/vad/).

QUAN TRỌNG - giữ đồng bộ 2 chiều:
Đây là bản dịch tay từ JS, KHÔNG phải import trực tiếp. Mỗi khi sửa hàm
translateGoogleFree() trong www/index.html (đổi số lần retry mặc định, công
thức waitMs, điều kiện dừng...) phải cập nhật lại file này cho khớp.

Bản gốc JS (www/index.html):

    async function translateGoogleFree(text, targetLang, retriesLeft = 3) {
      const url = 'https://translate.googleapis.com/translate_a/single'
        + '?client=gtx&sl=auto&tl=' + encodeURIComponent(targetLang)
        + '&dt=t&q=' + encodeURIComponent(text);
      const res = await fetch(url);
      if (res.status === 429 && retriesLeft > 0) {
        const waitMs = (4 - retriesLeft) * 1000; // 1s, 2s, 3s
        log('Dịch bị rate-limit (429), thử lại sau ' + waitMs + 'ms...');
        await new Promise((resolve) => setTimeout(resolve, waitMs));
        return translateGoogleFree(text, targetLang, retriesLeft - 1);
      }
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();
      return data[0].map(seg => seg[0]).join('');
    }

Khác biệt duy nhất so với bản JS: `fetch` và `sleep` được truyền vào (dependency
injection) thay vì gọi thẳng `fetch()`/`setTimeout()` toàn cục của trình duyệt,
để test có thể giả lập response/đo thời gian chờ mà không cần mạng thật và
không phải chờ thật vài giây mỗi lần chạy pytest.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import dataclass

# retriesLeft mặc định trong JS: async function translateGoogleFree(text, targetLang, retriesLeft = 3)
DEFAULT_RETRIES_LEFT = 3


@dataclass
class FakeResponse:
    """Tương đương tối thiểu của đối tượng Response mà fetch() trả về trong JS -
    chỉ cần đúng 2 thứ hàm gốc dùng tới: res.status (qua status_code) và res.json()."""

    status_code: int
    body: object = None  # payload trả về khi gọi .json(), format giống translate.googleapis.com:
    # [[ [translated_seg, original_seg, ...], ... ], ...]

    def json(self):
        return self.body


class GoogleFreeTranslateError(Exception):
    """Tương đương `throw new Error('HTTP ' + res.status)` trong bản JS gốc."""


def translate_google_free(
    text: str,
    target_lang: str,
    fetch: Callable[[str, str], FakeResponse],
    sleep: Callable[[float], None],
    retries_left: int = DEFAULT_RETRIES_LEFT,
) -> str:
    """Port 1-1 của translateGoogleFree() - xem docstring module để đối chiếu bản JS gốc.

    fetch(text, target_lang) -> FakeResponse: đóng vai trò `await fetch(url)` trong JS,
    nhận (text, target_lang) thay vì url đã build sẵn vì phần build URL (encodeURIComponent)
    không phải logic cần test ở đây.
    sleep(seconds): đóng vai trò `await new Promise(r => setTimeout(r, waitMs))`.
    """
    res = fetch(text, target_lang)

    if res.status_code == 429 and retries_left > 0:
        wait_ms = (4 - retries_left) * 1000  # đúng công thức JS: 1000, 2000, 3000
        sleep(wait_ms / 1000)
        return translate_google_free(text, target_lang, fetch, sleep, retries_left - 1)

    if not (200 <= res.status_code < 300):
        raise GoogleFreeTranslateError(f"HTTP {res.status_code}")

    data = res.json()
    # data[0].map(seg => seg[0]).join('') trong JS
    return "".join(seg[0] for seg in data[0])


def make_fixed_status_fetch(statuses: Sequence[int], body_on_success: object):
    """Helper cho test: trả về lần lượt các status trong `statuses` qua các lần gọi
    liên tiếp (mỗi lần gọi fetch() tiêu 1 phần tử), status cuối cùng dùng lại mãi nếu
    gọi nhiều hơn len(statuses). Ghi lại toàn bộ lời gọi vào .calls để assert."""

    calls: list[tuple[str, str]] = []
    idx = {"i": 0}

    def fetch(text: str, target_lang: str) -> FakeResponse:
        calls.append((text, target_lang))
        i = min(idx["i"], len(statuses) - 1)
        status = statuses[i]
        idx["i"] += 1
        return FakeResponse(status_code=status, body=body_on_success if status < 300 else None)

    fetch.calls = calls  # type: ignore[attr-defined]
    return fetch
