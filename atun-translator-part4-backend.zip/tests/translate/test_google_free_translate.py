"""Test cho translate_google_free (bản port Python của translateGoogleFree()
trong www/app.js). Chạy: cd tests/translate && pip install pytest && pytest -v

Mục tiêu: bắt được ngay lập tức khi sửa số lần retry, công thức waitMs, hoặc
điều kiện dừng làm hỏng hành vi mong đợi (vd sửa công thức
`Math.pow(2, 4 - retriesLeft) * 1000` thành công thức khác, hoặc quên check
retries_left > 0 gây lặp vô hạn).
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from google_free_translate import (
    DEFAULT_RETRIES_LEFT,
    GoogleFreeTranslateError,
    make_fixed_status_fetch,
    translate_google_free,
)


GOOGLE_BODY = [[["Xin chào", "Hello", None, None, 1]], None, "en"]


def make_recording_sleep():
    waits: list[float] = []

    def sleep(seconds: float) -> None:
        waits.append(seconds)

    sleep.waits = waits  # type: ignore[attr-defined]
    return sleep


# ===== Thành công ngay lần đầu - không retry ===== #

def test_success_first_try_no_retry_no_sleep():
    fetch = make_fixed_status_fetch([200], GOOGLE_BODY)
    sleep = make_recording_sleep()

    result = translate_google_free("Hello", "vi", fetch, sleep)

    assert result == "Xin chào"
    assert len(fetch.calls) == 1
    assert sleep.waits == []


def test_success_joins_multiple_segments():
    body = [[["Xin ", None, None, None, 1], ["chào", None, None, None, 1]], None, "en"]
    fetch = make_fixed_status_fetch([200], body)
    sleep = make_recording_sleep()

    result = translate_google_free("Hello", "vi", fetch, sleep)

    assert result == "Xin chào"


# ===== Retry đúng số lần, đúng thời gian chờ ===== #

def test_retries_on_429_then_succeeds():
    # 429, 429, rồi 200 - phải retry đúng 2 lần rồi thành công ở lần gọi thứ 3.
    fetch = make_fixed_status_fetch([429, 429, 200], GOOGLE_BODY)
    sleep = make_recording_sleep()

    result = translate_google_free("Hello", "vi", fetch, sleep)

    assert result == "Xin chào"
    assert len(fetch.calls) == 3
    # Fix (audit - "test còn theo công thức backoff CŨ"): công thức JS hiện tại là
    # waitMs = Math.pow(2, 4 - retriesLeft) * 1000 (exponential, kéo dài từ tuyến tính
    # 1s/2s/3s cũ - xem comment trong google_free_translate.py), retriesLeft bắt đầu = 3
    # -> lần retry đầu retriesLeft=3 -> wait 2^1*1000=2000ms=2.0s,
    #    lần 2 retriesLeft=2 -> wait 2^2*1000=4000ms=4.0s
    assert sleep.waits == [2.0, 4.0]


def test_wait_times_follow_exact_formula_2s_4s_8s():
    # Luôn 429 để retry hết cả 3 lần (DEFAULT_RETRIES_LEFT = 3) trước khi bỏ cuộc.
    fetch = make_fixed_status_fetch([429], GOOGLE_BODY)
    sleep = make_recording_sleep()

    try:
        translate_google_free("Hello", "vi", fetch, sleep)
    except GoogleFreeTranslateError:
        pass

    assert sleep.waits == [2.0, 4.0, 8.0]


def test_exhausts_retries_then_raises_with_final_status():
    fetch = make_fixed_status_fetch([429], GOOGLE_BODY)
    sleep = make_recording_sleep()

    try:
        translate_google_free("Hello", "vi", fetch, sleep)
        assert False, "phải raise GoogleFreeTranslateError"
    except GoogleFreeTranslateError as e:
        assert "429" in str(e)

    # 1 lần gọi đầu (retries_left=3) + 3 lần retry (retries_left=2,1,0) = 4 lần gọi fetch,
    # nhưng lần retries_left=0 không còn thoả điều kiện retry nữa nên KHÔNG retry thêm -
    # tổng cộng đúng 4 lần gọi fetch (1 gốc + 3 retry).
    assert len(fetch.calls) == DEFAULT_RETRIES_LEFT + 1
    assert len(sleep.waits) == DEFAULT_RETRIES_LEFT


# ===== Lỗi khác 429 - không retry, raise ngay ===== #

def test_non_429_error_raises_immediately_no_retry():
    fetch = make_fixed_status_fetch([500], GOOGLE_BODY)
    sleep = make_recording_sleep()

    try:
        translate_google_free("Hello", "vi", fetch, sleep)
        assert False, "phải raise GoogleFreeTranslateError"
    except GoogleFreeTranslateError as e:
        assert "500" in str(e)

    assert len(fetch.calls) == 1  # không retry cho lỗi khác 429
    assert sleep.waits == []  # không chờ gì cả


def test_404_raises_immediately_no_retry():
    fetch = make_fixed_status_fetch([404], GOOGLE_BODY)
    sleep = make_recording_sleep()

    try:
        translate_google_free("Hello", "vi", fetch, sleep)
        assert False, "phải raise GoogleFreeTranslateError"
    except GoogleFreeTranslateError:
        pass

    assert len(fetch.calls) == 1


# ===== retries_left tuỳ chỉnh (không dùng mặc định) ===== #

def test_custom_retries_left_zero_never_retries():
    fetch = make_fixed_status_fetch([429], GOOGLE_BODY)
    sleep = make_recording_sleep()

    try:
        translate_google_free("Hello", "vi", fetch, sleep, retries_left=0)
        assert False, "phải raise GoogleFreeTranslateError"
    except GoogleFreeTranslateError:
        pass

    assert len(fetch.calls) == 1  # retries_left=0 ngay từ đầu -> không đủ điều kiện retry (>0)
    assert sleep.waits == []
