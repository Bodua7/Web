"""Bản dịch tay của phần LOGIC CẮT ĐOẠN (segment cutting) dùng trong Whisper
Cloud (Groq) - đường DUY NHẤT còn lại để nhận diện giọng nói (đã bỏ Vosk
offline). Trải trên 2 file Kotlin thật:

  - `native/SttSegmentCutter.kt`: class THUẦN (không đụng AudioRecord/Thread/
    Service) - được port ĐẦY ĐỦ ở dưới (`SttSegmentCutter`, khớp tên với bản
    Kotlin, kể cả phần "nhận giọng ca sĩ khi hát" -
    `is_likely_continuous_music()`/`just_crossed_continuous_music_hint()`).
    Có bản test JUnit song song: `native-test/SttSegmentCutterTest.kt`.
  - `native/SttReadLoop.kt` (hàm `startCloudSttReadLoop()`): vòng lặp đọc
    AudioRecord thật + `pcmBuffer` (ByteArrayOutputStream) + hàm cục bộ
    `flushSegment()` - GHÉP `SttSegmentCutter` (ở trên) với kích thước buffer
    thật để quyết định có ĐÁNG gửi lên Whisper hay không
    (`cutter.hasVoice() && pcmBuffer.size() >= CLOUD_SEGMENT_MIN_BYTES`).
    Phần ghép này được port lại thành `CloudSttSegmenter` ở dưới - không phải
    kiến trúc 1-1 với Kotlin (SttReadLoop.kt gắn liền AudioRecord thật), chỉ
    mô phỏng lại đúng HÀNH VI ghép nối, nhận trực tiếp `read_bytes`/
    `is_voice` làm input thay vì tự đọc AudioRecord/chạy VadDetector thật.

Fix (audit - "port đang mô tả kiến trúc cũ"): bản trước đây mô tả
`segmentStartAt`/`lastVoiceAt`/`hasVoiceInSegment` như 3 biến closure rời
rạc nằm thẳng trong `startCloudSttReadLoop()` - đúng ở thời điểm viết lần
đầu, nhưng từ "audit đợt 2" (xem comment trong SttReadLoop.kt) 3 biến này +
logic quyết định đã được tách hẳn thành class `SttSegmentCutter` riêng,
KHÔNG còn là closure vars nữa. Bản trước cũng chưa từng port tính năng
"nhận giọng ca sĩ khi hát" (`consecutiveMaxDurationFlushes`, ngưỡng
`CONTINUOUS_MUSIC_HINT_THRESHOLD=3`, `isLikelyContinuousMusic()`,
`justCrossedContinuousMusicHint()`) được thêm vào SAU khi bản port này viết
lần đầu - đã bổ sung đầy đủ ở dưới, xem test tương ứng trong
test_cloud_stt_segment.py.

CỐ Ý KHÔNG port: AudioRecord.read() thật, Base64 encode, gọi
AudioCapturePlugin.emitCloudSttSegment()/emitPossibleMusicDetected() (JNI/JS
bridge), VadDetector.process() thật (native/VadDetector.kt, đã có port +
test riêng) - chỉ port state machine điều khiển KHI NÀO flush + KHI NÀO coi
là "giống nhạc", nhận trực tiếp is_voice (bool) làm input để tách rời khỏi
VAD thật.

Không import trực tiếp từ .kt - mỗi khi sửa `SttSegmentCutter.kt` (đổi
CLOUD_SEGMENT_PAUSE_MS/MAX_MS/MIN_BYTES trong AudioCaptureService.kt, đổi thứ
tự 2 điều kiện cắt đoạn, đổi ngưỡng CONTINUOUS_MUSIC_HINT_THRESHOLD, đổi hành
vi reset của bộ đếm nhạc...) thì phải sửa lại file này cho khớp.
"""

from __future__ import annotations

from dataclasses import dataclass

# ===== Hằng số cắt đoạn - PHẢI khớp companion object trong AudioCaptureService.kt ===== #

CLOUD_SEGMENT_PAUSE_MS = 600
CLOUD_SEGMENT_MAX_MS = 12000
CLOUD_SEGMENT_MIN_BYTES = 6000

# ===== Hằng số "nhận giọng ca sĩ khi hát" - PHẢI khớp companion object trong
# SttSegmentCutter.kt ===== #
CONTINUOUS_MUSIC_HINT_THRESHOLD = 3


class SttSegmentCutter:
    """Port 1-1 của class `SttSegmentCutter` (native/SttSegmentCutter.kt) -
    THUẦN logic thời điểm/có-giọng-nói-hay-không, KHÔNG tự đếm byte PCM (xem
    comment ở đầu file Kotlin đó - pcmBuffer thật nằm ở SttReadLoop.kt, tránh
    trùng 1 nguồn sự thật). Tên hàm giữ khớp bản Kotlin (chỉ đổi camelCase ->
    snake_case) để dễ đối chiếu khi Kotlin đổi hành vi.
    `last_flush_was_max_duration()`: KHÔNG có bản tương đương public trong
    Kotlin (field đó private) - thêm riêng cho test harness này để phân biệt
    lý do cắt đoạn (pause/max_duration) khi viết assertion, không phải 1 phần
    API mà SttReadLoop.kt thật sự gọi tới.
    """

    def __init__(self, pause_ms: int, max_segment_ms: int):
        self._pause_ms = pause_ms
        self._max_segment_ms = max_segment_ms
        self._has_voice_in_segment = False
        self._segment_start_at = 0
        self._last_voice_at = 0
        # Sống xuyên suốt nhiều đoạn - reset() (dọn state của 1 đoạn) KHÔNG đụng
        # tới 2 biến dưới đây, giống hệt Kotlin (xem comment tại khai báo trong .kt).
        self._consecutive_max_duration_flushes = 0
        self._last_flush_was_max_duration = False

    def reset(self, now: int) -> None:
        self._has_voice_in_segment = False
        self._segment_start_at = now
        self._last_voice_at = now

    def on_frame(self, now: int, is_voice_frame: bool) -> None:
        if is_voice_frame:
            self._last_voice_at = now
            self._has_voice_in_segment = True

    def should_flush(self, now: int) -> bool:
        if self._has_voice_in_segment and (now - self._last_voice_at) >= self._pause_ms:
            self._consecutive_max_duration_flushes = 0
            self._last_flush_was_max_duration = False
            return True
        if (now - self._segment_start_at) >= self._max_segment_ms:
            self._consecutive_max_duration_flushes += 1
            self._last_flush_was_max_duration = True
            return True
        return False

    def has_voice(self) -> bool:
        return self._has_voice_in_segment

    def is_likely_continuous_music(self) -> bool:
        return self._consecutive_max_duration_flushes >= CONTINUOUS_MUSIC_HINT_THRESHOLD

    def just_crossed_continuous_music_hint(self) -> bool:
        return (
            self._last_flush_was_max_duration
            and self._consecutive_max_duration_flushes == CONTINUOUS_MUSIC_HINT_THRESHOLD
        )

    def last_flush_was_max_duration(self) -> bool:
        """Chỉ dùng cho test harness này (xem docstring lớp) - gán nhãn
        reason="pause"|"max_duration" trong CloudSttSegmenter bên dưới."""
        return self._last_flush_was_max_duration


@dataclass(frozen=True)
class FlushResult:
    """Kết quả 1 lần flushSegment(). `emitted=False` nghĩa là đoạn bị bỏ qua
    (toàn im lặng, hoặc quá ngắn) — KHÔNG tốn request Whisper, khớp điều
    kiện `if (cutter.hasVoice() && pcmBuffer.size() >= CLOUD_SEGMENT_MIN_BYTES)`
    trong SttReadLoop.kt. `likely_music`/`just_crossed_music_hint` khớp đúng
    2 giá trị SttReadLoop.kt đọc từ cutter NGAY SAU shouldFlush(), TRƯỚC khi
    gọi reset() cho đoạn kế tiếp (xem SttSegmentCutter.isLikelyContinuousMusic()/
    justCrossedContinuousMusicHint())."""

    emitted: bool
    pcm_bytes: int
    reason: str  # "pause" | "max_duration" | "final"
    likely_music: bool = False
    just_crossed_music_hint: bool = False


class CloudSttSegmenter:
    """Port của phần GHÉP `SttSegmentCutter` (ở trên) với `pcmBuffer` +
    `flushSegment()` trong SttReadLoop.kt - xem docstring đầu file. Thời gian
    truyền vào bằng mili-giây tuyệt đối do caller tự quản lý (test dùng số
    nguyên đơn giản thay System.currentTimeMillis() thật)."""

    def __init__(self, now_ms: int):
        self._pcm_bytes = 0
        self._cutter = SttSegmentCutter(CLOUD_SEGMENT_PAUSE_MS, CLOUD_SEGMENT_MAX_MS)
        self._cutter.reset(now_ms)

    @property
    def pcm_bytes(self) -> int:
        return self._pcm_bytes

    @property
    def has_voice_in_segment(self) -> bool:
        return self._cutter.has_voice()

    def _flush(self, now_ms: int, reason: str) -> FlushResult:
        emitted = self._cutter.has_voice() and self._pcm_bytes >= CLOUD_SEGMENT_MIN_BYTES
        # Đọc likely_music/just_crossed NGAY TRƯỚC reset() - khớp đúng thứ tự
        # SttReadLoop.kt (đọc cutter rồi mới gọi flushSegment() -> cutter.reset()).
        likely_music = self._cutter.is_likely_continuous_music()
        just_crossed = self._cutter.just_crossed_continuous_music_hint()
        result = FlushResult(
            emitted=emitted,
            pcm_bytes=self._pcm_bytes,
            reason=reason,
            likely_music=likely_music,
            just_crossed_music_hint=just_crossed,
        )
        self._pcm_bytes = 0
        self._cutter.reset(now_ms)
        return result

    def process_read(self, read_bytes: int, is_voice: bool, now_ms: int) -> FlushResult | None:
        """Port của 1 vòng lặp `while (isCapturing)` khi `read > 0`: ghi
        thêm bytes vào buffer, gọi on_frame()/should_flush() ĐÚNG THỨ TỰ như
        Kotlin (pause trước, max-duration sau — 2 điều kiện loại trừ nhau
        qua if/else if nên thứ tự quyết định lý do được ghi nhận khi cả 2
        cùng đúng lúc)."""
        self._pcm_bytes += read_bytes
        self._cutter.on_frame(now_ms, is_voice)
        if self._cutter.should_flush(now_ms):
            reason = "max_duration" if self._cutter.last_flush_was_max_duration() else "pause"
            return self._flush(now_ms, reason)
        return None

    def flush_final(self, now_ms: int) -> FlushResult:
        """Port của lệnh flushSegment() gọi 1 lần cuối SAU khi thoát vòng lặp
        `while (isCapturing)` — đẩy nốt đoạn dang dở khi user bấm dừng nghe
        giữa câu, tránh mất trắng câu cuối. KHÔNG đi qua should_flush() (native
        cũng gọi thẳng flushSegment() ở đây, không qua cutter.shouldFlush())."""
        return self._flush(now_ms, "final")
