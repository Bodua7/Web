"""Bản dịch tay của phần LOGIC CẮT ĐOẠN (segment cutting) trong
`startCloudSttReadLoop()` (`native/SttReadLoop.kt`, tính năng
"Whisper Cloud (Groq)" - đường DUY NHẤT còn lại để nhận diện giọng nói) -
quyết định KHI NÀO gộp audio đang thu thành 1 đoạn (segment) để gửi lên
groq-relay?op=transcribe.

CỐ Ý KHÔNG port: AudioRecord.read() thật, Base64 encode, gọi
AudioCapturePlugin.emitCloudSttSegment() (JNI/JS bridge), VadDetector.process()
thật (native/VadDetector.kt) - chỉ port state machine điều khiển KHI NÀO
flush, nhận trực tiếp is_voice (bool) làm input để tách rời khỏi VAD thật.

Không import trực tiếp từ .kt - mỗi khi sửa `startCloudSttReadLoop()` trong
SttReadLoop.kt (đổi CLOUD_SEGMENT_PAUSE_MS/MAX_MS/MIN_BYTES, đổi thứ
tự 2 điều kiện cắt đoạn, đổi hành vi flush cuối vòng lặp...) thì phải sửa lại
file này cho khớp.
"""

from __future__ import annotations

from dataclasses import dataclass

# ===== Hằng số — PHẢI khớp companion object trong AudioCaptureService.kt ===== #

CLOUD_SEGMENT_PAUSE_MS = 600
CLOUD_SEGMENT_MAX_MS = 12000
CLOUD_SEGMENT_MIN_BYTES = 6000


@dataclass(frozen=True)
class FlushResult:
    """Kết quả 1 lần flushSegment(). `emitted=False` nghĩa là đoạn bị bỏ qua
    (toàn im lặng, hoặc quá ngắn) — KHÔNG tốn request Whisper, khớp điều
    kiện `if (hasVoiceInSegment && pcmBuffer.size() >= CLOUD_SEGMENT_MIN_BYTES)`
    trong Kotlin."""

    emitted: bool
    pcm_bytes: int
    reason: str  # "pause" | "max_duration" | "final"


class CloudSttSegmenter:
    """Port của các biến closure trong startCloudSttReadLoop(): pcmBuffer,
    segmentStartAt, lastVoiceAt, hasVoiceInSegment + hàm flushSegment().
    Thời gian truyền vào bằng mili-giây tuyệt đối do caller tự quản lý (test
    dùng số nguyên đơn giản thay System.currentTimeMillis() thật)."""

    def __init__(self, now_ms: int):
        self._pcm_bytes = 0
        self._segment_start_at = now_ms
        self._last_voice_at = now_ms
        self._has_voice_in_segment = False

    @property
    def pcm_bytes(self) -> int:
        return self._pcm_bytes

    @property
    def has_voice_in_segment(self) -> bool:
        return self._has_voice_in_segment

    def _flush(self, now_ms: int, reason: str) -> FlushResult:
        emitted = self._has_voice_in_segment and self._pcm_bytes >= CLOUD_SEGMENT_MIN_BYTES
        result = FlushResult(emitted=emitted, pcm_bytes=self._pcm_bytes, reason=reason)
        self._pcm_bytes = 0
        self._has_voice_in_segment = False
        self._segment_start_at = now_ms
        return result

    def process_read(self, read_bytes: int, is_voice: bool, now_ms: int) -> FlushResult | None:
        """Port của 1 vòng lặp `while (isCapturing)` khi `read > 0`: ghi
        thêm bytes vào buffer, cập nhật hasVoiceInSegment/lastVoiceAt, rồi
        kiểm tra 2 điều kiện cắt đoạn ĐÚNG THỨ TỰ như Kotlin (pause trước,
        max-duration sau — 2 điều kiện loại trừ nhau qua if/else if nên thứ
        tự quyết định lý do được ghi nhận khi cả 2 cùng đúng lúc)."""
        self._pcm_bytes += read_bytes

        if is_voice:
            self._last_voice_at = now_ms
            self._has_voice_in_segment = True

        if self._has_voice_in_segment and (now_ms - self._last_voice_at) >= CLOUD_SEGMENT_PAUSE_MS:
            return self._flush(now_ms, "pause")
        elif (now_ms - self._segment_start_at) >= CLOUD_SEGMENT_MAX_MS:
            return self._flush(now_ms, "max_duration")
        return None

    def flush_final(self, now_ms: int) -> FlushResult:
        """Port của lệnh flushSegment() gọi 1 lần cuối SAU khi thoát vòng lặp
        `while (isCapturing)` — đẩy nốt đoạn dang dở khi user bấm dừng nghe
        giữa câu, tránh mất trắng câu cuối."""
        return self._flush(now_ms, "final")
