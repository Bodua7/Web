# Test harness cho Whisper Cloud STT — cắt đoạn & đóng gói WAV (Hạng mục I)

Port thuần Python của 2 mảng LOGIC THUẦN trong `startCloudSttReadLoop()`
(`native/AudioCaptureService.kt`, tính năng "🌩️ Dùng Whisper Cloud (Groq)"):
đóng gói PCM16 thành file WAV, và state machine quyết định KHI NÀO cắt 1
đoạn audio để gửi lên `groq-relay?op=transcribe`. Trước bộ test này, tính
năng chỉ được "verify" bằng cách đếm ngoặc `{}`/`()` cân bằng trong file
`.kt` (không build/chạy thật được ở môi trường viết code) — bộ này chạy
được hành vi thật mà không cần máy Android/mic thật.

`AudioCaptureService.kt` (47KB, file lớn nhất repo) trước đó không có test
tự động nào.

## Chạy test

```bash
cd tests/cloud_stt_segment
pip install pytest
pytest -v
```

## Cấu trúc

- `wav_builder.py` — port 1-1 của `shortsToBytesLE()` + `buildWavFile()`:
  PCM16 mono little-endian, header WAV 44 byte chuẩn (RIFF/WAVE/fmt /data,
  ChunkSize=36+pcm, AudioFormat=1, NumChannels=1, BlockAlign=2,
  BitsPerSample=16 — đúng giá trị hardcode trong Kotlin).
- `segment_cutter.py` — port của các biến closure + `flushSegment()` trong
  `startCloudSttReadLoop()` (`pcmBuffer`, `segmentStartAt`, `lastVoiceAt`,
  `hasVoiceInSegment`), nhận trực tiếp `is_voice: bool` làm input (tách
  khỏi `VadDetector` thật — đã có port riêng ở `tests/vad/`, không port lại
  ở đây) để test riêng phần "khi nào cắt đoạn", không lẫn với "VAD có đúng
  không".
- `test_cloud_stt_segment.py` — 23 test case bao phủ: cấu trúc byte của WAV
  (marker RIFF/WAVE/fmt /data, các trường hardcode, ChunkSize/data size,
  sample rate/byte rate, PCM giữ nguyên sau header), và state machine cắt
  đoạn — cắt theo pause (`CLOUD_SEGMENT_PAUSE_MS`) CHỈ khi đã từng có
  voice, cắt theo `CLOUD_SEGMENT_MAX_MS` dù không có pause (người nói liên
  tục), bỏ qua (không emit) đoạn quá ngắn/toàn im lặng theo
  `CLOUD_SEGMENT_MIN_BYTES`, thứ tự ưu tiên `if/else if` giữa 2 điều kiện
  cắt khi cả 2 cùng đúng, việc nói lại giữa chừng chỉ dời mốc pause chứ
  không dời mốc max-duration, `flushSegment()` cuối vòng lặp đẩy nốt câu
  dang dở lúc user bấm dừng, và 1 kịch bản nhiều câu liên tiếp.

## ⚠️ Bắt buộc giữ đồng bộ

Cả 2 file port đều là bản dịch **tay**. Mỗi khi sửa `shortsToBytesLE()`,
`buildWavFile()`, hoặc phần khai báo biến/`flushSegment()`/2 điều kiện cắt
đoạn trong `startCloudSttReadLoop()` (đổi `CLOUD_SEGMENT_PAUSE_MS`/
`CLOUD_SEGMENT_MAX_MS`/`CLOUD_SEGMENT_MIN_BYTES`, đổi thứ tự if/else if,
đổi điều kiện emit...) thì phải sửa lại `wav_builder.py`/`segment_cutter.py`
cho khớp, rồi chạy lại `pytest`.

## Phạm vi CHƯA che phủ (cần build thật hoặc mic thật)

- `emitCloudSttSegment` thật qua JNI/Base64, AudioRecord/MediaProjection
  thật, WakeLock, foreground notification, resume qua `onStartCommand` khi
  service bị OS kill giữa chừng... - ngoài phạm vi lần này, cần máy
  Android thật.
- `VadDetector.process()` thật (đã có port riêng, xem `tests/vad/`) — bộ
  test này chỉ nhận `is_voice: bool` làm input giả lập, không gọi lại VAD
  thật.
