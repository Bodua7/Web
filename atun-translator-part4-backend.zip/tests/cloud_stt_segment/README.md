# Test harness cho Whisper Cloud STT — cắt đoạn & đóng gói WAV (Hạng mục I)

Port thuần Python của phần LOGIC THUẦN dùng trong Whisper Cloud (Groq) —
tính năng "🌩️ Dùng Whisper Cloud (Groq)", đường DUY NHẤT còn lại để nhận
diện giọng nói: đóng gói PCM16 thành file WAV (`native/AudioPcmUtils.kt`),
và state machine quyết định KHI NÀO cắt 1 đoạn audio để gửi lên
`groq-relay?op=transcribe` — bao gồm cả phương án "nhận giọng ca sĩ khi hát"
(`native/SttSegmentCutter.kt`). Trước bộ test này, các tính năng trên chỉ
được "verify" bằng cách đếm ngoặc `{}`/`()` cân bằng trong file `.kt` (không
build/chạy thật được ở môi trường viết code) — bộ này chạy được hành vi thật
mà không cần máy Android/mic thật.

Fix (audit - "README ghi sai vị trí/kích thước file"): bản trước đây ghi
"`native/AudioCaptureService.kt` (47KB, file lớn nhất repo) trước đó không
có test tự động nào" — cả 2 vế đều đã lệch so với thực tế hiện tại:
`AudioCaptureService.kt` đã được tách nhỏ qua nhiều đợt audit (còn ~17KB,
không còn là file lớn nhất repo — `www/app.js`/`app.module.js` mới là lớn
nhất), và 2 hàm WAV cũng đã dọn sang `AudioPcmUtils.kt` riêng (có
`native-test/AudioPcmUtilsTest.kt` JUnit thuần đi kèm) từ lâu.

## Chạy test

```bash
cd tests/cloud_stt_segment
pip install pytest
pytest -v
```

## Cấu trúc

- `wav_builder.py` — port 1-1 của `shortsToBytesLE()` + `buildWavFile()`
  (`native/AudioPcmUtils.kt`): PCM16 mono little-endian, header WAV 44 byte
  chuẩn (RIFF/WAVE/fmt /data, ChunkSize=36+pcm, AudioFormat=1, NumChannels=1,
  BlockAlign=2, BitsPerSample=16 — đúng giá trị hardcode trong Kotlin).
- `segment_cutter.py` — port của class `SttSegmentCutter`
  (`native/SttSegmentCutter.kt`: `hasVoiceInSegment`/`segmentStartAt`/
  `lastVoiceAt` + phương án "nhận giọng ca sĩ khi hát"
  `consecutiveMaxDurationFlushes`/`isLikelyContinuousMusic()`/
  `justCrossedContinuousMusicHint()`), ghép với phần buffer/`flushSegment()`
  trong `native/SttReadLoop.kt`. Nhận trực tiếp `is_voice: bool` làm input
  (tách khỏi `VadDetector` thật để test riêng phần "khi nào cắt đoạn",
  không lẫn với "VAD có đúng không" — `VadDetector` CHƯA có port Python
  riêng, chỉ có test JUnit thuần `native-test/VadDetectorTest.kt`, xem ghi
  chú trong `VadDetector.kt` về 1 kịch bản còn thiếu test).
- `test_cloud_stt_segment.py` — 27 test case bao phủ: cấu trúc byte của WAV
  (marker RIFF/WAVE/fmt /data, các trường hardcode, ChunkSize/data size,
  sample rate/byte rate, PCM giữ nguyên sau header), state machine cắt đoạn
  (cắt theo pause `CLOUD_SEGMENT_PAUSE_MS` CHỈ khi đã từng có voice, cắt
  theo `CLOUD_SEGMENT_MAX_MS` dù không có pause, bỏ qua đoạn quá ngắn/toàn
  im lặng theo `CLOUD_SEGMENT_MIN_BYTES`, thứ tự ưu tiên `if/else if` giữa 2
  điều kiện cắt khi cả 2 cùng đúng, nói lại giữa chừng chỉ dời mốc pause chứ
  không dời mốc max-duration, `flushSegment()` cuối vòng lặp đẩy nốt câu
  dang dở, 1 kịch bản nhiều câu liên tiếp), và phương án "nhận giọng ca sĩ
  khi hát" (chưa đạt ngưỡng vẫn `likely_music=False`, đạt ĐÚNG ngưỡng
  `CONTINUOUS_MUSIC_HINT_THRESHOLD` lần cắt liên tiếp do max_duration thì
  `likely_music=True` + `just_crossed_music_hint=True` CHỈ đúng 1 lần đó,
  các lần sau vẫn `likely_music=True` nhưng `just_crossed` về `False`, và 1
  lần cắt do pause thật xen giữa phải đưa bộ đếm về 0 hoàn toàn).

## ⚠️ Bắt buộc giữ đồng bộ

Cả 2 file port đều là bản dịch **tay**. Mỗi khi sửa `shortsToBytesLE()`/
`buildWavFile()` (`AudioPcmUtils.kt`), hoặc phần state/ngưỡng trong
`SttSegmentCutter.kt` (`CLOUD_SEGMENT_PAUSE_MS`/`CLOUD_SEGMENT_MAX_MS`/
`CLOUD_SEGMENT_MIN_BYTES` trong `AudioCaptureService.kt`,
`CONTINUOUS_MUSIC_HINT_THRESHOLD`, thứ tự if/else if, điều kiện emit, hành
vi reset bộ đếm nhạc...) thì phải sửa lại `wav_builder.py`/`segment_cutter.py`
cho khớp, rồi chạy lại `pytest`.

## Phạm vi CHƯA che phủ (cần build thật hoặc mic thật)

- `emitCloudSttSegment`/`emitPossibleMusicDetected` thật qua JNI/Base64,
  AudioRecord/MediaProjection thật, WakeLock, foreground notification,
  resume qua `onStartCommand` khi service bị OS kill giữa chừng... - ngoài
  phạm vi lần này, cần máy Android thật.
- `VadDetector.process()` thật — bộ test này chỉ nhận `is_voice: bool` làm
  input giả lập, không gọi lại VAD thật. Không có port Python riêng cho
  `VadDetector` (chỉ có JUnit thuần `native-test/VadDetectorTest.kt`) — lưu
  ý 1 comment trong `VadDetector.kt` còn nhắc tới `tests/vad/` như thể có
  port Python, nhưng thư mục đó **không tồn tại** trong repo, cần dọn lại
  comment đó hoặc viết thêm test cho đúng.
