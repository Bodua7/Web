// supabase-functions/groq-relay/pure.test.ts
//
// Test các hàm/hằng số THUẦN trong pure.ts. KHÔNG import index.ts (xem lý do ở đầu pure.ts) -
// import index.ts sẽ chạy Deno.serve(...) + khởi tạo Supabase client thật ngay khi test file
// load module, không an toàn/không cần thiết cho các test ở đây.
//
// Chạy: deno test --allow-env=GROQ_API_KEY,GROQ_API_KEY_2 supabase-functions/groq-relay/pure.test.ts
// (--allow-env chỉ cấp đúng 2 biến GROQ_API_KEY/GROQ_API_KEY_2 - một số test case tự set/xoá
// tạm 2 biến này để kiểm tra groqFetchWithFallback(); không cần --allow-net vì toàn bộ lệnh gọi
// fetch trong test đều dùng bản giả lập, không gọi mạng thật)

import { assertEquals, assertMatch, assertNotEquals, assertRejects } from "https://deno.land/std@0.224.0/assert/mod.ts";
import {
  CORS_HEADERS,
  currentDayKey,
  currentMonthKey,
  getClientIp,
  isGroqCircuitOpen,
  jsonError,
  jsonOk,
  recordGroqCircuitFailure,
  recordGroqCircuitSuccess,
  sanitizeClientError,
  translateViaDeepl,
  DeeplQuotaExceededError,
  translateViaAzure,
  AzureQuotaExceededError,
  translateViaGemini,
  GEMINI_TRANSLATE_MODELS,
  groqFetchWithFallback,
  _resetGroqCircuitForTest,
} from "./pure.ts";

Deno.test("currentMonthKey() trả về đúng định dạng YYYY-MM", () => {
  assertMatch(currentMonthKey(), /^\d{4}-\d{2}$/);
});

Deno.test("currentDayKey() trả về đúng định dạng YYYY-MM-DD", () => {
  assertMatch(currentDayKey(), /^\d{4}-\d{2}-\d{2}$/);
});

Deno.test("currentDayKey() bắt đầu bằng đúng currentMonthKey()", () => {
  // Hai hàm gọi `new Date()` độc lập nên về lý thuyết có thể lệch nếu chạy đúng lúc giao thời
  // giữa 2 tick millisecond khác ngày/tháng - xác suất cực thấp trong 1 test chạy tức thời,
  // chấp nhận được (không đáng để mock Date cho 1 rủi ro không đâu này).
  const day = currentDayKey();
  const month = currentMonthKey();
  assertEquals(day.slice(0, 7), month);
});

Deno.test("getClientIp() lấy IP đầu tiên trong X-Forwarded-For", () => {
  const req = new Request("https://example.com", {
    headers: { "x-forwarded-for": "203.0.113.5, 70.41.3.18, 150.172.238.178" },
  });
  assertEquals(getClientIp(req), "203.0.113.5");
});

Deno.test("getClientIp() bỏ khoảng trắng quanh IP", () => {
  const req = new Request("https://example.com", {
    headers: { "x-forwarded-for": "  203.0.113.5  , 70.41.3.18" },
  });
  assertEquals(getClientIp(req), "203.0.113.5");
});

Deno.test("getClientIp() trả về 'unknown' nếu thiếu header", () => {
  const req = new Request("https://example.com");
  assertEquals(getClientIp(req), "unknown");
});

Deno.test("circuit breaker: đóng ban đầu, mở sau 3 lần fail liên tiếp, đóng lại khi success", () => {
  _resetGroqCircuitForTest();
  assertEquals(isGroqCircuitOpen(), false);

  recordGroqCircuitFailure();
  assertEquals(isGroqCircuitOpen(), false, "mới fail 1 lần - chưa đủ ngưỡng 3, phải còn đóng");

  recordGroqCircuitFailure();
  assertEquals(isGroqCircuitOpen(), false, "mới fail 2 lần - chưa đủ ngưỡng 3, phải còn đóng");

  recordGroqCircuitFailure();
  assertEquals(isGroqCircuitOpen(), true, "fail đủ 3 lần liên tiếp - phải mở (open)");

  recordGroqCircuitSuccess();
  assertEquals(isGroqCircuitOpen(), false, "1 lần success phải reset về đóng ngay, không cần đợi hết 60s");

  _resetGroqCircuitForTest();
});

Deno.test("circuit breaker: fail rồi success sớm (chưa tới ngưỡng) không mở circuit", () => {
  _resetGroqCircuitForTest();
  recordGroqCircuitFailure();
  recordGroqCircuitSuccess();
  recordGroqCircuitFailure();
  recordGroqCircuitFailure();
  assertEquals(isGroqCircuitOpen(), false, "success ở giữa phải reset fail count về 0 - 2 fail sau đó chưa đủ ngưỡng 3");
  _resetGroqCircuitForTest();
});

Deno.test("jsonOk() trả về status 200, đúng CORS headers, body là JSON của data truyền vào", async () => {
  const res = jsonOk({ hello: "world" });
  assertEquals(res.status, 200);
  assertEquals(res.headers.get("Access-Control-Allow-Origin"), CORS_HEADERS["Access-Control-Allow-Origin"]);
  assertEquals(res.headers.get("Content-Type"), "application/json");
  const body = await res.json();
  assertEquals(body, { hello: "world" });
});

Deno.test("jsonError() trả về đúng status truyền vào, body { error: code }", async () => {
  const res = jsonError("RATE_LIMIT_EXCEEDED", 429);
  assertEquals(res.status, 429);
  const body = await res.json();
  assertEquals(body, { error: "RATE_LIMIT_EXCEEDED" });
});

Deno.test("sanitizeClientError() rút gọn lỗi có mã *_ERROR_<status>: về đúng mã, bỏ phần body gốc", () => {
  assertEquals(
    sanitizeClientError("GROQ_ERROR_429: {\"error\":{\"message\":\"rate limit exceeded for key ending ...\"}}"),
    "GROQ_ERROR_429",
  );
  assertEquals(sanitizeClientError("DEEPL_ERROR_403: quota exceeded, account id 12345"), "DEEPL_ERROR_403");
});

Deno.test("sanitizeClientError() giữ nguyên message không khớp định dạng *_ERROR_<status>", () => {
  const msg = "Network timeout while calling provider";
  assertEquals(sanitizeClientError(msg), msg);
});

Deno.test("sanitizeClientError() không nhầm message chỉ MỘT PHẦN giống định dạng lỗi", () => {
  // Không bắt đầu bằng ^[A-Z]+_ERROR_\d+: nên phải giữ nguyên, không được cắt nhầm.
  const msg = "something GROQ_ERROR_429: in the middle";
  assertNotEquals(sanitizeClientError(msg), "GROQ_ERROR_429");
});

// ===== translateViaDeepl - mock fetch, KHÔNG gọi DeepL thật =====

function fakeFetch(status: number, jsonBody?: unknown, textBody?: string): typeof fetch {
  return (() =>
    Promise.resolve(
      new Response(textBody ?? (jsonBody !== undefined ? JSON.stringify(jsonBody) : ""), {
        status,
      }),
    )) as unknown as typeof fetch;
}

Deno.test("translateViaDeepl() trả về đúng text dịch khi DeepL trả 200", async () => {
  const mockFetch = fakeFetch(200, { translations: [{ text: "Xin chào" }] });
  const result = await translateViaDeepl("fake-key", "Hello", "VI", undefined, undefined, mockFetch);
  assertEquals(result, "Xin chào");
});

Deno.test("translateViaDeepl() dùng đúng base URL 'api-free' khi key kết thúc bằng ':fx'", async () => {
  let calledUrl = "";
  const mockFetch = ((url: string) => {
    calledUrl = url;
    return Promise.resolve(new Response(JSON.stringify({ translations: [{ text: "ok" }] }), { status: 200 }));
  }) as unknown as typeof fetch;
  await translateViaDeepl("fake-key:fx", "Hello", "VI", undefined, undefined, mockFetch);
  assertEquals(calledUrl, "https://api-free.deepl.com/v2/translate");
});

Deno.test("translateViaDeepl() dùng đúng base URL 'api' (trả phí) khi key KHÔNG có ':fx'", async () => {
  let calledUrl = "";
  const mockFetch = ((url: string) => {
    calledUrl = url;
    return Promise.resolve(new Response(JSON.stringify({ translations: [{ text: "ok" }] }), { status: 200 }));
  }) as unknown as typeof fetch;
  await translateViaDeepl("fake-key-no-fx", "Hello", "VI", undefined, undefined, mockFetch);
  assertEquals(calledUrl, "https://api.deepl.com/v2/translate");
});

Deno.test("translateViaDeepl() ném DeeplQuotaExceededError khi DeepL trả 456", async () => {
  const mockFetch = fakeFetch(456, undefined, "Quota Exceeded");
  await assertRejects(
    () => translateViaDeepl("fake-key", "Hello", "VI", undefined, undefined, mockFetch),
    DeeplQuotaExceededError,
  );
});

Deno.test("translateViaDeepl() ném Error thường (KHÔNG phải DeeplQuotaExceededError) khi DeepL trả lỗi khác 456, vd 429", async () => {
  const mockFetch = fakeFetch(429, undefined, "Too Many Requests");
  try {
    await translateViaDeepl("fake-key", "Hello", "VI", undefined, undefined, mockFetch);
    throw new Error("phải throw nhưng lại không throw");
  } catch (e) {
    assertEquals(e instanceof DeeplQuotaExceededError, false);
    assertMatch((e as Error).message, /^DEEPL_ERROR_429:/);
  }
});

Deno.test("translateViaDeepl() ném DEEPL_EMPTY_RESPONSE khi DeepL trả 200 nhưng mảng translations rỗng", async () => {
  const mockFetch = fakeFetch(200, { translations: [] });
  await assertRejects(
    () => translateViaDeepl("fake-key", "Hello", "VI", undefined, undefined, mockFetch),
    Error,
    "DEEPL_EMPTY_RESPONSE",
  );
});

Deno.test("translateViaDeepl() gửi đúng source_lang/context khi có truyền vào (không gửi khi undefined)", async () => {
  let sentBody: Record<string, unknown> = {};
  const mockFetch = ((_url: string, init?: RequestInit) => {
    sentBody = JSON.parse(init?.body as string);
    return Promise.resolve(new Response(JSON.stringify({ translations: [{ text: "ok" }] }), { status: 200 }));
  }) as unknown as typeof fetch;

  await translateViaDeepl("fake-key", "Hello", "VI", "EN", "some context", mockFetch);
  assertEquals(sentBody.source_lang, "EN");
  assertEquals(sentBody.context, "some context");

  await translateViaDeepl("fake-key", "Hello", "VI", undefined, undefined, mockFetch);
  assertEquals("source_lang" in sentBody, false);
  assertEquals("context" in sentBody, false);
});

// ===== translateViaAzure - mock fetch, KHÔNG gọi Azure thật =====

Deno.test("translateViaAzure() trả về đúng text dịch khi Azure trả 200", async () => {
  const mockFetch = fakeFetch(200, [{ translations: [{ text: "Xin chào" }] }]);
  const result = await translateViaAzure(
    "fake-key",
    "eastasia",
    "https://api.cognitive.microsofttranslator.com",
    "Hello",
    "vi",
    undefined,
    mockFetch,
  );
  assertEquals(result, "Xin chào");
});

Deno.test("translateViaAzure() ném AzureQuotaExceededError khi HTTP 403", async () => {
  const mockFetch = fakeFetch(403, undefined, "Forbidden");
  await assertRejects(
    () =>
      translateViaAzure(
        "fake-key",
        "eastasia",
        "https://api.cognitive.microsofttranslator.com",
        "Hello",
        "vi",
        undefined,
        mockFetch,
      ),
    AzureQuotaExceededError,
  );
});

Deno.test("translateViaAzure() ném AzureQuotaExceededError khi body chứa chữ 'quota' dù status khác 403", async () => {
  const mockFetch = fakeFetch(400, undefined, "monthly quota exceeded for this resource");
  await assertRejects(
    () =>
      translateViaAzure(
        "fake-key",
        "eastasia",
        "https://api.cognitive.microsofttranslator.com",
        "Hello",
        "vi",
        undefined,
        mockFetch,
      ),
    AzureQuotaExceededError,
  );
});

Deno.test("translateViaAzure() ném Error thường khi 401 (sai key, KHÔNG phải hết quota)", async () => {
  const mockFetch = fakeFetch(401, undefined, "Access Denied");
  try {
    await translateViaAzure(
      "fake-key",
      "eastasia",
      "https://api.cognitive.microsofttranslator.com",
      "Hello",
      "vi",
      undefined,
      mockFetch,
    );
    throw new Error("phải throw nhưng lại không throw");
  } catch (e) {
    assertEquals(e instanceof AzureQuotaExceededError, false);
    assertMatch((e as Error).message, /^AZURE_ERROR_401:/);
  }
});

Deno.test("translateViaAzure() gửi đúng query string 'from' chỉ khi có sourceLangCode", async () => {
  let calledUrl = "";
  const mockFetch = ((url: string) => {
    calledUrl = url;
    return Promise.resolve(new Response(JSON.stringify([{ translations: [{ text: "ok" }] }]), { status: 200 }));
  }) as unknown as typeof fetch;

  await translateViaAzure("k", "r", "https://endpoint", "Hello", "vi", "en", mockFetch);
  assertMatch(calledUrl, /from=en/);

  await translateViaAzure("k", "r", "https://endpoint", "Hello", "vi", undefined, mockFetch);
  assertEquals(calledUrl.includes("from="), false);
});

// ===== translateViaGemini - mock fetch, KHÔNG gọi Gemini thật =====

function fakeGeminiResponse(text: string): Response {
  return new Response(
    JSON.stringify({ candidates: [{ content: { parts: [{ text }] } }] }),
    { status: 200 },
  );
}

Deno.test("translateViaGemini() trả về đúng text dịch khi model đầu tiên trả 200", async () => {
  let callCount = 0;
  const mockFetch = (() => {
    callCount++;
    return Promise.resolve(fakeGeminiResponse("Xin chào"));
  }) as unknown as typeof fetch;

  const result = await translateViaGemini("fake-key", "Hello", "Vietnamese", [], mockFetch);
  assertEquals(result.translated, "Xin chào");
  assertEquals(result.model, GEMINI_TRANSLATE_MODELS[0]);
  assertEquals(callCount, 1); // model đầu tiên thành công - không cần thử model dự phòng
});

Deno.test("translateViaGemini() tách đúng dòng PINYIN: ra khỏi phần dịch", async () => {
  const mockFetch = (() =>
    Promise.resolve(fakeGeminiResponse("你好\nPINYIN: Nǐ hǎo"))) as unknown as typeof fetch;

  const result = await translateViaGemini("fake-key", "Hello", "Chinese", [], mockFetch);
  assertEquals(result.translated, "你好");
  assertEquals(result.pinyin, "Nǐ hǎo");
});

Deno.test("translateViaGemini() không có dòng PINYIN thì pinyin rỗng", async () => {
  const mockFetch = (() => Promise.resolve(fakeGeminiResponse("Xin chào"))) as unknown as typeof fetch;
  const result = await translateViaGemini("fake-key", "Hello", "Vietnamese", [], mockFetch);
  assertEquals(result.pinyin, "");
});

Deno.test("translateViaGemini() model đầu 429 thì tự chuyển sang model dự phòng thứ 2", async () => {
  let callCount = 0;
  const mockFetch = (() => {
    callCount++;
    if (callCount === 1) {
      return Promise.resolve(new Response("rate limited", { status: 429 }));
    }
    return Promise.resolve(fakeGeminiResponse("Xin chào (model 2)"));
  }) as unknown as typeof fetch;

  const result = await translateViaGemini("fake-key", "Hello", "Vietnamese", [], mockFetch);
  assertEquals(result.translated, "Xin chào (model 2)");
  assertEquals(result.model, GEMINI_TRANSLATE_MODELS[1]);
  assertEquals(callCount, 2);
});

Deno.test("translateViaGemini() TẤT CẢ model đều lỗi 401/429 thì ném lỗi của model cuối cùng", async () => {
  const mockFetch = (() =>
    Promise.resolve(new Response("unauthorized", { status: 401 }))) as unknown as typeof fetch;

  await assertRejects(
    () => translateViaGemini("fake-key", "Hello", "Vietnamese", [], mockFetch),
    Error,
    "GEMINI_ERROR_401",
  );
});

Deno.test("translateViaGemini() lỗi KHÔNG phải 401/403/429 (vd 400) thì dừng ngay, không thử model dự phòng", async () => {
  let callCount = 0;
  const mockFetch = (() => {
    callCount++;
    return Promise.resolve(new Response("bad request", { status: 400 }));
  }) as unknown as typeof fetch;

  await assertRejects(
    () => translateViaGemini("fake-key", "Hello", "Vietnamese", [], mockFetch),
    Error,
    "GEMINI_ERROR_400",
  );
  assertEquals(callCount, 1, "lỗi 400 không nên thử model dự phòng thứ 2");
});

Deno.test("translateViaGemini() đưa context vào prompt gửi lên Gemini khi có truyền vào", async () => {
  let sentBody: Record<string, unknown> = {};
  const mockFetch = ((_url: string, init?: RequestInit) => {
    sentBody = JSON.parse(init?.body as string);
    return Promise.resolve(fakeGeminiResponse("ok"));
  }) as unknown as typeof fetch;

  await translateViaGemini("fake-key", "Hello", "Vietnamese", ["Câu trước đó"], mockFetch);
  const systemPrompt = (sentBody.system_instruction as { parts: { text: string }[] }).parts[0].text;
  assertMatch(systemPrompt, /Câu trước đó/);
});

// ===== groqFetchWithFallback - mock fetch, KHÔNG gọi Groq thật =====

function buildFakeGroqRequest(key: string) {
  return { url: `https://api.groq.com/fake?key=${key}`, init: {} as RequestInit };
}

Deno.test("groqFetchWithFallback() trả về response thành công ngay ở key đầu tiên", async () => {
  _resetGroqCircuitForTest();
  let calledKeys: string[] = [];
  const mockFetch = ((url: string) => {
    calledKeys.push(url);
    return Promise.resolve(new Response("ok", { status: 200 }));
  }) as unknown as typeof fetch;

  Deno.env.set("GROQ_API_KEY", "key-1");
  Deno.env.set("GROQ_API_KEY_2", "key-2");

  const res = await groqFetchWithFallback(buildFakeGroqRequest, mockFetch);
  assertEquals(res.status, 200);
  assertEquals(calledKeys.length, 1, "key đầu tiên đã thành công - không nên thử key thứ 2");

  Deno.env.delete("GROQ_API_KEY");
  Deno.env.delete("GROQ_API_KEY_2");
});

Deno.test("groqFetchWithFallback() key đầu 401 thì tự chuyển sang key thứ 2", async () => {
  _resetGroqCircuitForTest();
  let callCount = 0;
  const mockFetch = (() => {
    callCount++;
    if (callCount === 1) return Promise.resolve(new Response("unauthorized", { status: 401 }));
    return Promise.resolve(new Response("ok", { status: 200 }));
  }) as unknown as typeof fetch;

  Deno.env.set("GROQ_API_KEY", "key-1");
  Deno.env.set("GROQ_API_KEY_2", "key-2");

  const res = await groqFetchWithFallback(buildFakeGroqRequest, mockFetch);
  assertEquals(res.status, 200);
  assertEquals(callCount, 2);

  Deno.env.delete("GROQ_API_KEY");
  Deno.env.delete("GROQ_API_KEY_2");
});

Deno.test("groqFetchWithFallback() cả 2 key đều 401/429 thì mở circuit breaker rồi throw", async () => {
  _resetGroqCircuitForTest();
  const mockFetch = (() =>
    Promise.resolve(new Response("unauthorized", { status: 401 }))) as unknown as typeof fetch;

  Deno.env.set("GROQ_API_KEY", "key-1");
  Deno.env.set("GROQ_API_KEY_2", "key-2");

  await assertRejects(() => groqFetchWithFallback(buildFakeGroqRequest, mockFetch));
  assertEquals(isGroqCircuitOpen(), true, "hết key mà vẫn 401/429 phải mở breaker");

  Deno.env.delete("GROQ_API_KEY");
  Deno.env.delete("GROQ_API_KEY_2");
  _resetGroqCircuitForTest();
});

Deno.test("groqFetchWithFallback() lỗi KHÔNG phải 401/429 (vd 500) thì dừng ngay, không thử key khác", async () => {
  _resetGroqCircuitForTest();
  let callCount = 0;
  const mockFetch = (() => {
    callCount++;
    return Promise.resolve(new Response("server error", { status: 500 }));
  }) as unknown as typeof fetch;

  Deno.env.set("GROQ_API_KEY", "key-1");
  Deno.env.set("GROQ_API_KEY_2", "key-2");

  await assertRejects(
    () => groqFetchWithFallback(buildFakeGroqRequest, mockFetch),
    Error,
    "GROQ_ERROR_500",
  );
  assertEquals(callCount, 1, "lỗi 500 không nên thử key thứ 2");
  assertEquals(isGroqCircuitOpen(), false, "lỗi 500 không tính vào circuit breaker");

  Deno.env.delete("GROQ_API_KEY");
  Deno.env.delete("GROQ_API_KEY_2");
});

Deno.test("groqFetchWithFallback() breaker đang mở thì throw ngay, KHÔNG gọi fetch lần nào", async () => {
  _resetGroqCircuitForTest();
  // Mở breaker thủ công bằng 3 lần fail liên tiếp (qua recordGroqCircuitFailure, đã test riêng
  // ở nhóm test circuit breaker phía trên - dùng lại làm tiền đề cho test này).
  recordGroqCircuitFailure();
  recordGroqCircuitFailure();
  recordGroqCircuitFailure();
  assertEquals(isGroqCircuitOpen(), true);

  let callCount = 0;
  const mockFetch = (() => {
    callCount++;
    return Promise.resolve(new Response("ok", { status: 200 }));
  }) as unknown as typeof fetch;

  Deno.env.set("GROQ_API_KEY", "key-1");
  await assertRejects(() => groqFetchWithFallback(buildFakeGroqRequest, mockFetch), Error, "GROQ_CIRCUIT_OPEN");
  assertEquals(callCount, 0, "breaker mở thì không được gọi fetch lần nào");

  Deno.env.delete("GROQ_API_KEY");
  _resetGroqCircuitForTest();
});

Deno.test("groqFetchWithFallback() không có key nào (env trống) thì ném SERVER_MISSING_GROQ_KEY", async () => {
  _resetGroqCircuitForTest();
  Deno.env.delete("GROQ_API_KEY");
  Deno.env.delete("GROQ_API_KEY_2");
  const mockFetch = (() => Promise.resolve(new Response("ok", { status: 200 }))) as unknown as typeof fetch;
  await assertRejects(
    () => groqFetchWithFallback(buildFakeGroqRequest, mockFetch),
    Error,
    "SERVER_MISSING_GROQ_KEY",
  );
});
