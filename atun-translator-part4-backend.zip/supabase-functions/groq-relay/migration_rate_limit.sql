-- Chạy 1 lần trong Supabase Studio -> SQL Editor (hoặc supabase db push nếu dùng CLI).
--
-- Giới hạn tốc độ gọi THEO NGÀY, THEO IP, RIÊNG cho từng "op" - lớp phòng thủ BỔ SUNG phía
-- SERVER, độc lập với header "X-App-Secret". X-App-Secret chỉ chặn được request không đọc qua
-- mã nguồn app (xem checkAppSecret() trong index.ts) - nó ĐƯỢC GHI CỨNG trong app.js/bundle
-- JS chạy trong WebView nên KHÔNG phải xác thực thật, ai giải nén APK hoặc mở DevTools remote
-- debug đều đọc được. Nếu secret đó bị lộ, bảng này giới hạn thiệt hại tối đa 1 IP có thể gây
-- ra trong 1 ngày, thay vì để rút cạn quota Groq/Gemini/DeepL/Azure không giới hạn.
--
-- Đây KHÔNG phải giải pháp triệt để (vẫn có thể đổi IP/dùng proxy để né) - giải pháp triệt để
-- là chuyển sang xác thực THEO NGƯỜI DÙNG thật (vd Supabase Auth ẩn danh + kiểm tra JWT trong
-- Edge Function), việc đó cần thêm luồng đăng nhập phía client nên chưa làm trong bản vá này.

create table if not exists request_rate_limit (
  ip text not null,
  day text not null,        -- 'YYYY-MM-DD' (UTC)
  op text not null,         -- 'transcribe' | 'translate' | 'translateGemini' | 'translateDeepl' | 'translateAzure'
  count integer not null default 0,
  primary key (ip, day, op)
);

comment on table request_rate_limit is
  'Đếm số request THEO NGÀY/IP/op để chặn bớt lạm dụng nếu X-App-Secret phía client bị lộ. '
  'Không phải bảng log lâu dài - nên dọn định kỳ các dòng "day" cũ (vd pg_cron hàng ngày xoá '
  'day < hôm nay - 2, hoặc dọn tay) vì bảng không tự hết hạn dòng.';

-- Row Level Security: bảng này CHỈ được đọc/ghi bởi Edge Function qua service role key (tự
-- động bypass RLS) - không có client nào khác (app di động) truy cập bảng này trực tiếp, nên
-- bật RLS mà KHÔNG thêm policy nào (mặc định chặn hết mọi request qua anon/authenticated key)
-- là đủ an toàn. Cùng nguyên tắc với translate_quota_status ở migration khác.
alter table request_rate_limit enable row level security;

-- Tăng đếm NGUYÊN TỬ (atomic) qua đúng 1 câu lệnh SQL - tránh race condition kiểu đọc-rồi-ghi
-- (2 request cùng IP tới gần như đồng thời, cùng đọc giá trị cũ, cùng ghi lại -> mất 1 lần đếm,
-- vượt giới hạn thật mà không bị phát hiện).
create or replace function increment_rate_limit(p_ip text, p_day text, p_op text)
returns integer
language sql
as $$
  insert into request_rate_limit (ip, day, op, count)
  values (p_ip, p_day, p_op, 1)
  on conflict (ip, day, op)
  do update set count = request_rate_limit.count + 1
  returning count;
$$;

-- Fix (audit - "function_search_path_mutable", Supabase Advisor): khoá cứng search_path='public'
-- (KHÔNG dùng '' rỗng - hàm tham chiếu bảng "request_rate_limit" không schema-qualify, '' sẽ
-- làm hàm không tìm thấy bảng, gãy production ngay). Đã áp dụng trực tiếp lên project thật qua
-- Supabase MCP và xác nhận lại bằng get_advisors() - xem chi tiết đầy đủ trong
-- migration_rate_limit_per_user.sql (cùng 1 đợt vá, áp dụng chung cho cả 3 hàm rate-limit).
alter function increment_rate_limit(p_ip text, p_day text, p_op text) set search_path = 'public';
