// supabase-functions/groq-relay/pure.ts
//
// Các hàm/hằng số THUẦN (không gọi network, không đụng Deno.serve/Supabase client) tách ra từ
// index.ts (2026-09-08, đợt thêm test) để có thể unit-test bằng Deno.test MÀ KHÔNG phải import
// cả index.ts - import thẳng index.ts sẽ chạy luôn Deno.serve(...) (mở HTTP listener) và khởi
// tạo Supabase client thật (createClient() đọc SUPABASE_URL/SUPABASE_SERVICE_ROLE_KEY từ env,
// rỗng trong môi trường test) ngay khi module được load, không an toàn để import trong test.
// index.ts import lại mọi thứ ở đây - hành vi runtime CỦA index.ts không đổi so với trước khi
// tách, chỉ đổi vị trí khai báo.

export const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, apikey",
};

export function currentMonthKey(): string {
  return new Date().toISOString().slice(0, 7); // "2026-09" (UTC)
}

export function currentDayKey(): string {
  return new Date().toISOString().slice(0, 10); // "2026-09-06" (UTC)
}

export function getClientIp(req: Request): string {
  // Supabase Edge Functions chạy sau proxy - không có API lấy thẳng remote socket address ở
  // Deno.serve trong môi trường này, phải đọc từ header do proxy gắn vào. "unknown" (gộp chung
  // 1 nhóm) nếu vì lý do gì đó thiếu header - còn hơn để lỗi làm hỏng cả request.
  const fwd = req.headers.get("x-forwarded-for");
  if (fwd) return fwd.split(",")[0].trim();
  return "unknown";
}

// ===== Circuit breaker phía SERVER cho Groq (bổ sung cho breaker phía client trong app.js -
// hai lớp độc lập, không thay thế nhau: breaker client tránh client phải CHỜ timeout mỗi câu;
// breaker này tránh chính function này liên tục bắn request vô ích tới Groq khi CẢ 2 key đều
// đang 401/429, giúp trả lỗi ngay cho client (nhanh hơn) thay vì lại đi hết vòng lặp key trong
// groqFetchWithFallback() mỗi lần. State là module-level (biến ngoài Deno.serve) nên sống được
// qua nhiều request TRONG CÙNG 1 isolate còn "ấm" (warm) - Supabase Edge Functions có thể tái
// dùng isolate giữa các lần gọi gần nhau, nhưng KHÔNG đảm bảo tuyệt đối (isolate có thể bị
// dọn/khởi tạo lại bất kỳ lúc nào) - vì vậy đây chỉ là tối ưu "best-effort", không phải cơ chế
// bắt buộc đúng 100%: worst-case (isolate mới) chỉ đơn giản là mất tác dụng tạm thời, không
// gây lỗi sai kết quả.
const GROQ_CIRCUIT_FAIL_THRESHOLD = 3;
const GROQ_CIRCUIT_OPEN_MS = 60_000; // 60s - khớp với breaker phía client (app.js: groqCircuit)
let groqCircuitFailCount = 0;
let groqCircuitOpenUntil = 0;

export function isGroqCircuitOpen(): boolean {
  return Date.now() < groqCircuitOpenUntil;
}

export function recordGroqCircuitSuccess(): void {
  groqCircuitFailCount = 0;
  groqCircuitOpenUntil = 0;
}

export function recordGroqCircuitFailure(): void {
  groqCircuitFailCount += 1;
  if (groqCircuitFailCount >= GROQ_CIRCUIT_FAIL_THRESHOLD) {
    groqCircuitOpenUntil = Date.now() + GROQ_CIRCUIT_OPEN_MS;
  }
}

// CHỈ dùng trong test (index.test.ts) - reset state module-level giữa các test case, vì circuit
// breaker là biến module-level dùng chung: không reset thì test chạy sau bị ảnh hưởng bởi kết
// quả test chạy trước (Deno.test trong cùng file chia sẻ 1 lần load module).
export function _resetGroqCircuitForTest(): void {
  groqCircuitFailCount = 0;
  groqCircuitOpenUntil = 0;
}

// Cho handleDebug() (index.ts, op=debug) đọc trạng thái breaker hiện tại để hiển thị - trả bản
// sao (object mới), không trả tham chiếu trực tiếp tới biến module-level.
export function getGroqCircuitDebugInfo(): { failCount: number; openUntil: number } {
  return { failCount: groqCircuitFailCount, openUntil: groqCircuitOpenUntil };
}

export async function translateViaAzure(
  apiKey: string,
  region: string,
  endpoint: string,
  text: string,
  targetLangCode: string,
  sourceLangCode: string | undefined,
  fetchImpl: typeof fetch = fetch,
): Promise<string> {
  const params = new URLSearchParams({ "api-version": "3.0", to: targetLangCode });
  if (sourceLangCode) params.set("from", sourceLangCode);

  const res = await fetchImpl(`${endpoint}/translate?${params.toString()}`, {
    method: "POST",
    headers: {
      "Ocp-Apim-Subscription-Key": apiKey,
      "Ocp-Apim-Subscription-Region": region,
      "Content-Type": "application/json",
    },
    // Azure nhan mang cau (khong phai 1 object) - chi gui 1 phan tu, giong cach dung 1 cau/lan
    // dich cua ca DeepL lan Groq.
    body: JSON.stringify([{ Text: text }]),
  });

  if (!res.ok) {
    const bodyText = await res.text().catch(() => "");
    // Azure Translator KHÔNG có 1 mã HTTP riêng biệt cho "hết quota" như DeepL (456) - thường
    // trả về HTTP 403 (Forbidden) khi vượt hạn mức free-tier F0, nhưng chưa xác minh được số
    // mã lỗi con chính xác (vd 403001) qua tài liệu chính thức tại thời điểm viết. Vì vậy dùng
    // 2 tín hiệu HEURISTIC (best-effort, có thể đánh dấu nhầm 1 lần rồi tự sửa ở tháng sau):
    // (a) HTTP 403 (401 đã là lỗi sai key, không tính), HOẶC (b) chuỗi "quota" xuất hiện trong
    // response body bất kể status - nếu 1 trong 2 đúng thì coi là hết quota tháng.
    if (res.status === 403 || /quota/i.test(bodyText)) {
      throw new AzureQuotaExceededError(res.status, bodyText);
    }
    throw new Error(`AZURE_ERROR_${res.status}: ${bodyText.slice(0, 300)}`);
  }

  const data = await res.json();
  const translated = data?.[0]?.translations?.[0]?.text || "";
  if (!translated) throw new Error("AZURE_EMPTY_RESPONSE");
  return translated;
}

export class AzureQuotaExceededError extends Error {
  readonly status: number;
  readonly bodyText: string;
  constructor(status: number, bodyText: string) {
    super(`AZURE_ERROR_${status}: ${bodyText.slice(0, 300)}`);
    this.name = "AzureQuotaExceededError";
    this.status = status;
    this.bodyText = bodyText;
  }
}

// ===== translateViaGemini + getKeys/groqFetchWithFallback (Groq) - cũng tách sang đây, KHÔNG
// đụng Supabase (không giống DeepL/Azure, cả 2 hàm này chưa từng gọi isQuotaBlocked/
// markQuotaExhausted - Gemini/Groq tự dùng cơ chế fallback nhiều model/key + circuit breaker
// thay vì theo dõi quota tháng trên DB) - do đó tách được TOÀN BỘ logic, không chỉ phần
// "gọi API + parse response" như DeepL/Azure. =====

export const GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models";
export const GEMINI_TRANSLATE_MODELS = ["gemini-3.5-flash-lite", "gemini-2.5-flash-lite"];

export interface GeminiTranslateResult {
  translated: string;
  pinyin: string;
  model: string;
}

export async function translateViaGemini(
  apiKey: string,
  text: string,
  targetLangName: string,
  context: string[],
  fetchImpl: typeof fetch = fetch,
): Promise<GeminiTranslateResult> {
  const contextBlock = context.length > 0
    ? `\n\nContext: the following ${context.length} sentence(s) were said immediately before ` +
      `the message you need to translate (same speaker/scene, original language, for reference ` +
      `only - to resolve pronouns, ellipsis, and keep terminology consistent). Do NOT translate ` +
      `or repeat them in your output:\n` +
      context.map((c, i) => `${i + 1}. ${c}`).join("\n")
    : "";

  const systemPrompt =
    `You are a professional real-time interpreter. Translate the user's ` +
    `message into ${targetLangName}. ` +
    `Rules: output ONLY the translation of the message, no explanations, no quotes. ` +
    `If the target language is Chinese, also provide Pinyin on a new line prefixed ` +
    `with "PINYIN:". ` +
    `If not Chinese, do not include a PINYIN line.` +
    contextBlock;

  let lastErr: Error | null = null;
  for (const model of GEMINI_TRANSLATE_MODELS) {
    try {
      const res = await fetchImpl(
        `${GEMINI_BASE_URL}/${model}:generateContent?key=${apiKey}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            system_instruction: { parts: [{ text: systemPrompt }] },
            contents: [{ role: "user", parts: [{ text }] }],
            generationConfig: { temperature: 0.2 },
          }),
        },
      );

      if (!res.ok) {
        const bodyText = await res.text().catch(() => "");
        const err = new Error(`GEMINI_ERROR_${res.status}: ${bodyText.slice(0, 300)}`);
        // 401/403 (key sai/het quota) hoac 429 (rate limit) -> thu model du phong tiep theo;
        // loi khac (vd 400 do prompt) thi dung lai, khong co ich khi thu lai model khac.
        if (res.status === 401 || res.status === 403 || res.status === 429) {
          lastErr = err;
          continue;
        }
        throw err;
      }

      const data = await res.json();
      const raw: string =
        data?.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text || "").join("") || "";
      const trimmed = raw.trim();
      if (!trimmed) throw new Error("GEMINI_EMPTY_RESPONSE");

      let translated = trimmed;
      let pinyin = "";
      const pinyinMatch = trimmed.match(/PINYIN:\s*(.+)/i);
      if (pinyinMatch) {
        pinyin = pinyinMatch[1].trim();
        translated = trimmed.replace(/PINYIN:\s*.+/i, "").trim();
      }

      return { translated, pinyin, model };
    } catch (e) {
      lastErr = e instanceof Error ? e : new Error(String(e));
      continue;
    }
  }
  throw lastErr ?? new Error("GEMINI_ALL_MODELS_FAILED");
}

export function getKeys(): string[] {
  const k1 = Deno.env.get("GROQ_API_KEY");
  const k2 = Deno.env.get("GROQ_API_KEY_2");
  return [k1, k2].filter((k): k is string => !!k && k.length > 0);
}

// GroqHttpError: thay cho pattern cũ gắn `.status` lên Error qua ép kiểu
// `as unknown as { status: number }` (không an toàn về kiểu, TypeScript không kiểm tra được gì).
// Cùng họ với DeeplQuotaExceededError/AzureQuotaExceededError bên dưới - property thật trên
// class thay vì field "chui" gắn ngoài, đọc lại bằng `instanceof` + `.status` thay vì ép kiểu.
export class GroqHttpError extends Error {
  readonly status: number;
  constructor(message: string, status: number) {
    super(message);
    this.name = "GroqHttpError";
    this.status = status;
  }
}

export async function groqFetchWithFallback(
  buildRequest: (key: string) => { url: string; init: RequestInit },
  fetchImpl: typeof fetch = fetch,
): Promise<Response> {
  const keys = getKeys();
  if (keys.length === 0) {
    throw new Error("SERVER_MISSING_GROQ_KEY");
  }

  // Breaker đang mở (đã lỗi liên tiếp gần đây) -> trả lỗi ngay, KHÔNG bắn request nào tới Groq -
  // để client rơi xuống Gemini nhanh hơn, đỡ tốn cả thời gian lẫn quota gọi vô ích trong lúc
  // Groq nhiều khả năng vẫn đang lỗi.
  if (isGroqCircuitOpen()) {
    throw new GroqHttpError("GROQ_CIRCUIT_OPEN", 429);
  }

  let lastError: Error | null = null;
  for (const key of keys) {
    const { url, init } = buildRequest(key);
    try {
      const res = await fetchImpl(url, init);
      if (res.ok) {
        recordGroqCircuitSuccess();
        return res;
      }
      if (res.status === 401 || res.status === 429) {
        lastError = new GroqHttpError(`GROQ_${res.status}`, res.status);
        continue;
      }
      const body = await res.text().catch(() => "");
      // Lỗi không phải 401/429 (vd 400/500) không tính vào breaker - breaker chỉ nhắm tới
      // trường hợp "hết quota/rate-limit kéo dài", không nhắm lỗi request/server nhất thời.
      throw new GroqHttpError(`GROQ_ERROR_${res.status}: ${body.slice(0, 300)}`, res.status);
    } catch (e) {
      lastError = e instanceof Error ? e : new Error(String(e));
      if (lastError instanceof GroqHttpError && lastError.status !== 401 && lastError.status !== 429) {
        throw lastError;
      }
      continue;
    }
  }
  // Đã thử HẾT các key (cả 2, nếu có) mà vẫn toàn 401/429 -> tính là 1 lần lỗi breaker.
  recordGroqCircuitFailure();
  throw lastError ?? new Error("GROQ_ALL_KEYS_FAILED");
}

export function jsonOk(data: unknown): Response {
  return new Response(JSON.stringify(data, null, 2), {
    status: 200,
    headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
  });
}

export function jsonError(code: string, status: number): Response {
  return new Response(JSON.stringify({ error: code }), {
    status,
    headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
  });
}

// ===== sanitizeClientError: các lỗi *_ERROR_<status> (Groq/Gemini/DeepL/Azure) nhúng thẳng tối
// đa 300 ký tự body gốc trả về từ provider - hữu ích để debug qua console.error() NHƯNG không
// nên trả nguyên văn ra client, vì bất kỳ ai có JWT hợp lệ đều gọi được endpoint này (xem
// verifyUser() trong index.ts - JWT không đồng nghĩa "chắc chắn là app thật") nên client-facing
// message chỉ nên còn lại đúng mã lỗi + status, phần chi tiết body gốc (có thể chứa id tài
// khoản/nội dung nhạy cảm của bên thứ 3) chỉ giữ lại trong log server (console.error đã in đầy
// đủ msg trước khi hàm này được gọi).
export function sanitizeClientError(msg: string): string {
  const m = msg.match(/^([A-Z]+_ERROR_\d+):/);
  return m ? m[1] : msg;
}

// ===== translateViaDeepl: TÁCH RIÊNG khỏi handleTranslateDeepl() trong index.ts (2026-09-08,
// đợt thêm mock HTTP test) - đây là phần "gọi DeepL thật + parse response" THUẦN (không đụng
// Supabase/quota - phần check/ghi quota vẫn ở lại index.ts, gọi hàm này rồi tự quyết định có
// markQuotaExhausted() hay không dựa vào có bắt được DeeplQuotaExceededError hay không). Nhận
// fetchImpl làm tham số (mặc định = fetch thật) để test tự thay bằng fetch giả lập, không gọi
// mạng thật lúc chạy Deno.test.
export class DeeplQuotaExceededError extends Error {
  readonly bodyText: string;
  constructor(bodyText: string) {
    super(`DEEPL_ERROR_456: ${bodyText.slice(0, 300)}`);
    this.name = "DeeplQuotaExceededError";
    this.bodyText = bodyText;
  }
}

export async function translateViaDeepl(
  apiKey: string,
  text: string,
  targetLangCode: string,
  sourceLangCode: string | undefined,
  context: string | undefined,
  fetchImpl: typeof fetch = fetch,
): Promise<string> {
  const base = apiKey.trim().endsWith(":fx") ? "https://api-free.deepl.com" : "https://api.deepl.com";

  const payload: Record<string, unknown> = { text: [text], target_lang: targetLangCode };
  if (sourceLangCode) payload.source_lang = sourceLangCode;
  if (context) payload.context = context;

  const res = await fetchImpl(`${base}/v2/translate`, {
    method: "POST",
    headers: {
      Authorization: `DeepL-Auth-Key ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const bodyText = await res.text().catch(() => "");
    // HTTP 456 = "Quota Exceeded" - tín hiệu RIÊNG của DeepL cho "đã dùng hết quota billing
    // period hiện tại" (khác 429 rate-limit thường, vốn chỉ là tạm thời trong vài giây/phút).
    if (res.status === 456) {
      throw new DeeplQuotaExceededError(bodyText);
    }
    throw new Error(`DEEPL_ERROR_${res.status}: ${bodyText.slice(0, 300)}`);
  }

  const data = await res.json();
  const translated = data?.translations?.[0]?.text || "";
  if (!translated) throw new Error("DEEPL_EMPTY_RESPONSE");
  return translated;
}
