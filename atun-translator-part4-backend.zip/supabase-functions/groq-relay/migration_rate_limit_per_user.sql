-- Chạy 1 lần trong Supabase Studio -> SQL Editor (hoặc supabase db push), SAU KHI đã chạy
-- migration_rate_limit.sql VÀ migration_auth_rate_limit_user_id.sql (migration này chỉ BỔ
-- SUNG thêm 1 bảng+1 RPC mới, không đụng tới 2 migration trước).
--
-- Thêm lớp giới hạn THEO USER (bên cạnh lớp theo IP có sẵn) - xem comment đầy đủ ở
-- RATE_LIMIT_PER_DAY_PER_USER trong groq-relay/index.ts: lớp IP một mình không công bằng cho
-- nhiều user hợp lệ đứng sau cùng 1 IP (mạng trường học/công ty/NAT nhà mạng), lớp user đảm bảo
-- 1 user không dùng quá 1 phần hợp lý của hạn mức IP dùng chung.

create table if not exists request_rate_limit_user (
  user_id uuid not null,
  day text not null,
  op text not null,
  count integer not null default 0,
  primary key (user_id, day, op)
);

comment on table request_rate_limit_user is
  'Đếm số request/ngày THEO USER (bổ sung cho request_rate_limit đếm theo IP) - xem '
  'RATE_LIMIT_PER_DAY_PER_USER trong groq-relay/index.ts.';

-- Fix (audit - "file migration lệch khỏi production thật"): bản file này TỪNG thiếu dòng bật
-- Row Level Security bên dưới, trong khi 2 bảng chị em request_rate_limit
-- (migration_rate_limit.sql) và translate_quota_status (migration_translate_quota_status.sql)
-- đều có. Nếu đúng như file gốc (chưa bật RLS) trong khi KHÔNG có GRANT tường minh nào để tự
-- revoke lại quyền mặc định Supabase cấp cho anon/authenticated trên project đã tồn tại từ
-- trước (xem "Securing your API" - supabase.com/docs/guides/api/securing-your-api), đây sẽ là
-- lỗ hổng thật: ai cầm SUPABASE_ANON_KEY (vốn công khai theo thiết kế, nằm sẵn trong
-- www/app.js) cũng đọc/sửa/xoá được thẳng qua .../rest/v1/request_rate_limit_user.
--
-- ĐÃ KIỂM CHỨNG TRỰC TIẾP qua Supabase MCP (get_advisors) trên project thật đang chạy: RLS đã
-- được bật đúng trên bảng này (có thể đã tự chạy thêm ngoài file này từ trước) - KHÔNG phải lỗ
-- hổng đang mở trên production. Vẫn giữ dòng ALTER TABLE dưới đây trong file (an toàn để chạy
-- lại nhiều lần - lệnh này idempotent, no-op nếu đã bật) để bất kỳ ai dựng project MỚI từ đầu
-- bằng đúng file này không bị lặp lại thiếu sót tương tự.
alter table request_rate_limit_user enable row level security;

create or replace function increment_rate_limit_user(p_user_id uuid, p_day text, p_op text)
returns integer
language sql
as $$
  insert into request_rate_limit_user (user_id, day, op, count)
  values (p_user_id, p_day, p_op, 1)
  on conflict (user_id, day, op)
  do update set count = request_rate_limit_user.count + 1
  returning count;
$$;

-- Fix (audit - "function_search_path_mutable", Supabase Advisor): khoá cứng search_path='public'
-- (KHÔNG dùng '' rỗng - hàm tham chiếu bảng "request_rate_limit_user" không schema-qualify, ''
-- sẽ làm hàm không tìm thấy bảng, gãy production ngay). Đã áp dụng trực tiếp lên project thật
-- qua Supabase MCP (migration "harden_rate_limit_functions_search_path", cùng lúc với 2 overload
-- của increment_rate_limit trong migration_rate_limit.sql/migration_auth_rate_limit_user_id.sql)
-- và xác nhận lại bằng get_advisors() - cảnh báo này đã hết cho cả 3 hàm rate-limit của Atun
-- Translator (chỉ còn 3 hàm world-boss/arena thuộc 1 app KHÁC dùng chung project Supabase này,
-- ngoài phạm vi sửa của Atun Translator).
alter function increment_rate_limit_user(p_user_id uuid, p_day text, p_op text) set search_path = 'public';

-- Dọn dòng cũ hơn N ngày định kỳ (tự chạy tay hoặc đặt pg_cron) để bảng không phình vô hạn -
-- giống khuyến nghị dọn dẹp đã có cho request_rate_limit ở migration_rate_limit.sql.
-- delete from request_rate_limit_user where day < to_char(now() - interval '30 days', 'YYYY-MM-DD');
