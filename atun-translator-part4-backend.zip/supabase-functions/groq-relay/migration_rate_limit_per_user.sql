-- Chạy 1 lần trong Supabase Studio -> SQL Editor (hoặc supabase db push), SAU KHI đã chạy
-- migration_rate_limit.sql VÀ migration_auth_rate_limit_user_id.sql (migration này chỉ BỔ
-- SUNG thêm 1 bảng+1 RPC mới, không đụng tới 2 migration trước).
--
-- Thêm lớp giới hạn THEO USER (bên cạnh lớp theo IP có sẵn) - xem comment đầy đủ ở
-- RATE_LIMIT_PER_DAY_PER_USER trong groq-relay/index.ts: lớp IP một mình không công bằng cho
-- nhiều user hợp lệ đứng sau cùng 1 IP (mạng trường học/công ty/NAT nhà mạng), lớp user đảm bảo
-- 1 user không dùng quá 1 phần hợp lý của hạn mức IP dùng chung.

create table if not exists request_rate_limit_user (
  user_id uuid not null,
  day text not null,
  op text not null,
  count integer not null default 0,
  primary key (user_id, day, op)
);

comment on table request_rate_limit_user is
  'Đếm số request/ngày THEO USER (bổ sung cho request_rate_limit đếm theo IP) - xem '
  'RATE_LIMIT_PER_DAY_PER_USER trong groq-relay/index.ts.';

create or replace function increment_rate_limit_user(p_user_id uuid, p_day text, p_op text)
returns integer
language sql
as $$
  insert into request_rate_limit_user (user_id, day, op, count)
  values (p_user_id, p_day, p_op, 1)
  on conflict (user_id, day, op)
  do update set count = request_rate_limit_user.count + 1
  returning count;
$$;

-- Dọn dòng cũ hơn N ngày định kỳ (tự chạy tay hoặc đặt pg_cron) để bảng không phình vô hạn -
-- giống khuyến nghị dọn dẹp đã có cho request_rate_limit ở migration_rate_limit.sql.
-- delete from request_rate_limit_user where day < to_char(now() - interval '30 days', 'YYYY-MM-DD');
