-- Chạy 1 lần trong Supabase Studio -> SQL Editor (hoặc supabase db push), SAU KHI đã chạy
-- migration_rate_limit.sql (migration này chỉ BỔ SUNG, không thay thế bảng cũ).
--
-- Đi kèm việc chuyển sang xác thực THEO NGƯỜI DÙNG thật (Supabase Auth ẩn danh + kiểm tra JWT
-- trong Edge Function - xem verifyUser() trong groq-relay/index.ts,
-- đúng như ghi chú "giải pháp triệt để" đã để lại trong migration_rate_limit.sql trước đây).
-- Fix (audit - "tham chiếu tới function không tồn tại"): bản trước đây còn nhắc kèm
-- "youtube-extract/index.ts" - function đó KHÔNG tồn tại trong repo này (chỉ có 1 Edge Function
-- duy nhất là groq-relay). Việc phát video YouTube ở phía client hiện chỉ là nhúng iframe
-- (window.location youtube.com/embed/..., xem www/app.js) - không cần backend riêng cho việc
-- này, nên không có function nào khác cần áp cùng cơ chế xác thực/rate-limit ở migration này.
-- Việc đếm/giới hạn request vẫn giữ nguyên THEO IP như cũ (không đổi ngưỡng chặn) - migration
-- này chỉ thêm cột user_id để GHI KÈM danh tính user thật (lấy từ JWT đã xác minh) vào mỗi dòng
-- đếm, giúp tra được "IP này đang bị chiếm bởi user nào" khi cần điều tra lạm dụng, thay vì chỉ
-- có mỗi địa chỉ IP.

alter table request_rate_limit
  add column if not exists user_id uuid;

comment on column request_rate_limit.user_id is
  'user_id thật lấy từ JWT Supabase Auth đã xác minh (verifyUser() trong index.ts) - chỉ để tra '
  'cứu/điều tra, KHÔNG dùng làm khoá đếm giới hạn (khoá đếm vẫn là ip+day+op như cũ, xem '
  'migration_rate_limit.sql) vì user ẩn danh có thể tự tạo lại user_id mới bất kỳ lúc nào.';

-- Overload thêm bản 4 tham số (giữ nguyên bản 3 tham số cũ để không phá bất kỳ chỗ gọi nào
-- chưa kịp cập nhật) - p_user_id NULL nếu người gọi chưa truyền (vd đang chạy thử/migrate dở).
create or replace function increment_rate_limit(p_ip text, p_day text, p_op text, p_user_id uuid default null)
returns integer
language sql
as $$
  insert into request_rate_limit (ip, day, op, count, user_id)
  values (p_ip, p_day, p_op, 1, p_user_id)
  on conflict (ip, day, op)
  do update set count = request_rate_limit.count + 1, user_id = coalesce(excluded.user_id, request_rate_limit.user_id)
  returning count;
$$;

-- Fix (audit - "function_search_path_mutable", Supabase Advisor): khoá cứng search_path='public'
-- cho ĐÚNG overload 4 tham số này (overload 3 tham số ở migration_rate_limit.sql cần lệnh ALTER
-- FUNCTION riêng - Postgres phân biệt overload theo đầy đủ chữ ký tham số). Đã áp dụng trực tiếp
-- lên project thật qua Supabase MCP, xem chi tiết trong migration_rate_limit_per_user.sql.
alter function increment_rate_limit(p_ip text, p_day text, p_op text, p_user_id uuid) set search_path = 'public';
