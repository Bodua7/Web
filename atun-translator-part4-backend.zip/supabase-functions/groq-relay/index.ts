// supabase/functions/groq-relay/index.ts
//
// Proxy cho Groq API va DeepL API - giau API key phia server (Supabase Secrets).
//
// Gọi từ client:
//   POST https://<project-ref>.supabase.co/functions/v1/groq-relay?op=transcribe
//        body: FormData { file, language? }
//   POST https://<project-ref>.supabase.co/functions/v1/groq-relay?op=translate
//        body: JSON { text, targetLangCode, context? }         (Groq LLM)
//   POST https://<project-ref>.supabase.co/functions/v1/groq-relay?op=translateGemini
//        body: JSON { text, targetLangCode, context? }         (Gemini LLM - tang du phong
//        thu 2 sau Groq, xem comment o handleTranslateGemini() vi sao dat sau Groq chu khong
//        thay Groq lam uu tien so 1)
//   POST https://<project-ref>.supabase.co/functions/v1/groq-relay?op=translateDeepl
//        body: JSON { text, targetLangCode, sourceLangCode?, context? }   (DeepL)
//   POST https://<project-ref>.supabase.co/functions/v1/groq-relay?op=translateAzure
//        body: JSON { text, targetLangCode, sourceLangCode? }   (Azure Translator - chi dung
//        rieng cho kk/uz/ky, xem AZURE_TARGET_LANG_MAP trong app.js)
//   GET  https://<project-ref>.supabase.co/functions/v1/groq-relay?op=debug
//        (liet ke model that dang co tren tai khoan, mo truc tiep tren trinh duyet)
//
// Bang Postgres translate_quota_status (xem migration_translate_quota_status.sql) theo doi
// het quota THEO THANG cho DeepL/Azure (2 provider co free-tier reset theo billing period thang)
// - doc/ghi qua service role key (SUPABASE_URL + SUPABASE_SERVICE_ROLE_KEY, 2 bien nay Supabase
// TU DONG bom san cho moi Edge Function, khong can tu set secret).

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
// Các hàm/hằng số THUẦN (không network, không đụng Deno.serve/Supabase client) đã tách sang
// pure.ts để Deno.test import được mà không phải chạy cả file này (xem comment đầu pure.ts) -
// hành vi runtime không đổi, chỉ đổi vị trí khai báo.
import {
  CORS_HEADERS,
  currentMonthKey,
  currentDayKey,
  getClientIp,
  isGroqCircuitOpen,
  jsonOk,
  jsonError,
  sanitizeClientError,
  translateViaDeepl,
  DeeplQuotaExceededError,
  translateViaAzure,
  AzureQuotaExceededError,
  translateViaGemini,
  getKeys,
  groqFetchWithFallback,
  getGroqCircuitDebugInfo,
} from "./pure.ts";

const supabaseAdmin = createClient(
  Deno.env.get("SUPABASE_URL") ?? "",
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
);

// isQuotaBlocked: đọc lỗi -> false (KHÔNG chặn) thay vì throw - lỗi đọc DB tạm thời không nên
// làm hỏng cả luồng dịch, coi như "chưa biết trạng thái" thì cứ thử gọi provider bình thường,
// để chính request đó tự xác định lại (thành hoặc lại lỗi 456/quota, ghi lại bảng).
async function isQuotaBlocked(provider: string): Promise<boolean> {
  try {
    const { data, error } = await supabaseAdmin
      .from("translate_quota_status")
      .select("exhausted_month")
      .eq("provider", provider)
      .maybeSingle();
    if (error || !data) return false;
    return data.exhausted_month === currentMonthKey();
  } catch {
    return false;
  }
}

// markQuotaExhausted: upsert - lần lỗi 456/quota tiếp theo trong CÙNG tháng chỉ cập nhật lại
// exhausted_at/last_error mới nhất, không tạo thêm dòng (provider là primary key).
async function markQuotaExhausted(provider: string, errorMsg: string): Promise<void> {
  try {
    await supabaseAdmin.from("translate_quota_status").upsert({
      provider,
      exhausted_at: new Date().toISOString(),
      exhausted_month: currentMonthKey(),
      last_error: errorMsg.slice(0, 300),
    });
  } catch (e) {
    // Best-effort: ghi DB lỗi thì chỉ log, KHÔNG throw - không được để lỗi ghi log làm hỏng
    // response dịch chính (request vẫn nên trả lỗi provider gốc cho client như bình thường).
    console.error("markQuotaExhausted lỗi ghi DB:", String(e));
  }
}

async function getQuotaStatusForDebug(): Promise<unknown> {
  try {
    const { data, error } = await supabaseAdmin.from("translate_quota_status").select("*");
    if (error) return { error: error.message };
    return data;
  } catch (e) {
    return { error: String(e) };
  }
}

const GROQ_BASE_URL = "https://api.groq.com/openai/v1";
const GROQ_STT_MODEL = "whisper-large-v3-turbo";

// Cap nhat 28/8/2026 theo danh sach model THAT tra ve tu /models (tai khoan nay
// khong con llama-3.x/llama-4 nua). Uu tien: gpt-oss-120b (chat luong cao nhat,
// 120b) -> qwen3.8-27b (du phong) -> gpt-oss-20b (nhe, nhanh, du phong cuoi).
const GROQ_TRANSLATE_MODELS = [
  "openai/gpt-oss-120b",
  "qwen/qwen3.8-27b",
  "openai/gpt-oss-20b",
];

// Mo rong tu 3 ma (vi/en/zh) sang DAY DU ~99 ngon ngu Whisper ho tro (xem WHISPER_LANGS trong
// www/app.js) - truoc day cac ma con lai (ja, ko, fr, de...) bi normalizeGroqLangCode() phia
// client chan, roi thang xuong Google Translate free (chat luong thap hon, hay bi 429) dù Groq
// (LLM) hoan toan dich duoc cac ngon ngu nay. "en-in" khong can rieng - client tu cat ve "en"
// truoc khi goi, nhung van them o day de an toan neu lo gui nguyen.
const LANG_NAMES: Record<string, string> = {
  vi: "Vietnamese",
  en: "English",
  "en-in": "English",
  zh: "Chinese",
  ja: "Japanese",
  ko: "Korean",
  ru: "Russian",
  fr: "French",
  de: "German",
  es: "Spanish",
  pt: "Portuguese",
  tr: "Turkish",
  it: "Italian",
  nl: "Dutch",
  ca: "Catalan",
  fa: "Persian",
  uk: "Ukrainian",
  kz: "Kazakh",
  eo: "Esperanto",
  hi: "Hindi",
  cs: "Czech",
  pl: "Polish",
  uz: "Uzbek",
  gu: "Gujarati",
  tg: "Tajik",
  te: "Telugu",
  ky: "Kyrgyz",
  ka: "Georgian",
  br: "Breton",
};

// ===== Tra NGƯỢC tên ngôn ngữ Whisper -> mã app (dùng cho handleTranscribe khi client gọi với
// language="auto") - Whisper/Groq trả về TÊN TIẾNG ANH viết thường (vd "vietnamese", "english"),
// không phải mã ISO như "vi"/"en". Dựng lại từ LANG_NAMES ở trên (code -> tên) để không phải
// duy trì 2 bảng riêng dễ lệch pha - "en-in" bị bỏ qua vì trùng tên "English" với "en" (giữ "en"
// đứng trước trong object literal nên Object.entries() lặp qua "en" trước, set trước, "en-in"
// tới sau bị bỏ vì đã có key "english" rồi - đúng ý muốn, không cần lọc thủ công).
// Không phủ được TOÀN BỘ tên Whisper hỗ trợ (Whisper hỗ trợ ~99 ngôn ngữ, LANG_NAMES chỉ có 29
// khớp catalog model của app) - tên Whisper trả về mà không khớp bảng này sẽ cho kết quả
// null/undefined, xử lý như "không xác định được" (an toàn, KHÔNG đoán bừa), y hệt hành vi cũ
// trước khi có tính năng này.
const WHISPER_NAME_TO_CODE: Record<string, string> = (() => {
  const map: Record<string, string> = {};
  for (const [code, name] of Object.entries(LANG_NAMES)) {
    const key = name.toLowerCase();
    if (!(key in map)) map[key] = code;
  }
  return map;
})();

// ===== Xác thực THEO NGƯỜI DÙNG thật (Supabase Auth ẩn danh) - THAY THẾ cho header
// "X-App-Secret" ghi cứng cũ (xem ghi chú cũ trong migration_rate_limit.sql: "giải pháp triệt
// để là chuyển sang xác thực theo người dùng thật, vd Supabase Auth ẩn danh + kiểm tra JWT
// trong Edge Function"). Client (app.js) gọi supabase.auth.signInAnonymously() để lấy 1
// access_token JWT gắn với 1 user_id ổn định (is_anonymous=true), gửi qua header
// "Authorization: Bearer <token>". verifyUser() ở đây gọi ngược lên Supabase Auth server (qua
// supabaseAdmin.auth.getUser(token)) để xác minh CHỮ KÝ + HẠN DÙNG thật của JWT đó - không chỉ
// đọc claim mù (JWT giả/hết hạn sẽ bị Auth server từ chối) - trả về user_id nếu hợp lệ, null
// nếu không (thiếu header/token giả/hết hạn). Khác X-App-Secret cũ, token này KHÔNG bị ghi cứng
// trong APK nên không thể chỉ đơn giản unzip APK ra rồi đọc được - phải thực sự đi qua luồng
// đăng nhập ẩn danh của Supabase Auth (vốn tự có rate-limit riêng phía Supabase, mặc định
// 30 lần đăng ký/giờ/IP).
async function verifyUser(req: Request): Promise<{ userId: string; isAnonymous: boolean } | null> {
  const authz = req.headers.get("Authorization") || "";
  const token = authz.startsWith("Bearer ") ? authz.slice(7).trim() : "";
  if (!token) return null;
  try {
    const { data, error } = await supabaseAdmin.auth.getUser(token);
    if (error || !data?.user) return null;
    const isAnonymous = (data.user as { is_anonymous?: boolean }).is_anonymous === true;
    return { userId: data.user.id, isAnonymous };
  } catch (e) {
    console.error("verifyUser lỗi:", String(e));
    return null;
  }
}

// getKeys(): xem pure.ts (đã tách qua đó cùng groqFetchWithFallback).

// ===== Rate limit theo IP/ngày (xem migration_rate_limit.sql để hiểu lịch sử lớp này - ban đầu
// bổ sung cho header X-App-Secret ghi cứng cũ, nay verifyUser() ở trên đã thay X-App-Secret
// bằng JWT thật; lớp rate-limit theo IP vẫn giữ lại làm phòng thủ độc lập bổ sung, không phụ
// thuộc vào cơ chế xác thực). =====
// Giới hạn RIÊNG cho từng op - transcribe (Whisper Cloud) đặt thấp nhất vì tốn phí/quota nhiều
// nhất trên mỗi lần gọi so với 1 câu dịch text ngắn.
const RATE_LIMIT_PER_DAY: Record<string, number> = {
  transcribe: 300,
  translate: 2000,
  translateGemini: 2000,
  translateDeepl: 1000,
  translateAzure: 1000,
  // Fix (audit đợt 3 - "debug bypass rate-limit"): op=debug trước đây được xử lý TRƯỚC
  // enforceRateLimit() trong Deno.serve() (đã sửa, xem bên dưới) nên hoàn toàn không bị giới
  // hạn - có JWT ẩn danh (miễn phí, chỉ bị Supabase Auth giới hạn 30 lần đăng ký/giờ/IP ở tầng
  // hạ tầng, không phải giới hạn của app này) là gọi được vô hạn lần, mỗi lần bắn 1 request thật
  // tới Groq /models bằng key thật của server. Đặt hạn mức THẤP vì op này chỉ để debug thủ công
  // (mở trực tiếp trên trình duyệt xem README) - không nằm trong luồng dùng bình thường của app,
  // không có lý do gì 1 user/IP cần gọi quá vài chục lần/ngày.
  debug: 50,
};

// ===== Giới hạn RIÊNG CHO TỪNG USER (bằng nửa hạn mức IP ở trên) - bổ sung sau khi có xác thực
// JWT thật (xem verifyUser()). Hạn mức IP một mình không đủ công bằng: nhiều người dùng hợp lệ
// đứng sau CÙNG 1 IP (mạng trường học/công ty/NAT nhà mạng) chia nhau đúng 1 hạn mức IP - nếu 1
// user (hoặc 1 script tự động tạo request liên tục dưới 1 user_id) tiêu hết hạn mức đó thì mọi
// người khác cùng IP bị vạ lây. Đặt hạn mức user THẤP HƠN hạn mức IP (không phải thay thế) để
// mỗi user chỉ được dùng tối đa 1 PHẦN hợp lý của hạn mức IP dùng chung, đồng thời hạn mức IP
// vẫn là trần chung chống 1 IP tạo vô số user ẩn danh mới để né giới hạn (đổi user_id dễ, đổi IP
// khó hơn). Request bị chặn nếu VI PHẠM BẤT KỲ giới hạn nào trong 2 giới hạn.
const RATE_LIMIT_PER_DAY_PER_USER: Record<string, number> = {
  transcribe: 150,
  translate: 1000,
  translateGemini: 1000,
  translateDeepl: 500,
  translateAzure: 500,
  // Xem rationale ở RATE_LIMIT_PER_DAY.debug phía trên - thấp hơn hạn mức IP như quy ước chung.
  debug: 20,
};

// enforceRateLimit: trả về Response lỗi nếu IP HOẶC user đã vượt hạn mức NGÀY cho op này, null
// nếu còn được phép đi tiếp. Lỗi đọc/ghi DB tạm thời -> KHÔNG chặn (fail-open), cùng nguyên tắc
// với isQuotaBlocked()/markQuotaExhausted() ở trên: sự cố hạ tầng phụ (bảng rate-limit) không
// nên làm hỏng luồng dịch chính cho toàn bộ người dùng hợp lệ.
async function enforceRateLimit(req: Request, op: string, userId: string): Promise<Response | null> {
  const limit = RATE_LIMIT_PER_DAY[op];
  if (!limit) return null; // op không nằm trong danh sách cần giới hạn (vd đã bị chặn ở chỗ khác)
  try {
    const ip = getClientIp(req);
    // p_user_id: ghi kèm user_id thật (từ verifyUser()) vào bảng - vẫn đếm/giới hạn THEO IP như
    // cũ (không đổi hành vi chặn), chỉ thêm cột để truy vết đúng user nào gây ra khi cần tra
    // (xem migration_auth_rate_limit_user_id.sql). RPC cũ (increment_rate_limit 3 tham số) có
    // thể không còn tồn tại sau khi chạy migration mới (được thay bằng bản 4 tham số overload)
    // - nếu Postgres báo lỗi "function not found" do migration mới chưa chạy, lỗi đó rơi vào
    // catch bên dưới và fail-open như các lỗi DB tạm thời khác, không chặn nhầm người dùng hợp lệ.
    const { data, error } = await supabaseAdmin.rpc("increment_rate_limit", {
      p_ip: ip,
      p_day: currentDayKey(),
      p_op: op,
      p_user_id: userId,
    });
    if (error) return null;
    if (typeof data === "number" && data > limit) {
      return jsonError("RATE_LIMIT_EXCEEDED", 429);
    }

    // Lớp thứ 2: giới hạn riêng theo user (xem RATE_LIMIT_PER_DAY_PER_USER ở trên). Bảng/RPC
    // nằm trong migration_auth_rate_limit_user_id.sql - nếu migration đó CHƯA chạy, RPC này
    // chưa tồn tại và fail-open (bỏ qua lớp user, chỉ còn lớp IP) giống hệt cách xử lý lỗi DB ở
    // trên, không chặn nhầm ai vì thiếu migration.
    const userLimit = RATE_LIMIT_PER_DAY_PER_USER[op];
    if (userLimit) {
      const { data: userCount, error: userErr } = await supabaseAdmin.rpc("increment_rate_limit_user", {
        p_user_id: userId,
        p_day: currentDayKey(),
        p_op: op,
      });
      if (!userErr && typeof userCount === "number" && userCount > userLimit) {
        return jsonError("RATE_LIMIT_EXCEEDED", 429);
      }
    }

    return null;
  } catch {
    return null;
  }
}

// ===== Circuit breaker phía SERVER cho Groq - xem comment đầy đủ ở pure.ts (đã tách qua đó
// cùng với isGroqCircuitOpen/recordGroqCircuitSuccess/recordGroqCircuitFailure). =====

// ===== Gemini - tang du phong LLM thu 2, chen NGAY SAU Groq (truoc DeepL). Ly do dat o day
// (khong phai ngay sau DeepL/Azure): Gemini la LLM nhu Groq nen phu duoc CA ~29 ngon ngu app
// ho tro (dung chung LANG_NAMES ben tren), trong khi DeepL chi co ~16/29 ma - de Gemini lam
// tang du phong LLM thu 2 truoc khi roi xuong DeepL/Azure (von la NMT chuyen biet, chi phu 1
// phan ngon ngu) se giu duoc chat luong dich LLM cho nhieu ngon ngu hon truoc khi phai ha
// xuong Google Translate free. Model uu tien gemini-3.5-flash-lite (nhanh, re, du cho dich
// cau ngan real-time) -> du phong gemini-2.5-flash-lite (on dinh, da dung lau hon).
// GEMINI_BASE_URL/GEMINI_TRANSLATE_MODELS/translateViaGemini(): xem pure.ts.

function getGeminiKey(): string | null {
  const k = Deno.env.get("GEMINI_API_KEY");
  return k && k.length > 0 ? k : null;
}

async function handleTranslateGemini(req: Request): Promise<Response> {
  const body = await req.json().catch(() => null);
  const text = body?.text;
  const targetLangCode = body?.targetLangCode;
  // context: giong het dinh dang cua op=translate (Groq) - mang cau NGUON gan nhat, toi da 3
  // cau - tai dung chung translationContextHistory phia client (xem translateGemini() trong
  // app.js), khong can dinh dang rieng.
  const context: string[] = Array.isArray(body?.context)
    ? body.context.filter((c: unknown): c is string => typeof c === "string" && c.trim().length > 0).slice(-3)
    : [];

  if (!text || !targetLangCode) {
    return jsonError("MISSING_TEXT_OR_TARGET", 400);
  }

  const key = getGeminiKey();
  if (!key) throw new Error("SERVER_MISSING_GEMINI_KEY");

  const targetLangName =
    LANG_NAMES[targetLangCode] || LANG_NAMES[String(targetLangCode).split("-")[0]] || "English";

  // Logic gọi Gemini (kèm fallback nhiều model + dựng prompt) đầy đủ nằm ở pure.ts
  // (translateViaGemini) - tách ra để test được bằng fetch giả lập (xem pure.test.ts). Hành vi
  // giữ NGUYÊN so với trước khi tách.
  const { translated, pinyin, model } = await translateViaGemini(key, text, targetLangName, context);
  return jsonOk({ translated, pinyin, model });
}

async function handleDebug(): Promise<Response> {
  const keys = getKeys();
  const circuitDebug = getGroqCircuitDebugInfo();
  const circuitInfo = {
    open: isGroqCircuitOpen(),
    failCount: circuitDebug.failCount,
    openUntil: circuitDebug.openUntil ? new Date(circuitDebug.openUntil).toISOString() : null,
  };
  const monthlyQuotaStatus = await getQuotaStatusForDebug(); // DeepL/Azure - xem translate_quota_status
  if (keys.length === 0) {
    return jsonOk({
      ok: false,
      reason: "KHONG_TIM_THAY_SECRET",
      groqCircuit: circuitInfo,
      monthlyQuotaStatus,
    });
  }
  try {
    const res = await fetch(`${GROQ_BASE_URL}/models`, {
      headers: { Authorization: `Bearer ${keys[0]}` },
    });
    const data = await res.json();
    const ids: string[] = (data.data || []).map((m: any) => m.id).sort();
    return jsonOk({
      ok: true,
      httpStatus: res.status,
      totalModels: ids.length,
      modelIds: ids,
      currentTranslateModels: GROQ_TRANSLATE_MODELS,
      groqCircuit: circuitInfo,
      monthlyQuotaStatus,
    });
  } catch (e) {
    return jsonOk({ ok: false, error: String(e), groqCircuit: circuitInfo });
  }
}

// groqFetchWithFallback(): xem pure.ts (đã tách qua đó cùng getKeys()).

async function handleTranscribe(req: Request): Promise<Response> {
  const incomingForm = await req.formData();
  const file = incomingForm.get("file");
  const language = incomingForm.get("language");

  if (!(file instanceof File)) {
    return jsonError("MISSING_FILE", 400);
  }

  const res = await groqFetchWithFallback((key) => {
    const form = new FormData();
    form.append("file", file, "speech.webm");
    form.append("model", GROQ_STT_MODEL);
    // verbose_json (thay vì json trước đây) - CẦN thiết để lấy field "language" (Whisper tự
    // phát hiện ngôn ngữ khi client không gửi "language", tức chế độ "Tự động nhận diện" +
    // Whisper Cloud) - "json" thường KHÔNG trả field này, khiến app không bao giờ biết Whisper
    // vừa nhận diện ngôn ngữ gì cho đoạn audio đó (xem WHISPER_NAME_TO_CODE ở trên).
    form.append("response_format", "verbose_json");
    if (language && language !== "auto") {
      form.append("language", String(language));
    }
    return {
      url: `${GROQ_BASE_URL}/audio/transcriptions`,
      init: {
        method: "POST",
        headers: { Authorization: `Bearer ${key}` },
        body: form,
      },
    };
  });

  const data = await res.json();
  // data.language: tên tiếng Anh viết thường Whisper tự phát hiện (vd "vietnamese") - CHỈ có ý
  // nghĩa khi client gọi với language="auto" (không ép ngôn ngữ trước); nếu client đã ép sẵn 1
  // ngôn ngữ cụ thể, field này thường phản ánh đúng ngôn ngữ đã ép nên không cần dùng tới, vẫn
  // trả về cho nhất quán. Tra qua WHISPER_NAME_TO_CODE ra mã app - null nếu Whisper trả tên
  // không khớp bảng 29 ngôn ngữ app hỗ trợ (an toàn, không đoán bừa - xem ghi chú ở bảng đó).
  const detectedLangName = typeof data.language === "string" ? data.language.toLowerCase() : "";
  const detectedLangCode = WHISPER_NAME_TO_CODE[detectedLangName] ?? null;
  return jsonOk({ text: (data.text || "").trim(), language: detectedLangCode });
}

async function handleTranslate(req: Request): Promise<Response> {
  const body = await req.json().catch(() => null);
  const text = body?.text;
  const targetLangCode = body?.targetLangCode;
  // context: vai cau NGUON (chua dich) noi/xuat hien NGAY TRUOC cau dang dich, do client tu
  // gui kem (xem groqContextHistory trong app.js) - giup model giai quyet dai tu bi luoc,
  // thanh ngu noi cau, xung ho nhat quan giua cac cau lien tiep trong 1 doan hoi thoai/video,
  // thay vi dich moi cau hoan toan doc lap nhu truoc. Toi da 3 cau, chi lay string hop le.
  const context: string[] = Array.isArray(body?.context)
    ? body.context.filter((c: unknown): c is string => typeof c === "string" && c.trim().length > 0).slice(-3)
    : [];

  if (!text || !targetLangCode) {
    return jsonError("MISSING_TEXT_OR_TARGET", 400);
  }

  // Fallback cat ve ma goc (vd "zh-CN" -> "zh") neu khong tra trung thang - phong truong hop
  // client gui nguyen ma co hau to vung/mien chua co trong LANG_NAMES.
  const targetLangName =
    LANG_NAMES[targetLangCode] || LANG_NAMES[String(targetLangCode).split("-")[0]] || "English";

  const contextBlock = context.length > 0
    ? `\n\nContext: the following ${context.length} sentence(s) were said immediately before ` +
      `the message you need to translate (same speaker/scene, original language, for reference ` +
      `only - to resolve pronouns, ellipsis, and keep terminology consistent). Do NOT translate ` +
      `or repeat them in your output:\n` +
      context.map((c, i) => `${i + 1}. ${c}`).join("\n")
    : "";

  const systemPrompt =
    `You are a professional real-time interpreter. Translate the user's ` +
    `message into ${targetLangName}. ` +
    `Rules: output ONLY the translation of the message, no explanations, no quotes. ` +
    `If the target language is Chinese, also provide Pinyin on a new line prefixed ` +
    `with "PINYIN:". ` +
    `If not Chinese, do not include a PINYIN line.` +
    contextBlock;

  let lastErr: Error | null = null;
  for (const model of GROQ_TRANSLATE_MODELS) {
    try {
      const res = await groqFetchWithFallback((key) => ({
        url: `${GROQ_BASE_URL}/chat/completions`,
        init: {
          method: "POST",
          headers: {
            Authorization: `Bearer ${key}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model,
            temperature: 0.2,
            messages: [
              { role: "system", content: systemPrompt },
              { role: "user", content: text },
            ],
          }),
        },
      }));

      const data = await res.json();
      const raw = data.choices?.[0]?.message?.content?.trim() || "";

      let translated = raw;
      let pinyin = "";
      const pinyinMatch = raw.match(/PINYIN:\s*(.+)/i);
      if (pinyinMatch) {
        pinyin = pinyinMatch[1].trim();
        translated = raw.replace(/PINYIN:\s*.+/i, "").trim();
      }

      return jsonOk({ translated, pinyin, model });
    } catch (e) {
      lastErr = e instanceof Error ? e : new Error(String(e));
      continue;
    }
  }
  throw lastErr ?? new Error("GROQ_ALL_MODELS_FAILED");
}

// DeepL - tang dich xen giua Groq va Google Translate free (xem comment o app.js:
// DEEPL_TARGET_LANG_MAP - vi sao chi dung lam du phong, khong thay Groq lam uu tien so 1).
// Free-tier key DeepL luon co hau to ":fx" va PHAI goi api-free.deepl.com (khac Pro key goi
// api.deepl.com) - tu phat hien qua hau to nay thay vi bat nguoi dung config them 1 bien moi.
async function handleTranslateDeepl(req: Request): Promise<Response> {
  const body = await req.json().catch(() => null);
  const text = body?.text;
  // targetLangCode/sourceLangCode: da la ma DEEPL chuan (vd "VI", "EN-US") do client tu map
  // san (DEEPL_TARGET_LANG_MAP/DEEPL_SOURCE_LANG_MAP trong app.js) - server khong tu doan/map
  // lai de tranh 2 noi co danh sach ngon ngu lech nhau.
  const targetLangCode = body?.targetLangCode;
  const sourceLangCode = typeof body?.sourceLangCode === "string" ? body.sourceLangCode : undefined;
  // context: 1 chuoi (khac context dang mang cau cua op=translate/Groq) - dung dinh dang
  // "context" cua DeepL API (tham khao de dich cau hien tai, KHONG duoc dich/tra ve).
  const context = typeof body?.context === "string" && body.context.trim() ? body.context : undefined;

  if (!text || !targetLangCode) {
    return jsonError("MISSING_TEXT_OR_TARGET", 400);
  }

  // Tháng này DeepL đã từng trả 456 (Quota Exceeded) -> chắc chắn vẫn còn hết cho tới khi
  // sang billing period mới, bỏ qua thẳng, không tốn round-trip gọi DeepL vô ích.
  if (await isQuotaBlocked("deepl")) {
    throw new Error("DEEPL_QUOTA_EXHAUSTED_THIS_MONTH");
  }

  const key = Deno.env.get("DEEPL_API_KEY");
  if (!key) throw new Error("SERVER_MISSING_DEEPL_KEY");

  // Gọi DeepL thật + parse response - logic đầy đủ nằm ở pure.ts (translateViaDeepl), tách ra
  // để test được bằng fetch giả lập (xem pure.test.ts). Hành vi ở đây giữ NGUYÊN so với trước
  // khi tách: 456 -> ghi nhận hết quota + báo lỗi giống hệt message cũ (DeeplQuotaExceededError
  // tự dựng đúng message "DEEPL_ERROR_456: ...", xem pure.ts).
  try {
    const translated = await translateViaDeepl(key, text, targetLangCode, sourceLangCode, context);
    return jsonOk({ translated });
  } catch (e) {
    if (e instanceof DeeplQuotaExceededError) {
      await markQuotaExhausted("deepl", e.bodyText || "HTTP 456 Quota Exceeded");
    }
    throw e;
  }
}

// ===== Azure Translator - tang chen giua Groq va Google Translate free, RIENG cho 3 ma
// DeepL KHONG ho tro: kk (Kazakh, app dung ma "kz"), uz (Uzbek), ky (Kyrgyz) - xem
// AZURE_TARGET_LANG_MAP trong app.js. KHONG dung lam tang thay the DeepL cho cac ma DeepL da
// ho tro tot (khong can them 1 dependency moi cho thu da co san). Free tier F0 cua Azure
// Translator: 2 trieu ky tu/thang - lon hon nhieu DeepL free (500k/thang), giup giam ap luc
// quota rieng cho 3 ma nay khi Groq het quota.
async function handleTranslateAzure(req: Request): Promise<Response> {
  const body = await req.json().catch(() => null);
  const text = body?.text;
  // targetLangCode/sourceLangCode: da la ma AZURE chuan (vd "kk", "uz", "ky") do client tu map
  // san (AZURE_TARGET_LANG_MAP/AZURE_SOURCE_LANG_MAP trong app.js) - cung nguyen tac voi
  // handleTranslateDeepl(): server khong tu doan/map lai de tranh 2 noi co danh sach lech nhau.
  const targetLangCode = body?.targetLangCode;
  const sourceLangCode = typeof body?.sourceLangCode === "string" ? body.sourceLangCode : undefined;

  if (!text || !targetLangCode) {
    return jsonError("MISSING_TEXT_OR_TARGET", 400);
  }

  // Tháng này Azure đã từng báo hết quota -> bỏ qua thẳng, không gọi mạng vô ích.
  if (await isQuotaBlocked("azure")) {
    throw new Error("AZURE_QUOTA_EXHAUSTED_THIS_MONTH");
  }

  const key = Deno.env.get("AZURE_TRANSLATOR_KEY");
  if (!key) throw new Error("SERVER_MISSING_AZURE_KEY");
  // Region BAT BUOC voi resource Azure Translator tao theo vung (khac Global resource) - da
  // so tai khoan free F0 deu tao theo vung, nen coi day la bat buoc thay vi tuy chon de tranh
  // loi 401 kho hieu ("kho xac thuc") khi thieu header nay.
  const region = Deno.env.get("AZURE_TRANSLATOR_REGION");
  if (!region) throw new Error("SERVER_MISSING_AZURE_REGION");
  const endpoint = Deno.env.get("AZURE_TRANSLATOR_ENDPOINT") || "https://api.cognitive.microsofttranslator.com";

  // Logic gọi Azure + phát hiện hết quota (heuristic) đầy đủ nằm ở pure.ts (translateViaAzure) -
  // tách ra để test được bằng fetch giả lập (xem pure.test.ts). Hành vi giữ NGUYÊN so với trước
  // khi tách.
  try {
    const translated = await translateViaAzure(key, region, endpoint, text, targetLangCode, sourceLangCode);
    return jsonOk({ translated });
  } catch (e) {
    if (e instanceof AzureQuotaExceededError) {
      await markQuotaExhausted("azure", e.bodyText || `HTTP ${e.status}`);
    }
    throw e;
  }
}

// jsonOk/jsonError/sanitizeClientError: xem pure.ts (đã tách qua đó cùng CORS_HEADERS).

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: CORS_HEADERS });
  }

  // ===== Mọi request (kể cả GET op=debug) đều phải mang JWT hợp lệ của 1 user Supabase Auth
  // thật (ẩn danh hoặc đã đăng nhập) - xem verifyUser() ở trên. Đây là gate DUY NHẤT thay cho
  // checkAppSecret() cũ; op=debug không cần check thêm lần 2 vì đã qua đúng gate này rồi. =====
  const user = await verifyUser(req);
  if (!user) return jsonError("UNAUTHORIZED", 401);

  const url = new URL(req.url);
  const op = url.searchParams.get("op");

  // Fix (audit đợt 3 - "debug bypass rate-limit"): TRƯỚC ĐÂY op=debug được trả về ở ĐÂY, TRƯỚC
  // khi enforceRateLimit() được gọi (nó nằm trong khối try{} bên dưới, chỉ áp dụng cho nhánh
  // POST) - nghĩa là request GET op=debug chưa từng đi qua rate-limit dù có RATE_LIMIT_PER_DAY
  // hay không. Giờ enforceRateLimit() được gọi tường minh ngay tại đây cho riêng nhánh debug,
  // TRƯỚC khi gọi handleDebug() (vốn tự bắn 1 request thật tới Groq /models bằng key server) -
  // xem RATE_LIMIT_PER_DAY.debug/RATE_LIMIT_PER_DAY_PER_USER.debug để biết hạn mức.
  if (req.method === "GET" && op === "debug") {
    const rateLimitError = await enforceRateLimit(req, op, user.userId);
    if (rateLimitError) return rateLimitError;
    return handleDebug();
  }

  if (req.method !== "POST") {
    return jsonError("METHOD_NOT_ALLOWED", 405);
  }

  try {
    // ===== Fix: giới hạn thiệt hại nếu X-App-Secret bị lộ (xem enforceRateLimit() + comment ở
    // migration_rate_limit.sql) - chặn TRƯỚC KHI gọi bất kỳ provider trả phí/free-tier nào. =====
    if (op) {
      const rateLimitError = await enforceRateLimit(req, op, user.userId);
      if (rateLimitError) return rateLimitError;
    }
    if (op === "transcribe") return await handleTranscribe(req);
    if (op === "translate") return await handleTranslate(req);
    if (op === "translateGemini") return await handleTranslateGemini(req);
    if (op === "translateDeepl") return await handleTranslateDeepl(req);
    if (op === "translateAzure") return await handleTranslateAzure(req);
    return jsonError("UNKNOWN_OP", 400);
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("groq-relay error:", msg);
    const status =
      msg === "SERVER_MISSING_GROQ_KEY" ||
      msg === "SERVER_MISSING_GEMINI_KEY" ||
      msg === "SERVER_MISSING_DEEPL_KEY" ||
      msg === "SERVER_MISSING_AZURE_KEY" ||
      msg === "SERVER_MISSING_AZURE_REGION"
        ? 500
        : 502;
    return jsonError(sanitizeClientError(msg), status);
  }
});
