import shutil
import os

# Copy model Vosk (đã để sẵn trong assets-for-android/) vào android/app/src/main/assets/
# sau khi đã chạy `cap add android` / `cap sync android` (thư mục android/ được tạo lúc đó).
# Chạy script này SAU patch-vosk-gradle.py, TRƯỚC khi build APK.

SRC = "assets-for-android"
DEST = "android/app/src/main/assets"

if not os.path.isdir("android"):
    raise SystemExit("FAIL: chưa thấy thư mục android/ - chạy `npx cap add android` trước.")

os.makedirs(DEST, exist_ok=True)

for name in os.listdir(SRC):
    src_path = os.path.join(SRC, name)
    dest_path = os.path.join(DEST, name)
    if os.path.isdir(src_path):
        if os.path.exists(dest_path):
            print(f"SKIP: {dest_path} đã tồn tại (xóa thủ công nếu muốn ghi đè model mới)")
            continue
        shutil.copytree(src_path, dest_path)
        print(f"OK: đã copy {src_path} -> {dest_path}")

print("=== Xong copy model assets. Nhớ kiểm tra dung lượng APK (~51MB model tiếng Việt). ===")
