import re

path = "android/app/src/main/AndroidManifest.xml"
with open(path, "r", encoding="utf-8") as f:
    content = f.read()

permissions = [
    '<uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />',
    '<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />',
    '<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />',
    '<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION" />',
    '<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
    '<uses-permission android:name="android.permission.RECORD_AUDIO" />',
    '<uses-permission android:name="android.permission.WAKE_LOCK" />',
]

# Insert permissions right after <manifest ...> opening tag
if 'SYSTEM_ALERT_WINDOW' not in content:
    manifest_tag_end = content.index(">", content.index("<manifest")) + 1
    perm_block = "\n    " + "\n    ".join(permissions)
    content = content[:manifest_tag_end] + perm_block + content[manifest_tag_end:]

# Insert service declaration inside <application>...</application>, before closing tag
service_block = '''
    <service
        android:name=".ForegroundService"
        android:foregroundServiceType="mediaPlayback"
        android:exported="false" />
    <service
        android:name=".AudioCaptureService"
        android:foregroundServiceType="mediaProjection"
        android:exported="false" />
'''
if 'ForegroundService' not in content:
    app_close_idx = content.rindex("</application>")
    content = content[:app_close_idx] + service_block + content[app_close_idx:]
elif 'AudioCaptureService' not in content:
    audio_service_only = '''
    <service
        android:name=".AudioCaptureService"
        android:foregroundServiceType="mediaProjection"
        android:exported="false" />
'''
    app_close_idx = content.rindex("</application>")
    content = content[:app_close_idx] + audio_service_only + content[app_close_idx:]

with open(path, "w", encoding="utf-8") as f:
    f.write(content)

print("Manifest patched OK")
