def pytest_configure(config):
    config.addinivalue_line(
        "markers",
        "network: test gọi mạng thật (HEAD request) - có thể bị skip nếu không có "
        "internet, nhưng SẼ fail (không skip) nếu URL thật sự trả lỗi 4xx/5xx.",
    )
