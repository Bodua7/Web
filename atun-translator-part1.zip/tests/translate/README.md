# Test harness cho retry/rate-limit của `translateGoogleFree` (Hạng mục H)

Port thuần Python của logic retry khi endpoint free `translate.googleapis.com`
trả về HTTP 429 (rate-limit), để test số lần retry/thời gian chờ đúng công
thức mà không cần chờ bị rate-limit thật trên app.

## Chạy test

```bash
cd tests/translate
pip install pytest
pytest -v
```

## Cấu trúc

- `google_free_translate.py` — bản dịch tay 1-1 từ hàm `translateGoogleFree()`
  trong `www/index.html`. `fetch`/`sleep` được truyền vào (dependency
  injection) thay vì gọi thẳng `fetch()`/`setTimeout()` của trình duyệt, để
  test giả lập response và đo thời gian chờ mà không cần mạng thật/không phải
  chờ vài giây mỗi lần chạy.
- `test_google_free_translate.py` — test: thành công ngay lần đầu (không
  retry), retry đúng số lần + đúng công thức thời gian chờ (1s/2s/3s), dừng
  đúng lúc và raise lỗi có mã HTTP cuối cùng sau khi hết lượt retry, lỗi khác
  429 thì raise ngay không retry, `retries_left` tuỳ chỉnh.

## ⚠️ Bắt buộc giữ đồng bộ

`google_free_translate.py` là bản dịch **tay**, không phải import trực tiếp
từ JS. Mỗi khi sửa `translateGoogleFree()` trong `www/index.html` (đổi số lần
retry mặc định, công thức `waitMs`, điều kiện dừng...) phải sửa lại file này
cho khớp, rồi chạy lại `pytest` để biết thay đổi đó ảnh hưởng gì đến hành vi.
