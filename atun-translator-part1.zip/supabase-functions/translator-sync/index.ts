// Edge Function: translator-sync
// Đồng bộ settings (targetLang/sourceLang/captureMode/fontSize/vị trí overlay...) + nhật ký
// dịch giữa nhiều thiết bị của cùng 1 người dùng - KHÔNG cần đăng nhập, định danh bằng "Mã
// đồng bộ" tự chọn (giống mật khẩu riêng), gõ giống nhau trên các máy muốn đồng bộ với nhau.
//
// Dùng SUPABASE_SERVICE_ROLE_KEY (biến môi trường Supabase tự cấp sẵn cho mọi Edge Function,
// KHÔNG cần cấu hình thêm, KHÔNG lộ ra client) để ghi thẳng qua PostgREST. Bảng translator_sync
// bật RLS và không cấp policy nào cho anon -> client không thể đọc/ghi trực tiếp bảng này, chỉ
// đi qua function này (client cũng không cần biết anon key).
//
// ===== Nâng cấp bảo mật (Hạng mục I) =====
// Bản gốc lưu "Mã đồng bộ" dạng PLAINTEXT làm primary key, không giới hạn tốc độ gọi, độ dài
// tối thiểu chỉ 4 ký tự -> ai đoán trúng mã (kể cả brute-force tự động) là đọc/ghi được toàn
// bộ settings + nhật ký dịch của người khác. 2 lớp phòng thủ mới:
//   1. Hash SHA-256 mã đồng bộ trước khi lưu/truy vấn - KHÔNG BAO GIỜ lưu plaintext trong DB,
//      giảm rủi ro nếu DB/dashboard Supabase bị lộ (không tự nó chặn brute-force online, chỉ
//      chặn đọc trộm offline nếu có ai truy cập được DB).
//   2. Rate-limit theo IP (20 request/phút/thao-tác) - chặn brute-force ONLINE. Với mã tối
//      thiểu 8 ký tự (chữ/số/-/_, ~62^8 ≈ 2.2×10^14 tổ hợp), ở tốc độ 20 req/phút thì brute-
//      force hết không gian mã mất hàng triệu năm - đủ để coi là bất khả thi thực tế, kể cả
//      khi kẻ tấn công dùng nhiều IP khác nhau để né rate-limit (mỗi IP vẫn chỉ đoán được rất
//      ít mã/phút).
//
// SQL cần chạy 1 lần trong Supabase SQL Editor trước khi dùng (xem cuối file này) - CÓ THAY
// ĐỔI CẤU TRÚC BẢNG so với bản cũ (đổi cột sync_code -> sync_code_hash), xem phần MIGRATION.

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const TABLE = 'translator_sync';
const RATE_LIMIT_TABLE = 'translator_sync_rate_limit';

// Nâng từ 4 lên 8 ký tự tối thiểu - 4 ký tự (bảng chữ/số ~62 ký tự khả dụng, 62^4 ≈ 14.7
// triệu tổ hợp) vẫn brute-force nổi trong vài tuần dù có rate-limit; 8 ký tự (62^8 ≈ 2.2×10^14)
// thì không khả thi. Đây là thay đổi KHÔNG TƯƠNG THÍCH NGƯỢC với mã <8 ký tự đã lưu trước đó -
// xem MIGRATION note cuối file.
const MIN_SYNC_CODE_LENGTH = 8;
const MAX_SYNC_CODE_LENGTH = 64;

const RATE_LIMIT_WINDOW_MS = 60_000; // cửa sổ 1 phút
const RATE_LIMIT_MAX_REQUESTS = 20; // tối đa 20 request/phút cho mỗi (thao-tác, IP)

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
  });
}

function restHeaders() {
  return {
    apikey: SERVICE_ROLE_KEY,
    Authorization: `Bearer ${SERVICE_ROLE_KEY}`,
    'Content-Type': 'application/json',
  };
}

// Chỉ chấp nhận chữ/số/gạch ngang/gạch dưới, MIN-MAX ký tự - tránh ký tự lạ lọt vào query
// string PostgREST, và tránh mã quá ngắn dễ brute-force.
function isValidSyncCode(code: unknown): code is string {
  return (
    typeof code === 'string' &&
    new RegExp(`^[a-zA-Z0-9_-]{${MIN_SYNC_CODE_LENGTH},${MAX_SYNC_CODE_LENGTH}}$`).test(code)
  );
}

// SHA-256 qua Web Crypto API (có sẵn native trong Deno, không cần thư viện ngoài). Mỗi mã
// đồng bộ + cùng thuật toán luôn cho ra đúng 1 hash cố định -> dùng được làm khoá tra cứu
// (giống cách mật khẩu KHÔNG NÊN lưu plaintext, nhưng ở đây dùng hash trần không salt vì mục
// tiêu là tra cứu nhanh theo khoá cố định, không phải xác thực đăng nhập có salt/pepper -
// việc chống brute-force ONLINE đã do rate-limit đảm nhiệm, hash chỉ chống đọc trộm OFFLINE).
async function sha256Hex(input: string): Promise<string> {
  const data = new TextEncoder().encode(input);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(hashBuffer))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

// Lấy IP client thật từ header do hạ tầng Supabase Edge Network gắn vào - client không tự
// set được header này (bị hạ tầng ghi đè), nên đủ tin cậy làm khoá rate-limit cho mục đích
// chống brute-force (không phải mục đích xác thực danh tính chính xác).
function getClientIp(req: Request): string {
  const xff = req.headers.get('x-forwarded-for');
  if (xff) return xff.split(',')[0].trim();
  const xRealIp = req.headers.get('x-real-ip');
  if (xRealIp) return xRealIp.trim();
  return 'unknown';
}

// Rate-limit kiểu fixed-window, lưu counter trong Postgres qua PostgREST (không cần Redis/hạ
// tầng thêm). KHÔNG hoàn toàn atomic (đọc rồi ghi, có thể có race nhỏ nếu nhiều request cùng
// IP đến CÙNG lúc trong window) - chấp nhận được vì mục tiêu là làm chậm brute-force hàng
// nghìn request, không phải giới hạn tuyệt đối chính xác từng request.
async function checkRateLimit(op: string, ip: string): Promise<boolean> {
  const bucketKey = `${op}:${ip}`;
  const now = Date.now();

  const getRes = await fetch(
    `${SUPABASE_URL}/rest/v1/${RATE_LIMIT_TABLE}?bucket_key=eq.${encodeURIComponent(bucketKey)}&select=*`,
    { headers: restHeaders() }
  );
  const rows = getRes.ok ? await getRes.json() : [];
  const existing = rows[0];

  const windowExpired =
    !existing || now - new Date(existing.window_start).getTime() > RATE_LIMIT_WINDOW_MS;

  if (windowExpired) {
    // Cửa sổ mới (hoặc chưa từng có bucket này) - reset đếm về 1.
    await fetch(`${SUPABASE_URL}/rest/v1/${RATE_LIMIT_TABLE}?on_conflict=bucket_key`, {
      method: 'POST',
      headers: { ...restHeaders(), Prefer: 'resolution=merge-duplicates' },
      body: JSON.stringify([
        { bucket_key: bucketKey, window_start: new Date(now).toISOString(), request_count: 1 },
      ]),
    });
    return true;
  }

  if (existing.request_count >= RATE_LIMIT_MAX_REQUESTS) {
    return false; // vượt hạn mức trong window hiện tại
  }

  await fetch(
    `${SUPABASE_URL}/rest/v1/${RATE_LIMIT_TABLE}?bucket_key=eq.${encodeURIComponent(bucketKey)}`,
    {
      method: 'PATCH',
      headers: restHeaders(),
      body: JSON.stringify({ request_count: existing.request_count + 1 }),
    }
  );
  return true;
}

async function push(body: any, ip: string) {
  const { syncCode, settings, captionSettings, translationLog } = body;
  if (!isValidSyncCode(syncCode)) {
    return jsonResponse(
      { ok: false, error: `Mã đồng bộ không hợp lệ (${MIN_SYNC_CODE_LENGTH}-${MAX_SYNC_CODE_LENGTH} ký tự chữ/số/-/_)` },
      400
    );
  }
  if (!(await checkRateLimit('push', ip))) {
    return jsonResponse({ ok: false, error: 'Quá nhiều yêu cầu, thử lại sau ít phút.' }, 429);
  }

  const syncCodeHash = await sha256Hex(syncCode);
  const row = {
    sync_code_hash: syncCodeHash,
    settings: settings ?? {},
    caption_settings: captionSettings ?? {},
    translation_log: translationLog ?? [],
    updated_at: new Date().toISOString(),
  };
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?on_conflict=sync_code_hash`, {
    method: 'POST',
    headers: { ...restHeaders(), Prefer: 'resolution=merge-duplicates,return=representation' },
    body: JSON.stringify([row]),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    return jsonResponse({ ok: false, error: `Lỗi ghi DB: ${res.status} ${text}` }, 502);
  }
  return jsonResponse({ ok: true, updatedAt: row.updated_at });
}

async function pull(body: any, ip: string) {
  const { syncCode } = body;
  if (!isValidSyncCode(syncCode)) {
    return jsonResponse(
      { ok: false, error: `Mã đồng bộ không hợp lệ (${MIN_SYNC_CODE_LENGTH}-${MAX_SYNC_CODE_LENGTH} ký tự chữ/số/-/_)` },
      400
    );
  }
  if (!(await checkRateLimit('pull', ip))) {
    return jsonResponse({ ok: false, error: 'Quá nhiều yêu cầu, thử lại sau ít phút.' }, 429);
  }

  const syncCodeHash = await sha256Hex(syncCode);
  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/${TABLE}?sync_code_hash=eq.${encodeURIComponent(syncCodeHash)}&select=*`,
    { headers: restHeaders() }
  );
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    return jsonResponse({ ok: false, error: `Lỗi đọc DB: ${res.status} ${text}` }, 502);
  }
  const rows = await res.json();
  if (!rows.length) {
    return jsonResponse({ ok: true, found: false });
  }
  const row = rows[0];
  return jsonResponse({
    ok: true,
    found: true,
    settings: row.settings,
    captionSettings: row.caption_settings,
    translationLog: row.translation_log,
    updatedAt: row.updated_at,
  });
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: CORS_HEADERS });
  }

  try {
    const url = new URL(req.url);
    const op = url.searchParams.get('op');
    const body = await req.json().catch(() => ({}));
    const ip = getClientIp(req);

    if (op === 'push') return await push(body, ip);
    if (op === 'pull') return await pull(body, ip);

    return jsonResponse({ ok: false, error: 'Thiếu hoặc sai ?op= (push|pull)' }, 400);
  } catch (err) {
    return jsonResponse({ ok: false, error: (err as Error).message }, 500);
  }
});

/* ===== SQL chạy 1 lần trong Supabase Dashboard > SQL Editor trước khi dùng =====

-- Cài mới hoàn toàn (chưa có bảng translator_sync trước đó):

create table if not exists translator_sync (
  sync_code_hash text primary key,
  settings jsonb,
  caption_settings jsonb,
  translation_log jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists translator_sync_rate_limit (
  bucket_key text primary key,
  window_start timestamptz not null,
  request_count int not null default 0
);

alter table translator_sync enable row level security;
alter table translator_sync_rate_limit enable row level security;
-- Không cấp policy nào cho anon/authenticated ở cả 2 bảng -> chỉ service_role (Edge
-- Function) mới đọc/ghi được, đúng như groq-relay/youtube-extract đã dùng service role ngầm.


-- ===== MIGRATION: nếu đã tạo bảng translator_sync theo bản CŨ (cột sync_code plaintext) =====
-- Đây là thay đổi PHÁ VỠ TƯƠNG THÍCH: mọi "Mã đồng bộ" người dùng đã lưu trước đó sẽ KHÔNG
-- còn tra cứu được nữa sau migration (vì tra cứu giờ theo hash, và mã <8 ký tự không còn hợp
-- lệ) - cần thông báo trước cho người dùng hiện tại (nếu có) đặt lại mã đồng bộ (>=8 ký tự)
-- trên tất cả thiết bị sau khi migrate.

alter table translator_sync add column if not exists sync_code_hash text;
-- Không thể tự động backfill sync_code_hash từ sync_code cũ bằng SQL thuần (cần hàm sha256
-- có sẵn qua extension pgcrypto) - nếu muốn giữ dữ liệu cũ, chạy thêm:
--   create extension if not exists pgcrypto;
--   update translator_sync set sync_code_hash = encode(digest(sync_code, 'sha256'), 'hex');
-- rồi mới chạy tiếp các lệnh bên dưới. Nếu chấp nhận mất dữ liệu cũ (khuyến nghị cho app còn
-- ít người dùng), bỏ qua bước backfill này.

alter table translator_sync drop column if exists sync_code;
alter table translator_sync alter column sync_code_hash set not null;
alter table translator_sync add primary key (sync_code_hash);

create table if not exists translator_sync_rate_limit (
  bucket_key text primary key,
  window_start timestamptz not null,
  request_count int not null default 0
);
alter table translator_sync_rate_limit enable row level security;

*/
