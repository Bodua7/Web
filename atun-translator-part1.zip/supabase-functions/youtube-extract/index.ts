// Edge Function: youtube-extract
// Gọi trực tiếp InnerTube API của YouTube (API nội bộ mà app Android/iOS chính chủ dùng)
// thay vì phụ thuộc Piped/Invidious công khai (đang bị YouTube chặn diện rộng).
//
// Ưu tiên client "JS-less" (ANDROID_VR, IOS, ANDROID) vì các client này thường trả về
// hlsManifestUrl / audio url KHÔNG bị mã hoá signatureCipher -> không cần giải mã cipher
// (phần phức tạp nhất khi tự làm extractor, yt-dlp phải chạy JS deobfuscate cho việc này).
// WEB client để cuối vì thường cần PO Token mới hoạt động.
//
// LƯU Ý: clientVersion/apiKey là giá trị reverse-engineer từ cộng đồng (yt-dlp, Piped, Invidious).
// YouTube đổi version định kỳ -> nếu tất cả client đều fail, khả năng cao cần cập nhật version mới.

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

interface ClientConfig {
  name: string;
  version: string;
  apiKey: string;
  userAgent: string;
  extraClientFields?: Record<string, unknown>;
}

const CLIENTS: ClientConfig[] = [
  {
    name: 'ANDROID_VR',
    version: '1.60.19',
    apiKey: 'AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8',
    userAgent: 'com.google.android.apps.youtube.vr.oculus/1.60.19 (Linux; U; Android 12L) gzip',
    extraClientFields: { deviceMake: 'Oculus', deviceModel: 'Quest 3', androidSdkVersion: 32 },
  },
  {
    name: 'IOS',
    version: '19.45.4',
    apiKey: 'AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8',
    userAgent: 'com.google.ios.youtube/19.45.4 (iPhone16,2; U; CPU iOS 17_5 like Mac OS X)',
    extraClientFields: { deviceMake: 'Apple', deviceModel: 'iPhone16,2', osName: 'iOS', osVersion: '17.5.1.21F90' },
  },
  {
    name: 'ANDROID',
    version: '19.09.37',
    apiKey: 'AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w',
    userAgent: 'com.google.android.youtube/19.09.37 (Linux; U; Android 14) gzip',
    extraClientFields: { androidSdkVersion: 34 },
  },
  {
    name: 'WEB',
    version: '2.20240726.00.00',
    apiKey: 'AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8',
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
  },
];

function extractVideoId(input: string): string {
  const trimmed = input.trim();
  if (/^[a-zA-Z0-9_-]{11}$/.test(trimmed)) return trimmed;
  try {
    const url = new URL(trimmed);
    if (url.hostname.includes('youtu.be')) return url.pathname.slice(1);
    if (url.searchParams.has('v')) return url.searchParams.get('v')!;
    const liveMatch = url.pathname.match(/\/live\/([a-zA-Z0-9_-]{11})/);
    if (liveMatch) return liveMatch[1];
  } catch (_e) {
    // không phải URL
  }
  throw new Error('Không nhận diện được video ID từ: ' + input);
}

async function tryClient(client: ClientConfig, videoId: string) {
  const body = {
    context: {
      client: {
        clientName: client.name,
        clientVersion: client.version,
        hl: 'en',
        gl: 'US',
        ...(client.extraClientFields || {}),
      },
    },
    videoId,
    contentCheckOk: true,
    racyCheckOk: true,
  };

  const res = await fetch(`https://www.youtube.com/youtubei/v1/player?key=${client.apiKey}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'User-Agent': client.userAgent,
      'X-YouTube-Client-Name': client.name,
      'X-YouTube-Client-Version': client.version,
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    throw new Error(`HTTP ${res.status}`);
  }

  const data = await res.json();
  const status = data?.playabilityStatus?.status;
  if (status !== 'OK') {
    throw new Error(`playabilityStatus=${status}: ${data?.playabilityStatus?.reason || 'không rõ lý do'}`);
  }

  const streamingData = data.streamingData || {};
  const videoDetails = data.videoDetails || {};
  const isLive = Boolean(videoDetails.isLiveContent || streamingData.hlsManifestUrl);

  // Ưu tiên HLS (live hoặc VOD của client ios) vì không bị signatureCipher
  if (streamingData.hlsManifestUrl) {
    return {
      client: client.name,
      title: videoDetails.title,
      isLive,
      kind: 'hls' as const,
      url: streamingData.hlsManifestUrl,
    };
  }

  // Fallback: tìm audio format KHÔNG có signatureCipher (url mở trực tiếp)
  const adaptiveFormats: any[] = streamingData.adaptiveFormats || [];
  const openAudio = adaptiveFormats
    .filter((f) => typeof f.url === 'string' && String(f.mimeType || '').startsWith('audio/'))
    .sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0))[0];

  if (openAudio) {
    return {
      client: client.name,
      title: videoDetails.title,
      isLive,
      kind: 'direct' as const,
      url: openAudio.url,
      mimeType: openAudio.mimeType,
    };
  }

  throw new Error('Không có hlsManifestUrl và không có audio format mở (có thể bị signatureCipher)');
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: CORS_HEADERS });
  }

  try {
    const { videoId: rawInput } = await req.json();
    if (!rawInput) {
      return new Response(JSON.stringify({ error: 'Thiếu videoId hoặc url' }), {
        status: 400,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      });
    }

    const videoId = extractVideoId(rawInput);
    const attempts: string[] = [];

    for (const client of CLIENTS) {
      try {
        const result = await tryClient(client, videoId);
        return new Response(JSON.stringify({ ok: true, ...result }), {
          headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
        });
      } catch (err) {
        attempts.push(`${client.name}: ${(err as Error).message}`);
      }
    }

    return new Response(
      JSON.stringify({ ok: false, error: 'Tất cả client đều fail', attempts }),
      { status: 502, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
    );
  } catch (err) {
    return new Response(JSON.stringify({ ok: false, error: (err as Error).message }), {
      status: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
    });
  }
});
