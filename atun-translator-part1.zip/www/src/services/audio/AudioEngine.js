// AudioEngine: nhận { url, kind } từ AudioExtractor, phát qua <audio> ẩn,
// đồng thời tap vào Web Audio API để lấy AnalyserNode (dùng cho STT chunking ở Ưu tiên 3),
// và khai báo MediaSession thật để Android coi đây là app đang phát media (giữ tiến trình sống).

const HLS_JS_CDN = 'https://cdnjs.cloudflare.com/ajax/libs/hls.js/1.5.13/hls.min.js';

let hlsJsLoadPromise = null;
function loadHlsJs() {
  if (window.Hls) return Promise.resolve();
  if (hlsJsLoadPromise) return hlsJsLoadPromise;
  hlsJsLoadPromise = new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = HLS_JS_CDN;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error('Không tải được hls.js'));
    document.head.appendChild(script);
  });
  return hlsJsLoadPromise;
}

export class AudioEngine {
  constructor({ onLog } = {}) {
    this.onLog = onLog || (() => {});
    this.audioEl = document.createElement('audio');
    this.audioEl.autoplay = true;
    this.audioEl.crossOrigin = 'anonymous';
    this.audioEl.style.display = 'none';
    document.body.appendChild(this.audioEl);

    this.audioCtx = null;
    this.analyser = null;
    this.hls = null;
  }

  // stream: { url, kind: 'hls' | 'direct', title }
  async load(stream) {
    this.stop();
    this.onLog(`Đang nạp audio (${stream.kind}) từ ${stream.source || 'nguồn không rõ'}`);

    if (stream.kind === 'hls') {
      await this._loadHls(stream.url);
    } else {
      this.audioEl.src = stream.url;
    }

    await this._setupWebAudioGraph();
    this._setupMediaSession(stream.title);

    try {
      await this.audioEl.play();
      this.onLog('Đang phát audio.');
    } catch (err) {
      // Autoplay có thể bị chặn -> cần user tương tác trước (nút Play trên UI)
      this.onLog('Không tự phát được (cần user bấm Play): ' + err.message);
      throw err;
    }
  }

  async _loadHls(url) {
    if (this.audioEl.canPlayType('application/vnd.apple.mpegurl')) {
      // Safari / WebView hỗ trợ HLS gốc
      this.audioEl.src = url;
      return;
    }
    await loadHlsJs();
    this.hls = new window.Hls({ enableWorker: true, lowLatencyMode: true });
    this.hls.loadSource(url);
    this.hls.attachMedia(this.audioEl);
    await new Promise((resolve, reject) => {
      this.hls.on(window.Hls.Events.MANIFEST_PARSED, resolve);
      this.hls.on(window.Hls.Events.ERROR, (_evt, data) => {
        if (data.fatal) reject(new Error('hls.js lỗi fatal: ' + data.type));
      });
    });
  }

  async _setupWebAudioGraph() {
    this.audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    this.sourceNode = this.audioCtx.createMediaElementSource(this.audioEl);
    this.analyser = this.audioCtx.createAnalyser();
    this.analyser.fftSize = 2048;
    this.sourceNode.connect(this.analyser);
    this.analyser.connect(this.audioCtx.destination);
  }

  // ===== Ưu tiên 3: tap PCM thật để đưa vào STT (Vosk qua Capacitor plugin) =====
  // Dùng ScriptProcessorNode (cũ nhưng đơn giản, chạy đồng bộ, đủ dùng cho STT không
  // cần độ trễ cực thấp). Downsample từ sample rate gốc (thường 44100/48000) về 16000Hz
  // mono - đúng chuẩn Vosk cần - rồi convert sang PCM16LE, gọi onPcmChunk(Uint8Array).
  // Phải nối processor -> gainNode(0) -> destination để onaudioprocess được gọi đều đặn
  // mà KHÔNG phát trùng âm thanh ra loa (source đã tự nối thẳng -> analyser -> destination
  // ở trên rồi, đây chỉ là nhánh song song để lấy dữ liệu).
  attachPcmSink(onPcmChunk, targetSampleRate = 16000) {
    if (!this.audioCtx || !this.sourceNode) {
      throw new Error('Chưa setup Web Audio graph - gọi sau khi load() xong.');
    }
    this.detachPcmSink();

    const bufferSize = 4096;
    const channelCount = this.sourceNode.channelCount || 2;
    this._pcmProcessor = this.audioCtx.createScriptProcessor(bufferSize, channelCount, 1);
    this._pcmMuteGain = this.audioCtx.createGain();
    this._pcmMuteGain.gain.value = 0; // không cho ra loa qua nhánh này, tránh phát trùng

    this._pcmProcessor.onaudioprocess = (event) => {
      const input = event.inputBuffer;
      const mono = this._mixdownToMono(input);
      const down = this._downsampleBuffer(mono, this.audioCtx.sampleRate, targetSampleRate);
      const pcm16Bytes = this._floatTo16BitPCM(down);
      onPcmChunk(pcm16Bytes);
    };

    this.sourceNode.connect(this._pcmProcessor);
    this._pcmProcessor.connect(this._pcmMuteGain);
    this._pcmMuteGain.connect(this.audioCtx.destination);
  }

  detachPcmSink() {
    if (this._pcmProcessor) {
      this._pcmProcessor.disconnect();
      this._pcmProcessor.onaudioprocess = null;
      this._pcmProcessor = null;
    }
    if (this._pcmMuteGain) {
      this._pcmMuteGain.disconnect();
      this._pcmMuteGain = null;
    }
  }

  _mixdownToMono(audioBuffer) {
    const numChannels = audioBuffer.numberOfChannels;
    const length = audioBuffer.length;
    if (numChannels === 1) return audioBuffer.getChannelData(0);
    const out = new Float32Array(length);
    for (let ch = 0; ch < numChannels; ch++) {
      const data = audioBuffer.getChannelData(ch);
      for (let i = 0; i < length; i++) out[i] += data[i] / numChannels;
    }
    return out;
  }

  // Downsample bằng trung bình cộng các mẫu trong mỗi cửa sổ (chất lượng đủ tốt cho STT,
  // rẻ hơn nhiều so với resample nội suy bậc cao, không cần thư viện ngoài).
  _downsampleBuffer(buffer, inputSampleRate, outputSampleRate) {
    if (outputSampleRate === inputSampleRate) return buffer;
    const ratio = inputSampleRate / outputSampleRate;
    const newLength = Math.round(buffer.length / ratio);
    const result = new Float32Array(newLength);
    let offsetResult = 0;
    let offsetBuffer = 0;
    while (offsetResult < newLength) {
      const nextOffsetBuffer = Math.round((offsetResult + 1) * ratio);
      let accum = 0;
      let count = 0;
      for (let i = offsetBuffer; i < nextOffsetBuffer && i < buffer.length; i++) {
        accum += buffer[i];
        count++;
      }
      result[offsetResult] = count > 0 ? accum / count : 0;
      offsetResult++;
      offsetBuffer = nextOffsetBuffer;
    }
    return result;
  }

  _floatTo16BitPCM(float32Array) {
    const buf = new ArrayBuffer(float32Array.length * 2);
    const view = new DataView(buf);
    let offset = 0;
    for (let i = 0; i < float32Array.length; i++, offset += 2) {
      const s = Math.max(-1, Math.min(1, float32Array[i]));
      view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true); // little-endian
    }
    return new Uint8Array(buf);
  }

  _setupMediaSession(title) {
    if (!('mediaSession' in navigator)) return;
    navigator.mediaSession.metadata = new MediaMetadata({
      title: title || 'Đang dịch phụ đề trực tiếp',
      artist: 'Live Translator',
    });
    navigator.mediaSession.playbackState = 'playing';
    navigator.mediaSession.setActionHandler('play', () => this.audioEl.play());
    navigator.mediaSession.setActionHandler('pause', () => this.audioEl.pause());
    navigator.mediaSession.setActionHandler('stop', () => this.stop());
  }

  // Lấy buffer PCM hiện tại từ analyser - dùng để cắt chunk đưa vào STT (Ưu tiên 3)
  getFloatTimeDomainData() {
    if (!this.analyser) return null;
    const buf = new Float32Array(this.analyser.fftSize);
    this.analyser.getFloatTimeDomainData(buf);
    return buf;
  }

  stop() {
    this.detachPcmSink();
    if (this.hls) {
      this.hls.destroy();
      this.hls = null;
    }
    this.audioEl.pause();
    this.audioEl.removeAttribute('src');
    this.audioEl.load();
    if (this.audioCtx) {
      this.audioCtx.close();
      this.audioCtx = null;
      this.analyser = null;
      this.sourceNode = null;
    }
    if ('mediaSession' in navigator) {
      navigator.mediaSession.playbackState = 'none';
    }
  }
}
