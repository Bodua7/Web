// AudioEngine: nhận { url, kind } từ AudioExtractor, phát qua <audio> ẩn,
// đồng thời tap vào Web Audio API để lấy AnalyserNode (dùng cho STT chunking ở Ưu tiên 3),
// và khai báo MediaSession thật để Android coi đây là app đang phát media (giữ tiến trình sống).

const HLS_JS_CDN = 'https://cdnjs.cloudflare.com/ajax/libs/hls.js/1.5.13/hls.min.js';

let hlsJsLoadPromise = null;
function loadHlsJs() {
  if (window.Hls) return Promise.resolve();
  if (hlsJsLoadPromise) return hlsJsLoadPromise;
  hlsJsLoadPromise = new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = HLS_JS_CDN;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error('Không tải được hls.js'));
    document.head.appendChild(script);
  });
  return hlsJsLoadPromise;
}

export class AudioEngine {
  constructor({ onLog } = {}) {
    this.onLog = onLog || (() => {});
    this.audioEl = document.createElement('audio');
    this.audioEl.autoplay = true;
    this.audioEl.crossOrigin = 'anonymous';
    this.audioEl.style.display = 'none';
    document.body.appendChild(this.audioEl);

    this.audioCtx = null;
    this.analyser = null;
    this.hls = null;
  }

  // stream: { url, kind: 'hls' | 'direct', title }
  async load(stream) {
    this.stop();
    this.onLog(`Đang nạp audio (${stream.kind}) từ ${stream.source || 'nguồn không rõ'}`);

    if (stream.kind === 'hls') {
      await this._loadHls(stream.url);
    } else {
      this.audioEl.src = stream.url;
    }

    await this._setupWebAudioGraph();
    this._setupMediaSession(stream.title);

    try {
      await this.audioEl.play();
      this.onLog('Đang phát audio.');
    } catch (err) {
      // Autoplay có thể bị chặn -> cần user tương tác trước (nút Play trên UI)
      this.onLog('Không tự phát được (cần user bấm Play): ' + err.message);
      throw err;
    }
  }

  async _loadHls(url) {
    if (this.audioEl.canPlayType('application/vnd.apple.mpegurl')) {
      // Safari / WebView hỗ trợ HLS gốc
      this.audioEl.src = url;
      return;
    }
    await loadHlsJs();
    this.hls = new window.Hls({ enableWorker: true, lowLatencyMode: true });
    this.hls.loadSource(url);
    this.hls.attachMedia(this.audioEl);
    await new Promise((resolve, reject) => {
      this.hls.on(window.Hls.Events.MANIFEST_PARSED, resolve);
      this.hls.on(window.Hls.Events.ERROR, (_evt, data) => {
        if (data.fatal) reject(new Error('hls.js lỗi fatal: ' + data.type));
      });
    });
  }

  async _setupWebAudioGraph() {
    this.audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const source = this.audioCtx.createMediaElementSource(this.audioEl);
    this.analyser = this.audioCtx.createAnalyser();
    this.analyser.fftSize = 2048;
    source.connect(this.analyser);
    this.analyser.connect(this.audioCtx.destination);
  }

  _setupMediaSession(title) {
    if (!('mediaSession' in navigator)) return;
    navigator.mediaSession.metadata = new MediaMetadata({
      title: title || 'Đang dịch phụ đề trực tiếp',
      artist: 'Live Translator',
    });
    navigator.mediaSession.playbackState = 'playing';
    navigator.mediaSession.setActionHandler('play', () => this.audioEl.play());
    navigator.mediaSession.setActionHandler('pause', () => this.audioEl.pause());
    navigator.mediaSession.setActionHandler('stop', () => this.stop());
  }

  // Lấy buffer PCM hiện tại từ analyser - dùng để cắt chunk đưa vào STT (Ưu tiên 3)
  getFloatTimeDomainData() {
    if (!this.analyser) return null;
    const buf = new Float32Array(this.analyser.fftSize);
    this.analyser.getFloatTimeDomainData(buf);
    return buf;
  }

  stop() {
    if (this.hls) {
      this.hls.destroy();
      this.hls = null;
    }
    this.audioEl.pause();
    this.audioEl.removeAttribute('src');
    this.audioEl.load();
    if (this.audioCtx) {
      this.audioCtx.close();
      this.audioCtx = null;
      this.analyser = null;
    }
    if ('mediaSession' in navigator) {
      navigator.mediaSession.playbackState = 'none';
    }
  }
}
