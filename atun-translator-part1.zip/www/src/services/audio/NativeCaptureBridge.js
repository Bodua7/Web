// Bắt audio hệ thống qua plugin native AudioCapture (MediaProjection +
// AudioPlaybackCaptureConfiguration + Vosk on-device). Đây là cách duy nhất còn dùng để
// nhận audio - hướng lấy audio qua fetch mạng (InnerTube/Piped/Invidious) đã bị gỡ bỏ vì
// bị YouTube chặn hết mọi nguồn công khai (28/8/2026).
//
// Yêu cầu: user mở YouTube (hoặc app bất kỳ) và tự phát video thật; app này chỉ nhận
// text đã được Vosk nhận diện từ audio đang phát ra loa/qua audio pipeline của máy.

export class NativeCaptureBridge {
  constructor({ onPartial, onFinal, onError, onModelStatus, onAudioLevel } = {}) {
    this.onPartial = onPartial || (() => {});
    this.onFinal = onFinal || (() => {});
    this.onError = onError || (() => {});
    this.onModelStatus = onModelStatus || (() => {});
    this.onAudioLevel = onAudioLevel || (() => {}); // DEBUG: mức tín hiệu audio thực tế, xem NativeCaptureBridge/AudioCaptureService
    this._listenersRegistered = false;
  }

  _plugin() {
    const plugin = window.Capacitor?.Plugins?.AudioCapture;
    if (!plugin) {
      throw new Error('Plugin AudioCapture chưa sẵn sàng (chưa chạy trong app native đã build?)');
    }
    return plugin;
  }

  _registerListenersOnce() {
    if (this._listenersRegistered) return;
    const plugin = this._plugin();

    plugin.addListener('partialText', (data) => this.onPartial(data.text));
    plugin.addListener('finalText', (data) => this.onFinal(data.text));
    plugin.addListener('captureError', (data) => this.onError(data.message));
    plugin.addListener('modelStatus', (data) => this.onModelStatus(data.ready));
    plugin.addListener('audioLevel', (data) => this.onAudioLevel(data));

    this._listenersRegistered = true;
  }

  // Kích hoạt dialog hệ thống xin quyền MediaProjection, rồi start capture native.
  // PHẢI được gọi từ một user gesture (click/tap) - dialog hệ thống sẽ không tự bật được.
  // sourceLang: ngôn ngữ ĐANG được nói trong audio nguồn (vd 'en' nếu YouTube đang nói tiếng Anh),
  // không phải ngôn ngữ muốn dịch tới - việc dịch (translateText) làm ở bước sau, riêng.
  async start(sourceLang = 'en') {
    this._registerListenersOnce();
    const plugin = this._plugin();
    return plugin.requestCapture({ sourceLang });
  }

  async stop() {
    const plugin = this._plugin();
    return plugin.stopCapture();
  }
}
