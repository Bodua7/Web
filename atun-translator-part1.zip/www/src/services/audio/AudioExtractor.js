import { PIPED_INSTANCES, INVIDIOUS_INSTANCES, INSTANCE_TIMEOUT_MS, YOUTUBE_EXTRACT_FUNCTION_URL } from '../../config/constants.js';

// Lấy videoId từ URL YouTube (watch?v=, youtu.be/, live/) hoặc trả nguyên nếu đã là ID (11 ký tự)
export function extractVideoId(input) {
  const trimmed = input.trim();
  if (/^[a-zA-Z0-9_-]{11}$/.test(trimmed)) return trimmed;

  try {
    const url = new URL(trimmed);
    if (url.hostname.includes('youtu.be')) return url.pathname.slice(1);
    if (url.searchParams.has('v')) return url.searchParams.get('v');
    const liveMatch = url.pathname.match(/\/live\/([a-zA-Z0-9_-]{11})/);
    if (liveMatch) return liveMatch[1];
  } catch (e) {
    // không phải URL hợp lệ
  }

  throw new Error('Không nhận diện được video ID từ: ' + input);
}

function fetchWithTimeout(url, timeoutMs, options = {}) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeoutMs);
  return fetch(url, { ...options, signal: controller.signal }).finally(() => clearTimeout(id));
}

// ===== InnerTube trực tiếp từ điện thoại (IP di động/WiFi thật -> không bị chặn "datacenter IP") =====
// Version lấy từ request thực tế đã xác nhận hoạt động của cộng đồng (yt-dlp/gist reverse-engineer),
// KHÔNG tự chế số version vì YouTube trả 400 nếu version không tồn tại.
const INNERTUBE_CLIENTS = [
  {
    name: 'ANDROID',
    xClientId: '3',
    version: '17.31.35',
    apiKey: 'AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w',
    userAgent: 'com.google.android.youtube/17.31.35 (Linux; U; Android 11) gzip',
    extraClientFields: { androidSdkVersion: 30, timeZone: 'UTC', utcOffsetMinutes: 0 },
  },
  {
    name: 'ANDROID_VR',
    xClientId: '28',
    version: '1.60.19',
    apiKey: 'AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8',
    userAgent: 'com.google.android.apps.youtube.vr.oculus/1.60.19 (Linux; U; Android 12L) gzip',
    extraClientFields: { deviceMake: 'Oculus', deviceModel: 'Quest 3', androidSdkVersion: 32 },
  },
  {
    name: 'WEB',
    xClientId: '1',
    version: '2.20220916.00.00',
    apiKey: 'AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8',
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    extraClientFields: { clientScreen: 'WATCH' },
    thirdParty: { embedUrl: 'https://www.youtube.com/' },
  },
];

async function tryInnertubeClient(client, videoId) {
  const body = {
    context: {
      client: {
        clientName: client.name,
        clientVersion: client.version,
        hl: 'en',
        gl: 'US',
        ...(client.extraClientFields || {}),
      },
      ...(client.thirdParty ? { thirdParty: client.thirdParty } : {}),
    },
    videoId,
    contentCheckOk: true,
    racyCheckOk: true,
  };

  const res = await fetchWithTimeout(
    `https://www.youtube.com/youtubei/v1/player?key=${client.apiKey}`,
    10000,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': client.userAgent,
        'X-YouTube-Client-Name': client.xClientId,
        'X-YouTube-Client-Version': client.version,
        'Origin': 'https://www.youtube.com',
      },
      body: JSON.stringify(body),
    }
  );

  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const data = await res.json();

  const status = data?.playabilityStatus?.status;
  if (status !== 'OK') {
    throw new Error(`playabilityStatus=${status}: ${data?.playabilityStatus?.reason || 'không rõ lý do'}`);
  }

  const streamingData = data.streamingData || {};
  const videoDetails = data.videoDetails || {};
  const isLive = Boolean(videoDetails.isLiveContent || streamingData.hlsManifestUrl);

  if (streamingData.hlsManifestUrl) {
    return { url: streamingData.hlsManifestUrl, kind: 'hls', title: videoDetails.title, source: `innertube(${client.name})`, isLive };
  }

  const adaptiveFormats = streamingData.adaptiveFormats || [];
  const openAudio = adaptiveFormats
    .filter(f => typeof f.url === 'string' && String(f.mimeType || '').startsWith('audio/'))
    .sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0))[0];

  if (openAudio) {
    return { url: openAudio.url, kind: 'direct', title: videoDetails.title, source: `innertube(${client.name})`, isLive };
  }

  throw new Error('Không có hlsManifestUrl và không có audio mở (có thể bị signatureCipher)');
}

async function tryDirectInnertube(videoId, onAttempt) {
  const errs = [];
  for (const client of INNERTUBE_CLIENTS) {
    try {
      onAttempt?.(`Đang thử InnerTube trực tiếp (${client.name})...`);
      return await tryInnertubeClient(client, videoId);
    } catch (err) {
      errs.push(`innertube-${client.name}: ${err.message}`);
    }
  }
  throw new Error(errs.join(' | '));
}

// Gọi Edge Function youtube-extract (server-side, client version InnerTube mới hơn +
// có thêm client IOS). Thử trước tiên vì 1 lần gọi đã tự fallback qua nhiều client rồi,
// nhưng vẫn có thể fail nếu YouTube chặn theo IP datacenter của Supabase -> rơi xuống
// tryDirectInnertube (IP di động thật) rồi Piped/Invidious như cũ.
async function tryEdgeFunction(videoId) {
  const res = await fetchWithTimeout(YOUTUBE_EXTRACT_FUNCTION_URL, INSTANCE_TIMEOUT_MS, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ videoId }),
  });

  if (!res.ok) throw new Error(`edge-function HTTP ${res.status}`);
  const data = await res.json();

  if (!data.ok) {
    throw new Error(`edge-function: ${data.error || 'không rõ lỗi'}${data.attempts ? ' [' + data.attempts.join(' | ') + ']' : ''}`);
  }

  return { url: data.url, kind: data.kind, title: data.title, source: `edge-function(${data.client})`, isLive: Boolean(data.isLive) };
}

async function tryPipedInstance(instance, videoId) {
  const res = await fetchWithTimeout(`${instance}/streams/${videoId}`, INSTANCE_TIMEOUT_MS);
  if (!res.ok) throw new Error(`Piped ${instance} HTTP ${res.status}`);
  const data = await res.json();

  if (data.livestream && data.hls) {
    return { url: data.hls, kind: 'hls', title: data.title, source: instance };
  }
  if (Array.isArray(data.audioStreams) && data.audioStreams.length > 0) {
    const best = [...data.audioStreams].sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0))[0];
    return { url: best.url, kind: 'direct', title: data.title, source: instance };
  }
  throw new Error(`Piped ${instance}: không có stream audio khả dụng`);
}

async function tryInvidiousInstance(instance, videoId) {
  const res = await fetchWithTimeout(`${instance}/api/v1/videos/${videoId}`, INSTANCE_TIMEOUT_MS);
  if (!res.ok) throw new Error(`Invidious ${instance} HTTP ${res.status}`);
  const data = await res.json();

  if (data.liveNow && data.hlsUrl) {
    return { url: data.hlsUrl, kind: 'hls', title: data.title, source: instance };
  }
  if (Array.isArray(data.adaptiveFormats)) {
    const audioFormats = data.adaptiveFormats.filter(f => (f.type || '').startsWith('audio/'));
    const best = audioFormats.sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0))[0];
    if (best) return { url: best.url, kind: 'direct', title: data.title, source: instance };
  }
  throw new Error(`Invidious ${instance}: không có stream audio khả dụng`);
}

// Thứ tự thử: (1) Edge Function youtube-extract trên Supabase (client version InnerTube
// mới hơn, có thêm client IOS), (2) InnerTube trực tiếp từ điện thoại (IP thật, né được
// chặn datacenter), (3) Piped, (4) Invidious công khai làm lưới an toàn dự phòng.
export async function getAudioStreamUrl(videoIdOrUrl, onAttempt) {
  const videoId = extractVideoId(videoIdOrUrl);
  const attempts = [];

  try {
    onAttempt?.('Đang thử Edge Function (Supabase)...');
    return await tryEdgeFunction(videoId);
  } catch (err) {
    attempts.push(err.message);
  }

  try {
    return await tryDirectInnertube(videoId, onAttempt);
  } catch (err) {
    attempts.push(err.message);
  }

  for (const instance of PIPED_INSTANCES) {
    try {
      onAttempt?.(`Đang thử Piped: ${instance}`);
      return await tryPipedInstance(instance, videoId);
    } catch (err) {
      attempts.push(`${instance}: ${err.message}`);
    }
  }

  for (const instance of INVIDIOUS_INSTANCES) {
    try {
      onAttempt?.(`Đang thử Invidious: ${instance}`);
      return await tryInvidiousInstance(instance, videoId);
    } catch (err) {
      attempts.push(`${instance}: ${err.message}`);
    }
  }

  throw new Error('Tất cả nguồn đều fail:\n' + attempts.join('\n'));
}
