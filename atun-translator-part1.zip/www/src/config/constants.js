// Danh sách các instance công khai của Piped và Invidious.
// Dùng làm nguồn lấy audio stream từ YouTube Live mà không cần API key của Google.
// Instance công khai hay sập/đổi domain -> luôn có fallback nhiều cái, thử lần lượt.

// Nguồn: https://github.com/TeamPiped/documentation - danh sách instance công khai chính thức
export const PIPED_INSTANCES = [
  'https://pipedapi.kavin.rocks',
  'https://pipedapi-libre.kavin.rocks',
  'https://piped-api.privacy.com.de',
  'https://pipedapi.adminforge.de',
  'https://api.piped.yt',
  'https://pipedapi.drgns.space',
];

export const INVIDIOUS_INSTANCES = [
  'https://invidious.nerdvpn.de',
  'https://iv.ggtyler.dev',
  'https://yewtu.be',
];

// Timeout cho mỗi lần thử 1 instance (ms) - đừng để 1 instance chết kéo chậm cả app
export const INSTANCE_TIMEOUT_MS = 6000;

// Edge Function youtube-extract đã deploy trên Supabase (project clbddroyrueafygedycy).
// Chạy server-side với client version InnerTube mới hơn bản gọi trực tiếp từ điện thoại,
// và có thêm client IOS (thường né được signatureCipher tốt). Dùng làm nguồn thử ĐẦU TIÊN
// vì có nhiều client fallback nhất trong 1 lần gọi, trước khi rơi xuống các nguồn khác.
export const YOUTUBE_EXTRACT_FUNCTION_URL =
  'https://clbddroyrueafygedycy.supabase.co/functions/v1/youtube-extract';

// Bao nhiêu giây audio buffer trước khi đẩy vào STT (trade-off độ trễ vs độ chính xác)
export const STT_CHUNK_SECONDS = 5;
