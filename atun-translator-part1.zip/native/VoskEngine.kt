package com.atun.translator

import android.content.Context
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer

// Bọc Vosk để nhận PCM đẩy trực tiếp từ AudioCaptureService (KHÔNG qua mic).
// Lưu ý quan trọng: dùng Recognizer trực tiếp thay vì SpeechService của Vosk,
// vì SpeechService tự mở AudioRecord từ mic bên trong - không nhận được audio
// mình tự bắt bằng AudioPlaybackCaptureConfiguration.
class VoskEngine(
    private val context: Context,
    private val sampleRate: Float,
    private val modelSource: ModelSource,
    private val onEvent: (Event) -> Unit
) : SttEngine {
    sealed class Event {
        data class Partial(val text: String) : Event()
        // confidence: trung bình conf theo từ (0.0-1.0) do Vosk trả về khi bật setWords(true).
        // -1.0 nếu không lấy được (JSON không có "result", hoặc lỗi parse) - coi như "không rõ",
        // KHÔNG bị lọc bỏ bởi ngưỡng CONFIDENCE_DROP_THRESHOLD (xem feed()/forcePauseFinal()).
        data class Final(val text: String, val confidence: Double) : Event()
        // Câu bị lọc bỏ vì độ tin cậy quá thấp (nhiều khả năng Vosk "nghe nhầm" nhạc nền/nhiễu
        // thành lời nói) - vẫn bắn lên để debug/hiển thị mờ nếu muốn, nhưng KHÔNG đẩy vào luồng
        // dịch chính (AudioCaptureService không gọi emitFinal cho case này).
        data class LowConfidence(val text: String, val confidence: Double) : Event()
        object ModelReady : Event()
        data class Error(val message: String) : Event()
        // Chỉ MultiLangVoskEngine bắn event này (xem maybeNotifyReady ở đó) - báo số model con
        // đã load xong (settled, kể cả lỗi hẳn) trên tổng số, để UI hiện progress bar thay vì
        // text tĩnh "đang tải..." khi chế độ "Tự động nhận diện" phải load nhiều model song song.
        // VoskEngine 1 ngôn ngữ (không multi) không bao giờ bắn cái này.
        data class LoadingProgress(val loaded: Int, val total: Int) : Event()
        // Chỉ được bắn bởi MultiLangVoskEngine (chế độ "tự động nhận diện nhiều ngôn ngữ") -
        // giống Final nhưng kèm "lang" là ngôn ngữ mà bộ nhận diện song song đã thắng (confidence
        // cao nhất) cho câu này. VoskEngine (1 ngôn ngữ) không bao giờ tự bắn event này.
        data class DetectedFinal(val lang: String, val text: String, val confidence: Double) : Event()
    }

    // Nguồn model: mọi ngôn ngữ (kể cả "en") giờ đều tải về + giải nén sẵn trên filesystem qua
    // ModelManagerPlugin, load thẳng bằng Model(path) - không còn model nào bundle qua APK
    // asset nữa (trước đây "en" bundle sẵn qua StorageService.unpack, xem lịch sử VoskEngine
    // trước bản này nếu cần đối chiếu).
    sealed class ModelSource {
        data class Path(val dirPath: String) : ModelSource()
    }

    companion object {
        // Câu final có độ tin cậy trung bình (theo từ) THẤP HƠN ngưỡng này bị coi là rác/nhiễu
        // nghe nhầm, không đẩy vào luồng dịch (xem Event.LowConfidence). 0.35 là mức khá dè dặt
        // (chỉ chặn những câu RÕ RÀNG là rác) - model Vosk small thường cho conf 0.5-0.9 với
        // giọng nói nghe đúng, còn audio nhận nhầm từ nhạc/nhiễu nền thường rơi xuống rất thấp
        // (< 0.3). Tăng ngưỡng này nếu vẫn còn thấy nhiều câu rác lọt qua; giảm nếu thấy câu
        // đúng bị lọc oan (xem log confidence kèm mỗi câu final trong debug log của UI).
        const val CONFIDENCE_DROP_THRESHOLD = 0.35

        // Giới hạn tổng số sample audio được đệm (buffer) lại trong lúc model CHƯA load xong
        // (xem feed()/bufferPendingLocked() bên dưới) - tránh phình bộ nhớ vô hạn nếu model lỗi/
        // treo và không bao giờ ready. 6 giây audio (ở sample rate 16kHz mono ~192KB) đủ rộng rãi
        // so với thời gian load model thực tế (thường 1-3s), dư sức bù khoảng trễ mà không tốn
        // nhiều RAM; nếu vượt ngưỡng thì bỏ chunk CŨ NHẤT trước (ưu tiên giữ audio GẦN thời điểm
        // model ready nhất - hữu ích hơn audio từ tận lúc mới bấm nghe nếu model load bất thường
        // lâu).
        const val PENDING_AUDIO_BUFFER_SECONDS = 6

        // Mọi ngôn ngữ (kể cả "en") đều PHẢI tải về trước qua ModelManagerPlugin (xem
        // ModelManagerPlugin.CATALOG) - không còn model nào có sẵn ngay sau khi cài app nữa.
        //
        // Trả về null nếu model chưa sẵn sàng (chưa tải về) - caller (AudioCaptureService) PHẢI
        // kiểm tra null và báo lỗi cho JS thay vì start capture với model rỗng.
        fun resolveModelSource(context: Context, sourceLang: String): ModelSource? {
            return if (ModelManagerPlugin.isDownloaded(context, sourceLang)) {
                ModelSource.Path(ModelManagerPlugin.modelDir(context, sourceLang).absolutePath)
            } else {
                null
            }
        }
    }

    private var model: Model? = null
    private var recognizer: Recognizer? = null
    @Volatile private var ready = false

    // ===== Đệm (buffer) audio trong lúc model đang load - xem feed()/onModelLoaded() =====
    // BUG đã sửa: trước đây feed() chỉ `return` (bỏ luôn) mọi audio đọc được trong lúc
    // `!ready` (model Vosk load bất đồng bộ mất ~1-3s) - nếu người nói bắt đầu ngay khi vừa
    // bấm "Bắt đầu nghe", câu đầu tiên gần như chắc chắn mất vì audio của nó không có gì thay
    // thế. Giờ feed() đệm PCM vào hàng đợi này trong lúc chưa ready, rồi feed lại đúng thứ tự
    // cho recognizer NGAY khi model xong (xem onModelLoaded()), trước khi recognizer nhận audio
    // "sống" tiếp theo.
    //
    // pendingAudioLock đồng thời bảo vệ `ready`: mọi thay đổi/đọc `ready` liên quan tới quyết
    // định "đệm hay feed thẳng" đều nằm trong synchronized(pendingAudioLock) - tránh race giữa
    // luồng đọc audio (gọi feed() liên tục) và luồng load model (gọi onModelLoaded() 1 lần).
    private val pendingAudioLock = Object()
    private val pendingAudio = ArrayDeque<ShortArray>()
    private var pendingAudioSamples = 0
    private val maxPendingAudioSamples = (sampleRate * PENDING_AUDIO_BUFFER_SECONDS).toInt()

    // Theo dõi xem có "partial" đang dang dở (người nói chưa dứt câu, Vosk chưa tự chốt)
    // hay không - dùng cho forcePauseFinal() bên dưới, để không gọi ép chốt vô ích khi
    // không có gì để chốt (vd lúc đang im lặng hoàn toàn, chưa ai nói gì).
    @Volatile private var hasPendingPartial = false

    override fun init() {
        when (val source = modelSource) {
            is ModelSource.Path -> initFromPath(source.dirPath)
        }
    }

    // Model(path) là hàm dựng ĐỒNG BỘ (blocking, có thể mất vài giây) - chạy trên thread riêng,
    // KHÔNG gọi trực tiếp trên main thread. Caller (AudioCaptureService) đã gọi init() từ
    // background service nên an toàn, nhưng vẫn tách thread riêng để không chặn luồng gọi vào.
    private fun initFromPath(dirPath: String) {
        Thread {
            try {
                val loadedModel = Model(dirPath)
                onModelLoaded(loadedModel)
            } catch (e: Exception) {
                onEvent(Event.Error("Load model từ $dirPath thất bại: ${e.message}"))
            }
        }.start()
    }

    private fun onModelLoaded(loadedModel: Model) {
        model = loadedModel
        try {
            val rec = Recognizer(loadedModel, sampleRate)
            // Bật trả kèm danh sách từ + độ tin cậy (conf) trong JSON result - cần để tính
            // confidence trung bình cho lọc câu rác (xem extractResultWithConfidence()).
            rec.setWords(true)

            // Giữ lock suốt: gán recognizer, feed lại toàn bộ audio đã đệm (đúng thứ tự), rồi
            // mới bật ready = true - tất cả trong CÙNG 1 khối synchronized để feed() của luồng
            // đọc audio khác không thể xen ngang giữa lúc đang "trả nợ" audio cũ (nếu không,
            // audio "sống" mới có thể lọt vào recognizer TRƯỚC audio cũ đã đệm, khiến Vosk nhận
            // sai thứ tự thời gian). Việc feed lại này thường chỉ mất vài chục ms (1-3s audio,
            // decode nhanh hơn thời gian thực nhiều) nên giữ lock ngắn, không đáng lo chặn
            // luồng đọc audio lâu.
            synchronized(pendingAudioLock) {
                recognizer = rec
                for (chunk in pendingAudio) {
                    feedToRecognizer(rec, chunk, chunk.size)
                }
                pendingAudio.clear()
                pendingAudioSamples = 0
                ready = true
            }
            onEvent(Event.ModelReady)
        } catch (e: Exception) {
            onEvent(Event.Error("Khởi tạo Recognizer thất bại: ${e.message}"))
        }
    }

    // Gọi liên tục từ thread đọc AudioRecord. Đây là hàm nóng (hot path) -> tránh alloc thừa
    // ở nhánh "sống" (đã ready) - nhánh đệm (chưa ready) chỉ chạy ~1-3s lúc mới bắt đầu nghe
    // nên chấp nhận copyOf() tốn thêm chút alloc ở đó.
    override fun feed(pcm: ShortArray, length: Int) {
        if (length <= 0) return
        val rec: Recognizer
        synchronized(pendingAudioLock) {
            if (!ready) {
                bufferPendingLocked(pcm, length)
                return
            }
            rec = recognizer ?: return
        }
        feedToRecognizer(rec, pcm, length)
    }

    // PHẢI gọi trong synchronized(pendingAudioLock) - xem feed().
    private fun bufferPendingLocked(pcm: ShortArray, length: Int) {
        pendingAudio.add(pcm.copyOf(length))
        pendingAudioSamples += length
        while (pendingAudioSamples > maxPendingAudioSamples && pendingAudio.isNotEmpty()) {
            val dropped = pendingAudio.removeFirst()
            pendingAudioSamples -= dropped.size
        }
    }

    private fun feedToRecognizer(rec: Recognizer, pcm: ShortArray, length: Int) {
        val finished = rec.acceptWaveForm(pcm, length)
        if (finished) {
            val (text, confidence) = extractResultWithConfidence(rec.result)
            hasPendingPartial = false
            emitFinalOrLowConfidence(text, confidence)
        } else {
            val text = extractField(rec.partialResult, "partial")
            hasPendingPartial = text.isNotBlank()
            if (text.isNotBlank()) onEvent(Event.Partial(text))
        }
    }

    // confidence == -1.0 nghĩa là "không xác định được" (JSON thiếu "result", câu quá ngắn để
    // Vosk gán conf theo từ...) - trường hợp này KHÔNG lọc bỏ, vì đây là hạn chế đọc dữ liệu chứ
    // không phải bằng chứng câu đó là rác.
    private fun emitFinalOrLowConfidence(text: String, confidence: Double) {
        if (text.isBlank()) return
        val isLowConfidence = confidence in 0.0..CONFIDENCE_DROP_THRESHOLD
        if (isLowConfidence) {
            onEvent(Event.LowConfidence(text, confidence))
        } else {
            onEvent(Event.Final(text, confidence))
        }
    }

    // ===== Chế độ ngắt câu thông minh khi người nói tạm nghỉ =====
    // Endpointer mặc định của Kaldi/Vosk (quyết định "finished" trong feed() ở trên) thường
    // chờ khá lâu hoặc phụ thuộc cấu trúc câu trong HCLG graph, gây cảm giác phụ đề bị "dính"
    // câu trước vào câu sau, hoặc chốt câu trễ. AudioCaptureService tự đo im lặng qua biên độ
    // audio (không qua Vosk) và gọi hàm này khi phát hiện người nói đã ngừng đủ lâu (mặc định
    // ~200ms, xem AudioCaptureService.SMART_PAUSE_MS) - ép Recognizer chốt NGAY phần đã nghe
    // được thành 1 câu final, thay vì đợi endpointer tự nhiên (có thể lâu hơn nhiều, hoặc
    // không bao giờ tự chốt nếu người nói im lặng hẳn giữa câu).
    //
    // rec.finalResult (khác rec.result ở feed() phía trên): buộc Kaldi trả về kết quả tốt nhất
    // cho phần audio đã nhận từ lần chốt câu gần nhất, RESET lại trạng thái nội bộ để câu tiếp
    // theo bắt đầu "sạch" - không bị lẫn từ của câu vừa chốt.
    override fun forcePauseFinal() {
        val rec = recognizer ?: return
        if (!ready) return
        if (!hasPendingPartial) return // đang im lặng, chưa có gì để chốt - khỏi gọi finalResult vô ích

        val (text, confidence) = extractResultWithConfidence(rec.finalResult)
        hasPendingPartial = false
        emitFinalOrLowConfidence(text, confidence)
    }

    private fun extractField(json: String?, field: String): String {
        if (json.isNullOrBlank()) return ""
        return try {
            JSONObject(json).optString(field, "")
        } catch (e: Exception) {
            ""
        }
    }

    // Đọc text + tính confidence trung bình từ danh sách từ trong JSON result của Vosk (chỉ có
    // khi recognizer.setWords(true) đã bật - xem onModelLoaded()). Format JSON của Vosk:
    // {"result": [{"conf": 0.87, "start": 0.3, "end": 0.6, "word": "hello"}, ...], "text": "hello"}
    private fun extractResultWithConfidence(json: String?): Pair<String, Double> {
        if (json.isNullOrBlank()) return "" to -1.0
        return try {
            val obj = JSONObject(json)
            val text = obj.optString("text", "")
            val wordsArr = obj.optJSONArray("result")
            if (wordsArr == null || wordsArr.length() == 0) {
                text to -1.0 // không có info conf (câu rỗng, hoặc model/kết quả không trả words)
            } else {
                var sum = 0.0
                for (i in 0 until wordsArr.length()) {
                    sum += wordsArr.getJSONObject(i).optDouble("conf", 0.0)
                }
                text to (sum / wordsArr.length())
            }
        } catch (e: Exception) {
            "" to -1.0
        }
    }

    override fun release() {
        synchronized(pendingAudioLock) {
            ready = false
            pendingAudio.clear()
            pendingAudioSamples = 0
        }
        recognizer?.close()
        recognizer = null
        model?.close()
        model = null
    }
}
