package com.atun.translator

import android.content.Context
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.StorageService

// Bọc Vosk để nhận PCM đẩy trực tiếp từ AudioCaptureService (KHÔNG qua mic).
// Lưu ý quan trọng: dùng Recognizer trực tiếp thay vì SpeechService của Vosk,
// vì SpeechService tự mở AudioRecord từ mic bên trong - không nhận được audio
// mình tự bắt bằng AudioPlaybackCaptureConfiguration.
class VoskEngine(
    private val context: Context,
    private val sampleRate: Float,
    private val modelAssetName: String,
    private val onEvent: (Event) -> Unit
) {
    sealed class Event {
        data class Partial(val text: String) : Event()
        data class Final(val text: String) : Event()
        object ModelReady : Event()
        data class Error(val message: String) : Event()
    }

    companion object {
        // Ánh xạ mã ngôn ngữ nguồn (chọn ở UI) -> tên thư mục model trong assets/.
        // Hiện chỉ bundle model-en (đã bỏ model-vi để giảm dung lượng APK).
        // Thêm dòng mới ở đây + copy model vào assets-for-android/ nếu cần thêm ngôn ngữ khác.
        fun modelAssetForLang(sourceLang: String): String = when (sourceLang) {
            "en" -> "model-en"
            else -> "model-en"
        }
    }

    private var model: Model? = null
    private var recognizer: Recognizer? = null
    @Volatile private var ready = false

    fun init() {
        // StorageService.unpack chạy async, copy model từ assets ra internal storage
        // (Vosk cần đường dẫn file thật trên filesystem, không đọc thẳng từ APK asset).
        StorageService.unpack(
            context,
            modelAssetName,
            "model",
            { unpackedModel ->
                model = unpackedModel
                try {
                    recognizer = Recognizer(unpackedModel, sampleRate)
                    ready = true
                    onEvent(Event.ModelReady)
                } catch (e: Exception) {
                    onEvent(Event.Error("Khởi tạo Recognizer thất bại: ${e.message}"))
                }
            },
            { exception ->
                onEvent(Event.Error("Giải nén model Vosk thất bại: ${exception.message}"))
            }
        )
    }

    // Gọi liên tục từ thread đọc AudioRecord. Đây là hàm nóng (hot path) -> tránh alloc thừa.
    fun feed(pcm: ShortArray, length: Int) {
        val rec = recognizer ?: return
        if (!ready) return

        val finished = rec.acceptWaveForm(pcm, length)
        if (finished) {
            val text = extractField(rec.result, "text")
            if (text.isNotBlank()) onEvent(Event.Final(text))
        } else {
            val text = extractField(rec.partialResult, "partial")
            if (text.isNotBlank()) onEvent(Event.Partial(text))
        }
    }

    private fun extractField(json: String?, field: String): String {
        if (json.isNullOrBlank()) return ""
        return try {
            JSONObject(json).optString(field, "")
        } catch (e: Exception) {
            ""
        }
    }

    fun release() {
        ready = false
        recognizer?.close()
        recognizer = null
        model?.close()
        model = null
    }
}
