package com.atun.translator

import android.content.Context
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.StorageService

// Bọc Vosk để nhận PCM đẩy trực tiếp từ AudioCaptureService (KHÔNG qua mic).
// Lưu ý quan trọng: dùng Recognizer trực tiếp thay vì SpeechService của Vosk,
// vì SpeechService tự mở AudioRecord từ mic bên trong - không nhận được audio
// mình tự bắt bằng AudioPlaybackCaptureConfiguration.
class VoskEngine(
    private val context: Context,
    private val sampleRate: Float,
    private val modelSource: ModelSource,
    private val onEvent: (Event) -> Unit
) {
    sealed class Event {
        data class Partial(val text: String) : Event()
        data class Final(val text: String) : Event()
        object ModelReady : Event()
        data class Error(val message: String) : Event()
    }

    // Nguồn model: Asset = bundled sẵn trong APK (chỉ "en" hiện tại, giải nén qua
    // StorageService.unpack); Path = đã tải về + giải nén sẵn trên filesystem qua
    // ModelManagerPlugin (mọi ngôn ngữ khác) - load thẳng bằng Model(path), không qua asset.
    sealed class ModelSource {
        data class Asset(val assetName: String) : ModelSource()
        data class Path(val dirPath: String) : ModelSource()
    }

    companion object {
        // "en" là ngôn ngữ duy nhất bundle sẵn trong APK (xem scripts/copy-model-assets.py +
        // assets-for-android/model-en) - các ngôn ngữ khác PHẢI tải về trước qua ModelManagerPlugin
        // (xem ModelManagerPlugin.CATALOG), không có asset dự phòng nào khác nữa.
        //
        // Trả về null nếu model chưa sẵn sàng (chưa tải về) - caller (AudioCaptureService) PHẢI
        // kiểm tra null và báo lỗi cho JS thay vì start capture với model rỗng.
        fun resolveModelSource(context: Context, sourceLang: String): ModelSource? {
            if (sourceLang == ModelManagerPlugin.BUNDLED_LANG) {
                return ModelSource.Asset("model-en")
            }
            return if (ModelManagerPlugin.isDownloaded(context, sourceLang)) {
                ModelSource.Path(ModelManagerPlugin.modelDir(context, sourceLang).absolutePath)
            } else {
                null
            }
        }
    }

    private var model: Model? = null
    private var recognizer: Recognizer? = null
    @Volatile private var ready = false

    fun init() {
        when (val source = modelSource) {
            is ModelSource.Asset -> initFromAsset(source.assetName)
            is ModelSource.Path -> initFromPath(source.dirPath)
        }
    }

    // StorageService.unpack chạy async, copy model từ assets ra internal storage
    // (Vosk cần đường dẫn file thật trên filesystem, không đọc thẳng từ APK asset).
    private fun initFromAsset(assetName: String) {
        StorageService.unpack(
            context,
            assetName,
            "model",
            { unpackedModel -> onModelLoaded(unpackedModel) },
            { exception -> onEvent(Event.Error("Giải nén model Vosk thất bại: ${exception.message}")) }
        )
    }

    // Model(path) là hàm dựng ĐỒNG BỘ (blocking, có thể mất vài giây) - chạy trên thread riêng,
    // KHÔNG gọi trực tiếp trên main thread. Caller (AudioCaptureService) đã gọi init() từ
    // background service nên an toàn, nhưng vẫn tách thread riêng để không chặn luồng gọi vào.
    private fun initFromPath(dirPath: String) {
        Thread {
            try {
                val loadedModel = Model(dirPath)
                onModelLoaded(loadedModel)
            } catch (e: Exception) {
                onEvent(Event.Error("Load model từ $dirPath thất bại: ${e.message}"))
            }
        }.start()
    }

    private fun onModelLoaded(loadedModel: Model) {
        model = loadedModel
        try {
            recognizer = Recognizer(loadedModel, sampleRate)
            ready = true
            onEvent(Event.ModelReady)
        } catch (e: Exception) {
            onEvent(Event.Error("Khởi tạo Recognizer thất bại: ${e.message}"))
        }
    }

    // Gọi liên tục từ thread đọc AudioRecord. Đây là hàm nóng (hot path) -> tránh alloc thừa.
    fun feed(pcm: ShortArray, length: Int) {
        val rec = recognizer ?: return
        if (!ready) return

        val finished = rec.acceptWaveForm(pcm, length)
        if (finished) {
            val text = extractField(rec.result, "text")
            if (text.isNotBlank()) onEvent(Event.Final(text))
        } else {
            val text = extractField(rec.partialResult, "partial")
            if (text.isNotBlank()) onEvent(Event.Partial(text))
        }
    }

    private fun extractField(json: String?, field: String): String {
        if (json.isNullOrBlank()) return ""
        return try {
            JSONObject(json).optString(field, "")
        } catch (e: Exception) {
            ""
        }
    }

    fun release() {
        ready = false
        recognizer?.close()
        recognizer = null
        model?.close()
        model = null
    }
}
