package com.atun.translator

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

// Đọc to bản dịch tiếng Việt qua TextToSpeech có sẵn trong Android (KHÔNG cần thêm thư viện/
// npm package nào, không cần mạng nếu máy đã có giọng đọc offline) - hữu ích khi đang xem
// video mà không tiện nhìn màn hình liên tục để đọc phụ đề overlay.
//
// Mỗi lần đọc, xin AudioFocus kiểu "duck" (AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK) - hầu hết app
// media Android (YouTube, VLC...) tôn trọng yêu cầu này và tự hạ nhỏ tiếng gốc lại thay vì đè
// chan chát lên giọng đọc, rồi trả về mức cũ khi đọc xong (abandonAudioFocus).
@CapacitorPlugin(name = "TtsPlugin")
class TtsPlugin : Plugin() {

    private var tts: TextToSpeech? = null
    private var ready = false
    private val pendingUtterances = AtomicInteger(0)
    private var audioManager: AudioManager? = null
    private var focusRequest: AudioFocusRequest? = null

    private val speechAttributes: AudioAttributes by lazy {
        AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
    }

    override fun load() {
        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        tts = TextToSpeech(context) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                tts?.language = Locale("vi", "VN")
                tts?.setAudioAttributes(speechAttributes)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        if (pendingUtterances.decrementAndGet() <= 0) abandonAudioFocus()
                    }
                    @Deprecated("Deprecated in Java, vẫn phải override vì API cũ chưa gỡ")
                    override fun onError(utteranceId: String?) {
                        if (pendingUtterances.decrementAndGet() <= 0) abandonAudioFocus()
                    }
                })
            }
            val data = JSObject()
            data.put("ready", ready)
            notifyListeners("ttsStatus", data)
        }
    }

    @PluginMethod
    fun speak(call: PluginCall) {
        val text = call.getString("text")
        if (text.isNullOrBlank()) {
            call.resolve()
            return
        }
        val engine = tts
        if (engine == null || !ready) {
            call.reject("TTS engine chưa sẵn sàng (máy có thể chưa cài giọng đọc tiếng Việt)")
            return
        }

        // flushMode=true: xoá hàng đợi cũ, đọc câu MỚI NHẤT ngay - dùng khi bản dịch ra nhanh
        // hơn tốc độ đọc để tránh đọc dồn trễ xa audio thật. false (mặc định): QUEUE_ADD, đọc
        // đủ hết không bỏ câu nào, nhưng dễ bị trễ dần nếu người nói nhanh/liên tục.
        val flushMode = call.getBoolean("flushMode") ?: false
        val queueMode = if (flushMode) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        if (flushMode) pendingUtterances.set(0)

        requestAudioFocus()
        val utteranceId = "atun-tts-" + System.currentTimeMillis()
        pendingUtterances.incrementAndGet()
        engine.speak(text, queueMode, null, utteranceId)
        call.resolve()
    }

    @PluginMethod
    fun stop(call: PluginCall) {
        tts?.stop()
        pendingUtterances.set(0)
        abandonAudioFocus()
        call.resolve()
    }

    @PluginMethod
    fun setRate(call: PluginCall) {
        val rate = (call.getFloat("rate") ?: 1.0f).coerceIn(0.5f, 2.5f)
        tts?.setSpeechRate(rate)
        call.resolve()
    }

    // Giọng đọc tiếng Việt không có sẵn trên mọi máy (đặc biệt máy cũ/ROM tuỳ biến) - cho JS
    // biết trước để hiện nút "Cài giọng đọc tiếng Việt" thay vì im lặng không đọc được gì mà
    // không rõ lý do.
    @PluginMethod
    fun checkVietnameseVoice(call: PluginCall) {
        val engine = tts
        val result = if (engine == null) TextToSpeech.LANG_NOT_SUPPORTED
            else engine.isLanguageAvailable(Locale("vi", "VN"))
        val ret = JSObject()
        ret.put("available", result >= TextToSpeech.LANG_AVAILABLE)
        call.resolve(ret)
    }

    // Mở màn hình hệ thống để tải giọng đọc tiếng Việt (thường qua Google Text-to-Speech) -
    // không có API tự tải ngầm, bắt buộc phải qua màn hình hệ thống để user tự xác nhận tải.
    @PluginMethod
    fun promptInstallVoiceData(call: PluginCall) {
        try {
            val intent = Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(intent)
            call.resolve()
        } catch (e: Exception) {
            call.reject("Không mở được màn hình cài giọng đọc: ${e.message}")
        }
    }

    private fun requestAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val req = focusRequest ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(speechAttributes)
                .build().also { focusRequest = it }
            am.requestAudioFocus(req)
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
        }
    }

    private fun abandonAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            focusRequest?.let { am.abandonAudioFocusRequest(it) }
        } else {
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(null)
        }
    }

    override fun handleOnDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.handleOnDestroy()
    }
}
