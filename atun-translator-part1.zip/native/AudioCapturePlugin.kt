package com.atun.translator

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import com.getcapacitor.JSObject
import com.getcapacitor.PermissionState
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.ActivityCallback
import com.getcapacitor.annotation.CapacitorPlugin
import com.getcapacitor.annotation.Permission
import com.getcapacitor.annotation.PermissionCallback

// Cầu nối JS <-> AudioCaptureService.
// JS gọi requestCapture({ sourceLang, captureMode }) với captureMode = "system" | "mic":
// - "system": bật dialog hệ thống xin quyền MediaProjection (bắt audio phát ra từ app khác).
// - "mic": xin quyền RECORD_AUDIO (permission thường), ghi âm qua micro máy (nghe qua loa ngoài).
// Cả 2 đường đều start AudioCaptureService và trả về sự kiện "partialText"/"finalText"/
// "captureError" mỗi khi Vosk nhận diện được câu nói.
@CapacitorPlugin(
    name = "AudioCapture",
    permissions = [
        Permission(strings = [Manifest.permission.RECORD_AUDIO], alias = "microphone"),
        Permission(strings = [Manifest.permission.POST_NOTIFICATIONS], alias = "notifications")
    ]
)
class AudioCapturePlugin : com.getcapacitor.Plugin() {

    companion object {
        // Service gọi các hàm này để đẩy kết quả STT lên JS.
        // Dùng weak-ish singleton đơn giản vì chỉ có 1 instance plugin sống theo Activity.
        var instance: AudioCapturePlugin? = null
    }

    // Lưu tạm giữa requestCapture() và callback xảy ra sau (dialog hệ thống HOẶC xin quyền
    // micro trả kết quả về sau) - PluginCall gốc không giữ field custom qua các bước này.
    private var pendingSourceLang: String = "en"

    override fun load() {
        super.load()
        instance = this
    }

    @PluginMethod
    fun requestCapture(call: PluginCall) {
        pendingSourceLang = call.getString("sourceLang", "en") ?: "en"
        val mode = call.getString("captureMode", AudioCaptureService.MODE_SYSTEM)
            ?: AudioCaptureService.MODE_SYSTEM

        if (mode == AudioCaptureService.MODE_MIC) {
            if (getPermissionState("microphone") == PermissionState.GRANTED) {
                startMicCaptureService(call)
            } else {
                saveCall(call)
                requestPermissionForAlias("microphone", call, "handleMicPermissionResult")
            }
            return
        }

        requestSystemCapture(call)
    }

    private fun requestSystemCapture(call: PluginCall) {
        val projectionManager =
            context.getSystemService(android.content.Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        // Android 14+ mặc định hiện dialog cho user chọn "Toàn màn hình" hay "Một app".
        // Nếu chọn "Một app" (vd. chọn nhầm app khác, hoặc chọn chính app này), MediaProjection
        // bị giới hạn phạm vi (app-scoped) -> AudioPlaybackCaptureConfiguration dựng từ projection
        // đó CHỈ bắt được audio của app đã chọn, không bắt audio hệ thống/app khác (vd. YouTube).
        // build() vẫn thành công, không throw exception - chỉ đọc ra toàn silence (peak=0).
        // Ép chỉ cho chọn "toàn màn hình" để tránh đúng lỗi này.
        val intent = if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            projectionManager.createScreenCaptureIntent(
                android.media.projection.MediaProjectionConfig.createConfigForDefaultDisplay()
            )
        } else {
            projectionManager.createScreenCaptureIntent()
        }
        saveCall(call)
        startActivityForResult(call, intent, "handleProjectionResult")
    }

    @ActivityCallback
    private fun handleProjectionResult(call: PluginCall?, result: androidx.activity.result.ActivityResult) {
        if (call == null) return

        if (result.resultCode != Activity.RESULT_OK || result.data == null) {
            call.reject("Người dùng từ chối quyền chia sẻ/ghi âm màn hình (bắt buộc để bắt audio hệ thống).")
            return
        }

        val serviceIntent = Intent(context, AudioCaptureService::class.java).apply {
            action = AudioCaptureService.ACTION_START
            putExtra(AudioCaptureService.EXTRA_CAPTURE_MODE, AudioCaptureService.MODE_SYSTEM)
            putExtra(AudioCaptureService.EXTRA_RESULT_CODE, result.resultCode)
            putExtra(AudioCaptureService.EXTRA_RESULT_DATA, result.data)
            putExtra(AudioCaptureService.EXTRA_SOURCE_LANG, pendingSourceLang)
        }
        androidx.core.content.ContextCompat.startForegroundService(context, serviceIntent)

        val ret = JSObject()
        ret.put("started", true)
        call.resolve(ret)
    }

    @PermissionCallback
    private fun handleMicPermissionResult(call: PluginCall) {
        if (getPermissionState("microphone") == PermissionState.GRANTED) {
            startMicCaptureService(call)
        } else {
            call.reject("Người dùng từ chối quyền micro (bắt buộc để nghe qua micro).")
        }
    }

    private fun startMicCaptureService(call: PluginCall) {
        val serviceIntent = Intent(context, AudioCaptureService::class.java).apply {
            action = AudioCaptureService.ACTION_START
            putExtra(AudioCaptureService.EXTRA_CAPTURE_MODE, AudioCaptureService.MODE_MIC)
            putExtra(AudioCaptureService.EXTRA_SOURCE_LANG, pendingSourceLang)
        }
        androidx.core.content.ContextCompat.startForegroundService(context, serviceIntent)

        val ret = JSObject()
        ret.put("started", true)
        call.resolve(ret)
    }

    @PluginMethod
    fun stopCapture(call: PluginCall) {
        AudioCaptureService.clearSavedState(context)
        val serviceIntent = Intent(context, AudioCaptureService::class.java).apply {
            action = AudioCaptureService.ACTION_STOP
        }
        context.startService(serviceIntent)
        call.resolve()
    }

    // Gọi từ JS khi app mở lại (vd. onResume), để biết phiên "system" trước đó có bị hệ thống
    // âm thầm dừng giữa chừng không (bị OS kill, không tự phục hồi được vì token MediaProjection
    // dùng 1 lần) - nhờ đó UI có thể báo cho user biết thay vì im lặng không hiểu vì sao mất phụ đề.
    @PluginMethod
    fun checkLostSession(call: PluginCall) {
        val lost = AudioCaptureService.consumeLostSystemSession(context)
        if (lost) {
            AudioCaptureService.clearSavedState(context)
        }
        val ret = JSObject()
        ret.put("lostSystemSession", lost)
        call.resolve(ret)
    }

    // ===== Quyền thông báo (Android 13+/TIRAMISU bắt buộc xin runtime, trước đó luôn granted) =====
    // Tách riêng khỏi luồng overlay/mic vì thuộc bước onboarding khác - JS gọi tuần tự:
    // overlay permission -> notification permission -> sẵn sàng bắt đầu nghe.

    @PluginMethod
    fun checkNotificationPermission(call: PluginCall) {
        val granted = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            getPermissionState("notifications") == PermissionState.GRANTED
        val ret = JSObject()
        ret.put("granted", granted)
        call.resolve(ret)
    }

    @PluginMethod
    fun requestNotificationPermission(call: PluginCall) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            val ret = JSObject()
            ret.put("granted", true)
            call.resolve(ret)
            return
        }
        if (getPermissionState("notifications") == PermissionState.GRANTED) {
            val ret = JSObject()
            ret.put("granted", true)
            call.resolve(ret)
        } else {
            saveCall(call)
            requestPermissionForAlias("notifications", call, "handleNotificationPermissionResult")
        }
    }

    @PermissionCallback
    private fun handleNotificationPermissionResult(call: PluginCall) {
        val granted = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            getPermissionState("notifications") == PermissionState.GRANTED
        val ret = JSObject()
        ret.put("granted", granted)
        call.resolve(ret)
    }

    // ===== Gọi bởi AudioCaptureService/VoskEngine (chạy trên thread nền -> phải post lên JS an toàn) =====

    fun emitPartial(text: String) {
        val data = JSObject()
        data.put("text", text)
        notifyListeners("partialText", data)
    }

    fun emitFinal(text: String) {
        val data = JSObject()
        data.put("text", text)
        notifyListeners("finalText", data)
    }

    fun emitError(message: String) {
        val data = JSObject()
        data.put("message", message)
        notifyListeners("captureError", data)
    }

    fun emitModelLoading(ready: Boolean) {
        val data = JSObject()
        data.put("ready", ready)
        notifyListeners("modelStatus", data)
    }

    // Bắn khi service tự khởi động lại và phục hồi capture thành công sau khi bị OS kill
    // (chỉ xảy ra với MODE_MIC - xem AudioCaptureService.onStartCommand).
    fun emitCaptureResumed(mode: String) {
        val data = JSObject()
        data.put("mode", mode)
        notifyListeners("captureResumed", data)
    }

    // Đo mức tín hiệu audio thực tế đọc được từ AudioRecord, bắn lên JS mỗi ~1s.
    // Dùng để phân biệt "capture chạy nhưng audio là silence" (peak ~ 0 liên tục) với
    // "capture không chạy" hay "Vosk không nhận diện được dù có audio thật".
    fun emitAudioLevel(peak: Int, readCalls: Int, silentReads: Int, badReads: Int) {
        val data = JSObject()
        data.put("peak", peak) // 0..32767, PCM16 mono
        data.put("readCalls", readCalls)
        data.put("silentReads", silentReads)
        data.put("badReads", badReads)
        notifyListeners("audioLevel", data)
    }
}
