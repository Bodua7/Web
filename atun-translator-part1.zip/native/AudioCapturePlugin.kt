package com.atun.translator

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import com.getcapacitor.JSObject
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.ActivityCallback
import com.getcapacitor.annotation.CapacitorPlugin

// Cầu nối JS <-> AudioCaptureService.
// JS gọi requestCapture() -> plugin bật dialog hệ thống xin quyền MediaProjection ->
// nếu user đồng ý, plugin start AudioCaptureService (native) và trả về sự kiện
// "partialText"/"finalText"/"captureError" mỗi khi Vosk nhận diện được câu nói.
@CapacitorPlugin(name = "AudioCapture")
class AudioCapturePlugin : com.getcapacitor.Plugin() {

    companion object {
        // Service gọi các hàm này để đẩy kết quả STT lên JS.
        // Dùng weak-ish singleton đơn giản vì chỉ có 1 instance plugin sống theo Activity.
        var instance: AudioCapturePlugin? = null
    }

    // Lưu tạm giữa requestCapture() và handleProjectionResult() (callback xảy ra sau khi
    // Activity khác - dialog xin quyền hệ thống - trả kết quả về, PluginCall gốc không giữ field custom).
    private var pendingSourceLang: String = "en"

    override fun load() {
        super.load()
        instance = this
    }

    @PluginMethod
    fun requestCapture(call: PluginCall) {
        pendingSourceLang = call.getString("sourceLang", "en") ?: "en"
        val projectionManager =
            context.getSystemService(android.content.Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val intent = projectionManager.createScreenCaptureIntent()
        saveCall(call)
        startActivityForResult(call, intent, "handleProjectionResult")
    }

    @ActivityCallback
    private fun handleProjectionResult(call: PluginCall?, result: androidx.activity.result.ActivityResult) {
        if (call == null) return

        if (result.resultCode != Activity.RESULT_OK || result.data == null) {
            call.reject("Người dùng từ chối quyền chia sẻ/ghi âm màn hình (bắt buộc để bắt audio hệ thống).")
            return
        }

        val serviceIntent = Intent(context, AudioCaptureService::class.java).apply {
            action = AudioCaptureService.ACTION_START
            putExtra(AudioCaptureService.EXTRA_RESULT_CODE, result.resultCode)
            putExtra(AudioCaptureService.EXTRA_RESULT_DATA, result.data)
            putExtra(AudioCaptureService.EXTRA_SOURCE_LANG, pendingSourceLang)
        }
        androidx.core.content.ContextCompat.startForegroundService(context, serviceIntent)

        val ret = JSObject()
        ret.put("started", true)
        call.resolve(ret)
    }

    @PluginMethod
    fun stopCapture(call: PluginCall) {
        val serviceIntent = Intent(context, AudioCaptureService::class.java).apply {
            action = AudioCaptureService.ACTION_STOP
        }
        context.startService(serviceIntent)
        call.resolve()
    }

    // ===== Gọi bởi AudioCaptureService/VoskEngine (chạy trên thread nền -> phải post lên JS an toàn) =====

    // ===== Luồng phụ: STT cho audio LẤY QUA MẠNG (network fetch, vd YouTube qua InnerTube/
    // Piped/Invidious ở JS), KHÔNG qua MediaProjection/AudioRecord hệ thống. Dùng khi
    // AudioPlaybackCaptureConfiguration bị app nguồn (YouTube) chặn - xem AudioEngine.js.
    // Chạy VoskEngine riêng (externalVoskEngine), JS tự downsample PCM về 16kHz mono rồi
    // gửi từng chunk base64 qua feedExternalPcm(). Bắn event qua CÙNG các hàm emit*
    // bên dưới nên UI/JS không cần phân biệt nguồn - partialText/finalText dùng chung.
    private var externalVoskEngine: VoskEngine? = null

    @PluginMethod
    fun startExternalStt(call: PluginCall) {
        val sourceLang = call.getString("sourceLang", "en") ?: "en"
        if (externalVoskEngine != null) {
            // Đã có sẵn model đang chạy (vd user bấm Lấy & Phát Audio 2 lần) - khỏi load lại.
            call.resolve()
            return
        }
        externalVoskEngine = VoskEngine(
            context.applicationContext,
            sampleRate = 16000f,
            modelAssetName = VoskEngine.modelAssetForLang(sourceLang)
        ) { event ->
            when (event) {
                is VoskEngine.Event.Partial -> emitPartial(event.text)
                is VoskEngine.Event.Final -> emitFinal(event.text)
                is VoskEngine.Event.ModelReady -> emitModelLoading(true)
                is VoskEngine.Event.Error -> emitError(event.message)
            }
        }
        externalVoskEngine?.init()
        call.resolve()
    }

    @PluginMethod
    fun feedExternalPcm(call: PluginCall) {
        val base64 = call.getString("data")
        if (base64.isNullOrEmpty()) {
            call.reject("Thiếu field 'data' (base64 PCM16LE mono 16kHz).")
            return
        }
        try {
            val bytes = android.util.Base64.decode(base64, android.util.Base64.NO_WRAP)
            val shorts = ShortArray(bytes.size / 2)
            java.nio.ByteBuffer.wrap(bytes)
                .order(java.nio.ByteOrder.LITTLE_ENDIAN)
                .asShortBuffer()
                .get(shorts)
            externalVoskEngine?.feed(shorts, shorts.size)
            call.resolve()
        } catch (e: Exception) {
            call.reject("Lỗi giải mã PCM: ${e.message}")
        }
    }

    @PluginMethod
    fun stopExternalStt(call: PluginCall) {
        externalVoskEngine?.release()
        externalVoskEngine = null
        call.resolve()
    }

    fun emitPartial(text: String) {
        val data = JSObject()
        data.put("text", text)
        notifyListeners("partialText", data)
    }

    fun emitFinal(text: String) {
        val data = JSObject()
        data.put("text", text)
        notifyListeners("finalText", data)
    }

    fun emitError(message: String) {
        val data = JSObject()
        data.put("message", message)
        notifyListeners("captureError", data)
    }

    fun emitModelLoading(ready: Boolean) {
        val data = JSObject()
        data.put("ready", ready)
        notifyListeners("modelStatus", data)
    }

    // DEBUG: đo mức tín hiệu audio thực tế đọc được từ AudioRecord, bắn lên JS mỗi ~1s.
    // Dùng để phân biệt "capture chạy nhưng audio là silence" (peak ~ 0 liên tục) với
    // "capture không chạy" hay "Vosk không nhận diện được dù có audio thật".
    fun emitAudioLevel(peak: Int, readCalls: Int, silentReads: Int, badReads: Int) {
        val data = JSObject()
        data.put("peak", peak) // 0..32767, PCM16 mono
        data.put("readCalls", readCalls)
        data.put("silentReads", silentReads)
        data.put("badReads", badReads)
        notifyListeners("audioLevel", data)
    }
}
