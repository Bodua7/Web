package com.atun.translator

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import com.getcapacitor.JSObject
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.ActivityCallback
import com.getcapacitor.annotation.CapacitorPlugin

// Cầu nối JS <-> AudioCaptureService.
// JS gọi requestCapture() -> plugin bật dialog hệ thống xin quyền MediaProjection ->
// nếu user đồng ý, plugin start AudioCaptureService (native) và trả về sự kiện
// "partialText"/"finalText"/"captureError" mỗi khi Vosk nhận diện được câu nói.
@CapacitorPlugin(name = "AudioCapture")
class AudioCapturePlugin : com.getcapacitor.Plugin() {

    companion object {
        // Service gọi các hàm này để đẩy kết quả STT lên JS.
        // Dùng weak-ish singleton đơn giản vì chỉ có 1 instance plugin sống theo Activity.
        var instance: AudioCapturePlugin? = null
    }

    // Lưu tạm giữa requestCapture() và handleProjectionResult() (callback xảy ra sau khi
    // Activity khác - dialog xin quyền hệ thống - trả kết quả về, PluginCall gốc không giữ field custom).
    private var pendingSourceLang: String = "en"

    override fun load() {
        super.load()
        instance = this
    }

    @PluginMethod
    fun requestCapture(call: PluginCall) {
        pendingSourceLang = call.getString("sourceLang", "en") ?: "en"
        val projectionManager =
            context.getSystemService(android.content.Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val intent = projectionManager.createScreenCaptureIntent()
        saveCall(call)
        startActivityForResult(call, intent, "handleProjectionResult")
    }

    @ActivityCallback
    private fun handleProjectionResult(call: PluginCall?, result: androidx.activity.result.ActivityResult) {
        if (call == null) return

        if (result.resultCode != Activity.RESULT_OK || result.data == null) {
            call.reject("Người dùng từ chối quyền chia sẻ/ghi âm màn hình (bắt buộc để bắt audio hệ thống).")
            return
        }

        val serviceIntent = Intent(context, AudioCaptureService::class.java).apply {
            action = AudioCaptureService.ACTION_START
            putExtra(AudioCaptureService.EXTRA_RESULT_CODE, result.resultCode)
            putExtra(AudioCaptureService.EXTRA_RESULT_DATA, result.data)
            putExtra(AudioCaptureService.EXTRA_SOURCE_LANG, pendingSourceLang)
        }
        androidx.core.content.ContextCompat.startForegroundService(context, serviceIntent)

        val ret = JSObject()
        ret.put("started", true)
        call.resolve(ret)
    }

    @PluginMethod
    fun stopCapture(call: PluginCall) {
        val serviceIntent = Intent(context, AudioCaptureService::class.java).apply {
            action = AudioCaptureService.ACTION_STOP
        }
        context.startService(serviceIntent)
        call.resolve()
    }

    // ===== Gọi bởi AudioCaptureService/VoskEngine (chạy trên thread nền -> phải post lên JS an toàn) =====

    fun emitPartial(text: String) {
        val data = JSObject()
        data.put("text", text)
        notifyListeners("partialText", data)
    }

    fun emitFinal(text: String) {
        val data = JSObject()
        data.put("text", text)
        notifyListeners("finalText", data)
    }

    fun emitError(message: String) {
        val data = JSObject()
        data.put("message", message)
        notifyListeners("captureError", data)
    }

    fun emitModelLoading(ready: Boolean) {
        val data = JSObject()
        data.put("ready", ready)
        notifyListeners("modelStatus", data)
    }
}
