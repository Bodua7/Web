package com.atun.translator

import android.content.Context
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import kotlin.concurrent.thread

// Quản lý model Vosk KHÔNG bundle sẵn trong APK (mọi ngôn ngữ trừ "en") - tải zip trực tiếp
// từ URL chính chủ alphacephei.com (xem CATALOG), giải nén vào filesDir/models/<lang>/, dùng
// trực tiếp bằng Model(path) (xem VoskEngine.resolveModelSource) thay vì StorageService.unpack
// (chỉ đọc được asset đóng gói sẵn trong APK, không đọc được file tải về runtime).
//
// Lý do không bundle hết mọi ngôn ngữ vào APK: mỗi model Vosk ~30-80MB, bundle 4-5 ngôn ngữ
// sẽ đẩy APK vượt 200MB, rất khó tải/phân phối qua GitHub Releases + cài trực tiếp (không qua
// Play Store). Chỉ bundle "en" (ngôn ngữ dùng nhiều nhất), còn lại tải khi cần.
@CapacitorPlugin(name = "ModelManager")
class ModelManagerPlugin : com.getcapacitor.Plugin() {

    companion object {
        // Dùng thẳng model chính chủ từ alphacephei.com (giống cách "en-large" bên dưới đã
        // làm) thay vì tự nén lại rồi tự host trên GitHub Releases của repo này - tránh phải
        // tự tải về máy, nén .zip, tạo GitHub Release, upload thủ công mỗi khi cần thêm/đổi
        // model. unzip() bên dưới đã tự phát hiện + bóc lớp thư mục cha mà các zip gốc của
        // alphacephei hay bọc ngoài (vd "vosk-model-small-vn-0.4/"), nên dùng thẳng URL gốc
        // không cần xử lý gì thêm.
        // sizeMB lấy đúng theo trang https://alphacephei.com/vosk/models - chỉ để hiển thị
        // ước lượng cho UI trước khi tải, không ảnh hưởng logic.
        val CATALOG: Map<String, ModelInfo> = mapOf(
            "vi" to ModelInfo(
                "Tiếng Việt",
                "https://alphacephei.com/vosk/models/vosk-model-small-vn-0.4.zip",
                32
            ),
            "ja" to ModelInfo(
                "日本語",
                "https://alphacephei.com/vosk/models/vosk-model-small-ja-0.22.zip",
                48
            ),
            "ko" to ModelInfo(
                "한국어",
                "https://alphacephei.com/vosk/models/vosk-model-small-ko-0.22.zip",
                82
            ),
            // Model tiếng Anh LỚN, chính xác cao hơn hẳn bản "en" bundled (~40MB, WER thấp hơn
            // nhiều so với model small). Cùng cơ chế tải trực tiếp từ URL chính chủ Alphacephei
            // như vi/ja/ko ở trên - zip này cũng bọc 1 lớp thư mục cha "vosk-model-en-us-0.22/"
            // mà unzip() tự bóc ra. Cảnh báo: ~1.8GB, chỉ nên tải qua Wi-Fi.
            "en-large" to ModelInfo(
                "English (chính xác cao)",
                "https://alphacephei.com/vosk/models/vosk-model-en-us-0.22.zip",
                1800
            )
        )

        // "en" không nằm trong CATALOG - luôn coi là "bundled" (đã đóng gói sẵn trong APK,
        // xem scripts/copy-model-assets.py + assets-for-android/model-en).
        const val BUNDLED_LANG = "en"

        fun modelsDir(context: Context): File = File(context.filesDir, "models")

        fun modelDir(context: Context, lang: String): File = File(modelsDir(context), lang)

        // Dùng lại ở VoskEngine để biết model đã sẵn sàng chưa trước khi start capture.
        fun isDownloaded(context: Context, lang: String): Boolean {
            val dir = modelDir(context, lang)
            return dir.isDirectory && (dir.listFiles()?.isNotEmpty() == true)
        }

        // 15s cũ QUÁ NGẮN cho mạng di động/WiFi chập chờn - chỉ cần khựng >15s giữa chừng
        // (rất dễ xảy ra với model lớn như en-large ~1.8GB tải nhiều phút) là toàn bộ request
        // bị huỷ. Đây là nguyên nhân chính khiến tải hay báo "Lỗi tải - thử lại" dù mạng vẫn
        // dùng bình thường cho việc khác. Tăng lên rộng rãi hơn nhiều.
        const val CONNECT_TIMEOUT_MS = 20_000
        const val READ_TIMEOUT_MS = 60_000
        const val MAX_ATTEMPTS = 4
    }

    data class ModelInfo(val displayName: String, val url: String, val sizeMB: Int)

    // Theo dõi các lượt tải đang chạy để hỗ trợ cancelDownload() - key = lang.
    private val activeDownloads = mutableMapOf<String, Thread>()

    @PluginMethod
    fun listModels(call: PluginCall) {
        val arr = JSArray()

        val bundledObj = JSObject()
        bundledObj.put("lang", BUNDLED_LANG)
        bundledObj.put("name", "English")
        bundledObj.put("sizeMB", 40)
        bundledObj.put("status", "bundled")
        arr.put(bundledObj)

        for ((lang, info) in CATALOG) {
            val obj = JSObject()
            obj.put("lang", lang)
            obj.put("name", info.displayName)
            obj.put("sizeMB", info.sizeMB)
            obj.put("status", if (isDownloaded(context, lang)) "downloaded" else "not_downloaded")
            arr.put(obj)
        }

        val ret = JSObject()
        ret.put("models", arr)
        call.resolve(ret)
    }

    @PluginMethod
    fun downloadModel(call: PluginCall) {
        val lang = call.getString("lang")
        if (lang.isNullOrBlank()) {
            call.reject("Thiếu tham số lang.")
            return
        }
        val info = CATALOG[lang]
        if (info == null) {
            call.reject("Không có model cho lang=$lang trong catalog.")
            return
        }
        if (isDownloaded(context, lang)) {
            call.resolve(JSObject().apply { put("alreadyDownloaded", true) })
            return
        }
        if (activeDownloads.containsKey(lang)) {
            call.reject("Đang tải model cho lang=$lang rồi, đợi xong hoặc cancelDownload() trước.")
            return
        }

        val targetDir = modelDir(context, lang)
        val tmpZip = File(context.cacheDir, "model-$lang-download.zip")

        val t = thread(name = "ModelDownload-$lang") {
            try {
                downloadWithRetry(info.url, tmpZip) { downloadedBytes, totalBytes ->
                    emitProgress(lang, downloadedBytes, totalBytes)
                }
                unzip(tmpZip, targetDir)
                tmpZip.delete()

                if (!isDownloaded(context, lang)) {
                    throw IllegalStateException("Giải nén xong nhưng thư mục model rỗng - zip có thể sai cấu trúc.")
                }

                emitDone(lang, success = true, error = null)
            } catch (e: Exception) {
                // Dọn dẹp thư mục model dở dang (giải nén lỗi giữa chừng) để lần tải sau không
                // bị lẫn dữ liệu hỏng. KHÔNG xoá tmpZip ở đây nữa - downloadWithRetry() đã tự lo
                // giữ/xoá tmpZip tuỳ trường hợp (giữ lại để resume nếu còn khả năng thử lại,
                // xoá nếu đã bỏ cuộc hẳn - xem downloadWithRetry()).
                targetDir.deleteRecursively()
                emitDone(lang, success = false, error = e.message ?: e.toString())
            } finally {
                activeDownloads.remove(lang)
            }
        }
        activeDownloads[lang] = t

        // resolve ngay - tiến trình tải chạy nền, JS theo dõi qua sự kiện modelDownloadProgress
        // và modelDownloadDone (giống pattern audioLevel/partialText của AudioCapturePlugin).
        call.resolve(JSObject().apply { put("started", true) })
    }

    @PluginMethod
    fun cancelDownload(call: PluginCall) {
        val lang = call.getString("lang")
        val t = activeDownloads[lang]
        if (t != null) {
            t.interrupt()
            activeDownloads.remove(lang)
        }
        call.resolve()
    }

    @PluginMethod
    fun deleteModel(call: PluginCall) {
        val lang = call.getString("lang")
        if (lang.isNullOrBlank()) {
            call.reject("Thiếu tham số lang.")
            return
        }
        modelDir(context, lang).deleteRecursively()
        call.resolve()
    }

    // Bọc downloadWithProgress() bằng vòng lặp thử lại tự động - lỗi mạng thoáng qua (timeout,
    // mất kết nối giữa chừng...) không còn bắt người dùng tự bấm "Tải về" lại thủ công từng lần.
    // File tải dở (tmpZip) được GIỮ LẠI giữa các lần thử (không xoá) để lần thử tiếp theo RESUME
    // tiếp từ chỗ dở dang qua HTTP Range, không tải lại từ đầu - quan trọng nhất với model lớn
    // như en-large (~1.8GB), nơi phải tải lại từ 0% mỗi lần lỗi gần như không thể tải xong nổi
    // trên mạng hay chập chờn.
    private fun downloadWithRetry(urlStr: String, dest: File, onProgress: (Long, Long) -> Unit) {
        var lastError: Exception? = null
        for (attempt in 1..MAX_ATTEMPTS) {
            try {
                downloadWithProgress(urlStr, dest, onProgress)
                return // thành công
            } catch (e: InterruptedException) {
                dest.delete() // user chủ động huỷ (cancelDownload) - dọn luôn, không giữ lại để resume
                throw e
            } catch (e: Exception) {
                lastError = e
                if (attempt < MAX_ATTEMPTS) {
                    // Backoff tăng dần: 2s, 5s, 10s - đủ để mạng chập chờn có thời gian ổn định lại
                    // mà không bắt người dùng chờ quá lâu giữa các lần thử.
                    val backoffMs = when (attempt) { 1 -> 2000L; 2 -> 5000L; else -> 10000L }
                    Thread.sleep(backoffMs)
                    // KHÔNG xoá dest ở đây - giữ lại phần đã tải để lần thử kế resume tiếp.
                }
            }
        }
        dest.delete() // hết lượt thử, dọn file dở dang thật sự bỏ cuộc
        throw lastError ?: IllegalStateException("Tải thất bại không rõ lý do sau $MAX_ATTEMPTS lần thử.")
    }

    private fun downloadWithProgress(urlStr: String, dest: File, onProgress: (Long, Long) -> Unit) {
        // Resume: nếu đã có file tải dở từ lần thử trước (cùng phiên downloadModel(), xem
        // downloadWithRetry()), tiếp tục từ đúng byte đã có bằng header Range - không tải lại
        // từ đầu. Server tĩnh như alphacephei.com/GitHub Releases đều hỗ trợ Range mặc định.
        val alreadyHave = if (dest.exists()) dest.length() else 0L

        val url = URL(urlStr)
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = CONNECT_TIMEOUT_MS
        conn.readTimeout = READ_TIMEOUT_MS
        conn.instanceFollowRedirects = true // GitHub Releases redirect sang S3 - bắt buộc phải theo
        if (alreadyHave > 0) {
            conn.setRequestProperty("Range", "bytes=$alreadyHave-")
        }
        conn.connect()

        val isResuming = alreadyHave > 0 && conn.responseCode == 206
        if (conn.responseCode !in 200..299) {
            throw IllegalStateException("HTTP ${conn.responseCode} khi tải model từ $urlStr")
        }
        // Server không hỗ trợ Range (trả 200 thay vì 206 dù mình có gửi Range) -> nó sẽ gửi lại
        // TOÀN BỘ file từ đầu, nên phải bỏ phần cũ đi để không bị nối rác vào đầu file.
        if (alreadyHave > 0 && !isResuming) {
            dest.delete()
        }

        // totalBytes phải cộng lại phần đã có sẵn khi đang resume, vì Content-Length lúc này
        // chỉ tính phần CÒN LẠI server trả về (theo đúng ngữ nghĩa response 206 Partial Content).
        val remainingBytes = conn.contentLengthLong
        val totalBytes = if (isResuming && remainingBytes > 0) alreadyHave + remainingBytes else remainingBytes
        var downloadedBytes = if (isResuming) alreadyHave else 0L
        var lastEmitAt = 0L

        conn.inputStream.use { input ->
            FileOutputStream(dest, isResuming).use { output -> // append=true khi đang resume
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    if (Thread.currentThread().isInterrupted) throw InterruptedException("Đã huỷ tải model.")
                    val read = input.read(buffer)
                    if (read == -1) break
                    output.write(buffer, 0, read)
                    downloadedBytes += read

                    val now = System.currentTimeMillis()
                    if (now - lastEmitAt >= 300) { // throttle ~3 lần/giây, tránh spam bridge JS
                        onProgress(downloadedBytes, totalBytes)
                        lastEmitAt = now
                    }
                }
            }
        }
        onProgress(downloadedBytes, totalBytes)
    }

    private fun unzip(zipFile: File, targetDir: File) {
        targetDir.deleteRecursively()
        targetDir.mkdirs()

        // Zip gốc tải thẳng từ alphacephei.com bọc mọi thứ trong 1 thư mục cha (vd
        // "vosk-model-en-us-0.22/"), trong khi zip mình tự đóng gói lại (model-vi/ja/ko) thì
        // phẳng, không bọc. Tự phát hiện + bóc lớp đó ra khi giải nén, để catalog dùng được
        // CẢ 2 kiểu zip mà không cần re-zip thủ công từng model.
        val commonPrefix = detectCommonRootPrefix(zipFile)

        ZipInputStream(zipFile.inputStream()).use { zis ->
            var entry: ZipEntry? = zis.nextEntry
            val buffer = ByteArray(64 * 1024)
            while (entry != null) {
                val relativeName = if (commonPrefix != null && entry.name.startsWith(commonPrefix)) {
                    entry.name.substring(commonPrefix.length)
                } else {
                    entry.name
                }
                if (relativeName.isEmpty()) {
                    zis.closeEntry()
                    entry = zis.nextEntry
                    continue
                }

                // Chặn path traversal (zip slip) - phòng trường hợp zip nguồn bị chỉnh sửa độc hại.
                val outFile = File(targetDir, relativeName)
                if (!outFile.canonicalPath.startsWith(targetDir.canonicalPath + File.separator)) {
                    throw SecurityException("Zip entry bất thường: ${entry.name}")
                }
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { out ->
                        var read = zis.read(buffer)
                        while (read != -1) {
                            out.write(buffer, 0, read)
                            read = zis.read(buffer)
                        }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }

    // Đọc qua danh sách tên entry (không giải nén) để tìm xem toàn bộ zip có nằm chung trong
    // đúng 1 thư mục cha hay không. Đọc file zip 2 lần (lần này + lần unzip thật) chấp nhận
    // được vì đây là file cục bộ đã tải xong, không phải đọc lại qua mạng.
    private fun detectCommonRootPrefix(zipFile: File): String? {
        val topLevelDirs = mutableSetOf<String>()
        var hasRootLevelEntry = false
        ZipInputStream(zipFile.inputStream()).use { zis ->
            var entry: ZipEntry? = zis.nextEntry
            while (entry != null) {
                val name = entry.name.trimStart('/')
                val slashIdx = name.indexOf('/')
                if (slashIdx <= 0) {
                    if (name.isNotEmpty()) hasRootLevelEntry = true
                } else {
                    topLevelDirs.add(name.substring(0, slashIdx))
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        return if (!hasRootLevelEntry && topLevelDirs.size == 1) topLevelDirs.first() + "/" else null
    }

    private fun emitProgress(lang: String, downloadedBytes: Long, totalBytes: Long) {
        val data = JSObject()
        data.put("lang", lang)
        data.put("downloadedBytes", downloadedBytes)
        data.put("totalBytes", totalBytes)
        data.put("percent", if (totalBytes > 0) (downloadedBytes * 100 / totalBytes).toInt() else -1)
        notifyListeners("modelDownloadProgress", data)
    }

    private fun emitDone(lang: String, success: Boolean, error: String?) {
        val data = JSObject()
        data.put("lang", lang)
        data.put("success", success)
        if (error != null) data.put("error", error)
        notifyListeners("modelDownloadDone", data)
    }
}
