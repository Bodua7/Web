package com.atun.translator

import android.app.*
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlin.concurrent.thread

// Bắt audio đang phát bởi các app khác trên máy (YouTube, VLC, Netflix...) qua
// AudioPlaybackCaptureConfiguration (Android 10+), KHÔNG đụng vào API/scraping của YouTube.
// Yêu cầu: user đã cấp quyền MediaProjection (xin qua AudioCapturePlugin.requestCapture()).
class AudioCaptureService : Service() {

    companion object {
        const val ACTION_START = "com.atun.translator.action.START_CAPTURE"
        const val ACTION_STOP = "com.atun.translator.action.STOP_CAPTURE"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"
        const val EXTRA_SOURCE_LANG = "sourceLang"

        // Vosk hoạt động tốt nhất ở 16kHz mono PCM16 - hầu hết model Vosk train ở sample rate này.
        const val SAMPLE_RATE = 16000
        private const val CHANNEL_ID = "audio_capture_channel"
        private const val NOTIFICATION_ID = 42
    }

    private var mediaProjection: MediaProjection? = null
    private var audioRecord: AudioRecord? = null
    private var captureThread: Thread? = null
    @Volatile private var isCapturing = false

    // PARTIAL_WAKE_LOCK: chỉ giữ CPU chạy (không giữ màn hình sáng), để vòng lặp đọc
    // AudioRecord + Vosk không bị Doze/App Standby làm chậm/treo khi user tắt màn hình
    // giữa lúc đang nghe. Không giữ SCREEN wakelock vì không cần màn hình sáng liên tục.
    private var wakeLock: PowerManager.WakeLock? = null

    private var voskEngine: VoskEngine? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopCapture()
                stopSelf()
            }
            else -> {
                startForegroundNotification()
                val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                    ?: Activity.RESULT_CANCELED
                val resultData = intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
                val sourceLang = intent?.getStringExtra(EXTRA_SOURCE_LANG) ?: "en"
                if (resultCode == Activity.RESULT_OK && resultData != null) {
                    startCapture(resultCode, resultData, sourceLang)
                } else {
                    AudioCapturePlugin.instance?.emitError("Thiếu dữ liệu quyền MediaProjection.")
                    stopSelf()
                }
            }
        }
        return START_NOT_STICKY
    }

    // Bắt buộc có notification foreground TRƯỚC khi tạo MediaProjection/AudioRecord,
    // nếu không Android 14+ sẽ ném SecurityException (foregroundServiceType=mediaProjection).
    private fun startForegroundNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Bắt âm thanh để dịch", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Đang nghe và dịch phụ đề")
            .setContentText("Ứng dụng đang bắt âm thanh phát ra từ máy để dịch trực tiếp")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun startCapture(resultCode: Int, resultData: Intent, sourceLang: String) {
        acquireWakeLock()

        val projectionManager =
            getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = projectionManager.getMediaProjection(resultCode, resultData)
        mediaProjection = projection

        // Android 14+ yêu cầu đăng ký callback TRƯỚC khi gọi bất kỳ hàm capture nào.
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopCapture()
            }
        }, null)

        val config = android.media.AudioPlaybackCaptureConfiguration.Builder(projection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()

        val audioFormat = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SAMPLE_RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()

        val minBufferSize = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBufferSize <= 0) {
            AudioCapturePlugin.instance?.emitError("Thiết bị không hỗ trợ cấu hình audio 16kHz mono.")
            releaseWakeLock()
            stopSelf()
            return
        }

        val record = try {
            AudioRecord.Builder()
                .setAudioFormat(audioFormat)
                .setBufferSizeInBytes(minBufferSize * 4)
                .setAudioPlaybackCaptureConfig(config)
                .build()
        } catch (e: UnsupportedOperationException) {
            // Xảy ra khi thiết bị/app nguồn chặn capture (allowAudioPlaybackCapture=false)
            // hoặc không có app nào đang phát audio khớp usage MEDIA lúc build().
            AudioCapturePlugin.instance?.emitError(
                "Không bắt được audio hệ thống - có thể app đang phát (vd. YouTube) đã chặn playback capture: " + e.message
            )
            releaseWakeLock()
            stopSelf()
            return
        }

        if (record.state != AudioRecord.STATE_INITIALIZED) {
            AudioCapturePlugin.instance?.emitError("AudioRecord khởi tạo thất bại (state != INITIALIZED).")
            releaseWakeLock()
            stopSelf()
            return
        }

        audioRecord = record
        voskEngine = VoskEngine(
            applicationContext,
            sampleRate = SAMPLE_RATE.toFloat(),
            modelAssetName = VoskEngine.modelAssetForLang(sourceLang)
        ) { event ->
            when (event) {
                is VoskEngine.Event.Partial -> AudioCapturePlugin.instance?.emitPartial(event.text)
                is VoskEngine.Event.Final -> AudioCapturePlugin.instance?.emitFinal(event.text)
                is VoskEngine.Event.ModelReady -> AudioCapturePlugin.instance?.emitModelLoading(true)
                is VoskEngine.Event.Error -> AudioCapturePlugin.instance?.emitError(event.message)
            }
        }
        voskEngine?.init()

        isCapturing = true
        record.startRecording()
        captureThread = thread(name = "AudioCaptureReadLoop") {
            val buffer = ShortArray(minBufferSize / 2)
            // DEBUG: đo biên độ audio thực tế đọc được, bắn lên JS mỗi ~1s, để xác định
            // xem AudioRecord có đang nhận silence (bị app nguồn chặn capture / mute)
            // hay đang nhận audio thật, tách biệt khỏi việc Vosk có nhận diện được câu hay không.
            var lastLevelEmitAt = System.currentTimeMillis()
            var peakSinceLastEmit = 0
            var readCallsSinceLastEmit = 0
            var silentReadsSinceLastEmit = 0
            var badReadsSinceLastEmit = 0 // read() <= 0

            while (isCapturing) {
                val read = record.read(buffer, 0, buffer.size)
                if (read > 0) {
                    voskEngine?.feed(buffer, read)

                    var peak = 0
                    for (i in 0 until read) {
                        val v = kotlin.math.abs(buffer[i].toInt())
                        if (v > peak) peak = v
                    }
                    if (peak > peakSinceLastEmit) peakSinceLastEmit = peak
                    readCallsSinceLastEmit++
                    if (peak < 50) silentReadsSinceLastEmit++ // ngưỡng thấp = coi như im lặng/noise floor
                } else {
                    badReadsSinceLastEmit++
                }

                val now = System.currentTimeMillis()
                if (now - lastLevelEmitAt >= 1000) {
                    AudioCapturePlugin.instance?.emitAudioLevel(
                        peakSinceLastEmit, readCallsSinceLastEmit, silentReadsSinceLastEmit, badReadsSinceLastEmit
                    )
                    lastLevelEmitAt = now
                    peakSinceLastEmit = 0
                    readCallsSinceLastEmit = 0
                    silentReadsSinceLastEmit = 0
                    badReadsSinceLastEmit = 0
                }
            }
        }
    }

    // Giữ vô thời hạn (không set timeout) vì phiên dịch live có thể kéo dài vài giờ - nếu
    // set timeout ngắn (vd 30') sẽ tự hết hạn giữa chừng, gây lại đúng vấn đề WakeLock
    // muốn tránh. An toàn vì: mọi nhánh lỗi trong startCapture(), stopCapture() (được gọi
    // từ ACTION_STOP, MediaProjection.Callback.onStop, VÀ onDestroy) đều gọi releaseWakeLock();
    // nếu process bị OS kill hoàn toàn thì WakeLock cũng tự mất theo, không leak vĩnh viễn.
    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "AtunTranslator:AudioCaptureWakeLock"
        ).apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.let {
            if (it.isHeld) it.release()
        }
        wakeLock = null
    }

    private fun stopCapture() {
        isCapturing = false
        captureThread?.join(500)
        captureThread = null

        audioRecord?.let {
            try { it.stop() } catch (e: Exception) { /* đã stop rồi thì bỏ qua */ }
            it.release()
        }
        audioRecord = null

        voskEngine?.release()
        voskEngine = null

        mediaProjection?.stop()
        mediaProjection = null

        releaseWakeLock()
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }
}
