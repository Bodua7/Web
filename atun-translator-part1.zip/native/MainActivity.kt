package com.atun.translator

import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import com.getcapacitor.BridgeActivity
import com.getcapacitor.BridgeWebViewClient
import java.io.ByteArrayInputStream
import java.io.PrintWriter
import java.io.StringWriter

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installCrashLogger()
        registerPlugin(OverlayWindowPlugin::class.java)
        registerPlugin(AudioCapturePlugin::class.java)
        registerPlugin(ModelManagerPlugin::class.java)
        registerPlugin(MlkitTranslatePlugin::class.java)
        registerPlugin(ExportPlugin::class.java)
        registerPlugin(TtsPlugin::class.java)
        registerPlugin(BrowserLauncherPlugin::class.java)
        registerPlugin(ScreenOrientationPlugin::class.java)
        super.onCreate(savedInstanceState)
        installAdBlockOnMainWebView()
    }

    // Trang chính (www/index.html) nhúng video YouTube qua <iframe id="videoPlayerFrame"> ngay
    // trong CHÍNH WebView của Capacitor Bridge (khác hẳn "Web mini"/BrowserActivity vốn là
    // WebView riêng, tự dựng tay) - trước đây chỉ BrowserActivity có chặn banner/tracker, còn
    // video dịch phát trong app chính thì KHÔNG, nên quảng cáo/tracker trong iframe YouTube vẫn
    // lọt qua bình thường. Giờ bọc thêm 1 lớp WebViewClient kế thừa BridgeWebViewClient (KHÔNG
    // thay hẳn bằng WebViewClient trơn, để không mất hành vi riêng của Capacitor như xử lý
    // scheme capacitor://, đăng ký JS bridge...), chỉ chèn thêm shouldInterceptRequest soi qua
    // AdBlockList y hệt Web mini. Dùng chung 1 "Mã bật/tắt" với Web mini qua BrowserStorage
    // (SharedPreferences chung theo Context toàn app) - bật/tắt ở menu Web mini áp dụng luôn
    // cho cả video dịch, không cần công tắc riêng thứ 2.
    private fun installAdBlockOnMainWebView() {
        val storage = BrowserStorage(applicationContext)
        val webView = bridge.webView
        webView.webViewClient = object : BridgeWebViewClient(bridge) {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                if (storage.isAdBlockEnabled() && AdBlockList.isBlocked(request.url.host)) {
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                return super.shouldInterceptRequest(view, request)
            }
        }
    }

    private fun installCrashLogger() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                val content = "===== CRASH " + java.util.Date().toString() + " =====\n" +
                    "Thread: " + thread.name + "\n" +
                    sw.toString() + "\n"

                // CHỈ ghi qua AppLog (filesDir, có append thật + trim + xem/chia sẻ được qua
                // ExportPlugin trong app) - đã bỏ nhánh ghi thẳng vào Download công khai trước
                // đây vì gọi resolver.insert() không điều kiện mỗi lần crash tạo ra file MỚI
                // "atun_translator_crash_log (1).txt", (2).txt... trên Android 10+ thay vì nối
                // vào 1 file (MediaStore không hỗ trợ ghi đè theo DISPLAY_NAME qua insert()).
                AppLog.append(applicationContext, content)
            } catch (e: Exception) {
                // Nếu chính việc ghi log bị lỗi thì bỏ qua, không được crash thêm lần nữa ở đây
            }
            // Vẫn gọi handler mặc định để hệ thống xử lý crash (đóng app) như bình thường
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }
}
