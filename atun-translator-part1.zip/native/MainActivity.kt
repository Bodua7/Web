package com.atun.translator

import android.os.Bundle
import com.getcapacitor.BridgeActivity
import java.io.PrintWriter
import java.io.StringWriter

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installCrashLogger()
        registerPlugin(OverlayWindowPlugin::class.java)
        registerPlugin(AudioCapturePlugin::class.java)
        registerPlugin(ModelManagerPlugin::class.java)
        registerPlugin(MlkitTranslatePlugin::class.java)
        registerPlugin(ExportPlugin::class.java)
        registerPlugin(TtsPlugin::class.java)
        super.onCreate(savedInstanceState)
    }

    private fun installCrashLogger() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                val content = "===== CRASH " + java.util.Date().toString() + " =====\n" +
                    "Thread: " + thread.name + "\n" +
                    sw.toString() + "\n"

                // CHỈ ghi qua AppLog (filesDir, có append thật + trim + xem/chia sẻ được qua
                // ExportPlugin trong app) - đã bỏ nhánh ghi thẳng vào Download công khai trước
                // đây vì gọi resolver.insert() không điều kiện mỗi lần crash tạo ra file MỚI
                // "atun_translator_crash_log (1).txt", (2).txt... trên Android 10+ thay vì nối
                // vào 1 file (MediaStore không hỗ trợ ghi đè theo DISPLAY_NAME qua insert()).
                AppLog.append(applicationContext, content)
            } catch (e: Exception) {
                // Nếu chính việc ghi log bị lỗi thì bỏ qua, không được crash thêm lần nữa ở đây
            }
            // Vẫn gọi handler mặc định để hệ thống xử lý crash (đóng app) như bình thường
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }
}
