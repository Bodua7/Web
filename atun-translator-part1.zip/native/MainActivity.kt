package com.atun.translator

import android.content.ContentValues
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import com.getcapacitor.BridgeActivity
import java.io.PrintWriter
import java.io.StringWriter

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installCrashLogger()
        registerPlugin(OverlayWindowPlugin::class.java)
        registerPlugin(AudioCapturePlugin::class.java)
        super.onCreate(savedInstanceState)
    }

    private fun installCrashLogger() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                val content = "===== CRASH " + java.util.Date().toString() + " =====\n" +
                    "Thread: " + thread.name + "\n" +
                    sw.toString() + "\n"

                writeToDownloads(content)
            } catch (e: Exception) {
                // Nếu chính việc ghi log bị lỗi thì bỏ qua, không được crash thêm lần nữa ở đây
            }
            // Vẫn gọi handler mặc định để hệ thống xử lý crash (đóng app) như bình thường
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }

    private fun writeToDownloads(content: String) {
        val fileName = "atun_translator_crash_log.txt"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android 10+: dùng MediaStore để ghi vào thư mục Download công khai,
            // không cần xin quyền, xem được ngay bằng My Files > Download
            val resolver = contentResolver
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/")
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                resolver.openOutputStream(uri)?.use { out ->
                    out.write(content.toByteArray())
                }
            }
        } else {
            // Android 9 trở xuống: ghi file trực tiếp
            val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(
                android.os.Environment.DIRECTORY_DOWNLOADS
            )
            val file = java.io.File(downloadsDir, fileName)
            file.appendText(content)
        }
    }
}
