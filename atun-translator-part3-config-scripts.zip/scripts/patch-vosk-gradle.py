import re

# Thêm dependency vosk-android + jna vào android/app/build.gradle,
# và maven repo của Alphacephei (nơi host artifact Vosk) vào repositories.

VOSK_VERSION = "0.3.70"

app_path = "android/app/build.gradle"
with open(app_path, "r", encoding="utf-8") as f:
    content = f.read()

changed = False

if "com.alphacephei" not in content:
    content = re.sub(
        r"dependencies\s*\{",
        "dependencies {\n"
        "    implementation \"com.alphacephei:vosk-android:" + VOSK_VERSION + "\"\n"
        "    implementation \"net.java.dev.jna:jna:5.13.0@aar\"",
        content,
        count=1,
    )
    changed = True
    print("OK: da them dependency vosk-android + jna vao android/app/build.gradle")

# Vosk dung .so native (JNI) -> can pickFirst de tranh loi trung file .so khi merge
if "pickFirst" not in content:
    content = re.sub(
        r"android\s*\{",
        "android {\n"
        "    packagingOptions {\n"
        "        pickFirst 'lib/*/libc++_shared.so'\n"
        "        pickFirst 'lib/*/libjnidispatch.so'\n"
        "    }",
        content,
        count=1,
    )
    changed = True
    print("OK: da them packagingOptions pickFirst vao android/app/build.gradle")

if changed:
    with open(app_path, "w", encoding="utf-8") as f:
        f.write(content)
else:
    print("SKIP: vosk-android da co san")

# Repo Alphacephei host artifact Vosk - can them vao settings.gradle (repo Gradle 7+)
# hoac android/build.gradle (repo Gradle cu), tuy template Capacitor dang dung.
for repo_path in ["settings.gradle", "android/build.gradle"]:
    try:
        with open(repo_path, "r", encoding="utf-8") as f:
            repo_content = f.read()
    except FileNotFoundError:
        continue

    if "alphacephei" in repo_content:
        continue
    if "mavenCentral()" in repo_content:
        repo_content = repo_content.replace(
            "mavenCentral()",
            "mavenCentral()\n        maven { url 'https://alphacephei.com/maven/' }",
            1,
        )
        with open(repo_path, "w", encoding="utf-8") as f:
            f.write(repo_content)
        print(f"OK: da them maven repo alphacephei vao {repo_path}")
        break

print("=== Xong patch Vosk gradle ===")
