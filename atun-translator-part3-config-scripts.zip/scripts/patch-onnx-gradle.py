import os
import re

# Thêm dependency ONNX Runtime Android (chạy model LID thật, xem native/LidEngine.kt) vào
# android/app/build.gradle. Dùng mavenCentral() có sẵn (project đã dùng repo này cho các
# dependency Capacitor khác) - không cần thêm maven repo riêng như Vosk (alphacephei.com).
#
# CHƯA build-test được trên máy Android thật (chỉ build qua GitHub Actions CI) - xem ghi chú
# rủi ro trong native/VadDetector.kt/LidEngine.kt. Version 1.27.0 là bản ổn định mới nhất trên
# Maven Central tại thời điểm viết script này (kiểm tra lại tại
# https://central.sonatype.com/artifact/com.microsoft.onnxruntime/onnxruntime-android nếu build
# báo lỗi "could not find artifact").

ONNXRUNTIME_VERSION = "1.27.0"
ONNXRUNTIME_MIN_SDK = 24  # onnxruntime-android 1.27.0 khai báo uses-sdk:minSdkVersion=24 trong
                          # AndroidManifest.xml của chính nó - Android Gradle Plugin BẮT BUỘC
                          # minSdkVersion của app phải >= minSdkVersion của MỌI thư viện phụ
                          # thuộc, nếu không manifest merger sẽ FAIL build (lỗi "uses-sdk:
                          # minSdkVersion 22 cannot be smaller than version 24 declared in
                          # library"). Vì vậy phải tự nâng minSdkVersion của app lên >= 24 ngay
                          # khi thêm dependency này - không thể chỉ thêm dependency suông.

app_path = "android/app/build.gradle"
with open(app_path, "r", encoding="utf-8") as f:
    content = f.read()

if "com.microsoft.onnxruntime" not in content:
    content = re.sub(
        r"dependencies\s*\{",
        "dependencies {\n"
        "    implementation \"com.microsoft.onnxruntime:onnxruntime-android:" + ONNXRUNTIME_VERSION + "\"",
        content,
        count=1,
    )
    with open(app_path, "w", encoding="utf-8") as f:
        f.write(content)
    print("OK: da them dependency onnxruntime-android vao android/app/build.gradle")
else:
    print("SKIP: onnxruntime-android da co san")

# ===== Nâng minSdkVersion trong android/variables.gradle (file Capacitor tự sinh khi chạy
# `npx cap add android`, mặc định minSdkVersion=22) - CHỈ nâng lên nếu đang thấp hơn yêu cầu,
# không hạ xuống nếu ai đó đã set cao hơn từ trước (vd 26 vì lý do khác) - tránh patch này vô
# tình ghi đè quyết định minSdk khác đã có chủ đích. =====
variables_path = "android/variables.gradle"
if os.path.exists(variables_path):
    with open(variables_path, "r", encoding="utf-8") as f:
        vcontent = f.read()
    match = re.search(r"minSdkVersion\s*=\s*(\d+)", vcontent)
    if match:
        current_min_sdk = int(match.group(1))
        if current_min_sdk < ONNXRUNTIME_MIN_SDK:
            vcontent = re.sub(
                r"minSdkVersion\s*=\s*\d+",
                f"minSdkVersion = {ONNXRUNTIME_MIN_SDK}",
                vcontent,
                count=1,
            )
            with open(variables_path, "w", encoding="utf-8") as f:
                f.write(vcontent)
            print(f"OK: da nang minSdkVersion {current_min_sdk} -> {ONNXRUNTIME_MIN_SDK} "
                  f"(onnxruntime-android yeu cau toi thieu {ONNXRUNTIME_MIN_SDK})")
        else:
            print(f"SKIP: minSdkVersion da la {current_min_sdk}, khong can nang them")
    else:
        print("WARNING: khong tim thay dong 'minSdkVersion = <so>' trong "
              "android/variables.gradle - kiem tra thu cong, build co the van fail o buoc "
              "processDebugManifest neu minSdk hien tai < " + str(ONNXRUNTIME_MIN_SDK))
else:
    print("WARNING: khong tim thay android/variables.gradle (bat thuong sau `npx cap add "
          "android`) - kiem tra thu cong, build co the fail o buoc processDebugManifest")

print("=== Xong patch ONNX Runtime gradle ===")
