import re

# Thêm dependency ONNX Runtime Android (chạy model LID thật, xem native/LidEngine.kt) vào
# android/app/build.gradle. Dùng mavenCentral() có sẵn (project đã dùng repo này cho các
# dependency Capacitor khác) - không cần thêm maven repo riêng như Vosk (alphacephei.com).
#
# CHƯA build-test được trên máy Android thật (chỉ build qua GitHub Actions CI) - xem ghi chú
# rủi ro trong native/VadDetector.kt/LidEngine.kt. Version 1.27.0 là bản ổn định mới nhất trên
# Maven Central tại thời điểm viết script này (kiểm tra lại tại
# https://central.sonatype.com/artifact/com.microsoft.onnxruntime/onnxruntime-android nếu build
# báo lỗi "could not find artifact").

ONNXRUNTIME_VERSION = "1.27.0"

app_path = "android/app/build.gradle"
with open(app_path, "r", encoding="utf-8") as f:
    content = f.read()

if "com.microsoft.onnxruntime" not in content:
    content = re.sub(
        r"dependencies\s*\{",
        "dependencies {\n"
        "    implementation \"com.microsoft.onnxruntime:onnxruntime-android:" + ONNXRUNTIME_VERSION + "\"",
        content,
        count=1,
    )
    with open(app_path, "w", encoding="utf-8") as f:
        f.write(content)
    print("OK: da them dependency onnxruntime-android vao android/app/build.gradle")
else:
    print("SKIP: onnxruntime-android da co san")

print("=== Xong patch ONNX Runtime gradle ===")
