import re

KOTLIN_VERSION = "1.9.24"

# 1) Patch project-level build.gradle: add Kotlin Gradle Plugin classpath
proj_path = "android/build.gradle"
with open(proj_path, "r", encoding="utf-8") as f:
    content = f.read()

if "kotlin-gradle-plugin" not in content:
    match = re.search(r"buildscript\s*\{.*?dependencies\s*\{", content, re.DOTALL)
    if match:
        insert_pos = match.end()
        classpath_line = (
            "\n        classpath 'org.jetbrains.kotlin:kotlin-gradle-plugin:"
            + KOTLIN_VERSION + "'"
        )
        content = content[:insert_pos] + classpath_line + content[insert_pos:]
        with open(proj_path, "w", encoding="utf-8") as f:
            f.write(content)
        print("OK: da them Kotlin Gradle Plugin classpath vao android/build.gradle")
    else:
        raise SystemExit("FAIL: khong tim thay buildscript{ dependencies{ } } trong android/build.gradle")
else:
    print("SKIP: Kotlin plugin classpath da co san trong android/build.gradle")

# 2) Patch app-level build.gradle: apply kotlin-android plugin + add kotlin-stdlib
app_path = "android/app/build.gradle"
with open(app_path, "r", encoding="utf-8") as f:
    app_content = f.read()

changed = False

if "kotlin-android" not in app_content:
    app_content = app_content.replace(
        "apply plugin: 'com.android.application'",
        "apply plugin: 'com.android.application'\napply plugin: 'kotlin-android'",
        1
    )
    changed = True
    print("OK: da them apply plugin 'kotlin-android' vao android/app/build.gradle")

if "kotlin-stdlib" not in app_content:
    app_content = re.sub(
        r"dependencies\s*\{",
        "dependencies {\n    implementation \"org.jetbrains.kotlin:kotlin-stdlib:" + KOTLIN_VERSION + "\"",
        app_content,
        count=1
    )
    changed = True
    print("OK: da them dependency kotlin-stdlib vao android/app/build.gradle")

if changed:
    with open(app_path, "w", encoding="utf-8") as f:
        f.write(app_content)
else:
    print("SKIP: android/app/build.gradle da co san Kotlin support")

print("=== Xong patch Kotlin support ===")
