import os
import re

path = "android/app/src/main/AndroidManifest.xml"
with open(path, "r", encoding="utf-8") as f:
    content = f.read()

permissions = [
    # SYSTEM_ALERT_WINDOW: đã gỡ (dọn code chết) - từng cần cho OverlayWindowPlugin/OverlayView
    # (chữ nổi đè app khác), nhưng tính năng đó đã bị thay hoàn toàn bằng phụ đề trong app
    # (#inVideoCaption ở www/index.html) từ lâu, 2 file plugin đó đã xoá khỏi native/. Xin thừa
    # quyền nhạy cảm này không có lợi gì, chỉ khiến Play Store review khó hơn không cần thiết.
    '<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />',
    '<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION" />',
    '<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE" />',
    '<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
    '<uses-permission android:name="android.permission.RECORD_AUDIO" />',
    '<uses-permission android:name="android.permission.WAKE_LOCK" />',
    # INTERNET: KHÔNG khai báo lại ở đây - template mặc định của `npx cap add android` đã tự
    # thêm sẵn permission này rồi, khai báo trùng chỉ gây warning "duplicated with element
    # declared at AndroidManifest.xml:10" khi build (không phải lỗi, nhưng dọn cho log sạch).
    # Nâng cấp "ổn định chạy nền dài": cho phép xin miễn trừ tối ưu pin, tránh OEM
    # (Xiaomi/Oppo/Samsung...) tự kill AudioCaptureService giữa phiên nghe dài.
    '<uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />',
    # Chỉ cần cho tính năng tải file trong "web mini" (BrowserActivity) trên Android 9 trở
    # xuống - từ Android 10 (API 29+) DownloadManager ghi vào thư mục Downloads công khai qua
    # scoped storage, không cần quyền này nữa nên giới hạn maxSdkVersion=28 để khỏi hiện dialog
    # xin quyền thừa trên máy mới.
    '<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />',
]

# Insert permissions right after <manifest ...> opening tag
if 'FOREGROUND_SERVICE_MEDIA_PROJECTION' not in content:
    manifest_tag_end = content.index(">", content.index("<manifest")) + 1
    perm_block = "\n    " + "\n    ".join(permissions)
    content = content[:manifest_tag_end] + perm_block + content[manifest_tag_end:]

# largeHeap="true": phòng hờ chung cho model Vosk khi load vào RAM (Model()/Recognizer() native
# qua JNI, xem VoskEngine.kt) cộng thêm WebView + ML Kit Translate đang chạy sẵn - dù model lớn
# nhất trong catalog hiện tại chỉ ~128MB ("en"), heap mặc định (thường 192-256MB trên máy tầm
# trung) vẫn có thể bị hệ thống diệt đột ngột giữa chừng (OOM) trên máy RAM thấp. largeHeap chỉ
# nới trần heap của Dalvik/ART (phần app tự cấp phát bằng Kotlin/Java), KHÔNG nới được bộ nhớ
# native mà JNI Vosk dùng trực tiếp -> không đảm bảo hết bị kill hẳn trên máy RAM quá thấp,
# nhưng giảm khả năng bị kill vì phần lớn hơn (WebView, ML Kit, code Kotlin còn lại) có thêm chỗ
# thở.
if 'android:largeHeap' not in content:
    app_tag_start = content.index("<application")
    app_tag_end = content.index(">", app_tag_start)
    content = content[:app_tag_end] + '\n        android:largeHeap="true"' + content[app_tag_end:]

# Insert service declaration inside <application>...</application>, before closing tag.
# Chỉ còn AudioCaptureService - ForegroundService.kt đã bị xoá (dead code, không nơi
# nào start nó; AudioCaptureService đã tự làm foreground notification riêng, đúng
# foregroundServiceType=mediaProjection theo yêu cầu Android 14+).
service_block = '''
    <service
        android:name=".AudioCaptureService"
        android:foregroundServiceType="mediaProjection|microphone"
        android:exported="false" />
'''
if 'AudioCaptureService' not in content:
    app_close_idx = content.rindex("</application>")
    content = content[:app_close_idx] + service_block + content[app_close_idx:]

# BrowserActivity ("web mini") - Activity RIÊNG tách biệt khỏi MainActivity (BridgeActivity),
# tự dựng UI bằng code (không cần layout .xml). Theme AppTheme.NoActionBar (không phải
# AppTheme.NoActionBarLaunch) vì đó là theme launch có ảnh splash - không cần cho màn hình
# phụ này, tránh chớp ảnh splash mỗi lần mở. Cả 2 theme này do template `npx cap add android`
# mặc định sinh sẵn trong styles.xml, không cần tạo thêm resource nào.
browser_activity_block = '''
    <activity
        android:name=".BrowserActivity"
        android:exported="false"
        android:label="Web mini"
        android:theme="@style/AppTheme.NoActionBar"
        android:configChanges="orientation|screenSize|keyboardHidden" />
'''
if 'BrowserActivity' not in content:
    app_close_idx = content.rindex("</application>")
    content = content[:app_close_idx] + browser_activity_block + content[app_close_idx:]

# FileProvider cho ExportPlugin (xuất/chia sẻ nhật ký dịch .srt/.txt qua Share Sheet) -
# bắt buộc phải khai báo <provider> vì Android 7+ chặn Uri file:// trần trong ACTION_SEND
# (FileUriExposedException), phải đi qua content:// do FileProvider cấp.
provider_block = '''
    <provider
        android:name="androidx.core.content.FileProvider"
        android:authorities="${applicationId}.fileprovider"
        android:exported="false"
        android:grantUriPermissions="true">
        <meta-data
            android:name="android.support.FILE_PROVIDER_PATHS"
            android:resource="@xml/file_paths" />
    </provider>
'''
if 'FileProvider' not in content:
    app_close_idx = content.rindex("</application>")
    content = content[:app_close_idx] + provider_block + content[app_close_idx:]

with open(path, "w", encoding="utf-8") as f:
    f.write(content)

# res/xml/file_paths.xml khai báo thư mục cache/exports/ mà ExportPlugin.shareFile() ghi
# file vào, để FileProvider được phép cấp Uri cho đúng thư mục đó (không cấp toàn bộ app).
xml_dir = "android/app/src/main/res/xml"
os.makedirs(xml_dir, exist_ok=True)
file_paths_content = '''<?xml version="1.0" encoding="utf-8"?>
<paths>
    <cache-path name="exports" path="exports/" />
</paths>
'''
with open(f"{xml_dir}/file_paths.xml", "w", encoding="utf-8") as f:
    f.write(file_paths_content)

print("Manifest patched OK (+ FileProvider + file_paths.xml)")
