import re

# Thêm dependency ML Kit Translate (dịch on-device, không rate-limit, hoạt động offline sau
# khi tải model 1 lần) vào android/app/build.gradle. Không cần thêm maven repo riêng - ML Kit
# nằm trên Google's Maven repo, template Capacitor mặc định đã có sẵn google() trong
# repositories.

MLKIT_TRANSLATE_VERSION = "17.0.3"

app_path = "android/app/build.gradle"
with open(app_path, "r", encoding="utf-8") as f:
    content = f.read()

if "com.google.mlkit:translate" not in content:
    content = re.sub(
        r"dependencies\s*\{",
        "dependencies {\n"
        "    implementation \"com.google.mlkit:translate:" + MLKIT_TRANSLATE_VERSION + "\"",
        content,
        count=1,
    )
    with open(app_path, "w", encoding="utf-8") as f:
        f.write(content)
    print("OK: da them dependency com.google.mlkit:translate vao android/app/build.gradle")
else:
    print("SKIP: mlkit translate da co san")

print("=== Xong patch ML Kit Translate gradle ===")
