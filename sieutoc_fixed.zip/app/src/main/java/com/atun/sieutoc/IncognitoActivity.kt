package com.atun.sieutoc

import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.WebView
import android.widget.Toast

// Trình duyệt "ẩn danh" - chạy ở process Android RIÊNG BIỆT so với MainActivity
// (khai báo android:process=":incognito" trong AndroidManifest.xml).
//
// Vì sao phải tách process: Android CookieManager/WebStorage là singleton dùng chung cho CẢ
// process, không có cách nào cô lập cookie/localStorage riêng cho từng WebView trong CÙNG 1
// process. Bản trước app cố mô phỏng "ẩn danh" bằng cách bật/tắt cờ global mỗi khi tạo tab
// (setAcceptCookie(!incognito)) và xoá sạch cookie/storage global mỗi khi đóng 1 tab ẩn danh -
// cả 2 việc này đều đụng luôn tới tab THƯỜNG đang mở (bug: tự dưng bị đăng xuất, mất dữ liệu).
//
// Cách sửa tận gốc: cho toàn bộ tab ẩn danh chạy ở 1 process khác, với thư mục dữ liệu WebView
// (setDataDirectorySuffix) khác hẳn process của MainActivity. Nhờ vậy CookieManager/WebStorage
// trong process này là 1 kho HOÀN TOÀN riêng - gọi "xoá sạch" ở đây không còn đụng gì tới
// MainActivity nữa.
class IncognitoActivity : BrowserActivity() {

    override val isIncognitoActivity: Boolean = true

    // true nếu máy hỗ trợ cô lập thư mục dữ liệu WebView theo process (cần Android 9 / API 28
    // trở lên - WebView.setDataDirectorySuffix chỉ có từ phiên bản này). Dưới mức này, phiên ẩn
    // danh vẫn chạy ở process riêng (theo Manifest) nhưng KHÔNG có gì đảm bảo cookie/storage
    // tách biệt hoàn toàn khỏi tab thường - báo thẳng cho người dùng biết thay vì âm thầm nhận
    // vơ là "an toàn tuyệt đối" trong khi thực chất không phải vậy trên máy cũ.
    private var dataDirIsolated = false

    override fun onCreate(savedInstanceState: Bundle?) {
        // BẮT BUỘC phải gọi TRƯỚC khi bất kỳ WebView nào được tạo trong process này (kể cả các
        // WebView được tạo bên trong super.onCreate() ngay dưới đây, qua restoreSession()) -
        // theo đúng yêu cầu của tài liệu Android cho setDataDirectorySuffix. Vì vậy đặt là dòng
        // đầu tiên, trước cả super.onCreate().
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                WebView.setDataDirectorySuffix("incognito")
                dataDirIsolated = true
            } catch (e: IllegalStateException) {
                // Rất hiếm khi xảy ra: có gì đó trong process đã khởi tạo WebView trước lúc này.
                // Đành chấp nhận chạy KHÔNG cô lập, còn hơn để app crash ngay khi mở ẩn danh.
                dataDirIsolated = false
            }
        }

        super.onCreate(savedInstanceState)

        // Chặn chụp màn hình / xem trước trong danh sách "app gần đây" cho đúng tinh thần ẩn danh -
        // nội dung trang ẩn danh không nên lộ ra ở những chỗ đó.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        title = "🕶 Ẩn danh"

        if (!dataDirIsolated) {
            Toast.makeText(
                this,
                "Máy này không hỗ trợ cô lập ẩn danh hoàn toàn (cần Android 9 trở lên). Đang dùng chế độ ẩn danh cơ bản.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    // Luôn bắt đầu 1 tab trắng mới hoàn toàn - không lưu, không khôi phục bất kỳ URL nào của
    // phiên ẩn danh (persistSession() dùng nguyên bản mặc định "không làm gì" của lớp cha).
    override fun restoreSession() {
        addTab(homeUrl)
    }

    override fun onNewTabButtonClicked() {
        addTab(homeUrl)
    }

    // Ở màn ẩn danh, bấm thẳng nút này = đóng phiên luôn cho nhanh tay (giống mục trong menu)
    override fun onIncognitoButtonClicked() {
        onCloseIncognitoSessionRequested()
    }

    override fun onCloseIncognitoSessionRequested() {
        Toast.makeText(this, "Đã đóng phiên ẩn danh", Toast.LENGTH_SHORT).show()
        finishAndRemoveTask()
    }

    override fun onDestroy() {
        // Xoá sạch cookie + localStorage/IndexedDB của phiên ẩn danh. Gọi "xoá toàn bộ" ở đây AN
        // TOÀN vì process này (nhờ setDataDirectorySuffix ở trên) có thư mục dữ liệu WebView
        // RIÊNG BIỆT hoàn toàn với process của MainActivity - không còn đụng tới cookie/storage
        // của tab thường như bug cũ nữa.
        try {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
            WebStorage.getInstance().deleteAllData()
        } catch (e: Exception) {
            // Process sắp bị hệ thống dọn, không để lỗi dọn dẹp phụ làm crash thêm
        }
        super.onDestroy()
    }
}
