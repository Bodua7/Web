package com.atun.sieutoc

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder

/**
 * Foreground service "rỗng" (không tự chứa logic phát nhạc) - nhiệm vụ duy nhất là báo cho
 * Android biết app đang có việc quan trọng phải làm (phát audio/video), để hệ thống KHÔNG tạm
 * dừng WebView khi màn hình tắt hoặc người dùng chuyển sang app khác.
 *
 * BrowserActivity tự start service này khi có tab bắt đầu phát audio/video (xem
 * refreshMediaFocusState) và stop khi không còn tab nào phát - vòng đời gắn chặt với trạng thái
 * phát thực tế, không tồn tại dư thừa lúc không cần.
 */
class MediaPlaybackService : Service() {

    companion object {
        private const val CHANNEL_ID = "sieutoc_media_playback"
        private const val NOTIFICATION_ID = 1001
    }

    override fun onCreate() {
        super.onCreate()
        createChannelIfNeeded()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification())
        // START_STICKY: nếu hệ thống buộc phải giết process do thiếu bộ nhớ, cố khởi động lại
        // service (không phục hồi lại trạng thái phát, chỉ tránh việc service biến mất âm thầm)
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannelIfNeeded() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) != null) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Đang phát trong nền",
            NotificationManager.IMPORTANCE_LOW // im lặng, không rung/kêu - chỉ hiện thông báo
        ).apply {
            description = "Hiện khi Siêu Tốc đang phát video/audio để không bị hệ thống tạm dừng"
        }
        nm.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val openAppIntent = packageManager.getLaunchIntentForPackage(packageName)
        val contentIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID).apply {
            setContentTitle("Siêu Tốc đang phát")
            setContentText("Chạm để quay lại")
            setSmallIcon(android.R.drawable.ic_media_play)
            setContentIntent(contentIntent)
            setOngoing(true)
            setOnlyAlertOnce(true)
        }.build()
    }
}
