package com.atun.sieutoc

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Message
import android.os.PowerManager
import android.util.Patterns
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.ByteArrayInputStream

// Lớp cha chứa TOÀN BỘ logic duyệt web dùng chung: quản lý tab, tạo/cấu hình WebView, chặn
// quảng cáo, AudioFocus/wake lock, dịch trang, cài đặt, xoá dữ liệu duyệt web...
//
// MainActivity (tab thường) và IncognitoActivity (tab ẩn danh) đều kế thừa lớp này. Quan trọng:
// mỗi Activity con chạy CỐ ĐỊNH 1 loại tab (thường HOẶC ẩn danh), không còn trộn lẫn 2 loại
// trong cùng 1 danh sách tab như bản trước - nhờ vậy bỏ hẳn được field "isIncognito" riêng lẻ
// trên từng Tab, và IncognitoActivity có thể chạy ở 1 process Android riêng
// (xem AndroidManifest.xml: android:process=":incognito") với thư mục dữ liệu WebView
// (cookie/localStorage/cache) TÁCH BIỆT HOÀN TOÀN khỏi MainActivity - sửa tận gốc lỗi cookie
// dùng chung toàn app trước đây.
abstract class BrowserActivity : AppCompatActivity() {

    // ---- Model 1 tab ----
    // "protected" (không phải "private") vì kiểu Tab xuất hiện trong kiểu của "tabs" bên dưới,
    // mà "tabs" cần protected để MainActivity đọc được (vd lúc lưu lại danh sách URL).
    protected class Tab(
        val webView: WebView,
        var title: String = "Tab mới",
        // Tab được mở ra từ 1 popup (window.open/target=_blank) chứ không phải người dùng bấm "+".
        // Dùng để: nếu nội dung đầu tiên load vào tab này bị chặn (quảng cáo/tracker) thì tự đóng
        // luôn tab, tránh để lại 1 tab trắng vô dụng.
        var isPopup: Boolean = false,
        var popupFirstLoadChecked: Boolean = false,
        var jsDialogCount: Int = 0,
        // Tab này hiện có <video>/<audio> đang phát hay không. Gắn theo từng tab (thay vì chỉ
        // đếm tổng toàn app) để khi đóng tab biết chính xác cần trừ AudioFocus/wake lock của
        // đúng tab đó, tránh bị "kẹt" giữ tài nguyên nếu tab bị destroy() trước khi kịp bắn
        // sự kiện pause/ended về.
        var hasPlayingMedia: Boolean = false
    )

    // Activity con này có phải là phiên ẩn danh hay không - cố định theo từng lớp con
    // (MainActivity luôn false, IncognitoActivity luôn true).
    protected abstract val isIncognitoActivity: Boolean

    protected lateinit var webViewContainer: FrameLayout
    protected lateinit var rootUiLayout: View
    private lateinit var fullscreenContainer: FrameLayout
    private lateinit var tabsLayout: LinearLayout
    protected lateinit var addressBar: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var btnBookmark: ImageButton
    private lateinit var btnIncognito: ImageButton
    protected lateinit var prefs: SharedPreferences

    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

    private val blockedHosts: MutableSet<String> = mutableSetOf()
    protected val tabs = mutableListOf<Tab>()
    private val tabViews = mutableListOf<View>() // view tương ứng trên thanh tab
    private var currentTabIndex = -1
    // Mốc thời gian popup gần nhất được mở (để chặn popup "ăn theo" bắn liên tiếp - xem onCreateWindow)
    private var lastPopupOpenedAt = 0L

    protected val homeUrl = "https://www.google.com/"
    protected val currentTab: Tab? get() = tabs.getOrNull(currentTabIndex)

    // ---- Nhật ký console (để tự chẩn đoán lỗi trên điện thoại, không cần máy tính) ----
    private val consoleLogLines = ArrayDeque<String>()
    private val consoleLogCap = 400

    private fun appendConsoleLog(line: String) {
        consoleLogLines.addLast(line)
        while (consoleLogLines.size > consoleLogCap) consoleLogLines.removeFirst()
    }

    private fun showConsoleLogDialog() {
        val text = if (consoleLogLines.isEmpty()) {
            "(Chưa có log nào - hãy thử phát lại video rồi mở lại mục này)"
        } else {
            consoleLogLines.joinToString("\n\n")
        }
        val scrollView = android.widget.ScrollView(this)
        val textView = TextView(this).apply {
            setText(text)
            setTextIsSelectable(true)
            setPadding(32, 24, 32, 24)
            textSize = 12f
        }
        scrollView.addView(textView)

        AlertDialog.Builder(this)
            .setTitle("Nhật ký console (${consoleLogLines.size} dòng)")
            .setView(scrollView)
            .setPositiveButton("Sao chép toàn bộ") { _, _ ->
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("SieuToc console log", text))
                Toast.makeText(this, "Đã sao chép log - dán vào đâu cũng được", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Xoá log") { _, _ -> consoleLogLines.clear() }
            .setNegativeButton("Đóng", null)
            .show()
    }

    // ---- Wake lock để không tắt màn hình khi đang phát video/audio ----
    private lateinit var audioManager: AudioManager
    private var mediaWakeLock: PowerManager.WakeLock? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Chỉ bật ở bản debug (không bao giờ bật ở bản release cài cho người dùng thật - mở cổng
        // debug ra ngoài là 1 rủi ro bảo mật). Bật xong, cắm điện thoại vào máy tính (bật "Gỡ lỗi
        // qua USB" trong Cài đặt nhà phát triển của điện thoại), mở Chrome trên máy tính vào địa
        // chỉ chrome://inspect, sẽ thấy đúng WebView của app hiện ra ở đó -> bấm "inspect" để xem
        // thẳng lỗi Console/Network thật sự xảy ra khi phát video, thay vì phải đoán tiếp.
        if (BuildConfig.DEBUG) {
            WebView.setWebContentsDebuggingEnabled(true)
        }

        prefs = getSharedPreferences("sieutoc_prefs", MODE_PRIVATE)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        // Dòng đánh dấu phiên bản - mở là thấy ngay, không cần chờ lỗi xảy ra mới biết APK
        // đang cài có phải bản build mới nhất hay không (tránh mất công đoán do cache/build cũ)
        appendConsoleLog("[app] Khởi động SieuToc - bản vá media error log + chặn QC mở rộng + phát nền khi tắt màn hình (build ${BuildConfig.VERSION_NAME}.${BuildConfig.VERSION_CODE})")

        webViewContainer = findViewById(R.id.webViewContainer)
        rootUiLayout = findViewById(R.id.rootUiLayout)
        fullscreenContainer = findViewById(R.id.fullscreenContainer)
        tabsLayout = findViewById(R.id.tabsLayout)
        addressBar = findViewById(R.id.addressBar)
        progressBar = findViewById(R.id.progressBar)
        btnBookmark = findViewById(R.id.btnBookmark)
        btnIncognito = findViewById(R.id.btnIncognito)

        loadBlocklist()
        setupToolbar()
        restoreSession()
    }

    // Mỗi Activity con tự quyết định phiên làm việc bắt đầu thế nào: MainActivity nạp lại các
    // tab đã lưu từ lần trước; IncognitoActivity LUÔN bắt đầu 1 tab trắng mới, không khôi phục
    // gì cả.
    protected abstract fun restoreSession()

    // Lưu danh sách URL hiện tại để khôi phục lần mở sau. Mặc định KHÔNG làm gì (an toàn) -
    // chỉ MainActivity override để thật sự ghi ra đĩa. IncognitoActivity cố tình không override,
    // tránh vô tình ghi URL đã duyệt ẩn danh ra SharedPreferences.
    protected open fun persistSession() { }

    private fun loadBlocklist() {
        try {
            assets.open("blocklist.txt").bufferedReader().useLines { lines ->
                lines.forEach { line ->
                    val host = line.trim()
                    if (host.isNotEmpty() && !host.startsWith("#")) {
                        blockedHosts.add(host.lowercase())
                    }
                }
            }
        } catch (e: Exception) {
            // Không có blocklist thì vẫn chạy bình thường
        }
    }

    private fun isBlocked(url: String): Boolean {
        if (!isTrackerBlockEnabled()) return false
        val uri = try {
            Uri.parse(url)
        } catch (e: Exception) {
            return false
        }
        val host = uri.host?.lowercase() ?: return false

        return blockedHosts.any { blocked ->
            val slash = blocked.indexOf('/')
            if (slash < 0) {
                // Domain thường: chặn domain đó và mọi subdomain
                host == blocked || host.endsWith(".$blocked")
            } else {
                // Entry có path (vd "facebook.com/tr"): phải khớp cả host lẫn tiền tố path
                val blockedHost = blocked.substring(0, slash)
                val blockedPath = blocked.substring(slash)
                (host == blockedHost || host.endsWith(".$blockedHost")) &&
                    (uri.path ?: "").startsWith(blockedPath)
            }
        }
    }

    protected fun isJsEnabled(): Boolean = prefs.getBoolean("pref_js_enabled", true)
    protected fun isTrackerBlockEnabled(): Boolean = prefs.getBoolean("pref_block_tracker", true)

    // ---------------- Quản lý tab ----------------

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(): WebView {
        val incognito = isIncognitoActivity
        val webView = WebView(this)
        webView.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )

        val settings = webView.settings
        settings.javaScriptEnabled = isJsEnabled()
        settings.domStorageEnabled = !incognito // ẩn danh: không lưu localStorage
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.setSupportZoom(true)
        // KHÔNG bật builtInZoomControls: pinch-zoom vẫn chạy đầy đủ chỉ với setSupportZoom(true),
        // còn builtInZoomControls chỉ thêm lớp overlay nút +/- cũ (ZoomButtonsController) - lớp này
        // là 1 popup window ngoài WebView, dễ xung đột khi tab bị ẩn lúc chuyển tab hoặc vào/thoát
        // fullscreen video (tham chiếu tới view đã gỡ khỏi cây view) => bỏ hẳn cho an toàn
        settings.builtInZoomControls = false
        settings.displayZoomControls = false
        settings.cacheMode = if (incognito) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
        settings.mediaPlaybackRequiresUserGesture = true
        settings.saveFormData = !incognito
        settings.userAgentString = settings.userAgentString.replace(Regex("wv"), "")
        // Nhiều CDN video/ảnh cũ vẫn phục vụ nội dung qua HTTP dù trang chính là HTTPS;
        // mặc định WebView chặn tiệt (MIXED_CONTENT_NEVER_ALLOW) khiến video/ảnh đó không tải
        // được mà không báo lỗi gì rõ ràng => cho phép ở mức tương thích
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        // Cho phép mở "cửa sổ" mới (window.open()/target=_blank) - cần để onCreateWindow bên dưới
        // chạy được, đồng thời cũng là điều kiện để 1 số trình phát video nhúng qua window.open()
        // hoạt động (trước đây bị WebView âm thầm bỏ qua vì tính năng này mặc định tắt)
        settings.setSupportMultipleWindows(true)
        // Dựng sẵn nội dung ngoài khung hình trên 1 luồng riêng thay vì chặn luồng chính khi cuộn/vẽ
        // lại - giảm giật khi máy đang bận (vd có app khác chạy nền chiếm CPU/GPU cùng lúc)
        settings.offscreenPreRaster = true

        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, false)

        // KHÔNG ép webView.setLayerType(LAYER_TYPE_HARDWARE, ...): từng có ở đây với ý định
        // "ổn định hoá GPU khi máy đang bận", nhưng đây chính là nguyên nhân khiến video bị
        // đứng hình/đơ MỌI LÚC (không riêng gì lúc có app khác chạy nền). WebView đã tự dùng
        // GPU để giải mã/hiển thị <video> qua cơ chế texture riêng của Chromium; ép thêm 1 lớp
        // GPU (layer) bọc ngoài toàn bộ WebView khiến khung hình video bị "kẹt" ở frame đầu vì
        // lớp ngoài không được vẽ lại theo kịp texture video bên trong. Chỉ cần
        // android:hardwareAccelerated="true" khai báo sẵn trong AndroidManifest.xml là đủ để
        // WebView tăng tốc phần cứng bình thường, không cần ép layer type thủ công.

        // Cầu nối để trang web báo cho app biết lúc nào <video>/<audio> đang thực sự phát,
        // dùng để xin AudioFocus và giữ CPU thức (wake lock) đúng lúc cần, không giữ tràn lan.
        // Gắn kèm đúng webView sở hữu, để biết sự kiện play/pause này thuộc về tab nào.
        webView.addJavascriptInterface(MediaPlaybackBridge(webView), "AndroidMediaBridge")

        return webView
    }

    // Chỉ báo trạng thái play/pause về app, không đọc/thao túng nội dung trang -> an toàn về quyền riêng tư
    private inner class MediaPlaybackBridge(private val ownerWebView: WebView) {
        @JavascriptInterface
        fun onPlay() {
            runOnUiThread { onWebMediaPlayStateChanged(true, ownerWebView) }
        }

        @JavascriptInterface
        fun onPause() {
            runOnUiThread { onWebMediaPlayStateChanged(false, ownerWebView) }
        }

        // Trang báo về khi 1 thẻ video/audio phát lỗi (không tải được nguồn, decode lỗi...) -
        // báo cho người dùng biết thay vì để họ thấy video đứng im mà không hiểu vì sao.
        // Nhận kèm chi tiết (mã lỗi MediaError, currentSrc) để ghi vào nhật ký console, tự
        // chẩn đoán được nguyên nhân thật (mạng/CORS/mixed-content hay codec không hỗ trợ)
        // thay vì chỉ biết chung chung "có lỗi".
        @JavascriptInterface
        fun onError(detail: String) {
            runOnUiThread { onWebMediaError(detail) }
        }
    }

    // Script gắn listener 'play'/'pause'/'ended'/'error' lên mọi thẻ video/audio hiện có và cả
    // những thẻ được trang tạo thêm sau này (qua MutationObserver, vd trình phát video load động
    // kiểu YouTube)
    private val mediaHookScript = """
        (function() {
            if (window.__sieutocMediaHooked) return;
            window.__sieutocMediaHooked = true;
            function hook(el) {
                if (!el || el.__sieutocHooked) return;
                el.__sieutocHooked = true;
                el.addEventListener('play', function() { AndroidMediaBridge.onPlay(); });
                el.addEventListener('pause', function() { AndroidMediaBridge.onPause(); });
                el.addEventListener('ended', function() { AndroidMediaBridge.onPause(); });
                el.addEventListener('error', function() {
                    var err = el.error;
                    // Mã lỗi chuẩn của thẻ <video>/<audio>:
                    // 1=ABORTED, 2=NETWORK, 3=DECODE (hỏng dữ liệu/codec khi giải mã),
                    // 4=SRC_NOT_SUPPORTED (định dạng/URL không phát được, vd HLS .m3u8 cần JS
                    // player riêng vì WebView không tự phát HLS như trình duyệt Chrome đầy đủ)
                    var code = err ? err.code : -1;
                    var msg = err && err.message ? err.message : '';
                    var src = el.currentSrc || el.src || '';
                    AndroidMediaBridge.onError(JSON.stringify({code: code, message: msg, src: src, tag: el.tagName}));
                });
            }
            document.querySelectorAll('video,audio').forEach(hook);
            var mo = new MutationObserver(function(mutations) {
                mutations.forEach(function(m) {
                    m.addedNodes.forEach(function(node) {
                        if (!(node instanceof Element)) return;
                        if (node.tagName === 'VIDEO' || node.tagName === 'AUDIO') hook(node);
                        if (node.querySelectorAll) node.querySelectorAll('video,audio').forEach(hook);
                    });
                });
            });
            mo.observe(document.documentElement, { childList: true, subtree: true });
        })();
    """.trimIndent()

    // Chỉ báo mỗi lỗi media cách nhau tối thiểu vài giây, tránh spam Toast nếu 1 trang có
    // nhiều thẻ video cùng lỗi hoặc trình phát tự thử lại liên tục
    private var lastMediaErrorToastAt = 0L

    private fun onWebMediaError(detail: String) {
        // Luôn ghi vào nhật ký console (không giới hạn 4s như Toast) để không bỏ lỡ lần lỗi
        // đầu tiên - dùng để tự chẩn đoán qua menu "Xem nhật ký console (debug)"
        val hint = try {
            val json = org.json.JSONObject(detail)
            val code = json.optInt("code", -1)
            val codeMeaning = when (code) {
                1 -> "ABORTED (bị hủy giữa chừng)"
                2 -> "NETWORK (lỗi mạng/tải nguồn - có thể do mixed content hoặc CORS)"
                3 -> "DECODE (dữ liệu hỏng hoặc máy không giải mã được, thường do quá tải khi có app khác chạy nền)"
                4 -> "SRC_NOT_SUPPORTED (định dạng/URL không phát được - vd .m3u8/HLS cần JS player riêng, WebView không tự phát HLS như Chrome đầy đủ)"
                else -> "không rõ (code=$code)"
            }
            "[media error] code=$codeMeaning, src=${json.optString("src")}"
        } catch (e: Exception) {
            "[media error] $detail"
        }
        appendConsoleLog(hint)

        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastMediaErrorToastAt < 4000L) return
        lastMediaErrorToastAt = now
        Toast.makeText(
            this,
            "Video/âm thanh gặp lỗi khi phát. Có thể do mạng yếu hoặc máy đang bận (app khác chạy nền). Xem chi tiết ở \"Xem nhật ký console\"",
            Toast.LENGTH_LONG
        ).show()
    }

    // Chỉ báo lỗi tải trang cách nhau tối thiểu vài giây, tránh spam Toast khi 1 trang lỗi
    // gọi lại nhiều tài nguyên phụ liên tiếp
    private var lastLoadErrorToastAt = 0L

    private fun showLoadErrorToast(message: String) {
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastLoadErrorToastAt < 3000L) return
        lastLoadErrorToastAt = now
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun onWebMediaPlayStateChanged(isPlaying: Boolean, source: WebView) {
        appendConsoleLog("[media] trang báo ${if (isPlaying) "play" else "pause"}")
        // Gắn trạng thái phát vào đúng tab sở hữu webView này, không phải đếm dồn toàn app -
        // để khi 1 tab bị đóng, chỉ trạng thái của đúng tab đó biến mất
        val tab = tabs.find { it.webView === source } ?: return
        tab.hasPlayingMedia = isPlaying
        refreshMediaFocusState()
    }

    // Tính lại wake lock + foreground service dựa trên trạng thái phát THỰC TẾ của tất cả tab
    // đang mở, gọi lại mỗi khi có tab phát/dừng media HOẶC mỗi khi 1 tab bị đóng - nhờ vậy nếu
    // người dùng đóng tab đang phát video, tài nguyên được nhả ngay thay vì bị kẹt giữ tới khi
    // thoát hẳn app.
    //
    // LƯU Ý: đã BỎ việc app tự xin AudioFocus riêng (từng dùng để né xung đột khi có app khác
    // như Zoom giữ quyền âm thanh độc quyền). Lý do bỏ: WebView/Chromium đã tự có sẵn cơ chế
    // xin AudioFocus riêng cho từng thẻ <video>/<audio> đang phát tiếng. Khi app tự thêm 1 lớp
    // AudioFocus khác đè lên, 2 request trong CÙNG 1 app tranh giành nhau, khiến app tự nhận
    // nhầm broadcast AUDIOFOCUS_LOSS (do chính WebView vừa xin) là "bị app khác cướp mất vĩnh
    // viễn" rồi tự dừng video đang phát - đây chính là nguyên nhân video luôn dừng sau 1-2 giây.
    // Việc pause khi có cuộc gọi thật/app khác giành mất giờ do WebView tự xử lý.
    private fun refreshMediaFocusState() {
        val anyTabPlaying = tabs.any { it.hasPlayingMedia }
        if (anyTabPlaying) {
            acquireMediaWakeLock()
            startMediaPlaybackService()
        } else {
            releaseMediaWakeLock()
            stopMediaPlaybackService()
        }
    }

    private fun startMediaPlaybackService() {
        val intent = Intent(this, MediaPlaybackService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun stopMediaPlaybackService() {
        stopService(Intent(this, MediaPlaybackService::class.java))
    }

    private fun pauseAllWebMedia() {
        val js = "document.querySelectorAll('video,audio').forEach(function(m){ if(!m.paused){ m.dataset.sieutocAutoPaused='1'; m.pause(); } });"
        tabs.forEach { it.webView.evaluateJavascript(js, null) }
    }

    private fun resumeAllWebMedia() {
        val js = "document.querySelectorAll('video,audio').forEach(function(m){ if(m.dataset.sieutocAutoPaused==='1'){ delete m.dataset.sieutocAutoPaused; m.play().catch(function(){}); } });"
        tabs.forEach { it.webView.evaluateJavascript(js, null) }
    }

    // Wake lock CPU (không phải màn hình) để khi người dùng tắt màn hình lúc đang nghe/xem,
    // hệ thống không đưa tiến trình vào chế độ nghỉ sâu (Doze) làm âm thanh bị khựng/ngắt giữa chừng.
    // Có mốc thời gian an toàn 6 tiếng phòng trường hợp sự kiện pause/ended không bắn về được,
    // để không vô tình giữ CPU thức mãi mãi gây tốn pin.
    private fun acquireMediaWakeLock() {
        if (mediaWakeLock == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            mediaWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SieuToc:MediaPlayback").apply {
                setReferenceCounted(false)
            }
        }
        mediaWakeLock?.let { if (!it.isHeld) it.acquire(6 * 60 * 60 * 1000L) }
    }

    private fun releaseMediaWakeLock() {
        mediaWakeLock?.let { if (it.isHeld) it.release() }
    }

    private fun attachClients(tab: Tab) {
        val webView = tab.webView
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (tab === currentTab) {
                    progressBar.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                    progressBar.progress = newProgress
                }
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                tab.title = if (title.isNullOrBlank()) "Tab mới" else title
                refreshTabStrip()
            }

            // Nếu KHÔNG override hàm này, WebView sẽ tự tạo ảnh poster mặc định cho <video>
            // qua 1 URL nội bộ giả dạng "android-webview-video-poster:...". Nhiều trình phát
            // video (video.js và tương tự) chủ động load/kiểm tra ảnh poster đó trước khi phát -
            // trình duyệt coi URL giả này khác origin với trang, mà nó không có header CORS nên
            // bị chặn -> trình phát báo lỗi ngay bước đầu và KHÔNG BAO GIỜ chạy tới bước phát
            // thật, video đứng mãi ở 0:00 dù bấm gì cũng vô ích (lỗi này không xảy ra ở Chrome
            // thật vì Chrome không dùng cơ chế URL giả kiểu WebView). Cấp sẵn 1 bitmap trống ở
            // đây khiến WebView không bao giờ cần tạo ra URL giả đó nữa.
            override fun getDefaultVideoPoster(): Bitmap? {
                return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
            }

            // Bắt toàn bộ console.log/warn/error của trang, lưu vào bộ nhớ đệm để xem lại qua
            // menu "Xem nhật ký console" - dùng để tự chẩn đoán lỗi phát video/JS ngay trên điện
            // thoại, không cần cắm máy tính + chrome://inspect.
            override fun onConsoleMessage(consoleMessage: android.webkit.ConsoleMessage?): Boolean {
                consoleMessage ?: return false
                val levelTag = when (consoleMessage.messageLevel()) {
                    android.webkit.ConsoleMessage.MessageLevel.ERROR -> "LỖI"
                    android.webkit.ConsoleMessage.MessageLevel.WARNING -> "CẢNH BÁO"
                    else -> "LOG"
                }
                val fileName = consoleMessage.sourceId()?.substringAfterLast('/') ?: ""
                appendConsoleLog("[$levelTag] ${consoleMessage.message()}  ($fileName:${consoleMessage.lineNumber()})")
                return false
            }

            override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                if (view == null) return
                if (customView != null) {
                    callback?.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback
                fullscreenContainer.addView(
                    view,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
                fullscreenContainer.visibility = View.VISIBLE
                rootUiLayout.visibility = View.GONE
                enterImmersiveMode()
                // Chống tắt màn hình và giữ hardware acceleration khi phát video
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }

            override fun onHideCustomView() {
                val view = customView ?: return
                fullscreenContainer.removeView(view)
                fullscreenContainer.visibility = View.GONE
                rootUiLayout.visibility = View.VISIBLE
                customView = null
                customViewCallback?.onCustomViewHidden()
                customViewCallback = null
                exitImmersiveMode()
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }

            // Nhiều trang video (YouTube, TikTok, Facebook...) cần quyền phát nội dung có DRM
            // (Widevine) mới chạy được; WebChromeClient mặc định từ chối MỌI permission request,
            // khiến video load mãi không lên. Chỉ tự cấp đúng quyền DRM, các quyền nhạy cảm khác
            // (camera, mic, vị trí...) vẫn bị từ chối để giữ đúng tinh thần riêng tư của app.
            override fun onPermissionRequest(request: PermissionRequest?) {
                request ?: return
                val grantable = request.resources.filter { it == PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID }
                if (grantable.isNotEmpty()) {
                    request.grant(grantable.toTypedArray())
                } else {
                    request.deny()
                }
            }

            // Nhiều trang lạm dụng hộp thoại JS (alert/confirm/beforeunload) để "bẫy" người dùng ở
            // lại trang kiểu "Bạn có chắc muốn rời đi?" lặp đi lặp lại (chiêu quảng cáo/scareware
            // phổ biến). Khi bật chặn quảng cáo: cho phép tối đa vài hộp thoại mỗi tab, sau đó tự
            // chặn êm các hộp thoại tiếp theo thay vì hiện ra nữa - giống tính năng
            // "Prevent this page from creating additional dialogs" của Chrome.
            private fun allowJsDialog(): Boolean {
                if (!isTrackerBlockEnabled()) return true
                tab.jsDialogCount++
                return tab.jsDialogCount <= 3
            }

            override fun onJsBeforeUnload(
                view: WebView?,
                url: String?,
                message: String?,
                result: android.webkit.JsResult?
            ): Boolean {
                if (!allowJsDialog()) {
                    result?.confirm()
                    return true
                }
                return super.onJsBeforeUnload(view, url, message, result)
            }

            override fun onJsAlert(
                view: WebView?,
                url: String?,
                message: String?,
                result: android.webkit.JsResult?
            ): Boolean {
                if (!allowJsDialog()) {
                    result?.confirm()
                    return true
                }
                return super.onJsAlert(view, url, message, result)
            }

            override fun onJsConfirm(
                view: WebView?,
                url: String?,
                message: String?,
                result: android.webkit.JsResult?
            ): Boolean {
                if (!allowJsDialog()) {
                    result?.cancel()
                    return true
                }
                return super.onJsConfirm(view, url, message, result)
            }

            // Chặn popup quảng cáo: popup do JS tự mở (không phải người dùng bấm) khi đang bật
            // "Chặn quảng cáo / theo dõi" thì từ chối luôn. Popup do người dùng chủ động bấm
            // (link target="_blank", nút "mở tab mới" của trình phát video...) vẫn mở bình thường
            // ở 1 tab mới của app.
            //
            // Nhiều mạng quảng cáo lợi dụng đúng cú chạm thật của người dùng để bắn ra hàng loạt
            // popup liên tiếp (chỉ 1 click nhưng mở ra 3-4 tab quảng cáo) - "isUserGesture" vẫn là
            // true nên không chặn được bằng điều kiện trên. Vì vậy giới hạn thêm: mỗi lần chạm chỉ
            // cho phép mở đúng 1 popup, các popup bắn thêm ngay sau đó (trong khoảng ~1.2s) bị coi
            // là popup ăn theo và chặn luôn.
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: Message?
            ): Boolean {
                if (isTrackerBlockEnabled()) {
                    if (!isUserGesture) return false
                    val now = android.os.SystemClock.elapsedRealtime()
                    if (now - lastPopupOpenedAt < 1200L) {
                        Toast.makeText(this@BrowserActivity, "Đã chặn popup quảng cáo", Toast.LENGTH_SHORT).show()
                        return false
                    }
                    lastPopupOpenedAt = now
                }

                // Kiểm tra transport HỢP LỆ trước, rồi mới tạo/hiển thị tab mới trên UI - tránh để
                // lại 1 tab trắng "mồ côi" nếu vì lý do nào đó không lấy được transport để nhận nội
                // dung popup (trước đây tab được tạo trước khi kiểm tra, nếu bước này thất bại thì
                // tab trắng đó không ai dọn).
                val transport = resultMsg?.obj as? WebView.WebViewTransport ?: return false

                val newWebView = createWebView()
                registerNewTab(newWebView, isPopup = isTrackerBlockEnabled())
                switchTab(tabs.size - 1)

                transport.webView = newWebView
                resultMsg.sendToTarget()
                return true
            }

            // JS gọi window.close() trên popup (vd popup đăng nhập tự đóng sau khi xong) => đóng đúng tab đó
            override fun onCloseWindow(window: WebView?) {
                val idx = tabs.indexOfFirst { it.webView === window }
                if (idx >= 0) closeTab(idx)
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val url = request?.url?.toString() ?: return super.shouldInterceptRequest(view, request)
                if (isBlocked(url)) {
                    // Tab popup mà ngay nội dung đầu tiên (main frame) đã bị chặn: đó chắc chắn là
                    // 1 trang quảng cáo/redirect vô dụng -> tự đóng tab luôn thay vì để lại tab trắng
                    if (tab.isPopup && !tab.popupFirstLoadChecked && request.isForMainFrame) {
                        tab.popupFirstLoadChecked = true
                        runOnUiThread {
                            val idx = tabs.indexOf(tab)
                            if (idx >= 0) {
                                closeTab(idx)
                                Toast.makeText(this@BrowserActivity, "Đã chặn 1 popup quảng cáo", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                if (tab.isPopup && request.isForMainFrame) tab.popupFirstLoadChecked = true
                return super.shouldInterceptRequest(view, request)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (tab === currentTab) {
                    addressBar.setText(url ?: "")
                    updateBookmarkIcon(url)
                }
                persistSession()
                // Trang mới (kể cả sau reload) mất mọi listener JS cũ -> gắn lại hook theo dõi phát/dừng
                view?.evaluateJavascript(mediaHookScript, null)
            }

            // Lỗi tải trang (mất mạng, không tìm thấy máy chủ, timeout...). Chỉ báo lỗi của trang
            // chính (isForMainFrame) - lỗi của các tài nguyên phụ (ảnh, quảng cáo bị chặn...) là
            // bình thường và không nên làm phiền người dùng bằng thông báo.
            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame != true || tab !== currentTab) return
                val message = when (error?.errorCode) {
                    ERROR_HOST_LOOKUP -> "Không tìm thấy máy chủ - kiểm tra lại kết nối mạng"
                    ERROR_CONNECT, ERROR_TIMEOUT, ERROR_IO -> "Không kết nối được tới trang, thử lại sau"
                    ERROR_UNSUPPORTED_SCHEME -> null // vd tel:, intent: - không phải lỗi thật, bỏ qua
                    else -> "Không tải được trang" + (error?.description?.let { ": $it" } ?: "")
                }
                message?.let { showLoadErrorToast(it) }
            }

            // Trang chính tải được nhưng máy chủ trả về lỗi (404, 500...)
            override fun onReceivedHttpError(
                view: WebView?,
                request: WebResourceRequest?,
                errorResponse: WebResourceResponse?
            ) {
                super.onReceivedHttpError(view, request, errorResponse)
                if (request?.isForMainFrame != true || tab !== currentTab) return
                val code = errorResponse?.statusCode ?: return
                if (code < 400) return
                showLoadErrorToast("Trang báo lỗi (mã $code)")
            }

            // Chứng chỉ bảo mật (HTTPS) không hợp lệ - LUÔN từ chối tải tiếp (không gọi
            // handler.proceed(), làm vậy sẽ bỏ qua cảnh báo bảo mật và không an toàn cho người
            // dùng), chỉ thêm thông báo rõ ràng để người dùng hiểu vì sao trang không lên
            override fun onReceivedSslError(
                view: WebView?,
                handler: android.webkit.SslErrorHandler?,
                error: android.net.http.SslError?
            ) {
                handler?.cancel()
                if (tab === currentTab) {
                    showLoadErrorToast("Đã chặn trang vì chứng chỉ bảo mật (HTTPS) không hợp lệ")
                }
            }
        }
    }

    protected fun addTab(url: String?) {
        val webView = createWebView()
        registerNewTab(webView)
        webView.loadUrl(url ?: homeUrl)
        switchTab(tabs.size - 1)
    }

    // Đăng ký 1 WebView đã tạo sẵn thành 1 tab mới (thêm vào danh sách, gắn client, dựng UI thanh tab).
    // Không tự loadUrl/switchTab - việc đó do nơi gọi quyết định (addTab load URL trực tiếp,
    // onCreateWindow để chính WebView mới tự load URL đích qua cơ chế transport của WebView).
    private fun registerNewTab(webView: WebView, isPopup: Boolean = false): Tab {
        val tab = Tab(webView, isPopup = isPopup)
        attachClients(tab)
        tabs.add(tab)
        webViewContainer.addView(webView)

        val tabView = LayoutInflater.from(this).inflate(R.layout.item_tab, tabsLayout, false)
        tabsLayout.addView(tabView)
        tabViews.add(tabView)
        val index = tabs.size - 1

        tabView.findViewById<TextView>(R.id.tabTitle).apply {
            text = if (isIncognitoActivity) "🕶 Ẩn danh" else "Tab mới"
            if (isIncognitoActivity) setTextColor(0xFFFFFFFF.toInt())
        }
        if (isIncognitoActivity) tabView.setBackgroundColor(0xFF333333.toInt())

        tabView.setOnClickListener { switchTab(index) }
        tabView.findViewById<ImageButton>(R.id.tabClose).setOnClickListener { closeTab(index) }
        return tab
    }

    protected fun switchTab(index: Int) {
        if (index !in tabs.indices) return
        currentTabIndex = index
        tabs.forEachIndexed { i, tab -> tab.webView.visibility = if (i == index) View.VISIBLE else View.GONE }
        tabViews.forEachIndexed { i, v -> v.isSelected = (i == index) }
        val tab = tabs[index]
        addressBar.setText(tab.webView.url ?: "")
        progressBar.visibility = View.GONE
        updateBookmarkIcon(tab.webView.url)
    }

    private fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        val tab = tabs[index]
        val activeTabBeforeClose = currentTab // nhớ tab đang xem trước khi đóng, để không bị nhảy lung tung

        tab.webView.destroy()
        webViewContainer.removeView(tab.webView)
        tabsLayout.removeView(tabViews[index])
        tabs.removeAt(index)
        tabViews.removeAt(index)
        // Tab vừa đóng có thể đang mang theo video/audio đang phát; webView.destroy() ở trên
        // không kịp bắn sự kiện pause/ended về JS bridge, nên phải tính lại thủ công ngay ở đây
        // - nếu không tab đó sẽ để lại AudioFocus/wake lock bị "mồ côi", không ai nhả nữa.
        refreshMediaFocusState()
        // LƯU Ý: đóng 1 tab ẩn danh KHÔNG xoá cookie/storage toàn app ở đây nữa (bug cũ). Việc
        // xoá dữ liệu của phiên ẩn danh chỉ diễn ra 1 lần, khi TOÀN BỘ phiên kết thúc - xem
        // IncognitoActivity#onDestroy().

        if (tabs.isEmpty()) {
            addTab(homeUrl)
            return
        }

        // Cập nhật listener của các tab còn lại vì index đã lệch
        rebindTabListeners()

        val newIndex = if (tab === activeTabBeforeClose) {
            // Đóng đúng tab đang xem: lùi về tab liền trước, kiểu hành vi trình duyệt thường thấy
            (index - 1).coerceAtLeast(0)
        } else {
            // Đóng 1 tab khác: phải giữ nguyên tab đang xem (chỉ index của nó có thể bị lệch đi)
            val shiftedIndex = tabs.indexOf(activeTabBeforeClose)
            if (shiftedIndex >= 0) shiftedIndex else (index - 1).coerceAtLeast(0)
        }
        switchTab(newIndex.coerceAtMost(tabs.size - 1))
        persistSession()
    }

    private fun rebindTabListeners() {
        tabViews.forEachIndexed { i, v ->
            v.setOnClickListener { switchTab(i) }
            v.findViewById<ImageButton>(R.id.tabClose).setOnClickListener { closeTab(i) }
        }
    }

    private fun refreshTabStrip() {
        tabs.forEachIndexed { i, tab ->
            val view = tabViews.getOrNull(i) ?: return@forEachIndexed
            val label = if (isIncognitoActivity) "🕶 " + shortTitle(tab.title) else shortTitle(tab.title)
            view.findViewById<TextView>(R.id.tabTitle).text = label
        }
    }

    private fun shortTitle(title: String): String =
        if (title.length > 14) title.take(14) + "…" else title

    @Suppress("DEPRECATION")
    private fun enterImmersiveMode() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
    }

    @Suppress("DEPRECATION")
    private fun exitImmersiveMode() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }

    // ---------------- Điều hướng & thanh công cụ ----------------

    private fun navigateTo(input: String) {
        val query = input.trim()
        if (query.isEmpty()) return

        val url = when {
            Patterns.WEB_URL.matcher(query).matches() && !query.contains(" ") -> {
                if (query.startsWith("http://") || query.startsWith("https://")) query
                else "https://$query"
            }
            query.contains(".") && !query.contains(" ") -> "https://$query"
            else -> "https://www.google.com/search?q=" + Uri.encode(query)
        }
        currentTab?.webView?.loadUrl(url)
        currentFocus?.let {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
            imm.hideSoftInputFromWindow(it.windowToken, 0)
        }
    }

    private fun setupToolbar() {
        addressBar.setOnEditorActionListener { _, actionId, event ->
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_GO ||
                (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            ) {
                navigateTo(addressBar.text.toString())
                true
            } else {
                false
            }
        }

        findViewById<ImageButton>(R.id.btnBack).setOnClickListener {
            currentTab?.webView?.let { if (it.canGoBack()) it.goBack() }
        }
        findViewById<ImageButton>(R.id.btnForward).setOnClickListener {
            currentTab?.webView?.let { if (it.canGoForward()) it.goForward() }
        }
        btnBookmark.setOnClickListener { toggleBookmark() }
        findViewById<ImageButton>(R.id.btnMenu).setOnClickListener { view -> showMenu(view) }

        findViewById<ImageButton>(R.id.btnNewTab).setOnClickListener { onNewTabButtonClicked() }
        btnIncognito.setOnClickListener { onIncognitoButtonClicked() }
    }

    // Nút "+" trên thanh tab: MainActivity mở thêm 1 tab thường; IncognitoActivity mở thêm 1 tab
    // ẩn danh MỚI trong cùng phiên đang chạy (không phải phiên mới).
    protected abstract fun onNewTabButtonClicked()

    // Nút hình kính ẩn danh trên thanh tab: ở MainActivity dùng để MỞ phiên ẩn danh (1 Activity
    // riêng, process riêng); ở IncognitoActivity dùng để ĐÓNG hẳn phiên ẩn danh đang chạy.
    protected abstract fun onIncognitoButtonClicked()

    private fun toggleBookmark() {
        if (isIncognitoActivity) {
            Toast.makeText(this, "Không thể đánh dấu ở chế độ ẩn danh", Toast.LENGTH_SHORT).show()
            return
        }
        val tab = currentTab ?: return
        val url = tab.webView.url ?: return
        val bookmarks = prefs.getStringSet("bookmarks", mutableSetOf())!!.toMutableSet()
        if (bookmarks.contains(url)) {
            bookmarks.remove(url)
            Toast.makeText(this, "Đã bỏ đánh dấu", Toast.LENGTH_SHORT).show()
        } else {
            bookmarks.add(url)
            Toast.makeText(this, "Đã đánh dấu trang", Toast.LENGTH_SHORT).show()
        }
        prefs.edit().putStringSet("bookmarks", bookmarks).apply()
        updateBookmarkIcon(url)
    }

    private fun updateBookmarkIcon(url: String?) {
        if (isIncognitoActivity) {
            btnBookmark.setImageResource(android.R.drawable.star_off)
            btnBookmark.alpha = 0.4f
            return
        }
        btnBookmark.alpha = 1.0f
        val bookmarks = prefs.getStringSet("bookmarks", mutableSetOf())!!
        val isBookmarked = url != null && bookmarks.contains(url)
        btnBookmark.setImageResource(
            if (isBookmarked) android.R.drawable.star_on else android.R.drawable.star_off
        )
    }

    private fun showMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add(0, 1, 0, "Trang chủ")
        if (!isIncognitoActivity) popup.menu.add(0, 2, 1, "Danh sách đánh dấu")
        popup.menu.add(0, 5, 2, if (isCurrentPageTranslated()) "Xem bản gốc" else "Dịch trang")
        popup.menu.add(0, 6, 3, "Ngôn ngữ dịch (${translateLangLabel()})")
        popup.menu.add(0, 3, 4, "Xóa dữ liệu duyệt web")
        popup.menu.add(0, 4, 5, "Cài đặt")
        popup.menu.add(0, 8, 6, "Xem nhật ký console (debug)")
        if (isIncognitoActivity) popup.menu.add(0, 7, 7, "Đóng phiên ẩn danh")
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> { currentTab?.webView?.loadUrl(homeUrl); true }
                2 -> { showBookmarks(); true }
                3 -> { clearBrowsingData(); true }
                4 -> { showSettingsDialog(); true }
                5 -> { translateCurrentPage(); true }
                6 -> { showTranslateLanguageDialog(); true }
                7 -> { onCloseIncognitoSessionRequested(); true }
                8 -> { showConsoleLogDialog(); true }
                else -> false
            }
        }
        popup.show()
    }

    // Chỉ IncognitoActivity override để thật sự đóng phiên; mặc định không làm gì.
    protected open fun onCloseIncognitoSessionRequested() { }

    // ---------------- Dịch trang ----------------

    // Danh sách ngôn ngữ dịch hỗ trợ sẵn (mã ngôn ngữ Google Translate, tên hiển thị)
    private val translateLanguages = listOf(
        "vi" to "Tiếng Việt",
        "en" to "English",
        "zh-CN" to "中文 (Giản thể)",
        "ja" to "日本語",
        "ko" to "한국어",
        "fr" to "Français",
        "es" to "Español",
        "de" to "Deutsch",
        "th" to "ภาษาไทย"
    )

    private fun targetLang(): String = prefs.getString("pref_translate_lang", "vi") ?: "vi"

    private fun translateLangLabel(): String =
        translateLanguages.firstOrNull { it.first == targetLang() }?.second ?: targetLang()

    private fun showTranslateLanguageDialog() {
        val labels = translateLanguages.map { it.second }.toTypedArray()
        val currentIndex = translateLanguages.indexOfFirst { it.first == targetLang() }.coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Ngôn ngữ dịch")
            .setSingleChoiceItems(labels, currentIndex) { dialog, which ->
                val lang = translateLanguages[which].first
                prefs.edit().putString("pref_translate_lang", lang).apply()
                Toast.makeText(this, "Đã đặt ngôn ngữ dịch: ${translateLanguages[which].second}", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
                reapplyTranslationIfActive(lang) // nếu đang xem bản dịch, dịch lại ngay bằng ngôn ngữ mới
            }
            .setNegativeButton("Đóng", null)
            .show()
    }

    // Nếu trang hiện tại đang là bản dịch, tải lại bằng ngôn ngữ mới thay vì bắt người dùng
    // tự bấm "Xem bản gốc" rồi "Dịch trang" lại
    private fun reapplyTranslationIfActive(newLang: String) {
        val tab = currentTab ?: return
        val url = tab.webView.url ?: return
        if (!isTranslatedUrl(url)) return
        val original = originalUrlFromTranslated(url) ?: return
        val target = buildTranslateUrl(original, newLang) ?: return
        tab.webView.loadUrl(target)
    }

    private fun isTranslatedUrl(url: String): Boolean =
        Uri.parse(url).host?.endsWith(".translate.goog") == true

    private fun isCurrentPageTranslated(): Boolean {
        val url = currentTab?.webView?.url ?: return false
        return isTranslatedUrl(url)
    }

    // Chuyển URL gốc thành URL dịch qua proxy translate.goog của Google
    // (vd "example.com" -> "example-com.translate.goog", ký tự "-" gốc được nhân đôi để không lẫn với "." đã đổi)
    // Trả về null nếu URL không có host hợp lệ để dịch (about:blank, data:, IP nội bộ, localhost...)
    private fun buildTranslateUrl(url: String, targetLang: String): String? {
        val uri = Uri.parse(url)
        val host = uri.host?.lowercase() ?: return null
        if (host == "localhost" || Patterns.IP_ADDRESS.matcher(host).matches()) return null
        val encodedHost = host.replace("-", "--").replace(".", "-") + ".translate.goog"
        val builder = Uri.Builder()
            .scheme(uri.scheme ?: "https")
            .encodedAuthority(encodedHost)
            .encodedPath(uri.encodedPath ?: "/")
        uri.encodedQuery?.let { builder.encodedQuery(it) }
        builder.appendQueryParameter("_x_tr_sl", "auto")
        builder.appendQueryParameter("_x_tr_tl", targetLang)
        builder.appendQueryParameter("_x_tr_hl", targetLang)
        builder.appendQueryParameter("_x_tr_pto", "wapp")
        return builder.build().toString()
    }

    // Chiều ngược lại: từ URL dịch suy ra URL gốc, để bấm "Xem bản gốc" quay về đúng trang
    private fun originalUrlFromTranslated(url: String): String? {
        val uri = Uri.parse(url)
        val host = uri.host ?: return null
        if (!host.endsWith(".translate.goog")) return null
        val encodedHost = host.removeSuffix(".translate.goog")
        val originalHost = encodedHost
            .replace("--", "\u0000")
            .replace("-", ".")
            .replace("\u0000", "-")
        if (originalHost.isBlank()) return null

        val builder = Uri.Builder()
            .scheme(uri.scheme ?: "https")
            .encodedAuthority(originalHost)
            .encodedPath(uri.encodedPath ?: "/")
        uri.queryParameterNames
            .filterNot { it.startsWith("_x_tr_") }
            .forEach { name -> uri.getQueryParameter(name)?.let { builder.appendQueryParameter(name, it) } }
        return builder.build().toString()
    }

    private fun translateCurrentPage() {
        val tab = currentTab ?: return
        val url = tab.webView.url
        if (url.isNullOrBlank()) {
            Toast.makeText(this, "Chưa có trang để dịch", Toast.LENGTH_SHORT).show()
            return
        }
        val target = if (isTranslatedUrl(url)) {
            originalUrlFromTranslated(url)
        } else {
            buildTranslateUrl(url, targetLang())
        }
        if (target == null) {
            Toast.makeText(this, "Không dịch được trang này", Toast.LENGTH_SHORT).show()
            return
        }
        tab.webView.loadUrl(target)
    }

    private fun showBookmarks() {
        val bookmarks = prefs.getStringSet("bookmarks", mutableSetOf())!!.toList()
        if (bookmarks.isEmpty()) {
            Toast.makeText(this, "Chưa có trang nào được đánh dấu", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Đánh dấu")
            .setItems(bookmarks.toTypedArray()) { _, which ->
                currentTab?.webView?.loadUrl(bookmarks[which])
            }
            .setNegativeButton("Đóng", null)
            .create()
            .show()
    }

    private fun showSettingsDialog() {
        val options = arrayOf("Bật JavaScript", "Chặn quảng cáo / theo dõi / popup")
        val checked = booleanArrayOf(isJsEnabled(), isTrackerBlockEnabled())

        AlertDialog.Builder(this)
            .setTitle("Cài đặt")
            .setMultiChoiceItems(options, checked) { _, which, isChecked ->
                checked[which] = isChecked
            }
            .setPositiveButton("Áp dụng") { _, _ ->
                applySettings(jsEnabled = checked[0], trackerBlockEnabled = checked[1])
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun applySettings(jsEnabled: Boolean, trackerBlockEnabled: Boolean) {
        prefs.edit()
            .putBoolean("pref_js_enabled", jsEnabled)
            .putBoolean("pref_block_tracker", trackerBlockEnabled)
            .apply()

        // Áp dụng ngay cho mọi tab đang mở, không cần khởi động lại app
        tabs.forEach { tab -> tab.webView.settings.javaScriptEnabled = jsEnabled }

        Toast.makeText(this, "Đã lưu cài đặt, đang tải lại trang hiện tại", Toast.LENGTH_SHORT).show()
        currentTab?.webView?.reload()
    }

    // Hành động XOÁ THỦ CÔNG do người dùng chủ động bấm - khác với vụ đóng-1-tab-ẩn-danh-xoá-nhầm-
    // tab-khác trước đây: đây là nút "Xóa dữ liệu duyệt web" trong menu, người dùng biết rõ và
    // muốn xoá SẠCH của phiên/app hiện tại, nên gọi xoá toàn bộ ở đây là đúng ý, không phải bug.
    // Với IncognitoActivity, "toàn bộ" ở đây chỉ nằm trong process/thư mục dữ liệu riêng của phiên
    // ẩn danh - không đụng tới MainActivity.
    protected fun clearBrowsingData() {
        tabs.forEach { tab ->
            tab.webView.clearHistory()
            tab.webView.clearCache(true)
            tab.webView.clearFormData()
        }
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
        if (!isIncognitoActivity) prefs.edit().remove("tab_urls").apply()
        Toast.makeText(this, "Đã xóa toàn bộ dữ liệu duyệt web trên máy", Toast.LENGTH_SHORT).show()
    }

    override fun onBackPressed() {
        if (customView != null) {
            customViewCallback?.onCustomViewHidden()
            return
        }
        val webView = currentTab?.webView
        when {
            webView != null && webView.canGoBack() -> webView.goBack()
            tabs.size > 1 -> closeTab(currentTabIndex)
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() {
        // Nhả wake lock + tắt foreground service để không giữ máy sáng/chạy nền sau khi thoát
        releaseMediaWakeLock()
        stopMediaPlaybackService()
        super.onDestroy()
    }
}
