package com.atun.sieutoc

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Message
import android.os.PowerManager
import android.util.Patterns
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.ByteArrayInputStream

class MainActivity : AppCompatActivity() {

    // ---- Model 1 tab ----
    private class Tab(
        val webView: WebView,
        val isIncognito: Boolean,
        var title: String = "Tab mới"
    )

    private lateinit var webViewContainer: FrameLayout
    private lateinit var rootUiLayout: View
    private lateinit var fullscreenContainer: FrameLayout
    private lateinit var tabsLayout: LinearLayout
    private lateinit var addressBar: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var btnBookmark: ImageButton
    private lateinit var btnIncognito: ImageButton
    private lateinit var prefs: SharedPreferences

    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

    private val blockedHosts: MutableSet<String> = mutableSetOf()
    private val tabs = mutableListOf<Tab>()
    private val tabViews = mutableListOf<View>() // view tương ứng trên thanh tab
    private var currentTabIndex = -1

    // Chế độ ẩn danh đang bật khi bấm "+" (không phải trạng thái của tab hiện tại)
    private var incognitoModeArmed = false

    private val homeUrl = "https://www.google.com/"
    private val currentTab: Tab? get() = tabs.getOrNull(currentTabIndex)

    // ---- Audio focus & phát âm thanh nền khi tắt màn hình ----
    // Trước đây app không hề xin AudioFocus: khi 1 app khác giữ quyền âm thanh độc quyền
    // (điển hình là Zoom lúc đang gọi) thì video/audio trong WebView bị khựng/đơ mà không có
    // cách nào tự thoát ra, trông giống như "xung đột, không phát được video". Cơ chế dưới đây
    // lắng nghe play/pause của thẻ <video>/<audio> trong trang, chủ động xin AudioFocus khi phát,
    // và phản ứng đúng chuẩn khi bị app khác giành mất (tạm dừng rồi tự phát lại khi được trả
    // lại quyền, giống hành vi của Chrome thật) thay vì bị đơ.
    private lateinit var audioManager: AudioManager
    private var focusRequest: AudioFocusRequest? = null
    private var hasAudioFocus = false
    private var pausedByFocusLoss = false
    private var mediaPlayingCount = 0
    private var mediaWakeLock: PowerManager.WakeLock? = null

    private val audioFocusChangeListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
        when (focusChange) {
            AudioManager.AUDIOFOCUS_LOSS -> {
                // Mất hẳn quyền phát (vd người dùng chủ động mở Zoom lên gọi): dừng hẳn,
                // không tự phát lại kể cả khi có quyền trở lại - giống hành vi Chrome thật
                hasAudioFocus = false
                pausedByFocusLoss = false
                pauseAllWebMedia()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT,
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                // Mất tạm thời (vd có cuộc gọi/thông báo Zoom xen ngang trong chốc lát):
                // tạm dừng và nhớ để tự phát lại khi được trả quyền
                pausedByFocusLoss = true
                pauseAllWebMedia()
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                hasAudioFocus = true
                if (pausedByFocusLoss) {
                    pausedByFocusLoss = false
                    resumeAllWebMedia()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("sieutoc_prefs", MODE_PRIVATE)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        webViewContainer = findViewById(R.id.webViewContainer)
        rootUiLayout = findViewById(R.id.rootUiLayout)
        fullscreenContainer = findViewById(R.id.fullscreenContainer)
        tabsLayout = findViewById(R.id.tabsLayout)
        addressBar = findViewById(R.id.addressBar)
        progressBar = findViewById(R.id.progressBar)
        btnBookmark = findViewById(R.id.btnBookmark)
        btnIncognito = findViewById(R.id.btnIncognito)

        loadBlocklist()
        setupToolbar()

        restoreSession()
        handleViewIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleViewIntent(intent)
    }

    // Xử lý link mở từ app khác (share/"Mở bằng Siêu Tốc") - launchMode singleTask nên phải
    // bắt cả onCreate (lần mở đầu) lẫn onNewIntent (app đã chạy sẵn)
    private fun handleViewIntent(intent: Intent?) {
        if (intent?.action != Intent.ACTION_VIEW) return
        val url = intent.data?.toString() ?: return
        addTab(incognito = incognitoModeArmed, url = url)
    }

    private fun loadBlocklist() {
        try {
            assets.open("blocklist.txt").bufferedReader().useLines { lines ->
                lines.forEach { line ->
                    val host = line.trim()
                    if (host.isNotEmpty() && !host.startsWith("#")) {
                        blockedHosts.add(host.lowercase())
                    }
                }
            }
        } catch (e: Exception) {
            // Không có blocklist thì vẫn chạy bình thường
        }
    }

    private fun isBlocked(url: String): Boolean {
        if (!isTrackerBlockEnabled()) return false
        val uri = try {
            Uri.parse(url)
        } catch (e: Exception) {
            return false
        }
        val host = uri.host?.lowercase() ?: return false

        return blockedHosts.any { blocked ->
            val slash = blocked.indexOf('/')
            if (slash < 0) {
                // Domain thường: chặn domain đó và mọi subdomain
                host == blocked || host.endsWith(".$blocked")
            } else {
                // Entry có path (vd "facebook.com/tr"): phải khớp cả host lẫn tiền tố path
                val blockedHost = blocked.substring(0, slash)
                val blockedPath = blocked.substring(slash)
                (host == blockedHost || host.endsWith(".$blockedHost")) &&
                    (uri.path ?: "").startsWith(blockedPath)
            }
        }
    }

    private fun isJsEnabled(): Boolean = prefs.getBoolean("pref_js_enabled", true)
    private fun isTrackerBlockEnabled(): Boolean = prefs.getBoolean("pref_block_tracker", true)

    // ---------------- Quản lý tab ----------------

    private fun restoreSession() {
        val savedUrls = prefs.getString("tab_urls", null)
            ?.split("\n")
            ?.filter { it.isNotBlank() }

        if (savedUrls.isNullOrEmpty()) {
            addTab(incognito = false, url = homeUrl)
        } else {
            savedUrls.forEach { addTab(incognito = false, url = it) }
            switchTab(0)
        }
    }

    private fun persistSession() {
        val urls = tabs.filter { !it.isIncognito }.map { it.webView.url ?: homeUrl }
        prefs.edit().putString("tab_urls", urls.joinToString("\n")).apply()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(incognito: Boolean): WebView {
        val webView = WebView(this)
        webView.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )

        val settings = webView.settings
        settings.javaScriptEnabled = isJsEnabled()
        settings.domStorageEnabled = !incognito // ẩn danh: không lưu localStorage
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.setSupportZoom(true)
        // KHÔNG bật builtInZoomControls: pinch-zoom vẫn chạy đầy đủ chỉ với setSupportZoom(true),
        // còn builtInZoomControls chỉ thêm lớp overlay nút +/- cũ (ZoomButtonsController) - lớp này
        // là 1 popup window ngoài WebView, dễ xung đột khi tab bị ẩn lúc chuyển tab hoặc vào/thoát
        // fullscreen video (tham chiếu tới view đã gỡ khỏi cây view) => bỏ hẳn cho an toàn
        settings.builtInZoomControls = false
        settings.displayZoomControls = false
        settings.cacheMode = if (incognito) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
        settings.mediaPlaybackRequiresUserGesture = true
        settings.saveFormData = !incognito
        settings.userAgentString = settings.userAgentString.replace(Regex("wv"), "")
        // Nhiều CDN video/ảnh cũ vẫn phục vụ nội dung qua HTTP dù trang chính là HTTPS;
        // mặc định WebView chặn tiệt (MIXED_CONTENT_NEVER_ALLOW) khiến video/ảnh đó không tải
        // được mà không báo lỗi gì rõ ràng => cho phép ở mức tương thích
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        // Cho phép mở "cửa sổ" mới (window.open()/target=_blank) - cần để onCreateWindow bên dưới
        // chạy được, đồng thời cũng là điều kiện để 1 số trình phát video nhúng qua window.open()
        // hoạt động (trước đây bị WebView âm thầm bỏ qua vì tính năng này mặc định tắt)
        settings.setSupportMultipleWindows(true)

        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(!incognito)
        cookieManager.setAcceptThirdPartyCookies(webView, false)

        // Cầu nối để trang web báo cho app biết lúc nào <video>/<audio> đang thực sự phát,
        // dùng để xin AudioFocus và giữ CPU thức (wake lock) đúng lúc cần, không giữ tràn lan
        webView.addJavascriptInterface(MediaPlaybackBridge(), "AndroidMediaBridge")

        return webView
    }

    // Chỉ báo trạng thái play/pause về app, không đọc/thao túng nội dung trang -> an toàn về quyền riêng tư
    private inner class MediaPlaybackBridge {
        @JavascriptInterface
        fun onPlay() {
            runOnUiThread { onWebMediaPlayStateChanged(true) }
        }

        @JavascriptInterface
        fun onPause() {
            runOnUiThread { onWebMediaPlayStateChanged(false) }
        }
    }

    // Script gắn listener 'play'/'pause'/'ended' lên mọi thẻ video/audio hiện có và cả những thẻ
    // được trang tạo thêm sau này (qua MutationObserver, vd trình phát video load động kiểu YouTube)
    private val mediaHookScript = """
        (function() {
            if (window.__sieutocMediaHooked) return;
            window.__sieutocMediaHooked = true;
            function hook(el) {
                if (!el || el.__sieutocHooked) return;
                el.__sieutocHooked = true;
                el.addEventListener('play', function() { AndroidMediaBridge.onPlay(); });
                el.addEventListener('pause', function() { AndroidMediaBridge.onPause(); });
                el.addEventListener('ended', function() { AndroidMediaBridge.onPause(); });
            }
            document.querySelectorAll('video,audio').forEach(hook);
            var mo = new MutationObserver(function(mutations) {
                mutations.forEach(function(m) {
                    m.addedNodes.forEach(function(node) {
                        if (!(node instanceof Element)) return;
                        if (node.tagName === 'VIDEO' || node.tagName === 'AUDIO') hook(node);
                        if (node.querySelectorAll) node.querySelectorAll('video,audio').forEach(hook);
                    });
                });
            });
            mo.observe(document.documentElement, { childList: true, subtree: true });
        })();
    """.trimIndent()

    private fun onWebMediaPlayStateChanged(isPlaying: Boolean) {
        if (isPlaying) {
            mediaPlayingCount++
            if (mediaPlayingCount == 1) {
                requestPlaybackAudioFocus()
                acquireMediaWakeLock()
            }
        } else {
            mediaPlayingCount = (mediaPlayingCount - 1).coerceAtLeast(0)
            if (mediaPlayingCount == 0) {
                releaseMediaWakeLock()
                // Cố tình giữ nguyên AudioFocus thêm 1 lúc thay vì nhả ngay: tránh tình trạng
                // giành-nhả liên tục khi người dùng tua/dừng-phát lại video liên tiếp
            }
        }
    }

    private fun requestPlaybackAudioFocus() {
        if (hasAudioFocus) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                .build()
            val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(attrs)
                .setOnAudioFocusChangeListener(audioFocusChangeListener)
                .build()
            focusRequest = request
            hasAudioFocus = audioManager.requestAudioFocus(request) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        } else {
            @Suppress("DEPRECATION")
            hasAudioFocus = audioManager.requestAudioFocus(
                audioFocusChangeListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN
            ) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        }
    }

    private fun abandonPlaybackAudioFocus() {
        if (!hasAudioFocus) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            focusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
        } else {
            @Suppress("DEPRECATION")
            audioManager.abandonAudioFocus(audioFocusChangeListener)
        }
        hasAudioFocus = false
    }

    private fun pauseAllWebMedia() {
        val js = "document.querySelectorAll('video,audio').forEach(function(m){ if(!m.paused){ m.dataset.sieutocAutoPaused='1'; m.pause(); } });"
        tabs.forEach { it.webView.evaluateJavascript(js, null) }
    }

    private fun resumeAllWebMedia() {
        val js = "document.querySelectorAll('video,audio').forEach(function(m){ if(m.dataset.sieutocAutoPaused==='1'){ delete m.dataset.sieutocAutoPaused; m.play().catch(function(){}); } });"
        tabs.forEach { it.webView.evaluateJavascript(js, null) }
    }

    // Wake lock CPU (không phải màn hình) để khi người dùng tắt màn hình lúc đang nghe/xem,
    // hệ thống không đưa tiến trình vào chế độ nghỉ sâu (Doze) làm âm thanh bị khựng/ngắt giữa chừng.
    // Có mốc thời gian an toàn 6 tiếng phòng trường hợp sự kiện pause/ended không bắn về được,
    // để không vô tình giữ CPU thức mãi mãi gây tốn pin.
    private fun acquireMediaWakeLock() {
        if (mediaWakeLock == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            mediaWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SieuToc:MediaPlayback").apply {
                setReferenceCounted(false)
            }
        }
        mediaWakeLock?.let { if (!it.isHeld) it.acquire(6 * 60 * 60 * 1000L) }
    }

    private fun releaseMediaWakeLock() {
        mediaWakeLock?.let { if (it.isHeld) it.release() }
    }

    private fun attachClients(tab: Tab) {
        val webView = tab.webView
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (tab === currentTab) {
                    progressBar.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                    progressBar.progress = newProgress
                }
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                tab.title = if (title.isNullOrBlank()) "Tab mới" else title
                refreshTabStrip()
            }

            override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                if (view == null) return
                if (customView != null) {
                    callback?.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback
                fullscreenContainer.addView(
                    view,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
                fullscreenContainer.visibility = View.VISIBLE
                rootUiLayout.visibility = View.GONE
                enterImmersiveMode()
                // Chống tắt màn hình và giữ hardware acceleration khi phát video
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }

            override fun onHideCustomView() {
                val view = customView ?: return
                fullscreenContainer.removeView(view)
                fullscreenContainer.visibility = View.GONE
                rootUiLayout.visibility = View.VISIBLE
                customView = null
                customViewCallback?.onCustomViewHidden()
                customViewCallback = null
                exitImmersiveMode()
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }

            // Nhiều trang video (YouTube, TikTok, Facebook...) cần quyền phát nội dung có DRM
            // (Widevine) mới chạy được; WebChromeClient mặc định từ chối MỌI permission request,
            // khiến video load mãi không lên. Chỉ tự cấp đúng quyền DRM, các quyền nhạy cảm khác
            // (camera, mic, vị trí...) vẫn bị từ chối để giữ đúng tinh thần riêng tư của app.
            override fun onPermissionRequest(request: PermissionRequest?) {
                request ?: return
                val grantable = request.resources.filter { it == PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID }
                if (grantable.isNotEmpty()) {
                    request.grant(grantable.toTypedArray())
                } else {
                    request.deny()
                }
            }

            // Chặn popup quảng cáo: popup do JS tự mở (không phải người dùng bấm) khi đang bật
            // "Chặn quảng cáo / theo dõi" thì từ chối luôn. Popup do người dùng chủ động bấm
            // (link target="_blank", nút "mở tab mới" của trình phát video...) vẫn mở bình thường
            // ở 1 tab mới của app.
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: Message?
            ): Boolean {
                if (!isUserGesture && isTrackerBlockEnabled()) return false

                val newWebView = createWebView(tab.isIncognito)
                registerNewTab(newWebView, tab.isIncognito)
                switchTab(tabs.size - 1)

                val transport = resultMsg?.obj as? WebView.WebViewTransport ?: return false
                transport.webView = newWebView
                resultMsg.sendToTarget()
                return true
            }

            // JS gọi window.close() trên popup (vd popup đăng nhập tự đóng sau khi xong) => đóng đúng tab đó
            override fun onCloseWindow(window: WebView?) {
                val idx = tabs.indexOfFirst { it.webView === window }
                if (idx >= 0) closeTab(idx)
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val url = request?.url?.toString() ?: return super.shouldInterceptRequest(view, request)
                if (isBlocked(url)) {
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (tab === currentTab) {
                    addressBar.setText(url ?: "")
                    updateBookmarkIcon(url, tab.isIncognito)
                }
                if (!tab.isIncognito) persistSession()
                // Trang mới (kể cả sau reload) mất mọi listener JS cũ -> gắn lại hook theo dõi phát/dừng
                view?.evaluateJavascript(mediaHookScript, null)
            }
        }
    }

    private fun addTab(incognito: Boolean, url: String?) {
        val webView = createWebView(incognito)
        registerNewTab(webView, incognito)
        webView.loadUrl(url ?: homeUrl)
        switchTab(tabs.size - 1)
    }

    // Đăng ký 1 WebView đã tạo sẵn thành 1 tab mới (thêm vào danh sách, gắn client, dựng UI thanh tab).
    // Không tự loadUrl/switchTab - việc đó do nơi gọi quyết định (addTab load URL trực tiếp,
    // onCreateWindow để chính WebView mới tự load URL đích qua cơ chế transport của WebView).
    private fun registerNewTab(webView: WebView, incognito: Boolean): Tab {
        val tab = Tab(webView, incognito)
        attachClients(tab)
        tabs.add(tab)
        webViewContainer.addView(webView)

        val tabView = LayoutInflater.from(this).inflate(R.layout.item_tab, tabsLayout, false)
        tabsLayout.addView(tabView)
        tabViews.add(tabView)
        val index = tabs.size - 1

        tabView.findViewById<TextView>(R.id.tabTitle).apply {
            text = if (incognito) "🕶 Ẩn danh" else "Tab mới"
            if (incognito) setTextColor(0xFFFFFFFF.toInt())
        }
        if (incognito) tabView.setBackgroundColor(0xFF333333.toInt())

        tabView.setOnClickListener { switchTab(index) }
        tabView.findViewById<ImageButton>(R.id.tabClose).setOnClickListener { closeTab(index) }
        return tab
    }

    private fun switchTab(index: Int) {
        if (index !in tabs.indices) return
        currentTabIndex = index
        tabs.forEachIndexed { i, tab -> tab.webView.visibility = if (i == index) View.VISIBLE else View.GONE }
        tabViews.forEachIndexed { i, v -> v.isSelected = (i == index) }
        val tab = tabs[index]
        addressBar.setText(tab.webView.url ?: "")
        progressBar.visibility = View.GONE
        updateBookmarkIcon(tab.webView.url, tab.isIncognito)
    }

    private fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        val tab = tabs[index]
        val activeTabBeforeClose = currentTab // nhớ tab đang xem trước khi đóng, để không bị nhảy lung tung

        // Ẩn danh: xoá sạch dữ liệu của tab này khi đóng
        if (tab.isIncognito) {
            tab.webView.clearHistory()
            tab.webView.clearCache(true)
            tab.webView.clearFormData()
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
            WebStorage.getInstance().deleteAllData()
        }
        tab.webView.destroy()
        webViewContainer.removeView(tab.webView)
        tabsLayout.removeView(tabViews[index])
        tabs.removeAt(index)
        tabViews.removeAt(index)

        if (tabs.isEmpty()) {
            addTab(incognito = false, url = homeUrl)
            return
        }

        // Cập nhật listener của các tab còn lại vì index đã lệch
        rebindTabListeners()

        val newIndex = if (tab === activeTabBeforeClose) {
            // Đóng đúng tab đang xem: lùi về tab liền trước, kiểu hành vi trình duyệt thường thấy
            (index - 1).coerceAtLeast(0)
        } else {
            // Đóng 1 tab khác: phải giữ nguyên tab đang xem (chỉ index của nó có thể bị lệch đi)
            val shiftedIndex = tabs.indexOf(activeTabBeforeClose)
            if (shiftedIndex >= 0) shiftedIndex else (index - 1).coerceAtLeast(0)
        }
        switchTab(newIndex.coerceAtMost(tabs.size - 1))
        persistSession()
    }

    private fun rebindTabListeners() {
        tabViews.forEachIndexed { i, v ->
            v.setOnClickListener { switchTab(i) }
            v.findViewById<ImageButton>(R.id.tabClose).setOnClickListener { closeTab(i) }
        }
    }

    private fun refreshTabStrip() {
        tabs.forEachIndexed { i, tab ->
            val view = tabViews.getOrNull(i) ?: return@forEachIndexed
            val label = if (tab.isIncognito) "🕶 " + shortTitle(tab.title) else shortTitle(tab.title)
            view.findViewById<TextView>(R.id.tabTitle).text = label
        }
    }

    private fun shortTitle(title: String): String =
        if (title.length > 14) title.take(14) + "…" else title

    @Suppress("DEPRECATION")
    private fun enterImmersiveMode() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
    }

    @Suppress("DEPRECATION")
    private fun exitImmersiveMode() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }

    // ---------------- Điều hướng & thanh công cụ ----------------

    private fun navigateTo(input: String) {
        val query = input.trim()
        if (query.isEmpty()) return

        val url = when {
            Patterns.WEB_URL.matcher(query).matches() && !query.contains(" ") -> {
                if (query.startsWith("http://") || query.startsWith("https://")) query
                else "https://$query"
            }
            query.contains(".") && !query.contains(" ") -> "https://$query"
            else -> "https://www.google.com/search?q=" + Uri.encode(query)
        }
        currentTab?.webView?.loadUrl(url)
        currentFocus?.let {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
            imm.hideSoftInputFromWindow(it.windowToken, 0)
        }
    }

    private fun setupToolbar() {
        addressBar.setOnEditorActionListener { _, actionId, event ->
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_GO ||
                (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            ) {
                navigateTo(addressBar.text.toString())
                true
            } else {
                false
            }
        }

        findViewById<ImageButton>(R.id.btnBack).setOnClickListener {
            currentTab?.webView?.let { if (it.canGoBack()) it.goBack() }
        }
        findViewById<ImageButton>(R.id.btnForward).setOnClickListener {
            currentTab?.webView?.let { if (it.canGoForward()) it.goForward() }
        }
        btnBookmark.setOnClickListener { toggleBookmark() }
        findViewById<ImageButton>(R.id.btnMenu).setOnClickListener { view -> showMenu(view) }

        findViewById<ImageButton>(R.id.btnNewTab).setOnClickListener {
            addTab(incognito = incognitoModeArmed, url = homeUrl)
        }
        btnIncognito.setOnClickListener {
            incognitoModeArmed = !incognitoModeArmed
            val msg = if (incognitoModeArmed) "Tab mới tiếp theo sẽ là ẩn danh" else "Đã tắt chế độ ẩn danh cho tab mới"
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
            btnIncognito.alpha = if (incognitoModeArmed) 1.0f else 0.5f
        }
    }

    private fun toggleBookmark() {
        val tab = currentTab ?: return
        if (tab.isIncognito) {
            Toast.makeText(this, "Không thể đánh dấu ở chế độ ẩn danh", Toast.LENGTH_SHORT).show()
            return
        }
        val url = tab.webView.url ?: return
        val bookmarks = prefs.getStringSet("bookmarks", mutableSetOf())!!.toMutableSet()
        if (bookmarks.contains(url)) {
            bookmarks.remove(url)
            Toast.makeText(this, "Đã bỏ đánh dấu", Toast.LENGTH_SHORT).show()
        } else {
            bookmarks.add(url)
            Toast.makeText(this, "Đã đánh dấu trang", Toast.LENGTH_SHORT).show()
        }
        prefs.edit().putStringSet("bookmarks", bookmarks).apply()
        updateBookmarkIcon(url, false)
    }

    private fun updateBookmarkIcon(url: String?, isIncognito: Boolean) {
        if (isIncognito) {
            btnBookmark.setImageResource(android.R.drawable.star_off)
            btnBookmark.alpha = 0.4f
            return
        }
        btnBookmark.alpha = 1.0f
        val bookmarks = prefs.getStringSet("bookmarks", mutableSetOf())!!
        val isBookmarked = url != null && bookmarks.contains(url)
        btnBookmark.setImageResource(
            if (isBookmarked) android.R.drawable.star_on else android.R.drawable.star_off
        )
    }

    private fun showMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add(0, 1, 0, "Trang chủ")
        popup.menu.add(0, 2, 1, "Danh sách đánh dấu")
        popup.menu.add(0, 5, 2, if (isCurrentPageTranslated()) "Xem bản gốc" else "Dịch trang")
        popup.menu.add(0, 6, 3, "Ngôn ngữ dịch (${translateLangLabel()})")
        popup.menu.add(0, 3, 4, "Xóa dữ liệu duyệt web")
        popup.menu.add(0, 4, 5, "Cài đặt")
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> { currentTab?.webView?.loadUrl(homeUrl); true }
                2 -> { showBookmarks(); true }
                3 -> { clearBrowsingData(); true }
                4 -> { showSettingsDialog(); true }
                5 -> { translateCurrentPage(); true }
                6 -> { showTranslateLanguageDialog(); true }
                else -> false
            }
        }
        popup.show()
    }

    // ---------------- Dịch trang ----------------

    // Danh sách ngôn ngữ dịch hỗ trợ sẵn (mã ngôn ngữ Google Translate, tên hiển thị)
    private val translateLanguages = listOf(
        "vi" to "Tiếng Việt",
        "en" to "English",
        "zh-CN" to "中文 (Giản thể)",
        "ja" to "日本語",
        "ko" to "한국어",
        "fr" to "Français",
        "es" to "Español",
        "de" to "Deutsch",
        "th" to "ภาษาไทย"
    )

    private fun targetLang(): String = prefs.getString("pref_translate_lang", "vi") ?: "vi"

    private fun translateLangLabel(): String =
        translateLanguages.firstOrNull { it.first == targetLang() }?.second ?: targetLang()

    private fun showTranslateLanguageDialog() {
        val labels = translateLanguages.map { it.second }.toTypedArray()
        val currentIndex = translateLanguages.indexOfFirst { it.first == targetLang() }.coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Ngôn ngữ dịch")
            .setSingleChoiceItems(labels, currentIndex) { dialog, which ->
                val lang = translateLanguages[which].first
                prefs.edit().putString("pref_translate_lang", lang).apply()
                Toast.makeText(this, "Đã đặt ngôn ngữ dịch: ${translateLanguages[which].second}", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
                reapplyTranslationIfActive(lang) // nếu đang xem bản dịch, dịch lại ngay bằng ngôn ngữ mới
            }
            .setNegativeButton("Đóng", null)
            .show()
    }

    // Nếu trang hiện tại đang là bản dịch, tải lại bằng ngôn ngữ mới thay vì bắt người dùng
    // tự bấm "Xem bản gốc" rồi "Dịch trang" lại
    private fun reapplyTranslationIfActive(newLang: String) {
        val tab = currentTab ?: return
        val url = tab.webView.url ?: return
        if (!isTranslatedUrl(url)) return
        val original = originalUrlFromTranslated(url) ?: return
        val target = buildTranslateUrl(original, newLang) ?: return
        tab.webView.loadUrl(target)
    }

    private fun isTranslatedUrl(url: String): Boolean =
        Uri.parse(url).host?.endsWith(".translate.goog") == true

    private fun isCurrentPageTranslated(): Boolean {
        val url = currentTab?.webView?.url ?: return false
        return isTranslatedUrl(url)
    }

    // Chuyển URL gốc thành URL dịch qua proxy translate.goog của Google
    // (vd "example.com" -> "example-com.translate.goog", ký tự "-" gốc được nhân đôi để không lẫn với "." đã đổi)
    // Trả về null nếu URL không có host hợp lệ để dịch (about:blank, data:, IP nội bộ, localhost...)
    private fun buildTranslateUrl(url: String, targetLang: String): String? {
        val uri = Uri.parse(url)
        val host = uri.host?.lowercase() ?: return null
        if (host == "localhost" || Patterns.IP_ADDRESS.matcher(host).matches()) return null
        val encodedHost = host.replace("-", "--").replace(".", "-") + ".translate.goog"
        val builder = Uri.Builder()
            .scheme(uri.scheme ?: "https")
            .encodedAuthority(encodedHost)
            .encodedPath(uri.encodedPath ?: "/")
        uri.encodedQuery?.let { builder.encodedQuery(it) }
        builder.appendQueryParameter("_x_tr_sl", "auto")
        builder.appendQueryParameter("_x_tr_tl", targetLang)
        builder.appendQueryParameter("_x_tr_hl", targetLang)
        builder.appendQueryParameter("_x_tr_pto", "wapp")
        return builder.build().toString()
    }

    // Chiều ngược lại: từ URL dịch suy ra URL gốc, để bấm "Xem bản gốc" quay về đúng trang
    private fun originalUrlFromTranslated(url: String): String? {
        val uri = Uri.parse(url)
        val host = uri.host ?: return null
        if (!host.endsWith(".translate.goog")) return null
        val encodedHost = host.removeSuffix(".translate.goog")
        val originalHost = encodedHost
            .replace("--", "\u0000")
            .replace("-", ".")
            .replace("\u0000", "-")
        if (originalHost.isBlank()) return null

        val builder = Uri.Builder()
            .scheme(uri.scheme ?: "https")
            .encodedAuthority(originalHost)
            .encodedPath(uri.encodedPath ?: "/")
        uri.queryParameterNames
            .filterNot { it.startsWith("_x_tr_") }
            .forEach { name -> uri.getQueryParameter(name)?.let { builder.appendQueryParameter(name, it) } }
        return builder.build().toString()
    }

    private fun translateCurrentPage() {
        val tab = currentTab ?: return
        val url = tab.webView.url
        if (url.isNullOrBlank()) {
            Toast.makeText(this, "Chưa có trang để dịch", Toast.LENGTH_SHORT).show()
            return
        }
        val target = if (isTranslatedUrl(url)) {
            originalUrlFromTranslated(url)
        } else {
            buildTranslateUrl(url, targetLang())
        }
        if (target == null) {
            Toast.makeText(this, "Không dịch được trang này", Toast.LENGTH_SHORT).show()
            return
        }
        tab.webView.loadUrl(target)
    }

    private fun showBookmarks() {
        val bookmarks = prefs.getStringSet("bookmarks", mutableSetOf())!!.toList()
        if (bookmarks.isEmpty()) {
            Toast.makeText(this, "Chưa có trang nào được đánh dấu", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Đánh dấu")
            .setItems(bookmarks.toTypedArray()) { _, which ->
                currentTab?.webView?.loadUrl(bookmarks[which])
            }
            .setNegativeButton("Đóng", null)
            .create()
            .show()
    }

    private fun showSettingsDialog() {
        val options = arrayOf("Bật JavaScript", "Chặn quảng cáo / theo dõi / popup")
        val checked = booleanArrayOf(isJsEnabled(), isTrackerBlockEnabled())

        AlertDialog.Builder(this)
            .setTitle("Cài đặt")
            .setMultiChoiceItems(options, checked) { _, which, isChecked ->
                checked[which] = isChecked
            }
            .setPositiveButton("Áp dụng") { _, _ ->
                applySettings(jsEnabled = checked[0], trackerBlockEnabled = checked[1])
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun applySettings(jsEnabled: Boolean, trackerBlockEnabled: Boolean) {
        prefs.edit()
            .putBoolean("pref_js_enabled", jsEnabled)
            .putBoolean("pref_block_tracker", trackerBlockEnabled)
            .apply()

        // Áp dụng ngay cho mọi tab đang mở, không cần khởi động lại app
        tabs.forEach { tab -> tab.webView.settings.javaScriptEnabled = jsEnabled }

        Toast.makeText(this, "Đã lưu cài đặt, đang tải lại trang hiện tại", Toast.LENGTH_SHORT).show()
        currentTab?.webView?.reload()
    }

    private fun clearBrowsingData() {
        tabs.forEach { tab ->
            tab.webView.clearHistory()
            tab.webView.clearCache(true)
            tab.webView.clearFormData()
        }
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
        prefs.edit().remove("tab_urls").apply()
        Toast.makeText(this, "Đã xóa toàn bộ dữ liệu duyệt web trên máy", Toast.LENGTH_SHORT).show()
    }

    override fun onBackPressed() {
        if (customView != null) {
            customViewCallback?.onCustomViewHidden()
            return
        }
        val webView = currentTab?.webView
        when {
            webView != null && webView.canGoBack() -> webView.goBack()
            tabs.size > 1 -> closeTab(currentTabIndex)
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() {
        // Dọn sạch mọi tab ẩn danh còn mở khi thoát app
        tabs.filter { it.isIncognito }.forEach {
            it.webView.clearHistory()
            it.webView.clearCache(true)
        }
        if (tabs.any { it.isIncognito }) {
            WebStorage.getInstance().deleteAllData()
        }
        // Nhả AudioFocus và wake lock để không ảnh hưởng tới app khác (vd Zoom) sau khi thoát
        releaseMediaWakeLock()
        abandonPlaybackAudioFocus()
        super.onDestroy()
    }
}
