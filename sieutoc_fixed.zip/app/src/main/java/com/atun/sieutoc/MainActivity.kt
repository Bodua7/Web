package com.atun.sieutoc

import android.content.Intent
import android.os.Bundle

// Trình duyệt "thường" - toàn bộ tab ở đây LUÔN là tab thường, không bao giờ trộn tab ẩn danh
// (chế độ ẩn danh giờ chạy ở IncognitoActivity, 1 Activity/process hoàn toàn riêng - xem
// BrowserActivity.kt và AndroidManifest.xml để biết vì sao).
class MainActivity : BrowserActivity() {

    override val isIncognitoActivity: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleViewIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleViewIntent(intent)
    }

    // Xử lý link mở từ app khác (share/"Mở bằng Siêu Tốc") - launchMode singleTask nên phải
    // bắt cả onCreate (lần mở đầu) lẫn onNewIntent (app đã chạy sẵn)
    private fun handleViewIntent(intent: Intent?) {
        if (intent?.action != Intent.ACTION_VIEW) return
        val url = intent.data?.toString() ?: return
        addTab(url)
    }

    // Nạp lại các tab đã lưu từ lần mở trước; nếu chưa có gì thì mở 1 tab trang chủ
    override fun restoreSession() {
        val savedUrls = prefs.getString("tab_urls", null)
            ?.split("\n")
            ?.filter { it.isNotBlank() }
        if (savedUrls.isNullOrEmpty()) {
            addTab(homeUrl)
        } else {
            savedUrls.forEach { addTab(it) }
            // addTab() ở trên đã tự switchTab() sang tab cuối cùng mỗi lần gọi; sau khi nạp xong
            // toàn bộ, quay lại đúng tab đầu tiên cho giống trạng thái trước khi thoát app
            switchTab(0)
        }
    }

    override fun persistSession() {
        val urls = tabs.map { it.webView.url ?: homeUrl }
        prefs.edit().putString("tab_urls", urls.joinToString("\n")).apply()
    }

    override fun onNewTabButtonClicked() {
        addTab(homeUrl)
    }

    // Mở phiên ẩn danh: 1 Activity riêng, chạy ở process riêng - xem IncognitoActivity
    override fun onIncognitoButtonClicked() {
        startActivity(Intent(this, IncognitoActivity::class.java))
    }
}
