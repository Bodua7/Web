# Siêu Tốc — Trình duyệt Android không theo dõi

## Tính năng
- WebView tốc độ cao (loadWithOverviewMode, cacheMode mặc định của hệ thống)
- Chặn ~60 domain quảng cáo/tracker phổ biến ngay ở tầng shouldInterceptRequest
  (Google Ads, Facebook Pixel, AppsFlyer, Crashlytics, TikTok Ads, v.v.) —
  danh sách ở app/src/main/assets/blocklist.txt, tự thêm domain nếu muốn
- **Chặn popup quảng cáo**: popup do JS tự mở (không phải người dùng bấm) bị chặn khi
  "Chặn quảng cáo / theo dõi" đang bật ở Cài đặt; popup do người dùng chủ động bấm
  (link mở tab mới, nút "mở tab mới" của trình phát video...) vẫn mở bình thường
- Chặn cookie bên thứ 3 (giữ cookie bên thứ nhất để vẫn đăng nhập được)
- Không tích hợp bất kỳ SDK phân tích/quảng cáo nào — chỉ 1 quyền INTERNET
- Đánh dấu trang, lịch sử phiên gần nhất, xóa toàn bộ dữ liệu duyệt web 1 chạm
- Tìm kiếm mặc định qua DuckDuckGo (không theo dõi)
- **Đa tab**: nút "+" mở tab mới, bấm tab trên thanh để chuyển, "×" để đóng
- **Chế độ ẩn danh**: bấm icon kính râm để bật/tắt trước khi mở tab mới —
  tab ẩn danh không lưu localStorage, không lưu vào phiên khôi phục lúc mở lại app,
  không cho bookmark, và tự xóa cache/cookie/localStorage khi đóng tab hoặc thoát app
  (lưu ý: CookieManager của Android WebView dùng chung 1 kho cookie toàn app,
  nên lúc đóng tab ẩn danh sẽ xóa luôn cookie — chấp nhận được cho bản hobby,
  nếu cần cách ly cookie tuyệt đối giữa các tab thì phải tách process riêng, phức tạp hơn nhiều)

## Build qua GitHub Actions
1. Tạo repo mới, upload toàn bộ zip này — **có thể để nguyên file `.zip` ở gốc repo,
   không cần tự giải nén**: workflow sẽ tự phát hiện và giải nén nếu chưa thấy
   `settings.gradle` ở gốc repo (nếu bạn quen giải nén sẵn rồi upload từng file thì cũng
   chạy bình thường, workflow tự bỏ qua bước giải nén khi đã thấy `settings.gradle`)
2. Push lên nhánh `main` hoặc chạy tay bằng "Run workflow" (workflow_dispatch)
3. Tải APK debug ở tab Actions > Artifacts > SieuToc-debug-apk

## Đã có
- Đa tab, chế độ ẩn danh
- Menu > Cài đặt: bật/tắt JavaScript, bật/tắt chặn quảng cáo/theo dõi — áp dụng ngay
  cho mọi tab đang mở, không cần khởi động lại app; lưu vào SharedPreferences nên
  giữ nguyên qua các lần mở app sau
- **Xem video mượt**: video HTML5 fullscreen (YouTube, Facebook, TikTok web...) chuyển
  sang toàn màn hình thật (ẩn cả thanh tab, thanh địa chỉ, thanh điều hướng hệ thống),
  tự động chống tắt màn hình trong lúc xem, hardware acceleration bật rõ ràng, xoay màn
  hình không load lại video (configChanges đã xử lý). Bấm Back để thoát fullscreen mà
  không mất trang
- **Dịch trang**: Menu > "Dịch trang" — dịch toàn trang qua proxy translate.goog của
  Google (không cần thêm quyền hay SDK nào), bấm lại thành "Xem bản gốc" để quay về
  trang chưa dịch. Chọn ngôn ngữ đích ở Menu > "Ngôn ngữ dịch" (mặc định Tiếng Việt),
  áp dụng ngay cho lần dịch tiếp theo, lưu qua SharedPreferences nên giữ nguyên qua
  các lần mở app sau
- **Mở link từ app khác**: khai báo intent-filter VIEW cho http/https nên có thể chọn
  "Mở bằng Siêu Tốc" từ app khác (Zalo, Messenger, Gmail...), link sẽ mở ở tab mới

## Ký release build (khuyến nghị — bản debug không tối ưu, và mỗi lần build lại đổi chữ ký làm mất dữ liệu app khi cập nhật)
1. Vào repo trên GitHub > Settings > Secrets and variables > Actions > New repository secret, thêm đúng 3 secret sau (giá trị lấy trong file keystore_secrets.txt mình gửi kèm và file release.keystore.base64):
   - `KEYSTORE_BASE64` → dán toàn bộ nội dung file `release.keystore.base64`
   - `KEYSTORE_PASSWORD` → dán giá trị STOREPASS trong `keystore_secrets.txt`
   - `KEY_ALIAS` → `sieutoc`
   - `KEY_PASSWORD` → dán giá trị KEYPASS trong `keystore_secrets.txt` (thực chất bằng STOREPASS, vì keystore dạng PKCS12 dùng chung 1 mật khẩu)
2. Chạy lại workflow (push hoặc "Run workflow"), sẽ có thêm artifact `SieuToc-release-apk` đã ký sẵn, cài trực tiếp lên máy được, minify bật nên nhẹ hơn bản debug
3. **Giữ kỹ file `release.keystore` và mật khẩu** — mất là không thể phát hành bản cập nhật cùng chữ ký được nữa (Android sẽ bắt gỡ cài đặt cũ trước khi cài bản mới)
4. Không commit `release.keystore` hay `keystore_secrets.txt` vào repo — chỉ dùng để lấy giá trị nhập vào Secrets rồi lưu riêng ở chỗ an toàn (Google Drive riêng tư, password manager...)

## Nâng cấp gợi ý sau này (nói "Vá" hoặc "Tiếp" nếu muốn làm)
- Chặn tracker theo từng site riêng (hiện là cài đặt toàn cục)
