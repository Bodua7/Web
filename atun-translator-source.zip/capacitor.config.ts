import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.atun.translator',
  appName: 'Translator',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
