import { PIPED_INSTANCES, INVIDIOUS_INSTANCES, INSTANCE_TIMEOUT_MS } from '../../config/constants.js';

// Lấy videoId từ URL YouTube (watch?v=, youtu.be/, live/) hoặc trả nguyên nếu đã là ID (11 ký tự)
export function extractVideoId(input) {
  const trimmed = input.trim();
  if (/^[a-zA-Z0-9_-]{11}$/.test(trimmed)) return trimmed;

  try {
    const url = new URL(trimmed);
    if (url.hostname.includes('youtu.be')) {
      return url.pathname.slice(1);
    }
    if (url.searchParams.has('v')) {
      return url.searchParams.get('v');
    }
    const liveMatch = url.pathname.match(/\/live\/([a-zA-Z0-9_-]{11})/);
    if (liveMatch) return liveMatch[1];
  } catch (e) {
    // không phải URL hợp lệ
  }

  throw new Error('Không nhận diện được video ID từ: ' + input);
}

function fetchWithTimeout(url, timeoutMs) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeoutMs);
  return fetch(url, { signal: controller.signal }).finally(() => clearTimeout(id));
}

async function tryPipedInstance(instance, videoId) {
  const res = await fetchWithTimeout(`${instance}/streams/${videoId}`, INSTANCE_TIMEOUT_MS);
  if (!res.ok) throw new Error(`Piped ${instance} HTTP ${res.status}`);
  const data = await res.json();

  if (data.livestream && data.hls) {
    return { url: data.hls, kind: 'hls', title: data.title, source: instance };
  }
  if (Array.isArray(data.audioStreams) && data.audioStreams.length > 0) {
    const best = [...data.audioStreams].sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0))[0];
    return { url: best.url, kind: 'direct', title: data.title, source: instance };
  }
  throw new Error(`Piped ${instance}: không có stream audio khả dụng`);
}

async function tryInvidiousInstance(instance, videoId) {
  const res = await fetchWithTimeout(`${instance}/api/v1/videos/${videoId}`, INSTANCE_TIMEOUT_MS);
  if (!res.ok) throw new Error(`Invidious ${instance} HTTP ${res.status}`);
  const data = await res.json();

  if (data.liveNow && data.hlsUrl) {
    return { url: data.hlsUrl, kind: 'hls', title: data.title, source: instance };
  }
  if (Array.isArray(data.adaptiveFormats)) {
    const audioFormats = data.adaptiveFormats.filter(f => (f.type || '').startsWith('audio/'));
    const best = audioFormats.sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0))[0];
    if (best) return { url: best.url, kind: 'direct', title: data.title, source: instance };
  }
  throw new Error(`Invidious ${instance}: không có stream audio khả dụng`);
}

// Thử lần lượt từng instance Piped rồi tới Invidious, trả về stream đầu tiên lấy được.
// Ném lỗi kèm log chi tiết nếu tất cả instance đều fail (dùng để hiện cho user biết mạng/instance có vấn đề).
export async function getAudioStreamUrl(videoIdOrUrl, onAttempt) {
  const videoId = extractVideoId(videoIdOrUrl);
  const attempts = [];

  for (const instance of PIPED_INSTANCES) {
    try {
      onAttempt?.(`Đang thử Piped: ${instance}`);
      return await tryPipedInstance(instance, videoId);
    } catch (err) {
      attempts.push(`${instance}: ${err.message}`);
    }
  }

  for (const instance of INVIDIOUS_INSTANCES) {
    try {
      onAttempt?.(`Đang thử Invidious: ${instance}`);
      return await tryInvidiousInstance(instance, videoId);
    } catch (err) {
      attempts.push(`${instance}: ${err.message}`);
    }
  }

  throw new Error('Tất cả instance đều fail:\n' + attempts.join('\n'));
}
