// Danh sách các instance công khai của Piped và Invidious.
// Dùng làm nguồn lấy audio stream từ YouTube Live mà không cần API key của Google.
// Instance công khai hay sập/đổi domain -> luôn có fallback nhiều cái, thử lần lượt.

export const PIPED_INSTANCES = [
  'https://pipedapi.kavin.rocks',
  'https://api.piped.yt',
  'https://piped-api.lunar.icu',
  'https://pipedapi.adminforge.de',
  'https://piped-api.privacy.com.de',
];

export const INVIDIOUS_INSTANCES = [
  'https://invidious.nerdvpn.de',
  'https://iv.ggtyler.dev',
  'https://invidious.jing.rocks',
  'https://yewtu.be',
];

// Timeout cho mỗi lần thử 1 instance (ms) - đừng để 1 instance chết kéo chậm cả app
export const INSTANCE_TIMEOUT_MS = 6000;

// Bao nhiêu giây audio buffer trước khi đẩy vào STT (trade-off độ trễ vs độ chính xác)
export const STT_CHUNK_SECONDS = 5;
