package com.atun.translator

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class OverlayView(private val context: Context) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val textView = TextView(context).apply {
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.parseColor("#AA000000"))
        textSize = 18f
        setPadding(20, 10, 20, 10)
        text = "Testing overlay..."
    }

    private val params = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        android.graphics.PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        y = 150
    }

    fun attach() = windowManager.addView(textView, params)
    fun setText(text: String) { textView.text = text }
    fun detach() = windowManager.removeView(textView)
}
