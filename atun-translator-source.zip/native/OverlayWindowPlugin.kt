package com.atun.translator

import android.provider.Settings
import com.getcapacitor.*
import com.getcapacitor.annotation.CapacitorPlugin

@CapacitorPlugin(name = "OverlayPlugin")
class OverlayWindowPlugin : Plugin() {
    private var overlayView: OverlayView? = null

    @PluginMethod
    fun checkPermission(call: PluginCall) {
        val granted = Settings.canDrawOverlays(context)
        val ret = JSObject()
        ret.put("granted", granted)
        call.resolve(ret)
    }

    @PluginMethod
    fun requestPermission(call: PluginCall) {
        val intent = android.content.Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            android.net.Uri.parse("package:${context.packageName}")
        )
        activity.startActivity(intent)
        call.resolve()
    }

    @PluginMethod
    fun show(call: PluginCall) {
        if (overlayView == null) {
            overlayView = OverlayView(context)
            overlayView?.attach()
        }
        call.resolve()
    }

    @PluginMethod
    fun updateText(call: PluginCall) {
        val text = call.getString("text") ?: ""
        overlayView?.setText(text)
        call.resolve()
    }

    @PluginMethod
    fun hide(call: PluginCall) {
        overlayView?.detach()
        overlayView = null
        call.resolve()
    }
}
