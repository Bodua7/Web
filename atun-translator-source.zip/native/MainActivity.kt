package com.atun.translator

import android.os.Bundle
import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        registerPlugin(OverlayWindowPlugin::class.java)
        super.onCreate(savedInstanceState)
    }
}
