package com.atun.translator

import android.os.Bundle
import com.getcapacitor.BridgeActivity
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installCrashLogger()
        registerPlugin(OverlayWindowPlugin::class.java)
        super.onCreate(savedInstanceState)
    }

    private fun installCrashLogger() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))

                val dir = getExternalFilesDir(null)
                if (dir != null) {
                    val file = File(dir, "crash_log.txt")
                    file.appendText(
                        "\n===== CRASH " + java.util.Date().toString() + " =====\n" +
                            "Thread: " + thread.name + "\n" +
                            sw.toString() + "\n"
                    )
                }
            } catch (e: Exception) {
                // Nếu chính việc ghi log bị lỗi thì bỏ qua, không được crash thêm lần nữa ở đây
            }
            // Vẫn gọi handler mặc định để hệ thống xử lý crash (đóng app) như bình thường
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }
}
